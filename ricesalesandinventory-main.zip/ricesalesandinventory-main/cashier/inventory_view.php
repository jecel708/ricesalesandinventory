<?php
session_start();
if(!isset($_SESSION['user_id'])){
  header("Location: ../login.php");
  exit;
}
if(strtolower($_SESSION['role'] ?? '') !== 'cashier'){
  header("Location: ../login.php");
  exit;
}

$username = $_SESSION['username'] ?? 'Cashier';
include '../config/db.php';

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
/* =========================
   LOAD GLOBAL STOCK SETTINGS
========================= */

$DEFAULT_LOW  = 10;
$DEFAULT_OVER = 1000;

$LOW_STOCK_KG  = $DEFAULT_LOW;
$OVER_STOCK_KG = $DEFAULT_OVER;

$settingsRes = $conn->query("
    SELECT low_threshold_kg, over_threshold_kg
    FROM stock_settings
    WHERE id = 1
    LIMIT 1
");

if($settingsRes && $row = $settingsRes->fetch_assoc()){
    $LOW_STOCK_KG  = (float)$row['low_threshold_kg'];
    $OVER_STOCK_KG = (float)$row['over_threshold_kg'];
}

// Fetch products with computed stock (no SKU / no unit_price)
$sql = "
SELECT
  p.product_id,
  p.variety,
  p.grade,
  p.unit_weight_kg,
  p.price_per_kg,
  p.price_per_sack,
  p.sell_price_per_sack,
  IFNULL(SUM(
    CASE
      WHEN LOWER(it.type)='in' THEN it.qty_kg
      WHEN LOWER(it.type)='out' THEN -it.qty_kg
      WHEN LOWER(it.type)='adjust' THEN it.qty_kg
      ELSE 0
    END
  ),0) AS stock_kg
FROM products p
LEFT JOIN inventory_transactions it ON it.product_id = p.product_id
WHERE p.archived = 0
GROUP BY p.product_id
ORDER BY stock_kg ASC, p.variety ASC, p.grade ASC
";
$result = $conn->query($sql);
if(!$result){
  die("Query Error: " . $conn->error);
}

$products = [];
$searchSuggestions = [];
$summary = [
  'total' => 0,
  'available' => 0,
  'low' => 0,
  'out' => 0,
];
while($row = $result->fetch_assoc()){
  $stock = (float)($row['stock_kg'] ?? 0);
  $isLow = ($stock > 0 && $stock <= $LOW_STOCK_KG);
  $isOver = ($stock >= $OVER_STOCK_KG);
  $variety = trim((string)($row['variety'] ?? ''));
  $grade = trim((string)($row['grade'] ?? ''));
  $searchValue = trim($variety.' '.$grade);
  if($searchValue !== ''){
    $searchSuggestions[$searchValue] = trim($variety.' - '.$grade);
  }

  $row['_status'] = $stock <= 0 ? 'out' : ($isOver ? 'over' : ($isLow ? 'low' : 'available'));
  $summary['total']++;
  if($row['_status'] === 'available' || $row['_status'] === 'over') $summary['available']++;
  if($row['_status'] === 'low') $summary['low']++;
  if($row['_status'] === 'out') $summary['out']++;
  $products[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Stocks View | Cashier</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="../css/layout.css" rel="stylesheet">
<link href="../css/cashier-inventory-view.css?v=stock-view-1" rel="stylesheet">
<link href="../css/cashier-mobile.css" rel="stylesheet">
</head>

<body>

<?php
$profileLink = 'cashier_profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>

<div class="container-fluid">
  <div class="row">

    <?php include '../includes/cashier_sidebar.php'; ?>

    <!-- MAIN CONTENT -->
<main class="col-lg-10 ms-sm-auto px-4 main-content">
<div class="py-4">

<!-- HEADER -->
<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
  <div>
    <h3 class="fw-bold mb-1">Stocks View</h3>
    <div class="text-muted">Read-only stock and price reference for cashier sales.</div>
  </div>
</div>

<div class="stock-summary-grid mt-3">
  <div class="stock-summary-card">
    <div class="summary-label">Products</div>
    <div class="summary-value"><?= number_format((int)$summary['total']) ?></div>
  </div>
  <div class="stock-summary-card">
    <div class="summary-label">Available</div>
    <div class="summary-value text-success"><?= number_format((int)$summary['available']) ?></div>
  </div>
  <div class="stock-summary-card">
    <div class="summary-label">Low Stock</div>
    <div class="summary-value text-warning"><?= number_format((int)$summary['low']) ?></div>
  </div>
  <div class="stock-summary-card">
    <div class="summary-label">Out of Stock</div>
    <div class="summary-value text-danger"><?= number_format((int)$summary['out']) ?></div>
  </div>
</div>

<!-- CARD -->
<div class="card modern-card mt-3">
<div class="card-body">
<div class="stock-toolbar mb-3">
  <div>
    <label class="form-label mb-1" for="stockSearch">Search</label>
    <input class="form-control" id="stockSearch" list="stockSearchSuggestions" placeholder="Search variety or grade" autocomplete="off">
    <datalist id="stockSearchSuggestions">
      <?php foreach($searchSuggestions as $value => $label): ?>
        <option value="<?= h($value) ?>" label="<?= h($label) ?>"></option>
      <?php endforeach; ?>
    </datalist>
  </div>
  <div>
    <label class="form-label mb-1" for="stockStatusFilter">Status</label>
    <select class="form-select" id="stockStatusFilter">
      <option value="all">All</option>
      <option value="available">Available</option>
      <option value="low">Low</option>
      <option value="out">Out of Stock</option>
      <option value="over">Overstock</option>
    </select>
  </div>
  <div class="threshold-note">
    Low ≤ <?= number_format($LOW_STOCK_KG,2) ?> kg
    <span>Over ≥ <?= number_format($OVER_STOCK_KG,2) ?> kg</span>
  </div>
</div>

<div class="table-responsive">
<table class="table table-striped align-middle mb-0 stock-table" id="stockTable">
<thead class="table-dark">
<tr>
<th>Product</th>
<th class="text-end">Stock (kg)</th>
<th class="text-end">Sacks Left</th>
<th class="text-end">Sell / Kg</th>
<th class="text-end">Sell / Sack</th>
<th>Status</th>
</tr>
</thead>
<tbody>

                <?php if(count($products) > 0): ?>
                  <?php foreach($products as $row):
                    $stock = (float)($row['stock_kg'] ?? 0);
                    $w     = (float)($row['unit_weight_kg'] ?? 0);
                    $pKg   = (float)($row['price_per_kg'] ?? 0);
                    $pSack = (float)($row['sell_price_per_sack'] ?? 0);
                    $statusKey = (string)($row['_status'] ?? 'available');

                    $isLow  = ($stock > 0 && $stock <= $LOW_STOCK_KG);
                    $isOver = ($stock >= $OVER_STOCK_KG);

$fullSacks = ($w > 0) ? floor($stock / $w) : 0;
$looseKg = ($w > 0) ? max(0, $stock - ($fullSacks * $w)) : 0;

// Status badge
if($stock <= 0){
    $badge = "<span class='badge bg-secondary'>Out of Stock</span>";
    $rowClass = "table-secondary";

} elseif($isOver){
    $badge = "<span class='badge bg-danger'>Overstock</span>";
    $rowClass = "table-danger";

} elseif($isLow){
    $badge = "<span class='badge bg-warning text-dark'>Low</span>";
    $rowClass = "table-warning";

} else {
    $badge = "<span class='badge bg-success'>Available</span>";
    $rowClass = "";
}
?>
                    <tr class="<?= $rowClass ?>" data-status="<?= h($statusKey) ?>" data-search="<?= h(strtolower(($row['variety'] ?? '').' '.($row['grade'] ?? ''))) ?>">
                      <td class="fw-semibold">
                        <?= h(($row['variety'] ?? '').' - '.($row['grade'] ?? '')) ?>
                        <?php if($w > 0): ?>
                          <div class="text-muted small">Sack size: <?= number_format($w,0) ?> kg</div>
                        <?php else: ?>
                          <div class="text-muted small">Sack size: —</div>
                        <?php endif; ?>
                      </td>

                      <td class="text-end fw-bold"><?= number_format($stock,2) ?></td>

                      <td class="text-end">
                        <?php if($w > 0): ?>
                          <strong><?= number_format($fullSacks,0) ?></strong>
                          <?php if($looseKg > 0.004): ?>
                            <div class="small text-muted">+ <?= number_format($looseKg,2) ?> kg loose</div>
                          <?php endif; ?>
                        <?php else: ?>
                          —
                        <?php endif; ?>
                      </td>

                      <td class="text-end">
                        <?php if($pKg > 0): ?>
                          ₱<?= number_format($pKg,2) ?>
                        <?php else: ?>
                          <span class="text-muted">0.00</span>
                        <?php endif; ?>
                      </td>

                      <td class="text-end">
                        <?php if($pSack > 0): ?>
                          ₱<?= number_format($pSack,2) ?>
                        <?php else: ?>
                          <span class="text-muted">0.00</span>
                        <?php endif; ?>
                      </td>

                      <td><?= $badge ?></td>
                    </tr>
                  <?php endforeach; ?>
                <?php else: ?>
                  <tr><td colspan="6" class="text-center text-muted">No products found.</td></tr>
                <?php endif; ?>
                  <tr id="stockNoResults" class="d-none"><td colspan="6" class="text-center text-muted">No matching products found.</td></tr>

                </tbody>
              </table>
            </div>

            <div class="text-muted small mt-2">
              Low stock threshold: <?= number_format($LOW_STOCK_KG,2) ?> kg
              <span class="mx-1">•</span>
              “Sacks Left” is computed from current stock and product sack size.
            </div>

          </div>
        </div>

      </div>
    </main>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(() => {
  const search = document.getElementById('stockSearch');
  const status = document.getElementById('stockStatusFilter');

  function applyFilters(){
    const q = (search?.value || '').toLowerCase().trim();
    const st = status?.value || 'all';
    const rows = Array.from(document.querySelectorAll('#stockTable tbody tr[data-status]'));
    const empty = document.getElementById('stockNoResults');
    let visible = 0;
    rows.forEach((row) => {
      const matchesText = q === '' || (row.dataset.search || '').includes(q);
      const matchesStatus = st === 'all' || row.dataset.status === st;
      const show = matchesText && matchesStatus;
      row.classList.toggle('d-none', !show);
      if(show) visible++;
    });
    if(empty) empty.classList.toggle('d-none', visible !== 0);
  }

  search?.addEventListener('input', applyFilters);
  status?.addEventListener('change', applyFilters);
})();
</script>
<script>
(function () {
  const pollIntervalMs = 5000;
  let pollingInFlight = false;
  async function pollLiveMain() {
    if (pollingInFlight) return;
    pollingInFlight = true;
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('_live', Date.now().toString());
      const response = await fetch(url.toString(), { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const sourceMain = doc.querySelector('main');
      const targetMain = document.querySelector('main');
      if (sourceMain && targetMain) {
        ['.stock-summary-grid', '#stockTable tbody', '#stockSearchSuggestions'].forEach((selector) => {
          const source = sourceMain.querySelector(selector);
          const target = targetMain.querySelector(selector);
          if (source && target) target.innerHTML = source.innerHTML;
        });
        document.getElementById('stockSearch')?.dispatchEvent(new Event('input', { bubbles: true }));
      }
    } catch (error) {
      console.error('Inventory view live poll failed:', error);
    } finally {
      pollingInFlight = false;
    }
  }
  pollLiveMain();
  window.setInterval(pollLiveMain, pollIntervalMs);
})();
</script>
</body>
</html>
