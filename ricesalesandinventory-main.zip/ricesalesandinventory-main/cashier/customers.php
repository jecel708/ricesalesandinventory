<?php
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit;
}

if(strtolower($_SESSION['role'] ?? '') !== 'cashier'){
    header("Location: ../login.php");
    exit;
}

$username = $_SESSION['username'] ?? 'Cashier';
$user_id = (int)($_SESSION['user_id'] ?? 0);

include '../config/db.php';
require_once __DIR__ . '/../includes/receivable_penalty.php';
ensurePenaltyPaymentColumn($conn);
$penaltyOutstandingSql = receivablePenaltyOutstandingSql();

function h($v){
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function js_arg($v){
    return htmlspecialchars(
        json_encode(
            (string)$v,
            JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES
        ),
        ENT_QUOTES,
        'UTF-8'
    );
}


// ============================================================
// SUCCESS / ERROR MESSAGES
// ============================================================

$success = $_GET['success'] ?? '';
$error = $_GET['error'] ?? '';


// ============================================================
// CSRF TOKEN
// ============================================================

if(empty($_SESSION['csrf_token'])){
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrf_token = (string)$_SESSION['csrf_token'];


function require_csrf_or_redirect(string $target): void {

    $posted = (string)($_POST['csrf_token'] ?? '');
    $stored = (string)($_SESSION['csrf_token'] ?? '');

    if(
        $posted === '' ||
        $stored === '' ||
        !hash_equals($stored, $posted)
    ){
        header(
            "Location: {$target}?error=" .
            urlencode("Invalid request token. Please refresh and try again.")
        );

        exit;
    }
}

function ensure_customer_email_column(mysqli $conn): void {
    $dbRes = $conn->query("SELECT DATABASE() AS db_name");
    $dbRow = $dbRes ? $dbRes->fetch_assoc() : null;
    $dbName = (string)($dbRow['db_name'] ?? '');
    if($dbName === ''){
        return;
    }

    $stmt = $conn->prepare("
        SELECT COUNT(*) AS cnt
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = ?
          AND TABLE_NAME = 'customers'
          AND COLUMN_NAME = 'email'
    ");
    if(!$stmt){
        return;
    }

    $stmt->bind_param("s", $dbName);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if((int)($row['cnt'] ?? 0) === 0){
        $conn->query("ALTER TABLE customers ADD COLUMN email VARCHAR(255) NULL AFTER phone");
    }
}

ensure_customer_email_column($conn);

function ensure_customer_archive_column(mysqli $conn): void {
    $dbRes = $conn->query("SELECT DATABASE() AS db_name");
    $dbRow = $dbRes ? $dbRes->fetch_assoc() : null;
    $dbName = (string)($dbRow['db_name'] ?? '');
    if($dbName === ''){
        return;
    }

    $stmt = $conn->prepare("
        SELECT COUNT(*) AS cnt
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = ?
          AND TABLE_NAME = 'customers'
          AND COLUMN_NAME = 'archived_at'
    ");
    if(!$stmt){
        return;
    }

    $stmt->bind_param("s", $dbName);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if((int)($row['cnt'] ?? 0) === 0){
        $conn->query("ALTER TABLE customers ADD COLUMN archived_at DATETIME NULL AFTER email");
    }
}

ensure_customer_archive_column($conn);


// ============================================================
// ADD CUSTOMER
// ============================================================

if(isset($_POST['add_customer'])){

    require_csrf_or_redirect('customers.php');

    $first = trim($_POST['first_name'] ?? '');
    $last = trim($_POST['last_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim(strtolower((string)($_POST['email'] ?? '')));
    $addr = trim($_POST['address'] ?? '');

    if(
        $first === '' ||
        $last === '' ||
        $phone === ''
    ){
        header(
            "Location: customers.php?error=" .
            urlencode("First name, last name, and phone are required.")
        );

        exit;
    }

    if($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)){
        header(
            "Location: customers.php?error=" .
            urlencode("Please enter a valid email address.")
        );

        exit;
    }

    $dup = $conn->prepare("
        SELECT customer_id
        FROM customers
        WHERE LOWER(first_name) = LOWER(?)
          AND LOWER(last_name) = LOWER(?)
          AND phone = ?
        LIMIT 1
    ");

    if(!$dup){
        die("SQL PREPARE ERROR: " . $conn->error);
    }

    $dup->bind_param("sss", $first, $last, $phone);
    $dup->execute();
    $existing = $dup->get_result()->fetch_assoc();
    $dup->close();

    if($existing){
        header(
            "Location: customers.php?error=" .
            urlencode("This customer is already listed.")
        );

        exit;
    }

    if($email !== ''){
        $dupEmail = $conn->prepare("
            SELECT customer_id
            FROM customers
            WHERE LOWER(email) = LOWER(?)
            LIMIT 1
        ");
        if(!$dupEmail){
            die("SQL PREPARE ERROR: " . $conn->error);
        }
        $dupEmail->bind_param("s", $email);
        $dupEmail->execute();
        $existingEmail = $dupEmail->get_result()->fetch_assoc();
        $dupEmail->close();

        if($existingEmail){
            header(
                "Location: customers.php?error=" .
                urlencode("This email is already listed for another customer.")
            );

            exit;
        }
    }

    $stmt = $conn->prepare("
        INSERT INTO customers
        (
            first_name,
            last_name,
            phone,
            email,
            address,
            created_at
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            NOW()
        )
    ");

    if(!$stmt){
        die("SQL PREPARE ERROR: " . $conn->error);
    }

    $stmt->bind_param(
        "sssss",
        $first,
        $last,
        $phone,
        $email,
        $addr
    );

    $stmt->execute();
    $stmt->close();

    header(
        "Location: customers.php?success=" .
        urlencode("Customer added successfully.")
    );

    exit;
}


// ============================================================
// EDIT CUSTOMER
// ============================================================

if(isset($_POST['edit_customer'])){

    require_csrf_or_redirect('customers.php');

    $cid = (int)($_POST['customer_id'] ?? 0);
    $first = trim($_POST['first_name'] ?? '');
    $last = trim($_POST['last_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim(strtolower((string)($_POST['email'] ?? '')));
    $addr = trim($_POST['address'] ?? '');

    if(
        $cid <= 0 ||
        $first === '' ||
        $last === '' ||
        $phone === ''
    ){
        header(
            "Location: customers.php?error=" .
            urlencode("Invalid customer data.")
        );

        exit;
    }

    if($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)){
        header(
            "Location: customers.php?error=" .
            urlencode("Please enter a valid email address.")
        );

        exit;
    }

    $dup = $conn->prepare("
        SELECT customer_id
        FROM customers
        WHERE LOWER(first_name) = LOWER(?)
          AND LOWER(last_name) = LOWER(?)
          AND phone = ?
          AND customer_id <> ?
        LIMIT 1
    ");

    if(!$dup){
        die("SQL PREPARE ERROR: " . $conn->error);
    }

    $dup->bind_param("sssi", $first, $last, $phone, $cid);
    $dup->execute();
    $existing = $dup->get_result()->fetch_assoc();
    $dup->close();

    if($existing){
        header(
            "Location: customers.php?error=" .
            urlencode("Another customer already has the same details.")
        );

        exit;
    }

    if($email !== ''){
        $dupEmail = $conn->prepare("
            SELECT customer_id
            FROM customers
            WHERE LOWER(email) = LOWER(?)
              AND customer_id <> ?
            LIMIT 1
        ");
        if(!$dupEmail){
            die("SQL PREPARE ERROR: " . $conn->error);
        }
        $dupEmail->bind_param("si", $email, $cid);
        $dupEmail->execute();
        $existingEmail = $dupEmail->get_result()->fetch_assoc();
        $dupEmail->close();

        if($existingEmail){
            header(
                "Location: customers.php?error=" .
                urlencode("Another customer already uses this email.")
            );

            exit;
        }
    }

    $stmt = $conn->prepare("
        UPDATE customers
        SET
            first_name = ?,
            last_name = ?,
            phone = ?,
            email = ?,
            address = ?
        WHERE customer_id = ?
    ");

    if(!$stmt){
        die("SQL PREPARE ERROR: " . $conn->error);
    }

    $stmt->bind_param(
        "sssssi",
        $first,
        $last,
        $phone,
        $email,
        $addr,
        $cid
    );

    $stmt->execute();
    $stmt->close();

    header(
        "Location: customers.php?success=" .
        urlencode("Customer updated.")
    );

    exit;
}

if(isset($_POST['archive_customer']) || isset($_POST['restore_customer'])){

    require_csrf_or_redirect('customers.php');

    $cid = (int)($_POST['customer_id'] ?? 0);
    if($cid <= 0){
        header("Location: customers.php?error=" . urlencode("Invalid customer selected."));
        exit;
    }

    if(isset($_POST['archive_customer'])){
        $stmt = $conn->prepare("UPDATE customers SET archived_at = NOW() WHERE customer_id = ?");
        $msg = "Customer archived.";
    } else {
        $stmt = $conn->prepare("UPDATE customers SET archived_at = NULL WHERE customer_id = ?");
        $msg = "Customer restored.";
    }

    if(!$stmt){
        die("SQL PREPARE ERROR: " . $conn->error);
    }

    $stmt->bind_param("i", $cid);
    $stmt->execute();
    $stmt->close();

    header("Location: customers.php?success=" . urlencode($msg));
    exit;
}


// ============================================================
// SEARCH
// ============================================================

$q = trim($_GET['q'] ?? '');
$includeArchived = !empty($_GET['include_archived']);


// ============================================================
// SUMMARY
// ============================================================

$summary = [
    'customer_count' => 0,
    'open_balance' => 0,
    'penalty_total' => 0,
    'overdue_count' => 0,
];

$summaryRes = $conn->query("
    SELECT
        (SELECT COUNT(*) FROM customers) AS customer_count,

        (
            SELECT IFNULL(SUM(balance),0)
            FROM account_receivable
            WHERE status != 'paid'
        ) AS open_balance,

        (
            SELECT IFNULL(SUM({$penaltyOutstandingSql}),0)
            FROM account_receivable ar
            LEFT JOIN penalties p
              ON p.reference_id = ar.ar_id AND p.reference_type = 'receivable'
        ) AS penalty_total,

        (
            SELECT COUNT(*)
            FROM account_receivable ar
            LEFT JOIN penalties p
              ON p.reference_id = ar.ar_id AND p.reference_type = 'receivable'
            WHERE (ar.balance > 0 OR ({$penaltyOutstandingSql}) > 0)
              AND ar.due_date < CURDATE()
        ) AS overdue_count
");

if($summaryRes){

    $summary = array_merge(
        $summary,
        $summaryRes->fetch_assoc() ?: []
    );
}


// ============================================================
// CUSTOMER QUERY
// ============================================================

$sql = "
    SELECT
        c.*,

        IFNULL(SUM(ar.total_amount), 0) AS ar_total,

        IFNULL(SUM(ar.balance), 0) AS ar_balance,

        IFNULL(SUM({$penaltyOutstandingSql}), 0) AS total_penalties,

        MAX(ar.due_date) AS latest_due_date,

        IFNULL(SUM({$penaltyOutstandingSql}), 0) AS overdue_fee_estimate,

        SUM(
            CASE
                WHEN (ar.balance > 0 OR ({$penaltyOutstandingSql}) > 0)
                AND ar.due_date < CURDATE()
                THEN 1
                ELSE 0
            END
        ) AS overdue_count

    FROM customers c

    LEFT JOIN account_receivable ar
        ON c.customer_id = ar.customer_id

    LEFT JOIN penalties p
        ON ar.ar_id = p.reference_id
        AND p.reference_type = 'receivable'
";

$params = [];
$types = "";


if($q !== ''){

    $sql .= "
        WHERE
            c.first_name LIKE CONCAT('%',?,'%')
            OR c.last_name LIKE CONCAT('%',?,'%')
            OR c.phone LIKE CONCAT('%',?,'%')
            OR c.address LIKE CONCAT('%',?,'%')
    ";

    $params = [
        $q,
        $q,
        $q,
        $q
    ];

    $types = "ssss";
}

if(!$includeArchived){
    if($q === ''){
        $sql .= "\n    WHERE c.archived_at IS NULL";
    } else {
        $sql .= "\n        AND c.archived_at IS NULL";
    }
}


$sql .= "
    GROUP BY c.customer_id
    ORDER BY c.created_at DESC
    LIMIT 200
";


$stmt = $conn->prepare($sql);

if(!$stmt){
    die(
        "SQL PREPARE ERROR: " .
        $conn->error .
        "<br><pre>$sql</pre>"
    );
}


if($types !== ''){

    $stmt->bind_param(
        $types,
        ...$params
    );
}


$stmt->execute();

$customers = $stmt->get_result();

$stmt->close();


// ============================================================
// LIVE AJAX RESPONSE
// ============================================================

if(
    isset($_GET['ajax']) &&
    $_GET['ajax'] === 'live'
){

    header(
        'Content-Type: application/json; charset=utf-8'
    );

    $customerRows = [];

    if($customers){

        while($row = $customers->fetch_assoc()){

            $name = trim(
                (string)($row['first_name'] ?? '') .
                ' ' .
                (string)($row['last_name'] ?? '')
            );

            $ar_balance =
                (float)($row['ar_balance'] ?? 0);

            $penalties =
                (float)($row['total_penalties'] ?? 0);

            $total_due =
                $ar_balance + $penalties;

            $overdue =
                (int)($row['overdue_count'] ?? 0);


            $customerRows[] = [

                'customer_id' =>
                    (int)($row['customer_id'] ?? 0),

                'name' =>
                    $name !== ''
                        ? $name
                        : 'N/A',

                'phone' =>
                    (string)($row['phone'] ?? ''),

                'address' =>
                    (string)($row['address'] ?? ''),

                'email' =>
                    (string)($row['email'] ?? ''),

                'ar_balance' =>
                    $ar_balance,

                'penalties' =>
                    $penalties,

                'total_due' =>
                    $total_due,

                'overdue' =>
                    $overdue,

                'due_date' =>
                    (string)($row['latest_due_date'] ?? ''),

                'overdue_fee_estimate' =>
                    (float)($row['overdue_fee_estimate'] ?? 0),

                'archived_at' =>
                    (string)($row['archived_at'] ?? ''),
            ];
        }
    }


    echo json_encode([

        'ok' => true,

        'summary' => [

            'customer_count' =>
                (int)($summary['customer_count'] ?? 0),

            'open_balance' =>
                (float)($summary['open_balance'] ?? 0),

            'penalty_total' =>
                (float)($summary['penalty_total'] ?? 0),

            'overdue_count' =>
                (int)($summary['overdue_count'] ?? 0),
        ],

        'customers' =>
            $customerRows,
    ]);

    exit;
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1"
>

<title>Customers | Cashier</title>


<link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
    rel="stylesheet"
>

<link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    rel="stylesheet"
>


<link
    href="../css/layout.css"
    rel="stylesheet"
>

<link
    href="../css/cashier-customers.css?v=customer-enhance-1"
    rel="stylesheet"
>

<link
    href="../css/cashier-mobile.css"
    rel="stylesheet"
>


<style>

.loading-text {
    color: #666;
    font-style: italic;
}


/* ============================================================
   PURCHASE HISTORY ITEMS
   ============================================================ */

.purchase-items-list {
    line-height: 1.5;
}

.purchase-item-name {
    color: #6c757d;
    font-size: 0.85rem;
    margin-bottom: 2px;
    white-space: normal;
}

.purchase-item-name i {
    color: #6c757d;
}


/* Keep the Items column readable */

#purchase-table-container th:nth-child(3),
#purchase-table-container td:nth-child(3) {
    min-width: 220px;
}


/* Prevent long product names from making the modal too wide */

#purchase-table-container .purchase-item-name {
    overflow-wrap: anywhere;
}

.customer-modal .modal-content{
    border: 0;
    border-radius: 18px;
    overflow: hidden;
    box-shadow: 0 20px 50px rgba(31, 44, 57, .22);
}

.customer-modal .modal-header{
    background: linear-gradient(135deg, rgb(44, 62, 80), rgb(31, 44, 57));
    color: #fff;
    border-bottom: 0;
    padding: 1rem 1.25rem;
}

.customer-modal .modal-header .btn-close{
    filter: invert(1) grayscale(100%);
    opacity: .9;
}

.customer-modal .modal-title{
    font-weight: 800;
    letter-spacing: -.02em;
}

.customer-modal .modal-body{
    background: linear-gradient(180deg, #ffffff 0%, #f7f9fb 100%);
    padding: 1.25rem;
}

.customer-modal .modal-footer{
    background: #f7f9fb;
    border-top: 1px solid rgba(45, 62, 87, .12);
    padding: 1rem 1.25rem;
}

.customer-form-grid{
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 12px;
}

.customer-field{
    position: relative;
}

.customer-field .field-icon{
    position: absolute;
    left: 14px;
    top: 41px;
    color: rgba(44, 62, 80, .55);
    pointer-events: none;
}

.customer-field .form-control,
.customer-field textarea{
    padding-left: 2.4rem;
    border-radius: 12px;
    border: 1px solid rgba(45, 62, 87, .22);
    min-height: 44px;
}

.customer-field textarea{
    padding-top: .75rem;
}

.customer-field .form-control:focus,
.customer-field textarea:focus{
    border-color: rgba(44, 62, 80, .85);
    box-shadow: 0 0 0 .2rem rgba(44, 62, 80, .10);
}

.customer-field .helper-text{
    font-size: .8rem;
    color: rgba(44, 62, 80, .68);
    margin-top: .35rem;
}

.customer-field.full-span{
    grid-column: 1 / -1;
}

.modal-action-note{
    font-size: .82rem;
    color: rgba(44, 62, 80, .7);
}

@media (max-width: 576px){
    .customer-form-grid{
        grid-template-columns: 1fr;
    }
}

</style>

</head>


<body>

<?php

$profileLink = 'cashier_profile.php';

$logoutLink = '../logout.php';

include '../includes/topnav.php';

?>


<div class="container-fluid">

<div class="row">


<?php include '../includes/cashier_sidebar.php'; ?>


<!-- MAIN -->

<main class="col-lg-10 ms-sm-auto px-4 main-content">

<div class="py-4">


<div
    class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3"
    id="customersTopbar"
>

<div>

<h3 class="fw-bold mb-1">
    Customers
</h3>

<div class="text-muted">
    Manage named customers for utang accounts and follow-up payments.
</div>

</div>


<button
    class="btn btn-dark"
    data-bs-toggle="modal"
    data-bs-target="#addCustomerModal"
>

<i class="fa-solid fa-user-plus me-1"></i>

Add Customer

</button>

</div>


<?php if(!empty($success)): ?>

<div class="alert alert-success py-2">

<?= h($success) ?>

</div>

<?php endif; ?>


<?php if(!empty($error)): ?>

<div class="alert alert-danger py-2">

<?= h($error) ?>

</div>

<?php endif; ?>


<!-- ========================================================
     SUMMARY CARDS
     ======================================================== -->

<div
    class="customer-summary-grid mb-3"
    id="customerSummaryGrid"
>

<div class="customer-summary-card">

<div class="summary-label">
    Customers
</div>

<div class="summary-value">

<?= number_format(
    (int)($summary['customer_count'] ?? 0)
) ?>

</div>

</div>


<div class="customer-summary-card">

<div class="summary-label">
    Open Balance
</div>

<div class="summary-value">

₱<?= number_format(
    (float)($summary['open_balance'] ?? 0),
    2
) ?>

</div>

</div>


<div class="customer-summary-card">

<div class="summary-label">
    Penalties
</div>

<div class="summary-value text-danger">

₱<?= number_format(
    (float)($summary['penalty_total'] ?? 0),
    2
) ?>

</div>

</div>


<div class="customer-summary-card">

<div class="summary-label">
    Overdue
</div>

<div
    class="summary-value
    <?= (int)($summary['overdue_count'] ?? 0) > 0
        ? 'text-danger'
        : '' ?>"
>

<?= number_format(
    (int)($summary['overdue_count'] ?? 0)
) ?>

</div>

</div>

</div>


<!-- ========================================================
     SEARCH
     ======================================================== -->

<div
    class="card modern-card mb-3"
    id="customerSearchCard"
>

<div class="card-body">

<form
    class="row g-2 align-items-end"
    method="GET"
    autocomplete="off"
>

<div class="col-12 col-md-8">

<label class="form-label">
    Search
</label>

<input
    class="form-control"
    name="q"
    id="customerSearchInput"
    value="<?= h($q) ?>"
    placeholder="Name, phone, address..."
    autocomplete="new-password"
    spellcheck="false"
    data-lpignore="true"
>
<div class="form-text">Type to filter customers live.</div>

</div>


<div class="col-6 col-md-2 d-grid">

<button class="btn btn-outline-dark">

<i class="fa-solid fa-magnifying-glass me-1"></i>

Search

</button>

</div>


<div class="col-6 col-md-2 d-grid">

<a
    class="btn btn-outline-secondary"
    href="customers.php"
>

<i class="fa-solid fa-rotate-left me-1"></i>

Reset

</a>

</div>

</form>

</div>

</div>


<!-- ========================================================
     CUSTOMER TABLE
     ======================================================== -->

<div
    class="card modern-card"
    id="customerTableCard"
>

<div class="card-body table-responsive">

<table
    class="table table-striped align-middle mb-0 customers-table"
>

<thead class="table-dark">

<tr>

<th>ID</th>

<th>Customer</th>

<th>Phone</th>

<th style="width:100px;">
    Balance
</th>

<th style="width:90px;">
    Penalty
</th>

<th style="width:100px;">
    Total Due
</th>

<th style="width:80px;">
    Status
</th>

<th class="text-end">
    Action
</th>

</tr>

</thead>


<tbody>

<?php if($customers && $customers->num_rows > 0): ?>


<?php while($c = $customers->fetch_assoc()): ?>


<?php

$name = trim(
    ($c['first_name'] ?? '') .
    ' ' .
    ($c['last_name'] ?? '')
);

$address =
    trim((string)($c['address'] ?? ''));

$ar_balance =
    (float)($c['ar_balance'] ?? 0);

$penalties =
    (float)($c['total_penalties'] ?? 0);

$total_due =
    $ar_balance + $penalties;

$overdue =
    (int)($c['overdue_count'] ?? 0);

$has_debt =
    $total_due > 0;

$cid =
    (int)($c['customer_id'] ?? 0);

$dueDate =
    $c['latest_due_date'] ?? '';

$overdueFeeEstimate =
    (float)($c['overdue_fee_estimate'] ?? 0);

?>


<tr>

<td class="fw-bold">

<?= $cid ?>

</td>


<td>

<div class="fw-semibold">

<?= h($name ?: 'N/A') ?>

</div>


<?php if($address !== ''): ?>

<div
    class="small text-muted text-truncate customer-address"
>

<?= h($address) ?>

</div>

<?php endif; ?>

</td>


<td>

<?= h($c['phone'] ?? '') ?>

</td>


<td>

<?php if($has_debt): ?>

<span class="badge bg-warning text-dark">

₱<?= number_format($ar_balance, 2) ?>

</span>

<?php else: ?>

<span class="badge bg-success">

Cleared

</span>

<?php endif; ?>

</td>


<td>

<?php if($penalties > 0): ?>

<span class="badge bg-danger">

₱<?= number_format($penalties, 2) ?>

</span>

<?php elseif($overdue > 0): ?>

<span class="badge bg-warning text-dark">

Pending

</span>

<?php else: ?>

<span class="badge bg-success">

None

</span>

<?php endif; ?>

</td>


<td>

<?php if($total_due > 0): ?>

<strong
    class="<?= $overdue > 0
        ? 'text-danger'
        : '' ?>"
>

₱<?= number_format($total_due, 2) ?>

</strong>


<?php if($overdue > 0): ?>

<br>

<small class="text-danger">

<i class="fa-solid fa-triangle-exclamation me-1"></i>

<?= $overdue ?> overdue

</small>

<?php endif; ?>


<?php else: ?>

<span
    class="badge text-white"
    style="background-color: #607D8B;"
>

₱0.00

</span>

<?php endif; ?>

</td>


<td>

<?php if($overdue > 0): ?>

<span class="badge bg-danger">
    Overdue
</span>

<?php elseif($has_debt): ?>

<span class="badge bg-warning text-dark">
    Owing
</span>

<?php else: ?>

<span class="badge bg-success">
    Clear
</span>

<?php endif; ?>

</td>


<td class="text-end">

<div class="d-inline-flex flex-column align-items-end gap-1">

<div class="d-inline-flex gap-1">

<button
    class="btn btn-sm btn-outline-primary"
    type="button"
    onclick="viewCustomer(
        <?= $cid ?>,
        <?= js_arg($name ?: 'N/A') ?>,
        <?= $ar_balance ?>,
        <?= $penalties ?>,
        <?= $overdue ?>,
        <?= $total_due ?>,
        <?= js_arg($dueDate) ?>,
        <?= $overdueFeeEstimate ?>
    )"
>

<i class="fa-solid fa-eye me-1"></i>

View

</button>


<button
    class="btn btn-sm btn-outline-dark"
    type="button"
    onclick="editCustomer(
        <?= $cid ?>,
        <?= js_arg($c['first_name'] ?? '') ?>,
        <?= js_arg($c['last_name'] ?? '') ?>,
        <?= js_arg($c['phone'] ?? '') ?>,
        <?= js_arg($c['email'] ?? '') ?>,
        <?= js_arg($address) ?>
    )"
    <?= !empty($c['archived_at']) ? 'disabled' : '' ?>
>

<i class="fa-solid fa-pen-to-square me-1"></i>

Edit

</button>

<?php if(!empty($c['archived_at'])): ?>
<form method="POST" class="d-inline">
    <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
    <input type="hidden" name="customer_id" value="<?= $cid ?>">
    <button class="btn btn-sm btn-outline-success" name="restore_customer" value="1" type="submit" title="Restore customer" aria-label="Restore customer">
        <i class="fa-solid fa-arrow-rotate-left"></i>
    </button>
</form>
<?php else: ?>
<form method="POST" class="d-inline" onsubmit="return confirm('Archive this customer? They will be hidden from the active list.');">
    <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
    <input type="hidden" name="customer_id" value="<?= $cid ?>">
    <button class="btn btn-sm btn-outline-secondary" name="archive_customer" value="1" type="submit" title="Archive customer" aria-label="Archive customer">
        <i class="fa-solid fa-box-archive"></i>
    </button>
</form>
<?php endif; ?>


</div>

</td>

</tr>


<?php endwhile; ?>


<?php else: ?>

<tr>

<td
    colspan="8"
    class="text-center text-muted py-4"
>

No customers found.

</td>

</tr>

<?php endif; ?>

</tbody>

</table>

</div>

</div>


</div>

</main>


</div>

</div>


<!-- ========================================================
     VIEW CUSTOMER MODAL
     ======================================================== -->

<div
    class="modal fade"
    id="viewCustomerModal"
    tabindex="-1"
>

<div class="modal-dialog modal-lg">

<div class="modal-content">


<div class="modal-header">

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center w-100 gap-2">
<h5
    class="modal-title mb-0"
    id="viewModalTitle"
>

Account Details

</h5>

<div class="d-flex flex-wrap gap-2">
    <div class="acct-mini-stat">
        <div class="small text-muted">Total Purchases</div>
        <div class="fw-bold" id="viewPurchaseAmount">₱0.00</div>
    </div>
    <div class="acct-mini-stat">
        <div class="small text-muted">Total Utang</div>
        <div class="fw-bold" id="viewUtangAmount">₱0.00</div>
    </div>
</div>
</div>


<button
    type="button"
    class="btn-close"
    data-bs-dismiss="modal"
></button>

</div>


<div class="modal-body">


<!-- ======================================================
     ACCOUNT SUMMARY
     ====================================================== -->

<div class="row g-3 mb-3">


<div class="col-md-3">

<div class="acct-box">

<div class="small text-muted">
    Balance
</div>

<div
    class="fw-bold"
    id="viewBalance"
>
    ₱0.00
</div>

</div>

</div>


<div class="col-md-3">

<div
    class="acct-box"
    id="penaltyBox"
>

<div class="small text-muted">

Penalty

<small>
    One-time fee per overdue invoice
</small>

</div>

<div
    class="fw-bold"
    id="viewPenalty"
>
    ₱0.00
</div>

<div
    class="small text-muted mt-1"
    id="viewDueDate"
></div>

<div
    class="small text-muted mt-1"
    id="viewLateFeeEstimate"
></div>

</div>

</div>


<div class="col-md-3">

<div
    class="acct-box"
    id="overdueBox"
>

<div class="small text-muted">
    Overdue Items
</div>

<div
    class="fw-bold"
    id="viewOverdue"
>
    0
</div>

</div>

</div>


<div class="col-md-3">

<div
    class="acct-box"
    id="totalBox"
>

<div class="small text-muted">
    Total Due
</div>

<div
    class="fw-bold"
    id="viewTotal"
>
    ₱0.00
</div>

</div>

</div>

</div>


<div id="penaltyNotice"></div>


<!-- ======================================================
     PENALTY BREAKDOWN
     ====================================================== -->

<div
    id="penaltyBreakdown"
    style="display:none;"
>

<div class="border-top pt-3 mt-3">

<h6 class="mb-3">

<i class="fa-solid fa-receipt me-2 text-danger"></i>

Penalty Breakdown

</h6>


<div class="table-responsive">

<table
    class="table table-sm table-striped align-middle mb-0"
>

<thead class="table-dark penalty-table">

<tr>

<th>
    Reference #
</th>

<th>
    Due Date
</th>

<th>
    Days Late
</th>

<th>
    Rate/Day
</th>

<th class="text-end">
    Amount
</th>

<th class="text-end">
    Last Calc
</th>

</tr>

</thead>


<tbody id="penaltyTableBody"></tbody>

</table>

</div>

</div>

</div>


<!-- ======================================================
     PURCHASE HISTORY
     ====================================================== -->

<div class="border-top pt-3 mt-3">


<h6 class="mb-3">

<i class="fa-solid fa-bag-shopping me-2 text-primary"></i>

Purchase History

</h6>


<div
    id="purchase-loading"
    class="loading-text text-center py-3"
>

<div
    class="spinner-border spinner-border-sm me-2"
></div>

Loading purchases...

</div>


<div
    id="purchase-empty"
    class="text-center text-muted py-3"
    style="display:none;"
>

<i class="fa-solid fa-inbox me-1"></i>

No purchases found for this customer.

</div>


<div
    id="purchase-error"
    class="text-center text-danger py-3"
    style="display:none;"
>

<i class="fa-solid fa-triangle-exclamation me-1"></i>

Could not load purchase history.

</div>


<div
    class="table-responsive"
    id="purchase-table-container"
    style="display:none;"
>


<table
    class="table table-sm table-striped table-bordered"
>

<thead class="table-dark">

<tr>

<th>
    Date
</th>

<th>
    Invoice #
</th>

<th>
    Items
</th>

<th class="text-end">
    Total Amount
</th>

<th class="text-center">
    Payment Status
</th>

</tr>

</thead>


<tbody id="purchase-table-body"></tbody>

</table>

</div>

</div>


</div>


<div class="modal-footer">

<button
    type="button"
    class="btn btn-secondary"
    data-bs-dismiss="modal"
>

Close

</button>

</div>


</div>

</div>

</div>


<!-- ========================================================
     EDIT CUSTOMER MODAL
     ======================================================== -->

<div
    class="modal fade"
    id="editCustomerModal"
    data-bs-backdrop="static"
    data-bs-keyboard="true"
    tabindex="-1"
>

<div class="modal-dialog">

<div class="modal-content customer-modal">


<div class="modal-header">

<h5 class="modal-title">
    Edit Customer
</h5>

<button
    type="button"
    class="btn-close"
    data-bs-dismiss="modal"
></button>

</div>


<form method="POST">

<div class="modal-body">

<div class="customer-form-hero">
    <div class="hero-icon">
        <i class="fa-solid fa-user-pen"></i>
    </div>
    <div>
        <h6>Edit Customer</h6>
        <p>Update contact details and keep the customer record clean.</p>
    </div>
</div>


<input
    type="hidden"
    name="edit_customer"
    value="1"
>


<input
    type="hidden"
    name="csrf_token"
    value="<?= h($csrf_token) ?>"
>


<input
    type="hidden"
    name="customer_id"
    id="editCustomerId"
    value=""
>


<div class="customer-form-grid">

<div class="customer-field">
<label class="form-label">
    First Name
</label>
<i class="fa-solid fa-id-badge field-icon"></i>
<input class="form-control" name="first_name" id="editFirstName" required>
</div>

<div class="customer-field">
<label class="form-label">
    Last Name
</label>
<i class="fa-solid fa-id-card field-icon"></i>
<input class="form-control" name="last_name" id="editLastName" required>
</div>

<div class="customer-field">
<label class="form-label">
    Phone
</label>
<i class="fa-solid fa-phone field-icon"></i>
<input class="form-control" name="phone" id="editPhone" required>
</div>

<div class="customer-field">
<label class="form-label">
    Email
</label>
<i class="fa-solid fa-envelope field-icon"></i>
<input type="email" class="form-control" name="email" id="editEmail" placeholder="customer@email.com">
<div class="helper-text">Optional, but helpful for reminders and contact.</div>
</div>

<div class="customer-field full-span">
<label class="form-label">
    Address
</label>
<i class="fa-solid fa-location-dot field-icon"></i>
<textarea class="form-control" name="address" id="editAddress" rows="3"></textarea>
<div class="helper-text">Add only relevant delivery or contact notes.</div>
</div>

</div>


</div>


<div class="modal-footer d-flex flex-column flex-sm-row gap-2">

<button
    type="button"
    class="btn btn-secondary"
    data-bs-dismiss="modal"
>

Cancel

</button>


<button class="btn btn-dark px-4">

<i class="fa-solid fa-floppy-disk me-1"></i>

Save

</button>

</div>

</form>

</div>

</div>

</div>


<!-- ========================================================
     ADD CUSTOMER MODAL
     ======================================================== -->

<div
    class="modal fade"
    id="addCustomerModal"
    data-bs-backdrop="static"
    data-bs-keyboard="true"
    tabindex="-1"
>

<div class="modal-dialog">

<div class="modal-content customer-modal">


<div class="modal-header">

<h5 class="modal-title">
    Add Customer
</h5>

<button
    type="button"
    class="btn-close"
    data-bs-dismiss="modal"
></button>

</div>


<form method="POST">

<div class="modal-body">

<div class="customer-form-hero">
    
</div>


<input
    type="hidden"
    name="add_customer"
    value="1"
>


<input
    type="hidden"
    name="csrf_token"
    value="<?= h($csrf_token) ?>"
>


<div class="customer-form-grid">

<div class="customer-field">
<label class="form-label">
    First Name
</label>
<i class="fa-solid fa-id-badge field-icon"></i>
<input class="form-control" name="first_name" required>
</div>

<div class="customer-field">
<label class="form-label">
    Last Name
</label>
<i class="fa-solid fa-id-card field-icon"></i>
<input class="form-control" name="last_name" required>
</div>

<div class="customer-field">
<label class="form-label">
    Phone
</label>
<i class="fa-solid fa-phone field-icon"></i>
<input class="form-control" name="phone" required>
</div>

<div class="customer-field">
<label class="form-label">
    Email
</label>
<i class="fa-solid fa-envelope field-icon"></i>
<input type="email" class="form-control" name="email" placeholder="customer@email.com">
<div class="helper-text">Optional, but useful for follow-up and notifications.</div>
</div>

<div class="customer-field full-span">
<label class="form-label">
    Address
</label>
<i class="fa-solid fa-location-dot field-icon"></i>
<textarea class="form-control" name="address" rows="3"></textarea>
<div class="helper-text">Optional, but useful for delivery or follow-up notes.</div>
</div>

</div>


</div>


<div class="modal-footer d-flex flex-column flex-sm-row gap-2">

<button
    type="button"
    class="btn btn-secondary"
    data-bs-dismiss="modal"
>

Cancel

</button>


<button class="btn btn-dark px-4">

<i class="fa-solid fa-user-plus me-1"></i>

Add

</button>

</div>

</form>

</div>

</div>

</div>


<!-- ========================================================
     SCRIPTS
     ======================================================== -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>


<script>

const csrfToken = <?= json_encode($csrf_token, JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES) ?>;
window.csrfToken = csrfToken;

let customerPollInFlight = false;

const customerPollIntervalMs = 4000;

let activeCustomerId = null;
let customerSearchQuery = <?= json_encode($q, JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES) ?>;
let customerSearchTimer = null;
let customerSearchSuggestTimer = null;


// ============================================================
// HTML ESCAPE
// ============================================================

function escapeHtml(value){

    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function escapeAttr(value){
    return String(value ?? '').replace(/"/g, '&quot;');
}


// ============================================================
// CUSTOMER BADGE CLASS
// ============================================================

function customerBadgeClass(overdue, balance){

    if(overdue > 0){
        return 'badge bg-danger';
    }

    if(balance > 0){
        return 'badge bg-warning text-dark';
    }

    return 'badge bg-success';
}


// ============================================================
// RENDER CUSTOMER ROWS
// ============================================================

function renderCustomerRows(customers){

    const tbody =
        document.querySelector('.customers-table tbody');

    if(!tbody){
        return;
    }


    if(
        !Array.isArray(customers) ||
        customers.length === 0
    ){

        tbody.innerHTML = `
            <tr>
                <td
                    colspan="8"
                    class="text-center text-muted py-4"
                >
                    No customers found.
                </td>
            </tr>
        `;

        return;
    }


    tbody.innerHTML = customers.map((c) => {

        const balance =
            Number(c.ar_balance || 0);

        const penalties =
            Number(c.penalties || 0);

        const totalDue =
            Number(c.total_due || 0);

        const overdue =
            Number(c.overdue || 0);

        const dueDate =
            c.due_date || '';

        const overdueFeeEstimate =
            Number(c.overdue_fee_estimate || 0);

        const name =
            c.name || 'N/A';

        const address =
            c.address || '';

        const phone =
            c.phone || '';

        const email =
            c.email || '';


        const statusLabel =
            overdue > 0
                ? 'Overdue'
                : (
                    balance > 0
                        ? 'Owing'
                        : 'Clear'
                );


        const statusClass =
            overdue > 0
                ? 'badge bg-danger'
                : (
                    balance > 0
                        ? 'badge bg-warning text-dark'
                        : 'badge bg-success'
                );


        const viewArgs = [

            Number(c.customer_id || 0),

            JSON.stringify(name),

            balance,

            penalties,

            overdue,

            totalDue,

            JSON.stringify(dueDate),

            overdueFeeEstimate

        ];


        const editArgs = [

            Number(c.customer_id || 0),

            JSON.stringify(
                name
                    .split(' ')
                    .slice(0, -1)
                    .join(' ') || ''
            ),

            JSON.stringify(
                name
                    .split(' ')
                    .slice(-1)
                    .join(' ') || ''
            ),

            JSON.stringify(phone),

            JSON.stringify(email),

            JSON.stringify(address)

        ];


        return `

            <tr>

                <td class="fw-bold">
                    ${Number(c.customer_id || 0)}
                </td>


                <td>

                    <div class="fw-semibold">
                        ${escapeHtml(name)}
                    </div>

                    ${
                        address !== ''
                            ? `
                                <div
                                    class="small text-muted text-truncate customer-address"
                                >
                                    ${escapeHtml(address)}
                                </div>
                            `
                            : ''
                    }

                </td>


                <td>
                    ${escapeHtml(phone)}
                </td>


                <td>

                    ${
                        balance > 0
                            ? `
                                <span class="badge bg-warning text-dark">
                                    ₱${balance.toFixed(2)}
                                </span>
                            `
                            : `
                                <span class="badge bg-success">
                                    Cleared
                                </span>
                            `
                    }

                </td>


                <td>

                    ${
                        penalties > 0

                            ? `
                                <span class="badge bg-danger">
                                    ₱${penalties.toFixed(2)}
                                </span>
                            `

                            : (

                                overdue > 0

                                    ? `
                                        <span class="badge bg-warning text-dark">
                                            Pending
                                        </span>
                                    `

                                    : `
                                        <span class="badge bg-success">
                                            None
                                        </span>
                                    `
                            )
                    }

                </td>


                <td>

                    ${
                        totalDue > 0

                            ? `
                                <strong
                                    class="${
                                        overdue > 0
                                            ? 'text-danger'
                                            : ''
                                    }"
                                >
                                    ₱${totalDue.toFixed(2)}
                                </strong>

                                ${
                                    overdue > 0

                                        ? `
                                            <br>

                                            <small class="text-danger">

                                                <i
                                                    class="fa-solid fa-triangle-exclamation me-1"
                                                ></i>

                                                ${overdue} overdue

                                            </small>
                                        `

                                        : ''
                                }
                            `

                            : `
                                <span
                                    class="badge text-white"
                                    style="background-color: #607D8B;"
                                >
                                    ₱0.00
                                </span>
                            `
                    }


                    ${
                        dueDate ||
                        overdueFeeEstimate > 0

                            ? `
                                <div class="small text-muted mt-1">

                                    ${
                                        dueDate
                                            ? `
                                                Due ${
                                                    new Date(
                                                        dueDate
                                                    ).toLocaleDateString(
                                                        'en-PH',
                                                        {
                                                            year: 'numeric',
                                                            month: 'short',
                                                            day: 'numeric'
                                                        }
                                                    )
                                                }
                                            `
                                            : ''
                                    }

                                    ${
                                        dueDate &&
                                        overdueFeeEstimate > 0
                                            ? ' · '
                                            : ''
                                    }

                                    ${
                                        overdueFeeEstimate > 0

                                            ? `
                                                Penalty due:
                                                ₱${overdueFeeEstimate.toLocaleString(
                                                    'en-PH',
                                                    {
                                                        minimumFractionDigits: 2,
                                                        maximumFractionDigits: 2
                                                    }
                                                )}
                                            `

                                            : ''
                                    }

                                </div>
                            `

                            : ''
                    }

                </td>


                <td>

                    <span class="${statusClass}">
                        ${statusLabel}
                    </span>

                </td>


                <td class="text-end">

                    <div class="d-inline-flex flex-column align-items-end gap-1">

                        <div class="d-inline-flex gap-1">


                        <button
                            class="btn btn-sm btn-outline-primary"
                            type="button"
                            onclick='viewCustomer(${viewArgs.join(', ')})'
                        >

                            <i class="fa-solid fa-eye me-1"></i>

                            View

                        </button>


                        <button
                            class="btn btn-sm btn-outline-dark"
                            type="button"
                            onclick='editCustomer(${editArgs.join(', ')})'
                        >

                            <i class="fa-solid fa-pen-to-square me-1"></i>

                            Edit

                        </button>

                        </div>

                        ${
                            c.archived_at
                                ? `
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="csrf_token" value="${escapeHtml(window.csrfToken || '')}">
                                        <input type="hidden" name="customer_id" value="${Number(c.customer_id || 0)}">
                                        <button class="btn btn-sm btn-outline-success" name="restore_customer" value="1" type="submit" title="Restore customer" aria-label="Restore customer">
                                            <i class="fa-solid fa-arrow-rotate-left"></i>
                                        </button>
                                    </form>
                                `
                                : `
                                    <form method="POST" class="d-inline" onsubmit="return confirm('Archive this customer? They will be hidden from the active list.');">
                                        <input type="hidden" name="csrf_token" value="${escapeHtml(window.csrfToken || '')}">
                                        <input type="hidden" name="customer_id" value="${Number(c.customer_id || 0)}">
                                        <button class="btn btn-sm btn-outline-secondary" name="archive_customer" value="1" type="submit" title="Archive customer" aria-label="Archive customer">
                                            <i class="fa-solid fa-box-archive"></i>
                                        </button>
                                    </form>
                                `
                        }

                    </div>

                </td>

            </tr>

        `;

    }).join('');
}


// ============================================================
// UPDATE CUSTOMER SUMMARY
// ============================================================

function updateCustomerSummary(summary){

    const cards =
        document.querySelectorAll(
            '#customerSummaryGrid .customer-summary-card'
        );

    if(cards.length < 4){
        return;
    }


    const safe = summary || {};


    cards[0]
        .querySelector('.summary-value')
        .textContent =
            Number(
                safe.customer_count || 0
            ).toLocaleString();


    cards[1]
        .querySelector('.summary-value')
        .textContent =
            '₱' +
            Number(
                safe.open_balance || 0
            ).toLocaleString(
                'en-PH',
                {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }
            );


    cards[2]
        .querySelector('.summary-value')
        .textContent =
            '₱' +
            Number(
                safe.penalty_total || 0
            ).toLocaleString(
                'en-PH',
                {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }
            );


    const overdueValue =
        cards[3]
            .querySelector('.summary-value');


    overdueValue.textContent =
        Number(
            safe.overdue_count || 0
        ).toLocaleString();


    overdueValue.classList.toggle(
        'text-danger',
        Number(safe.overdue_count || 0) > 0
    );
}


// ============================================================
// LIVE CUSTOMER POLLING
// ============================================================

async function pollCustomersPage(){

    if(customerPollInFlight){
        return;
    }

    customerPollInFlight = true;


    try{

        const url =
            new URL(window.location.href);

        url.searchParams.set(
            'ajax',
            'live'
        );

        if(customerSearchQuery){
            url.searchParams.set('q', customerSearchQuery);
        } else {
            url.searchParams.delete('q');
        }


        const response =
            await fetch(
                url.toString(),
                {
                    credentials: 'same-origin',

                    headers: {
                        'X-Requested-With':
                            'XMLHttpRequest'
                    }
                }
            );


        const data =
            await response.json();


        if(!data || !data.ok){
            return;
        }


        updateCustomerSummary(
            data.summary
        );


        renderCustomerRows(
            data.customers
        );


    }catch(error){

        console.error(
            'Customers live poll failed:',
            error
        );

    }finally{

        customerPollInFlight = false;
    }
}

function handleCustomerSearchInput(value){
    customerSearchQuery = String(value || '').trim();

    if(customerSearchTimer){
        clearTimeout(customerSearchTimer);
    }
    if(customerSearchSuggestTimer){
        clearTimeout(customerSearchSuggestTimer);
    }

    customerSearchTimer = setTimeout(() => {
        pollCustomersPage();
    }, 220);
}


// ============================================================
// VIEW CUSTOMER
// ============================================================

function viewCustomer(
    id,
    name,
    balance,
    penalties,
    overdue,
    total,
    dueDate,
    overdueFeeEstimate
){

    activeCustomerId = id;


    document.getElementById(
        'viewModalTitle'
    ).textContent =
        name + ' - Account Details';


    document.getElementById(
        'viewBalance'
    ).textContent =
        '₱' +
        parseFloat(balance).toLocaleString(
            'en-PH',
            {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }
        );


    document.getElementById(
        'viewPenalty'
    ).textContent =
        '₱' +
        parseFloat(penalties).toLocaleString(
            'en-PH',
            {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }
        );


    document.getElementById(
        'viewOverdue'
    ).textContent =
        overdue;


    document.getElementById(
        'viewTotal'
    ).textContent =
        '₱' +
        parseFloat(total).toLocaleString(
            'en-PH',
            {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }
        );

    document.getElementById(
        'viewPurchaseAmount'
    ).textContent = '₱0.00';

    document.getElementById(
        'viewUtangAmount'
    ).textContent = '₱0.00';


    document.getElementById(
        'viewDueDate'
    ).textContent =
        dueDate
            ? 'Due ' +
              new Date(
                  dueDate
              ).toLocaleDateString(
                  'en-PH',
                  {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric'
                  }
              )
            : '';


    document.getElementById(
        'viewLateFeeEstimate'
    ).textContent =
        overdueFeeEstimate > 0

            ? 'Penalty due: ₱' +
              parseFloat(
                  overdueFeeEstimate
              ).toLocaleString(
                  'en-PH',
                  {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                  }
              )

            : '';


    // ========================================================
    // UPDATE BOX STYLING
    // ========================================================

    const penaltyBox =
        document.getElementById(
            'penaltyBox'
        );

    const overdueBox =
        document.getElementById(
            'overdueBox'
        );

    const totalBox =
        document.getElementById(
            'totalBox'
        );


    penaltyBox.className =
        'border rounded p-2' +
        (
            penalties > 0
                ? ' bg-danger bg-opacity-10'
                : ' bg-light'
        );


    overdueBox.className =
        'border rounded p-2' +
        (
            overdue > 0
                ? ' bg-warning bg-opacity-10'
                : ' bg-light'
        );


    totalBox.className =
        'border rounded p-2' +
        (
            total > 0
                ? ' bg-danger bg-opacity-10'
                : ' bg-light'
        );


    // ========================================================
    // UPDATE TEXT COLORS
    // ========================================================

    document.querySelector(
        '#penaltyBox .fw-bold'
    ).className =
        'fw-bold' +
        (
            penalties > 0
                ? ' text-danger'
                : ''
        );


    document.querySelector(
        '#overdueBox .fw-bold'
    ).className =
        'fw-bold' +
        (
            overdue > 0
                ? ' text-danger'
                : ''
        );


    document.querySelector(
        '#totalBox .fw-bold'
    ).className =
        'fw-bold' +
        (
            total > 0
                ? ' text-danger'
                : ''
        );


    // ========================================================
    // PENALTY NOTICE
    // ========================================================

    const noticeDiv =
        document.getElementById(
            'penaltyNotice'
        );


    if(penalties > 0){

        noticeDiv.innerHTML = `
            <div class="alert alert-warning mb-0">

                <strong>
                    ⚠ Penalty Notice:
                </strong>

                A one-time overdue fee applies:
                ₱50 per sack or ₱100 per invoice.

            </div>
        `;

    }else{

        noticeDiv.innerHTML = '';
    }


    // ========================================================
    // RESET PURCHASE HISTORY
    // ========================================================

    document.getElementById(
        'purchase-loading'
    ).style.display = 'block';


    document.getElementById(
        'purchase-empty'
    ).style.display = 'none';


    document.getElementById(
        'purchase-error'
    ).style.display = 'none';


    document.getElementById(
        'purchase-table-container'
    ).style.display = 'none';


    document.getElementById(
        'purchase-table-body'
    ).innerHTML = '';


    // ========================================================
    // LOAD PURCHASE HISTORY
    // ========================================================

    fetch(
        'get_customer_purchases.php?customer_id=' +
        encodeURIComponent(id),
        {
            credentials: 'same-origin',
            headers: {
                'Accept': 'application/json'
            }
        }
    )

    .then(async response => {

        const text =
            await response.text();


        let data;


        try{

            data =
                JSON.parse(text);

        }catch(error){

            console.error(
                'Invalid purchase history response:',
                text
            );

            throw new Error(
                'Server returned an invalid response.'
            );
        }


        if(!response.ok){

            throw new Error(
                data.error ||
                'Server error'
            );
        }


        return data;
    })


    .then(data => {

        console.log(
            'Purchase history:',
            data
        );


        document.getElementById(
            'purchase-loading'
        ).style.display = 'none';


        if(!data.success){

            document.getElementById(
                'purchase-error'
            ).style.display = 'block';

            document.getElementById(
                'viewPurchaseAmount'
            ).textContent = '₱0.00';

            document.getElementById(
                'viewUtangAmount'
            ).textContent = '₱0.00';

            return;
        }


        if(
            !data.purchases ||
            data.purchases.length === 0
        ){

            document.getElementById(
                'purchase-empty'
            ).style.display = 'block';

            document.getElementById(
                'viewPurchaseAmount'
            ).textContent = '₱0.00';

            document.getElementById(
                'viewUtangAmount'
            ).textContent = '₱0.00';

            return;
        }

        const purchaseTotal = data.purchases.reduce((sum, p) => {
            return sum + Number(p.total_amount || 0);
        }, 0);

        const utangTotal = data.purchases.reduce((sum, p) => {
            const status = String(p.payment_status || '').toLowerCase().trim();
            return sum + (status !== 'paid' ? Number(p.total_amount || 0) : 0);
        }, 0);

        document.getElementById(
            'viewPurchaseAmount'
        ).textContent = '₱' + purchaseTotal.toLocaleString('en-PH', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });

        document.getElementById(
            'viewUtangAmount'
        ).textContent = '₱' + utangTotal.toLocaleString('en-PH', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });


        // ====================================================
        // BUILD PURCHASE HISTORY TABLE
        // ====================================================

        let html = '';


        data.purchases.forEach(p => {

            // ------------------------------------------------
            // PAYMENT STATUS
            // ------------------------------------------------

            const status =
                String(
                    p.payment_status || ''
                )
                .toLowerCase()
                .trim();


            let statusClass =
                'bg-danger';


            if(status === 'paid'){

                statusClass =
                    'bg-success';

            }else if(status === 'partial'){

                statusClass =
                    'bg-warning text-dark';
            }


            // ------------------------------------------------
            // ITEM COUNT
            // ------------------------------------------------

            const itemCount =
                Number(
                    p.item_count || 0
                );


            // ------------------------------------------------
            // ITEM NAMES
            // ------------------------------------------------

            const rawItemNames =
                p.item_names ||
                'No items';


            /*
             * The PHP endpoint separates each product
             * using |||
             *
             * Example:
             *
             * Jasmine - Premium|||Sinandomeng - Regular
             *
             * We turn those into individual lines.
             */

            const itemList =
                String(rawItemNames)
                    .split('|||')
                    .map(item => item.trim())
                    .filter(item => item !== '');


            let itemNamesHtml = '';


            if(itemList.length > 0){

                itemNamesHtml =
                    itemList
                        .map(item => {

                            return `
                                <div class="purchase-item-name">

                                    <i
                                        class="fa-solid fa-circle me-1"
                                        style="
                                            font-size:5px;
                                            vertical-align:middle;
                                        "
                                    ></i>

                                    ${escapeHtml(item)}

                                </div>
                            `;

                        })
                        .join('');

            }else{

                itemNamesHtml = `
                    <div class="text-muted">
                        No items
                    </div>
                `;
            }


            // ------------------------------------------------
            // TOTAL
            // ------------------------------------------------

            const totalAmount =
                Number(
                    p.total_amount || 0
                );


            const formattedAmount =
                totalAmount.toLocaleString(
                    'en-PH',
                    {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    }
                );


            // ------------------------------------------------
            // BUILD ROW
            // ------------------------------------------------

            html += `

                <tr>

                    <td>
                        ${escapeHtml(
                            p.sale_date || 'N/A'
                        )}
                    </td>


                    <td>
                        <strong>
                            #${escapeHtml(
                                String(
                                    p.sale_id
                                )
                            )}
                        </strong>
                    </td>


                    <td>

                        <div class="fw-semibold mb-1">

                            ${itemCount}
                            item(s)

                        </div>


                        <div class="purchase-items-list">

                            ${itemNamesHtml}

                        </div>

                    </td>


                    <td class="text-end">

                        ₱${formattedAmount}

                    </td>


                    <td class="text-center">

                        <span
                            class="badge ${statusClass}"
                        >

                            ${escapeHtml(
                                p.payment_status ||
                                'Unknown'
                            )}

                        </span>

                    </td>

                </tr>

            `;
        });


        // ====================================================
        // INSERT INTO TABLE
        // ====================================================

        document.getElementById(
            'purchase-table-body'
        ).innerHTML = html;


        document.getElementById(
            'purchase-table-container'
        ).style.display = 'block';

    })


    .catch(err => {

        console.error(
            '❌ Purchase history error:',
            err
        );


        document.getElementById(
            'purchase-loading'
        ).style.display = 'none';


        document.getElementById(
            'purchase-error'
        ).style.display = 'block';

    });


    // ========================================================
    // LOAD PENALTY DETAILS
    // ========================================================

    if(penalties > 0){

        fetch(
            'get_penalty_details.php?customer_id=' +
            encodeURIComponent(id)
        )

        .then(response =>
            response.json()
        )

        .then(data => {

            if(
                data.success &&
                data.has_penalties
            ){

                populatePenaltyTable(
                    data.penalties
                );
            }

        })

        .catch(error =>
            console.error(
                'Error fetching penalties:',
                error
            )
        );

    }else{

        document.getElementById(
            'penaltyBreakdown'
        ).style.display = 'none';
    }


    // ========================================================
    // SHOW MODAL
    // ========================================================

    const modal =
        new bootstrap.Modal(
            document.getElementById(
                'viewCustomerModal'
            )
        );


    modal.show();
}


// ============================================================
// POPULATE PENALTY TABLE
// ============================================================

function populatePenaltyTable(penalties){

    const tbody =
        document.getElementById(
            'penaltyTableBody'
        );


    tbody.innerHTML = '';


    penalties.forEach(penalty => {

        const row =
            document.createElement('tr');


        const lastCalcDate =
            new Date(
                penalty.last_calculated
            ).toLocaleDateString(
                'en-US',
                {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric'
                }
            );


        const dueDate =
            new Date(
                penalty.due_date
            ).toLocaleDateString(
                'en-US',
                {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric'
                }
            );


        row.innerHTML = `

            <td>
                <strong>
                    ${escapeHtml(
                        penalty.reference
                    )}
                </strong>
            </td>


            <td>
                ${dueDate}
            </td>


            <td>

                <span class="badge bg-warning text-dark">

                    ${
                        penalty.days_late > 0
                            ? 'Overdue'
                            : '—'
                    }

                </span>

            </td>


            <td>
                One-time overdue fee
            </td>


            <td class="text-end text-danger">

                <strong>

                    ₱${parseFloat(
                        penalty.penalty_due
                    ).toFixed(2)}

                </strong>

            </td>


            <td class="text-end">

                <small class="text-muted">

                    ${lastCalcDate}

                </small>

            </td>

        `;


        tbody.appendChild(row);

    });


    document.getElementById(
        'penaltyBreakdown'
    ).style.display = 'block';
}


// ============================================================
// EDIT CUSTOMER
// ============================================================

function editCustomer(
    id,
    firstName,
    lastName,
    phone,
    email,
    address
){

    document.getElementById(
        'editCustomerId'
    ).value = id;


    document.getElementById(
        'editFirstName'
    ).value = firstName;


    document.getElementById(
        'editLastName'
    ).value = lastName;


    document.getElementById(
        'editPhone'
    ).value = phone;

    document.getElementById(
        'editEmail'
    ).value = email;


    document.getElementById(
        'editAddress'
    ).value = address;


    const modal =
        new bootstrap.Modal(
            document.getElementById(
                'editCustomerModal'
            )
        );


    modal.show();
}


// ============================================================
// INITIAL LOAD + POLLING
// ============================================================

pollCustomersPage();

const customerSearchInput = document.getElementById('customerSearchInput');
if(customerSearchInput){
    customerSearchInput.addEventListener('input', function(){
        handleCustomerSearchInput(this.value);
    });
}

function resetCustomerSearchIfNoQuery(){
    const url = new URL(window.location.href);
    const hasQuery = url.searchParams.has('q') && url.searchParams.get('q') !== '';
    const input = document.getElementById('customerSearchInput');

    if(input && !hasQuery){
        input.value = '';
        customerSearchQuery = '';
    }
}

document.addEventListener('DOMContentLoaded', function(){
    resetCustomerSearchIfNoQuery();
    pollCustomersPage();
});

window.addEventListener('pageshow', function(event){
    if(event.persisted){
        resetCustomerSearchIfNoQuery();
        pollCustomersPage();
    }
});

setInterval(
    pollCustomersPage,
    customerPollIntervalMs
);

</script>


</body>

</html>
