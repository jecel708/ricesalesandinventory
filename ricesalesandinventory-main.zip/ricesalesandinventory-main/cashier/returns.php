<?php
session_start();
if(!isset($_SESSION['user_id'])){
header("Location: ../login.php");
exit;
}
if(strtolower($_SESSION['role'] ?? '') !== 'cashier'){
header("Location: ../login.php");
exit;
}

$username = $_SESSION['username'] ?? 'Cashier';
$user_id = (int)($_SESSION['user_id'] ?? 0);

include '../config/db.php';
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$success = $_GET['success'] ?? '';
$error = $_GET['error'] ?? '';

if(empty($_SESSION['csrf_token'])){
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = (string)$_SESSION['csrf_token'];

function require_csrf_or_redirect(string $target): void {
  $posted = (string)($_POST['csrf_token'] ?? '');
  $stored = (string)($_SESSION['csrf_token'] ?? '');
  if($posted === '' || $stored === '' || !hash_equals($stored, $posted)){
    header("Location: {$target}?error=" . urlencode("Invalid request token. Please refresh and try again."));
    exit;
  }
}

if(isset($_GET['ajax']) && $_GET['ajax'] === 'sale_items'){
$sale_id = (int)($_GET['sale_id'] ?? 0);

// Ensure sale belongs to this cashier
$stmt = $conn->prepare("SELECT sale_id FROM sales WHERE sale_id=? AND user_id=? LIMIT 1");
if(!$stmt){
header('Content-Type: application/json');
echo json_encode(['error' => 'Prepare error: '.$conn->error]);
exit;
}
$stmt->bind_param("ii", $sale_id, $user_id);
$stmt->execute();
$owned = $stmt->get_result()->fetch_assoc();
$stmt->close();

if(!$owned){
header('Content-Type: application/json');
echo json_encode([]);
exit;
}

// Load products from sales_items + compute max returnable
$sql = "
SELECT
si.product_id,
CONCAT(p.variety,' - ',p.grade) AS label,
IFNULL(SUM(si.qty_kg),0) AS sold_qty,
IFNULL((
SELECT SUM(r.qty_returned)
FROM returns r
WHERE r.sale_id = si.sale_id
AND r.product_id = si.product_id
AND LOWER(r.status) IN ('pending','approved')
),0) AS returned_qty
FROM sales_items si
JOIN products p ON p.product_id = si.product_id
WHERE si.sale_id = ?
GROUP BY si.product_id
ORDER BY label ASC
";

$stmt = $conn->prepare($sql);
if(!$stmt){
header('Content-Type: application/json');
echo json_encode(['error' => 'Prepare error: '.$conn->error]);
exit;
}
$stmt->bind_param("i", $sale_id);
$stmt->execute();
$res = $stmt->get_result();

$out = [];
while($r = $res->fetch_assoc()){
$sold = (float)$r['sold_qty'];
$ret = (float)$r['returned_qty'];
$max = max(0, $sold - $ret);

// Only show if there is still returnable qty
if($max > 0){
$out[] = [
'product_id' => (int)$r['product_id'],
'label' => $r['label'],
'sold_qty' => $sold,
'returned_qty' => $ret,
'max_qty' => $max
];
}
}

$stmt->close();
header('Content-Type: application/json');
echo json_encode($out);
exit;
}

if(isset($_POST['create_return'])){
require_csrf_or_redirect('returns.php');
$sale_id = (int)($_POST['sale_id'] ?? 0);
$product_id= (int)($_POST['product_id'] ?? 0);
$qty = (float)($_POST['qty_returned'] ?? 0);
$reason = trim($_POST['reason'] ?? '');

if($sale_id<=0 || $product_id<=0 || $qty<=0 || $reason===''){
header("Location: returns.php?error=" . urlencode("Please fill up all fields correctly."));
exit;
}

// Make sure this sale belongs to the cashier
$stmt = $conn->prepare("SELECT sale_id FROM sales WHERE sale_id=? AND user_id=? LIMIT 1");
if(!$stmt){ die("SQL PREPARE ERROR: ".$conn->error); }
$stmt->bind_param("ii", $sale_id, $user_id);
$stmt->execute();
$owned = $stmt->get_result()->fetch_assoc();
$stmt->close();

if(!$owned){
header("Location: returns.php?error=" . urlencode("You can only file returns for your own sales."));
exit;
}

// Validate product exists in that sale + qty not exceeding sold qty
$stmt = $conn->prepare("
SELECT IFNULL(SUM(qty_kg),0) AS sold_qty
FROM sales_items
WHERE sale_id=? AND product_id=?
");
if(!$stmt){ die("SQL PREPARE ERROR: ".$conn->error); }
$stmt->bind_param("ii", $sale_id, $product_id);
$stmt->execute();
$sold = (float)($stmt->get_result()->fetch_assoc()['sold_qty'] ?? 0);
$stmt->close();

if($sold <= 0){
header("Location: returns.php?error=" . urlencode("This product is not part of Sale #{$sale_id}."));
exit;
}

// Compute already-returned (approved + pending) to prevent exceeding sold
$stmt = $conn->prepare("
SELECT IFNULL(SUM(qty_returned),0) AS returned_qty
FROM returns
WHERE sale_id=? AND product_id=? AND LOWER(status) IN ('pending','approved')
");
if(!$stmt){ die("SQL PREPARE ERROR: ".$conn->error); }
$stmt->bind_param("ii", $sale_id, $product_id);
$stmt->execute();
$already = (float)($stmt->get_result()->fetch_assoc()['returned_qty'] ?? 0);
$stmt->close();

$maxAllowed = max(0, $sold - $already);
if($qty > $maxAllowed){
header("Location: returns.php?error=" . urlencode("Qty exceeds allowed return. Max allowed: ".number_format($maxAllowed,2)." kg"));
exit;
}

// Insert return request
$stmt = $conn->prepare("
INSERT INTO returns (sale_id, product_id, qty_returned, reason, return_date, status)
VALUES (?, ?, ?, ?, NOW(), 'PENDING')
");
if(!$stmt){ die("SQL PREPARE ERROR: ".$conn->error); }
$stmt->bind_param("iids", $sale_id, $product_id, $qty, $reason);
$stmt->execute();
$stmt->close();

header("Location: returns.php?success=" . urlencode("Return request submitted (PENDING)."));
exit;
}

$sales = $conn->prepare("
SELECT s.sale_id, s.sale_date, s.status AS sale_status, c.first_name, c.last_name
FROM sales s
LEFT JOIN customers c ON s.customer_id = c.customer_id
WHERE s.user_id=?
ORDER BY s.sale_date DESC
LIMIT 50
");
if(!$sales){ die("SQL PREPARE ERROR: ".$conn->error); }
$sales->bind_param("i", $user_id);
$sales->execute();
$salesRes = $sales->get_result();
$sales->close();

$q = trim($_GET['q'] ?? '');
$filter_status = strtolower(trim($_GET['status'] ?? 'all')); // all|pending|approved|rejected

$where = "WHERE 1=1";
$params = [];
$types = "";

if($q !== ''){
$where .= " AND (r.return_id LIKE CONCAT('%',?,'%') OR r.sale_id LIKE CONCAT('%',?,'%') OR p.variety LIKE CONCAT('%',?,'%'))";
$params[] = $q; $params[] = $q; $params[] = $q;
$types .= "sss";
}
if(in_array($filter_status, ['pending','approved','rejected'], true)){
$where .= " AND LOWER(r.status)=?";
$params[] = $filter_status;
$types .= "s";
}

$listSql = "
SELECT
r.return_id, r.sale_id, r.product_id, r.qty_returned, r.reason, r.return_date, r.status,
s.status AS sale_status,
p.variety, p.grade,
c.first_name, c.last_name
FROM returns r
JOIN sales s ON r.sale_id = s.sale_id
LEFT JOIN products p ON r.product_id = p.product_id
LEFT JOIN customers c ON s.customer_id = c.customer_id
{$where}
ORDER BY r.return_date DESC, r.return_id DESC
";

$stmt = $conn->prepare($listSql);
if(!$stmt){ die("SQL PREPARE ERROR: ".$conn->error."<br><pre>$listSql</pre>"); }
if($types !== ""){
  $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$returnsRes = $stmt->get_result();
$stmt->close();

$suggestionStmt = $conn->prepare("
  SELECT DISTINCT r.return_id, r.sale_id, p.variety, p.grade
  FROM returns r
  JOIN sales s ON r.sale_id = s.sale_id
  LEFT JOIN products p ON r.product_id = p.product_id
  WHERE s.user_id = ?
  ORDER BY r.return_id DESC
");
if(!$suggestionStmt){ die("SQL PREPARE ERROR: ".$conn->error); }
$suggestionStmt->bind_param("i", $user_id);
$suggestionStmt->execute();
$suggestionResult = $suggestionStmt->get_result();
$suggestionStmt->close();

$searchSuggestions = [];
while($suggestion = $suggestionResult->fetch_assoc()){
  $returnId = (string)(int)$suggestion['return_id'];
  $saleId = (string)(int)$suggestion['sale_id'];
  $variety = trim((string)($suggestion['variety'] ?? ''));
  $grade = trim((string)($suggestion['grade'] ?? ''));

  $searchSuggestions[$returnId] = 'Return #'.$returnId;
  $searchSuggestions[$saleId] = 'Sale #'.$saleId;
  if($variety !== ''){
    $searchSuggestions[$variety] = trim($variety.' - '.$grade);
  }
}

if(isset($_GET['ajax']) && $_GET['ajax'] === 'live'){
  $rows = [];
  if($returnsRes){
    while($r = $returnsRes->fetch_assoc()){
      $saleStatus = strtolower(trim((string)($r['sale_status'] ?? '')));
      $cust = trim(($r['first_name'] ?? '').' '.($r['last_name'] ?? ''));
      if($saleStatus !== 'unpaid' || $cust === '') $cust = 'Walk-in Customer';
      $prod = trim(($r['variety'] ?? 'N/A') . " - " . ($r['grade'] ?? ''));
      $st = strtolower(trim($r['status'] ?? 'pending'));
      $rows[] = [
        'return_id' => (int)$r['return_id'],
        'sale_id' => (int)$r['sale_id'],
        'customer' => $cust,
        'product' => $prod,
        'qty_returned' => (float)$r['qty_returned'],
        'return_date' => (string)($r['return_date'] ?? ''),
        'status' => $st,
        'reason' => (string)($r['reason'] ?? ''),
      ];
    }
  }

  $counts = ['pending' => 0, 'approved' => 0, 'rejected' => 0];
  $countRes = $conn->query("
    SELECT LOWER(status) AS status_key, COUNT(*) AS cnt
    FROM returns
    WHERE LOWER(status) IN ('pending','approved','rejected')
    GROUP BY LOWER(status)
  ");
  if($countRes){
    while($c = $countRes->fetch_assoc()){
      $key = strtolower((string)($c['status_key'] ?? ''));
      if(isset($counts[$key])) $counts[$key] = (int)($c['cnt'] ?? 0);
    }
  }

  header('Content-Type: application/json; charset=utf-8');
  echo json_encode([
    'ok' => true,
    'rows' => $rows,
    'summary' => $counts,
  ]);
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Returns | Cashier</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">


<link href="../css/layout.css" rel="stylesheet">
<link href="../css/cashier-returns.css" rel="stylesheet">
<link href="../css/cashier-mobile.css" rel="stylesheet">
</head>

<body>

<?php
$profileLink = 'cashier_profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>

<div class="container-fluid">
<div class="row">

<?php include '../includes/cashier_sidebar.php'; ?>

<!-- MAIN -->
<main class="col-lg-10 ms-sm-auto px-4 main-content">
<div class="py-4">

<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
<div>
<h3 class="fw-bold mb-1">Returns</h3>
<div class="text-muted">File return requests. Owner will approve and update inventory.</div>
</div>
</div>

<?php if($success): ?><div class="alert alert-success py-2"><?= h($success) ?></div><?php endif; ?>
<?php if($error): ?><div class="alert alert-danger py-2"><?= h($error) ?></div><?php endif; ?>

<div class="row g-4">

<!-- CREATE RETURN -->
<div class="col-12 col-xl-4">
<div class="card modern-card">
<div class="card-body">
<h5 class="fw-bold mb-3">Create Return Request</h5>

<form method="POST" id="returnForm">
<input type="hidden" name="create_return" value="1">
<input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">

<div class="mb-3">
<label class="form-label">Sale</label>
<select class="form-select" name="sale_id" id="saleSelect" required>
<option value="">Select Sale</option>
<?php while($s = $salesRes->fetch_assoc()): ?>
<?php
$saleStatus = strtolower(trim((string)($s['sale_status'] ?? '')));
$cust = trim(($s['first_name'] ?? '').' '.($s['last_name'] ?? ''));
if($saleStatus !== 'unpaid' || $cust === '') $cust = 'Walk-in Customer';
$label = "#".$s['sale_id']." — ".$cust." — ".date("M d, Y", strtotime($s['sale_date']));
?>
<option value="<?= (int)$s['sale_id'] ?>"><?= h($label) ?></option>
<?php endwhile; ?>
</select>
<div class="small-muted mt-1">Tip: Pick the correct sale first.</div>
</div>

<!-- ENHANCED: Product dropdown instead of manual product_id -->
<div class="mb-3">
<label class="form-label">Product (from Sale Items)</label>
<select class="form-select" name="product_id" id="productSelect" required disabled>
<option value="">Select Sale first</option>
</select>
<div class="small-muted mt-1" id="maxHint" style="display:none;">
Max returnable: <b id="maxQtyText">0</b> kg
</div>
</div>

<div class="mb-3">
<label class="form-label">Qty Returned (kg)</label>
<input type="number" step="0.01" min="0" class="form-control" name="qty_returned" id="qtyInput" required>
</div>

<div class="mb-3">
<label class="form-label">Reason</label>
<textarea class="form-control" name="reason" rows="3" required placeholder="e.g. Damaged packaging"></textarea>
</div>

<button class="btn btn-dark w-100">
<i class="fa-solid fa-paper-plane me-1"></i> Submit (PENDING)
</button>

</form>
</div>
</div>
</div>

<!-- RETURNS LIST -->
<div class="col-12 col-xl-8">
<div class="card modern-card mb-3">
<div class="card-body">
<form class="row g-2 align-items-end" method="GET">
<div class="col-12 col-md-6">
<label class="form-label" for="returnsSearch">Search (Return ID / Sale ID / Variety)</label>
<input class="form-control" id="returnsSearch" name="q" list="returnsSearchSuggestions" value="<?= h($q) ?>" placeholder="e.g. 10 or Jasmine" autocomplete="off">
<datalist id="returnsSearchSuggestions">
<?php foreach($searchSuggestions as $value => $label): ?>
<option value="<?= h($value) ?>" label="<?= h($label) ?>"></option>
<?php endforeach; ?>
</datalist>
</div>
<div class="col-12 col-md-3">
<label class="form-label">Status</label>
<select class="form-select" name="status">
<option value="all" <?= $filter_status==='all'?'selected':'' ?>>All</option>
<option value="pending" <?= $filter_status==='pending'?'selected':'' ?>>Pending</option>
<option value="approved" <?= $filter_status==='approved'?'selected':'' ?>>Approved</option>
<option value="rejected" <?= $filter_status==='rejected'?'selected':'' ?>>Rejected</option>
</select>
</div>
<div class="col-12 col-md-3 d-grid">
<button class="btn btn-outline-dark"><i class="fa-solid fa-filter me-1"></i> Filter</button>
</div>
</form>
</div>
</div>

<div class="card modern-card">
<div class="card-body table-responsive">
<table class="table table-striped align-middle mb-0 returns-table" id="returnsTable">
<thead class="table-dark">
<tr>
<th>Return #</th>
<th>Sale #</th>
<th>Customer</th>
<th>Product</th>
<th>Qty</th>
<th>Date</th>
<th>Status</th>
<th>Reason</th>
</tr>
</thead>
<tbody id="returnsTableBody">
<?php if($returnsRes && $returnsRes->num_rows > 0): ?>
<?php while($r = $returnsRes->fetch_assoc()): ?>
<?php
$saleStatus = strtolower(trim((string)($r['sale_status'] ?? '')));
$cust = trim(($r['first_name'] ?? '').' '.($r['last_name'] ?? ''));
if($saleStatus !== 'unpaid' || $cust === '') $cust = 'Walk-in Customer';
$prod = trim(($r['variety'] ?? 'N/A') . " - " . ($r['grade'] ?? ''));
$st = strtolower(trim($r['status'] ?? 'pending'));
$reasonFull = (string)($r['reason'] ?? '');
?>
<tr>
<td class="fw-bold"><?= (int)$r['return_id'] ?></td>
<td><?= (int)$r['sale_id'] ?></td>
<td><?= h($cust) ?></td>
<td><?= h($prod) ?></td>
<td class="fw-bold"><?= number_format((float)$r['qty_returned'],2) ?> kg</td>
<td><?= $r['return_date'] ? date("M d, Y h:i A", strtotime($r['return_date'])) : '' ?></td>
<td>
<?php if($st==='approved'): ?>
<span class="badge bg-success">APPROVED</span>
<?php elseif($st==='rejected'): ?>
<span class="badge bg-danger">REJECTED</span>
<?php else: ?>
<span class="badge bg-warning text-dark">PENDING</span>
<?php endif; ?>
</td>
<td style="max-width:320px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
<?= h($reasonFull) ?>
<?php if(mb_strlen($reasonFull) > 35): ?>
<button
type="button"
class="btn btn-sm btn-link p-0 ms-2"
data-bs-toggle="modal"
data-bs-target="#reasonModal"
data-reason="<?= h($reasonFull) ?>"
>View</button>
<?php endif; ?>
</td>
</tr>
<?php endwhile; ?>
<?php else: ?>
<tr><td colspan="8" class="text-center text-muted py-4">No return requests found.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
</div>

<div class="small-muted mt-2" id="returnsLiveHint">
Live updates enabled. Approved returns will move here automatically.
</div>

<div class="small-muted mt-2">
Note: Only Owmer approves returns → then inventory logs will record an <b>IN</b> transaction.
</div>
</div>

</div>

</div>
</main>

</div>
</div>

<!-- Reason Modal (Bootstrap) -->
<div class="modal fade" id="reasonModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title">Return Reason</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body" id="reasonBody" style="white-space:pre-wrap;"></div>
<div class="modal-footer">
<button type="button" class="btn btn-dark" data-bs-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="../js/cashier-returns.js"></script>
<script>
(function () {
  const pollIntervalMs = 5000;
  let pollingInFlight = false;
  const bodyEl = document.getElementById('returnsTableBody');
  const hintEl = document.getElementById('returnsLiveHint');
  const summaryBadges = Array.from(document.querySelectorAll('.card-kpi .kpi-value'));

  function escapeHtml(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function statusBadge(status) {
    if (status === 'approved') return '<span class="badge bg-success">APPROVED</span>';
    if (status === 'rejected') return '<span class="badge bg-danger">REJECTED</span>';
    return '<span class="badge bg-warning text-dark">PENDING</span>';
  }

  function formatReturnDate(value) {
    if (!value) return '';
    const match = String(value).match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/);
    if (!match) return String(value);

    const [, year, month, day, hours = '00', minutes = '00', seconds = '00'] = match;
    const date = new Date(Number(year), Number(month) - 1, Number(day), Number(hours), Number(minutes), Number(seconds));
    return date.toLocaleString(undefined, {
      year: 'numeric', month: 'numeric', day: 'numeric',
      hour: 'numeric', minute: '2-digit', second: '2-digit'
    });
  }

  function renderRows(rows) {
    if (!bodyEl) return;
    if (!Array.isArray(rows) || rows.length === 0) {
      bodyEl.innerHTML = '<tr><td colspan="8" class="text-center text-muted py-4">No return requests found.</td></tr>';
      return;
    }

    bodyEl.innerHTML = rows.map((r) => {
      const reason = String(r.reason || '');
      const hasLongReason = reason.length > 35;
      const reasonId = `reason-${r.return_id}`;
      return `
        <tr>
          <td class="fw-bold">${Number(r.return_id || 0)}</td>
          <td>${Number(r.sale_id || 0)}</td>
          <td>${escapeHtml(r.customer || 'Walk-in Customer')}</td>
          <td>${escapeHtml(r.product || 'N/A')}</td>
          <td class="fw-bold">${Number(r.qty_returned || 0).toFixed(2)} kg</td>
          <td>${escapeHtml(formatReturnDate(r.return_date))}</td>
          <td>${statusBadge(String(r.status || 'pending').toLowerCase())}</td>
          <td style="max-width:320px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
            ${escapeHtml(reason)}
            ${hasLongReason ? `
              <button
                type="button"
                class="btn btn-sm btn-link p-0 ms-2"
                data-bs-toggle="modal"
                data-bs-target="#reasonModal"
                data-reason="${escapeHtml(reason)}"
              >View</button>
            ` : ''}
          </td>
        </tr>
      `;
    }).join('');
  }

  function updateSummary(summary) {
    if (!Array.isArray(summaryBadges) || summaryBadges.length < 3) return;
    const safe = summary || {};
    summaryBadges[0].textContent = Number(safe.pending || 0).toLocaleString();
    summaryBadges[1].textContent = Number(safe.approved || 0).toLocaleString();
    summaryBadges[2].textContent = Number(safe.rejected || 0).toLocaleString();
  }

  async function pollReturns() {
    if (pollingInFlight) return;
    pollingInFlight = true;
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('ajax', 'live');
      const response = await fetch(url.toString(), { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      const data = await response.json();
      if (!data || !data.ok) return;
      renderRows(data.rows);
      updateSummary(data.summary);
      if (hintEl) hintEl.textContent = 'Live updates enabled. Last checked just now.';
    } catch (error) {
      console.error('Cashier returns live poll failed:', error);
      if (hintEl) hintEl.textContent = 'Live updates paused temporarily.';
    } finally {
      pollingInFlight = false;
    }
  }

  pollReturns();
  window.setInterval(pollReturns, pollIntervalMs);
})();
</script>

</body>
</html>
