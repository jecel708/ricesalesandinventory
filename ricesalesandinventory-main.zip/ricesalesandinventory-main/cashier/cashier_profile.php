<?php
session_start();
if(!isset($_SESSION['user_id'])){
  header("Location: ../login.php");
  exit;
}
if(strtolower($_SESSION['role'] ?? '') !== 'cashier'){
  header("Location: ../login.php");
  exit;
}

include "../config/db.php";
require_once "../includes/mfa.php";

$user_id = (int)$_SESSION['user_id'];
$username = $_SESSION['username'] ?? 'Cashier';

function h($v){
  return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

$csrf_token = (string)($_SESSION['csrf_token'] ?? '');
if($csrf_token === ''){
  $csrf_token = bin2hex(random_bytes(32));
  $_SESSION['csrf_token'] = $csrf_token;
}

function require_csrf_token_or_redirect(string $target): void {
  $posted = (string)($_POST['csrf_token'] ?? '');
  $stored = (string)($_SESSION['csrf_token'] ?? '');
  if($posted === '' || $stored === '' || !hash_equals($stored, $posted)){
    header("Location: {$target}?error=" . urlencode("Session expired. Please try again."));
    exit;
  }
}

$success = $_GET['success'] ?? '';
$error = $_GET['error'] ?? '';

/* =====================
Fetch cashier data
===================== */
$stmt = $conn->prepare("
  SELECT user_id, username, first_name, last_name, phone, email, password, role, status
  FROM users
  WHERE user_id = ?
  LIMIT 1
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if(!$user){
  header("Location: ../logout.php");
  exit;
}
if (empty($user['display_name'])) {
  $user['display_name'] = trim((string)($user['first_name'] ?? '') . ' ' . (string)($user['last_name'] ?? ''));
}

// compute trusted device expiry for UI badge
$trustedDeviceExpiry = null;
try {
  if (isset($conn) && $conn instanceof mysqli) {
    $trustedDeviceExpiry = mfa_get_trusted_device_expiry($conn, $user_id);
  }
} catch (Throwable $e) {
  $trustedDeviceExpiry = null;
}

if($_SERVER['REQUEST_METHOD'] === 'POST'){
  require_csrf_token_or_redirect('cashier_profile.php');
}

/* =====================
Update profile info
===================== */
if(isset($_POST['update_profile'])){
  $first = trim($_POST['first_name'] ?? '');
  $last  = trim($_POST['last_name'] ?? '');
  $displayName = trim($_POST['display_name'] ?? '');
  $phone = trim($_POST['phone'] ?? '');
  $email = trim(strtolower((string)($_POST['email'] ?? '')));

  if($first === '' || $last === '' || $displayName === ''){
    header("Location: cashier_profile.php?error=" . urlencode("Display name, first name, and last name are required."));
    exit;
  }
  if($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)){
    header("Location: cashier_profile.php?error=" . urlencode("A valid email is required."));
    exit;
  }

  $check = $conn->prepare("SELECT user_id FROM users WHERE LOWER(email)=LOWER(?) AND user_id<>? LIMIT 1");
  $check->bind_param("si", $email, $user_id);
  $check->execute();
  $existsEmail = $check->get_result()->fetch_assoc();
  $check->close();

  if($existsEmail){
    header("Location: cashier_profile.php?error=" . urlencode("Email already exists."));
    exit;
  }

  $up = $conn->prepare("
    UPDATE users
    SET display_name = ?, first_name = ?, last_name = ?, phone = ?, email = ?
    WHERE user_id = ?
  ");
  $up->bind_param("sssssi", $displayName, $first, $last, $phone, $email, $user_id);
  $up->execute();
  $up->close();

  header("Location: cashier_profile.php?success=" . urlencode("Profile updated successfully."));
  exit;
}

/* =====================
Change password
===================== */
if(isset($_POST['change_password'])){
  if(empty($_SESSION['cashier_pwd_change_pending'])){
    header("Location: cashier_profile.php?error=" . urlencode("No pending OTP verification. Start password change again."));
    exit;
  }

  $otp = trim((string)($_POST['otp'] ?? ''));
  if(!preg_match('/^[0-9]{6}$/', $otp)){
    header("Location: cashier_profile.php?error=" . urlencode("Enter a valid 6-digit OTP code."));
    exit;
  }

  $stmt = $conn->prepare("SELECT id, otp_hash, expires_at, attempts, max_attempts, used_at FROM user_email_otp_challenges WHERE user_id=? ORDER BY id DESC LIMIT 1");
  $stmt->bind_param("i", $user_id);
  $stmt->execute();
  $challenge = $stmt->get_result()->fetch_assoc();
  $stmt->close();

  if(!$challenge){
    header("Location: cashier_profile.php?error=" . urlencode("No OTP challenge found. Please request a new OTP."));
    exit;
  }
  if(!empty($challenge['used_at'])){
    header("Location: cashier_profile.php?error=" . urlencode("This OTP was already used. Request a new OTP."));
    exit;
  }
  if(strtotime((string)$challenge['expires_at']) < time()){
    header("Location: cashier_profile.php?error=" . urlencode("OTP expired. Request a new OTP."));
    exit;
  }

  $attempts = (int)($challenge['attempts'] ?? 0);
  $maxAttempts = (int)($challenge['max_attempts'] ?? 5);
  if($attempts >= $maxAttempts){
    header("Location: cashier_profile.php?error=" . urlencode("Too many OTP attempts. Request a new OTP."));
    exit;
  }
  if(!password_verify($otp, (string)$challenge['otp_hash'])){
    $up = $conn->prepare("UPDATE user_email_otp_challenges SET attempts=attempts+1 WHERE id=?");
    if($up){
      $cid = (int)$challenge['id'];
      $up->bind_param("i", $cid);
      $up->execute();
      $up->close();
    }
    $left = max(0, $maxAttempts - ($attempts + 1));
    header("Location: cashier_profile.php?error=" . urlencode("Incorrect OTP. {$left} attempt(s) left."));
    exit;
  }

  $mark = $conn->prepare("UPDATE user_email_otp_challenges SET used_at=NOW() WHERE id=?");
  if($mark){
    $cid = (int)$challenge['id'];
    $mark->bind_param("i", $cid);
    $mark->execute();
    $mark->close();
  }

  $pendingHash = (string)($_SESSION['cashier_pwd_change_hash'] ?? '');
  if($pendingHash === ''){
    header("Location: cashier_profile.php?error=" . urlencode("Pending password data missing. Start again."));
    exit;
  }

  $up = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
  $up->bind_param("si", $pendingHash, $user_id);
  $up->execute();
  $up->close();

  $wipe = $conn->prepare("DELETE FROM user_trusted_devices WHERE user_id=?");
  if($wipe){
    $wipe->bind_param("i", $user_id);
    $wipe->execute();
    $wipe->close();
  }
  mfa_clear_trusted_cookie();

  unset($_SESSION['cashier_pwd_change_pending'], $_SESSION['cashier_pwd_change_hash']);

  if($conn->query("SHOW TABLES LIKE 'activity_logs'")->num_rows > 0){
    $type = "PASSWORD_CHANGE";
    $desc = "Changed cashier password with OTP verification and revoked trusted devices";
    $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, activity_type, description, created_at) VALUES (?,?,?,NOW())");
    if($stmt){
      $stmt->bind_param("iss", $user_id, $type, $desc);
      $stmt->execute();
      $stmt->close();
    }
  }

  header("Location: cashier_profile.php?success=" . urlencode("Password changed successfully."));
  exit;
}

if(isset($_POST['request_change_password_otp'])){
  $old = $_POST['old_password'] ?? '';
  $new = $_POST['new_password'] ?? '';
  $con = $_POST['confirm_password'] ?? '';

  if($old === '' || $new === '' || $con === ''){
    header("Location: cashier_profile.php?error=" . urlencode("All password fields are required."));
    exit;
  }

  if($new !== $con){
    header("Location: cashier_profile.php?error=" . urlencode("Passwords do not match."));
    exit;
  }

  if(strlen($new) < 6){
    header("Location: cashier_profile.php?error=" . urlencode("Password must be at least 6 characters."));
    exit;
  }

  if(!password_verify($old, $user['password'])){
    header("Location: cashier_profile.php?error=" . urlencode("Old password is incorrect."));
    exit;
  }

  $email = trim((string)($user['email'] ?? ''));
  if($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)){
    header("Location: cashier_profile.php?error=" . urlencode("No valid email found for this account."));
    exit;
  }

  $hashed = password_hash($new, PASSWORD_DEFAULT);
  if($hashed === false){
    header("Location: cashier_profile.php?error=" . urlencode("Unable to process new password. Try again."));
    exit;
  }

  if(!mfa_send_otp_for_user($conn, $user_id, $email)){
    header("Location: cashier_profile.php?error=" . urlencode("Unable to send OTP email right now."));
    exit;
  }

  $_SESSION['cashier_pwd_change_pending'] = true;
  $_SESSION['cashier_pwd_change_hash'] = $hashed;

  header("Location: cashier_profile.php?success=" . urlencode("OTP sent to your email. Enter it below to confirm password change."));
  exit;
}

if(isset($_POST['cancel_change_password'])){
  unset($_SESSION['cashier_pwd_change_pending'], $_SESSION['cashier_pwd_change_hash']);
  header("Location: cashier_profile.php?success=" . urlencode("Pending password change canceled."));
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cashier Profile</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="../css/layout.css" rel="stylesheet">
<link href="../css/cashier-profile.css" rel="stylesheet">
<link href="../css/cashier-mobile.css" rel="stylesheet">
<style>
.strength-container { margin-top: 0.5rem; margin-bottom: 0.25rem; }
.strength-bar { height: 8px; border-radius: 4px; background: #e9ecef; overflow: hidden; }
.strength-fill { height: 100%; width: 0%; border-radius: 4px; transition: all 0.3s ease; }
.strength-text { font-size: 0.85rem; font-weight: 500; margin-top: 0.25rem; }
.strength-weak { background-color: #dc3545; width: 25%; }
.strength-fair { background-color: #ffc107; width: 50%; }
.strength-good { background-color: #0dcaf0; width: 75%; }
.strength-strong { background-color: #198754; width: 100%; }
.requirement-list { list-style: none; padding: 0; margin: 0.5rem 0; font-size: 0.85rem; }
.requirement-list li { padding: 0.15rem 0; }
.requirement-list li i { margin-right: 0.5rem; font-size: 0.9rem; }
.req-pass { color: #198754; }
.req-fail { color: #6c757d; }
.match-text { font-size: 0.85rem; margin-top: 0.25rem; }
.match-yes { color: #198754; }
.match-no { color: #dc3545; }
</style>
</head>
<body>

<?php
$profileLink = 'cashier_profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>

<div class="container-fluid">
<div class="row">

<?php include '../includes/cashier_sidebar.php'; ?>

<main class="col-lg-10 ms-sm-auto px-4 main-content">
<div class="py-4">

  <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
    <div>
      <div class="section-subtitle mb-1">Cashier Dashboard</div>
      <h3 class="fw-bold mb-1">Profile</h3>
      <div class="text-muted">Manage your account details and password.</div>
    </div>
  </div>

  <?php if($success): ?><div class="alert alert-success py-2"><?= h($success) ?></div><?php endif; ?>
  <?php if($error): ?><div class="alert alert-danger py-2"><?= h($error) ?></div><?php endif; ?>

  <div class="row g-4">

    <div class="col-12 col-xl-6">
      <div class="card modern-card h-100">
        <div class="panel-head">
          <div class="user-avatar"><i class="fa-solid fa-user"></i></div>
          <h5 class="fw-bold mb-1">Profile Details</h5>
          <div class="small text-muted">Keep your contact details updated for OTP delivery.</div>
        </div>
        <div class="panel-body">

          <form method="post">
          <input type="hidden" name="update_profile" value="1">
          <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">

<div class="mb-2">
<label class="form-label">Username</label>
<input class="form-control" value="<?= h($user['username']) ?>" disabled>
</div>

<div class="mb-2">
<label class="form-label">Display Name <span class="text-danger">*</span></label>
<input class="form-control" name="display_name" value="<?= h($user['display_name'] ?? '') ?>" maxlength="100" required>
</div>

<div class="mb-2">
<label class="form-label">First Name <span class="text-danger">*</span></label>
<input class="form-control" name="first_name" value="<?= h($user['first_name']) ?>" required>
</div>

<div class="mb-2">
<label class="form-label">Last Name <span class="text-danger">*</span></label>
<input class="form-control" name="last_name" value="<?= h($user['last_name']) ?>" required>
</div>

<div class="mb-3">
<label class="form-label">Phone</label>
<input class="form-control" name="phone" value="<?= h($user['phone']) ?>">
</div>

<div class="mb-3">
<label class="form-label">Email <span class="text-danger">*</span></label>
<input type="email" class="form-control" name="email" value="<?= h($user['email']) ?>" required>
</div>

          <div class="profile-meta mb-3">
            <span class="profile-badge">MFA Enabled</span>
            <?php if (is_array($trustedDeviceExpiry) && ($trustedDeviceExpiry['days_left'] ?? 0) > 0): ?>
              <span class="profile-badge" style="border:1px solid #dc3545;color:#dc3545;padding:6px 10px;border-radius:20px;font-weight:700;margin-left:8px;">
                Expires in <?= (int)$trustedDeviceExpiry['days_left'] ?> Day<?= ((int)$trustedDeviceExpiry['days_left'] === 1) ? '' : 's' ?>
              </span>
            <?php endif; ?>
          </div>

          <button class="btn btn-dark w-100">
            <i class="fa-solid fa-save me-1"></i> Save Changes
          </button>
          </form>

        </div>
      </div>
    </div>

    <div class="col-12 col-xl-6">
      <div class="card modern-card h-100">
        <div class="panel-head">
          <h5 class="fw-bold mb-1"><i class="fa-solid fa-key me-2"></i>Change Password</h5>
          <div class="small text-muted">Password updates require email OTP verification.</div>
        </div>
        <div class="panel-body">

          <form method="post">
          <?php if(empty($_SESSION['cashier_pwd_change_pending'])): ?>
          <input type="hidden" name="request_change_password_otp" value="1">
          <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">

<div class="mb-2">
  <label class="form-label">Old Password <span class="text-danger">*</span></label>
  <div class="password-wrapper">
    <input type="password" class="form-control pe-5" id="old_password" name="old_password" required>
    <span class="toggle-password" data-target="old_password" aria-label="Toggle password">
      <i class="fa-solid fa-eye"></i>
    </span>
  </div>
</div>

<div class="mb-2">
  <label class="form-label">New Password <span class="text-danger">*</span></label>
  <div class="password-wrapper">
    <input type="password" class="form-control pe-5" id="new_password" name="new_password" minlength="6" required oninput="checkPasswordStrength(this.value)">
    <span class="toggle-password" data-target="new_password" aria-label="Toggle password">
      <i class="fa-solid fa-eye"></i>
    </span>
  </div>
  <div class="text-muted small mt-1">
    Password policy: at least 6 characters. For better security, use a mix of letters, numbers, and symbols.
  </div>
  <div class="strength-container">
    <div class="strength-bar"><div id="strengthFill" class="strength-fill"></div></div>
    <div id="strengthText" class="strength-text text-muted">Start typing a password...</div>
  </div>
  <ul class="requirement-list">
    <li id="req-length" data-label="At least 6 characters" class="req-fail"><i class="fa-solid fa-circle-xmark"></i> At least 6 characters</li>
    <li id="req-upper" data-label="One uppercase letter (A-Z)" class="req-fail"><i class="fa-solid fa-circle-xmark"></i> One uppercase letter (A-Z)</li>
    <li id="req-lower" data-label="One lowercase letter (a-z)" class="req-fail"><i class="fa-solid fa-circle-xmark"></i> One lowercase letter (a-z)</li>
    <li id="req-number" data-label="One number (0-9)" class="req-fail"><i class="fa-solid fa-circle-xmark"></i> One number (0-9)</li>
    <li id="req-special" data-label="One special character (!@#$%^&* etc.)" class="req-fail"><i class="fa-solid fa-circle-xmark"></i> One special character (!@#$%^&* etc.)</li>
  </ul>
</div>

<div class="mb-3">
  <label class="form-label">Confirm New Password <span class="text-danger">*</span></label>
  <div class="password-wrapper">
    <input type="password" class="form-control pe-5" id="confirm_password" name="confirm_password" required oninput="checkPasswordMatch()">
    <span class="toggle-password" data-target="confirm_password" aria-label="Toggle password">
      <i class="fa-solid fa-eye"></i>
    </span>
  </div>
  <div id="matchText" class="match-text"></div>
</div>

<button class="btn btn-outline-dark w-100">
  <i class="fa-solid fa-paper-plane me-1"></i> Send OTP and Continue
</button>
<div class="text-muted small mt-2">Tip: Use at least 6 characters.</div>
<?php else: ?>
<input type="hidden" name="change_password" value="1">
<input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
<div class="mb-3">
  <label class="form-label">OTP Code <span class="text-danger">*</span></label>
  <input type="text" class="form-control" name="otp" maxlength="6" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" placeholder="123456" required>
  <div class="text-muted small mt-1">Check your email for the 6-digit code.</div>
</div>
<button class="btn btn-dark w-100">
  <i class="fa-solid fa-shield-halved me-1"></i> Verify OTP and Update Password
</button>
<?php endif; ?>
</form>
<?php if(!empty($_SESSION['cashier_pwd_change_pending'])): ?>
<form method="post" class="mt-2">
  <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
  <button class="btn btn-outline-secondary w-100" name="cancel_change_password" value="1">Cancel Pending Change</button>
</form>
<?php endif; ?>

        </div>
      </div>
    </div>

  </div>

</div>
</main>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="../js/cashier-profile.js"></script>
<script>
function updateReq(el, passed) {
  if(!el) return;
  const label = el.getAttribute('data-label') || el.textContent.trim();
  if(passed){
    el.classList.remove('req-fail');
    el.classList.add('req-pass');
    el.innerHTML = '<i class="fa-solid fa-circle-check"></i> ' + label;
  } else {
    el.classList.remove('req-pass');
    el.classList.add('req-fail');
    el.innerHTML = '<i class="fa-solid fa-circle-xmark"></i> ' + label;
  }
}

function checkPasswordStrength(pwd) {
  const fill = document.getElementById('strengthFill');
  const text = document.getElementById('strengthText');
  if(!fill || !text) return;

  const hasLength = pwd.length >= 6;
  const hasUpper = /[A-Z]/.test(pwd);
  const hasLower = /[a-z]/.test(pwd);
  const hasNumber = /[0-9]/.test(pwd);
  const hasSpecial = /[^A-Za-z0-9]/.test(pwd);

  updateReq(document.getElementById('req-length'), hasLength);
  updateReq(document.getElementById('req-upper'), hasUpper);
  updateReq(document.getElementById('req-lower'), hasLower);
  updateReq(document.getElementById('req-number'), hasNumber);
  updateReq(document.getElementById('req-special'), hasSpecial);

  const score = [hasLength, hasUpper, hasLower, hasNumber, hasSpecial].filter(Boolean).length;
  fill.className = 'strength-fill';

  if(pwd.length === 0){
    fill.style.width = '0%';
    text.textContent = 'Start typing a password...';
    text.className = 'strength-text text-muted';
  } else if(score <= 2){
    fill.classList.add('strength-weak');
    text.textContent = 'Weak - add more variety';
    text.className = 'strength-text text-danger';
  } else if(score === 3){
    fill.classList.add('strength-fair');
    text.textContent = 'Fair - could be stronger';
    text.className = 'strength-text text-warning';
  } else if(score === 4){
    fill.classList.add('strength-good');
    text.textContent = 'Good password';
    text.className = 'strength-text text-info';
  } else {
    fill.classList.add('strength-strong');
    text.textContent = 'Strong password!';
    text.className = 'strength-text text-success';
  }

  checkPasswordMatch();
}

function checkPasswordMatch() {
  const p1 = document.getElementById('new_password');
  const p2 = document.getElementById('confirm_password');
  const matchText = document.getElementById('matchText');
  if(!p1 || !p2 || !matchText) return;

  if(p2.value.length === 0){
    matchText.textContent = '';
    return;
  }

  if(p1.value === p2.value){
    matchText.innerHTML = '<span class="match-yes"><i class="fa-solid fa-check"></i> Passwords match</span>';
  } else {
    matchText.innerHTML = '<span class="match-no"><i class="fa-solid fa-xmark"></i> Passwords do not match</span>';
  }
}

document.addEventListener('DOMContentLoaded', function(){
  const newPassword = document.getElementById('new_password');
  if(newPassword) checkPasswordStrength(newPassword.value || '');
});
</script>

</body>
</html>
