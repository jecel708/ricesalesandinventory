<?php
session_start();
if(!isset($_SESSION['user_id'])){ header("Location: ../login.php"); exit; }
$userRole = strtolower($_SESSION['role'] ?? '');
$isOwner = ($userRole === 'owner');
if(!in_array($userRole, ['cashier', 'owner'], true)){ header("Location: ../login.php"); exit; }

$username = $_SESSION['username'] ?? 'Cashier';
$user_id = (int)($_SESSION['user_id'] ?? 0);

include __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/receivable_penalty.php';
ensurePenaltyPaymentColumn($conn);
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$success = $_GET['success'] ?? '';
$error = $_GET['error'] ?? '';

if(empty($_SESSION['csrf_token'])){
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = (string)$_SESSION['csrf_token'];

function require_csrf_or_redirect(string $target): void {
  $posted = (string)($_POST['csrf_token'] ?? '');
  $stored = (string)($_SESSION['csrf_token'] ?? '');
  if($posted === '' || $stored === '' || !hash_equals($stored, $posted)){
    header("Location: {$target}?error=" . urlencode("Invalid request token. Please refresh and try again."));
    exit;
  }
}

if(isset($_POST['add_payment'])){
  require_csrf_or_redirect('payments.php');
  $sale_id = (int)($_POST['sale_id'] ?? 0);
  $amount = (float)($_POST['amount'] ?? 0);
  $method = strtolower(trim($_POST['method'] ?? 'cash'));
  $ext_ref = trim($_POST['external_ref'] ?? '');

  if($sale_id <= 0 || $amount <= 0){
    header("Location: payments.php?error=" . urlencode("Invalid sale or amount."));
    exit;
  }
  if(!in_array($method, ['cash','gcash','bank','other'], true)){
    header("Location: payments.php?error=" . urlencode("Invalid payment method."));
    exit;
  }
  if($ext_ref !== '' && preg_match('/^[A-Za-z0-9]+$/', $ext_ref) !== 1){
    header("Location: payments.php?error=" . urlencode("Reference number may contain only letters and numbers."));
    exit;
  }
  if($method !== 'cash' && $ext_ref === ''){
    header("Location: payments.php?error=" . urlencode("Reference number is required for non-cash payments."));
    exit;
  }

  $conn->begin_transaction();
  try{
    $stmt = $conn->prepare("
      SELECT ar.ar_id, ar.customer_id, ar.total_amount, ar.amount_paid, ar.balance, ar.status,
             ar.due_date, p.penalty_id, p.penalty_amount,
             IFNULL(p.amount_paid,0) AS penalty_paid,
             IFNULL(p.waived_amount,0) AS penalty_waived,
             (
               SELECT IFNULL(SUM(si.qty_input),0)
               FROM sales_items si
               WHERE si.sale_id = ar.sales_id AND si.unit_type = 'sack'
             ) AS sack_count
      FROM account_receivable ar
      LEFT JOIN penalties p
        ON p.reference_id = ar.ar_id AND p.reference_type = 'receivable'
      WHERE ar.sales_id=? LIMIT 1
      FOR UPDATE
    ");
    if(!$stmt){
      throw new Exception("Unable to load the receivable: " . $conn->error);
    }
    $stmt->bind_param("i", $sale_id);
    if(!$stmt->execute()){
      throw new Exception("Unable to load the receivable: " . $stmt->error);
    }
    $ar = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if(!$ar){
      throw new Exception("No account receivable found for Sale #{$sale_id}.");
    }

    $arId = (int)$ar['ar_id'];
    $balance = max(0, (float)$ar['balance']);
    $penaltyAmount = $ar['penalty_id'] !== null
      ? max(0, (float)$ar['penalty_amount'])
      : ((strtolower((string)$ar['status']) !== 'paid'
          && !empty($ar['due_date'])
          && $ar['due_date'] < date('Y-m-d'))
          ? ((float)$ar['sack_count'] > 0 ? (float)$ar['sack_count'] * 50 : 100)
          : 0);
    $penaltyPaid = max(0, (float)$ar['penalty_paid']);
    $penaltyWaived = max(0, (float)$ar['penalty_waived']);
    $penaltyBalance = max(0, $penaltyAmount - $penaltyPaid - $penaltyWaived);
    $totalDue = $balance + $penaltyBalance;

    if($totalDue <= 0.00001){
      throw new Exception("Sale #{$sale_id} is already fully paid.");
    }

    if($amount > $totalDue + 0.00001){
      throw new Exception("Amount exceeds total due. Total due is ₱".number_format($totalDue,2));
    }

    if($ar['penalty_id'] === null && $penaltyAmount > 0){
      $daysLate = max(1, (int)floor((time() - strtotime((string)$ar['due_date'])) / 86400));
      $stmt = $conn->prepare("
        INSERT INTO penalties (reference_id, reference_type, penalty_amount, days_late, last_calculated)
        VALUES (?, 'receivable', ?, ?, NOW())
      ");
      if(!$stmt){
        throw new Exception("Unable to create penalty record: " . $conn->error);
      }
      $stmt->bind_param("idi", $arId, $penaltyAmount, $daysLate);
      if(!$stmt->execute()){
        throw new Exception("Unable to create penalty record: " . $stmt->error);
      }
      $stmt->close();
    }

    $payStatus = "paid";
    $stmt = $conn->prepare("
      INSERT INTO payments (sale_id, amount, method, status, paid_at, external_ref)
      VALUES (?, ?, ?, ?, NOW(), ?)
    ");
    if(!$stmt){
      throw new Exception("Unable to record payment: " . $conn->error);
    }
    $stmt->bind_param("idsss", $sale_id, $amount, $method, $payStatus, $ext_ref);
    if(!$stmt->execute()){
      throw new Exception("Unable to record payment: " . $stmt->error);
    }
    $payment_id = (int)$conn->insert_id;
    $stmt->close();

    $cust_id = (int)($ar['customer_id'] ?? 0);
    $message = "Payment received for Sale #{$sale_id}: ₱".number_format($amount,2).". Thank you!";
    $stmt = $conn->prepare("
      INSERT INTO push_notif_logs (payment_id, customer_id, message, sent_at, status)
      VALUES (NULL, ?, ?, NOW(), 'SENT')
    ");
    $stmt->bind_param("is", $cust_id, $message);
    $stmt->execute();
    $stmt->close();

    $receivableApplied = min($amount, $balance);
    $penaltyApplied = max(0, $amount - $receivableApplied);
    $new_paid = (float)$ar['amount_paid'] + $receivableApplied;
    $new_bal = max(0, $balance - $receivableApplied);
    $new_penalty_paid = $penaltyPaid + $penaltyApplied;
    $new_status = ($new_bal <= 0.00001 && $new_penalty_paid + $penaltyWaived + 0.00001 >= $penaltyAmount) ? "paid" : "partial";

    $stmt = $conn->prepare("
      UPDATE account_receivable
      SET amount_paid=?, balance=?, status=?
      WHERE sales_id=?
    ");
    if(!$stmt){
      throw new Exception("Unable to update receivable: " . $conn->error);
    }
    $stmt->bind_param("ddsi", $new_paid, $new_bal, $new_status, $sale_id);
    if(!$stmt->execute()){
      throw new Exception("Unable to update receivable: " . $stmt->error);
    }
    $stmt->close();

    if($penaltyApplied > 0){
      $stmt = $conn->prepare("
        UPDATE penalties
        SET amount_paid = IFNULL(amount_paid,0) + ?
        WHERE reference_id = ? AND reference_type = 'receivable'
      ");
      if(!$stmt){
        throw new Exception("Unable to update penalty payment: " . $conn->error);
      }
      $stmt->bind_param("di", $penaltyApplied, $arId);
      if(!$stmt->execute()){
        throw new Exception("Unable to update penalty payment: " . $stmt->error);
      }
      $stmt->close();
    }

    if($new_status === "paid"){
      $stmt = $conn->prepare("UPDATE sales SET status='paid' WHERE sale_id=?");
      $stmt->bind_param("i", $sale_id);
      $stmt->execute();
      $stmt->close();
    } else {
      $stmt = $conn->prepare("UPDATE sales SET status='unpaid' WHERE sale_id=?");
      $stmt->bind_param("i", $sale_id);
      $stmt->execute();
      $stmt->close();
    }

    $conn->commit();

    $desc ="Payment received for Sale #{$sale_id} amount ₱".number_format($amount,2);
    $stmt = $conn->prepare("
      INSERT INTO activity_logs (user_id, activity_type, description, created_at)
      VALUES (?, 'PAYMENT_RECEIVED', ?, NOW())
    ");
    $stmt->bind_param("is", $user_id, $desc);
    $stmt->execute();
    $stmt->close();

    header("Location: payment_receipt.php?payment_id=".(int)$payment_id);
    exit;

  } catch(Exception $e){
    $conn->rollback();
    header("Location: payments.php?error=" . urlencode($e->getMessage()));
    exit;
  }
}

$q = trim($_GET['q'] ?? '');
$filter_status = strtolower(trim($_GET['status'] ?? 'all'));

$where = "WHERE 1=1";
$params = [];
$types = "";
$penaltyDueSql = receivablePenaltyOutstandingSql();

if($q !== ''){
  $where .= " AND (ar.sales_id LIKE CONCAT('%',?,'%') OR c.first_name LIKE CONCAT('%',?,'%') OR c.last_name LIKE CONCAT('%',?,'%') OR CONCAT_WS(' ', c.first_name, c.last_name) LIKE CONCAT('%',?,'%'))";
  $params[] = $q; $params[] = $q; $params[] = $q; $params[] = $q;
  $types .= "ssss";
}

if($filter_status === 'open'){
  $where .= " AND (LOWER(IFNULL(ar.status,'')) IN ('unpaid','partial','overdue') OR ({$penaltyDueSql}) > 0)";
} elseif($filter_status === 'paid'){
  $where .= " AND LOWER(IFNULL(ar.status,'')) = 'paid' AND ({$penaltyDueSql}) <= 0";
} elseif($filter_status === 'overdue'){
  $where .= " AND (ar.balance > 0 OR ({$penaltyDueSql}) > 0) AND ar.due_date IS NOT NULL AND ar.due_date < CURDATE()";
}

$sql = "
SELECT
  ar.ar_id, ar.sales_id, ar.customer_id, ar.total_amount, ar.amount_paid, ar.balance,
  ar.due_date, ar.status AS ar_status, ar.created_at,
  ({$penaltyDueSql}) AS penalty_due,
  IFNULL(p.penalty_amount,0) AS penalty_amount,
  IFNULL(p.amount_paid,0) AS penalty_paid,
  IFNULL(p.waived_amount,0) AS penalty_waived,
  c.first_name, c.last_name, c.phone
FROM account_receivable ar
JOIN sales s ON ar.sales_id = s.sale_id
LEFT JOIN customers c ON ar.customer_id = c.customer_id
LEFT JOIN penalties p ON p.reference_id = ar.ar_id AND p.reference_type = 'receivable'
{$where}
ORDER BY ar.created_at DESC
";
$stmt = $conn->prepare($sql);
if($types !== ""){
  $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$ars = $stmt->get_result();
$stmt->close();

$suggestionResult = $conn->query("
  SELECT ar.sales_id, c.first_name, c.last_name
  FROM account_receivable ar
  JOIN sales s ON ar.sales_id = s.sale_id
  LEFT JOIN customers c ON ar.customer_id = c.customer_id
  ORDER BY ar.sales_id DESC
");
if(!$suggestionResult){
  die("Query Error: " . $conn->error);
}
$searchSuggestions = [];
while($suggestion = $suggestionResult->fetch_assoc()){
  $saleId = (string)(int)$suggestion['sales_id'];
  $customerName = trim(($suggestion['first_name'] ?? '').' '.($suggestion['last_name'] ?? ''));
  $searchSuggestions[$saleId] = 'Sale #'.$saleId.($customerName !== '' ? ' — '.$customerName : '');
  if($customerName !== ''){
    $searchSuggestions[$customerName] = 'Customer — Sale #'.$saleId;
  }
}

// Helper: get payment history for a sale
function get_payments($conn, $sale_id){
  $stmt = $conn->prepare("SELECT amount, method, external_ref, paid_at FROM payments WHERE sale_id = ? ORDER BY paid_at DESC");
  $stmt->bind_param("i", $sale_id);
  $stmt->execute();
  $res = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
  $stmt->close();
  return $res;
}

$prefill_sale_id = (int)($_GET['sale_id'] ?? 0);
$statement_customer_id = (int)($_GET['customer_id'] ?? 0);
$prefill = null;
$statement = null;
$statementRows = [];
$statementPayments = [];

if($prefill_sale_id > 0){
  $stmt = $conn->prepare("
    SELECT ar.sales_id, ar.balance, c.first_name, c.last_name,
      ({$penaltyDueSql}) AS penalty_due
    FROM account_receivable ar
    JOIN sales s ON ar.sales_id = s.sale_id
    LEFT JOIN customers c ON ar.customer_id = c.customer_id
    LEFT JOIN penalties p ON p.reference_id = ar.ar_id AND p.reference_type = 'receivable'
    WHERE ar.sales_id=?
    LIMIT 1
  ");
  $stmt->bind_param("i", $prefill_sale_id);
  $stmt->execute();
  $prefill = $stmt->get_result()->fetch_assoc();
  $stmt->close();
}

if($statement_customer_id > 0){
  $stmt = $conn->prepare("
    SELECT c.customer_id, c.first_name, c.last_name, c.phone,
      IFNULL(SUM(ar.total_amount),0) AS total_credit,
      IFNULL(SUM(IFNULL(ar.amount_paid,0) + IFNULL(p.amount_paid,0)),0) AS total_paid,
      IFNULL(SUM(ar.balance),0) AS total_balance,
      IFNULL(SUM({$penaltyDueSql}),0) AS total_penalty_balance,
      IFNULL(SUM(ar.accrued_interest),0) AS total_interest,
      IFNULL(SUM(ar.accrued_penalty),0) AS total_penalty,
      SUM(CASE WHEN ar.balance > 0 OR ({$penaltyDueSql}) > 0 THEN 1 ELSE 0 END) AS open_docs,
      SUM(CASE WHEN (ar.balance > 0 OR ({$penaltyDueSql}) > 0) AND ar.due_date IS NOT NULL AND ar.due_date < CURDATE() THEN 1 ELSE 0 END) AS overdue_docs
     FROM customers c
     JOIN account_receivable ar ON ar.customer_id = c.customer_id
     JOIN sales s ON s.sale_id = ar.sales_id
     LEFT JOIN penalties p ON p.reference_id = ar.ar_id AND p.reference_type = 'receivable'
     WHERE c.customer_id = ?
     GROUP BY c.customer_id
     LIMIT 1
  ");
  $stmt->bind_param("i", $statement_customer_id);
  $stmt->execute();
  $statement = $stmt->get_result()->fetch_assoc();
  $stmt->close();

  if($statement){
    $stmt = $conn->prepare("
      SELECT ar.sales_id, ar.total_amount, ar.amount_paid, ar.balance, ar.due_date, ar.status,
             ar.accrued_interest, ar.accrued_penalty, s.sale_date,
             IFNULL(p.penalty_amount,0) AS penalty_amount,
             IFNULL(p.waived_amount,0) AS penalty_waived,
             IFNULL(p.amount_paid,0) AS penalty_paid,
             ({$penaltyDueSql}) AS penalty_due
      FROM account_receivable ar
      JOIN sales s ON s.sale_id = ar.sales_id
      LEFT JOIN penalties p ON p.reference_id = ar.ar_id AND p.reference_type = 'receivable'
      WHERE ar.customer_id = ?
      ORDER BY CASE WHEN ar.balance > 0 OR ({$penaltyDueSql}) > 0 THEN 0 ELSE 1 END, ar.due_date ASC, ar.created_at DESC
    ");
    $stmt->bind_param("i", $statement_customer_id);
    $stmt->execute();
    $statementPayments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Utang Payments | DE ORO HIYS</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

<link href="../css/layout.css" rel="stylesheet">
<link href="../css/cashier-payments.css?v=pay-options-1" rel="stylesheet">
<link href="../css/cashier-mobile.css" rel="stylesheet">

<style>
/* ✅ Clickable row style */
.history-row { cursor: pointer; }
.history-row:hover { background-color: #f8f9fa; }
.payment-row:focus-visible { outline: 3px solid #0d6efd; outline-offset: -3px; }
.view-history-btn { color: #0d6efd; border: none; background: transparent; padding: 0; cursor: pointer; }
.view-history-btn:hover { color: #0a58ca; text-decoration: underline; }
</style>

</head>

<body>

<?php
$profileLink = $isOwner ? 'profile.php' : 'cashier_profile.php';
$logoutLink = '../logout.php';
include __DIR__ . '/../includes/topnav.php';
?>

<div class="container-fluid">
<div class="row">

<?php if($isOwner): ?>
  <?php include __DIR__ . '/../includes/owner_sidebar.php'; ?>
<?php else: ?>
  <?php include __DIR__ . '/../includes/cashier_sidebar.php'; ?>
<?php endif; ?>

<main class="col-lg-10 ms-sm-auto px-4 main-content">
<div class="py-4">

  <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
    <div>
      <h3 class="fw-bold mb-1">Utang Payments</h3>
      <div class="text-muted">Click "View History" on any row to see payment records.</div>
    </div>
  </div>

  <?php if($success): ?><div class="alert alert-success py-2"><?= h($success) ?></div><?php endif; ?>
  <?php if($error): ?><div class="alert alert-danger py-2"><?= h($error) ?></div><?php endif; ?>

  <?php if($statement): ?>
    <?php $statementName = trim(($statement['first_name'] ?? '').' '.($statement['last_name'] ?? '')); ?>
    <div class="card modern-card mb-4">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
          <div>
            <h5 class="fw-bold mb-1">Customer Statement: <?= h($statementName ?: 'Customer') ?></h5>
            <div class="text-muted"><?= h($statement['phone'] ?? '') ?></div>
          </div>
          <a class="btn btn-sm btn-outline-dark" href="payments.php"><i class="fa-solid fa-xmark me-1"></i>Close Statement</a>
        </div>
        <div class="row g-3 mb-3">
          <div class="col-md-3"><div class="payment-balance-card"><div class="metric-label">Total Credit</div><div class="payment-balance">₱<?= number_format((float)$statement['total_credit'],2) ?></div></div></div>
          <div class="col-md-3"><div class="payment-balance-card"><div class="metric-label">Paid</div><div class="payment-balance text-success">₱<?= number_format((float)$statement['total_paid'],2) ?></div></div></div>
          <div class="col-md-3"><div class="payment-balance-card"><div class="metric-label">Remaining Balance</div><div class="payment-balance text-danger">₱<?= number_format((float)$statement['total_balance'] + (float)$statement['total_penalty_balance'],2) ?></div></div></div>
          <div class="col-md-3"><div class="payment-balance-card"><div class="metric-label">Open / Overdue</div><div class="payment-balance"><?= (int)$statement['open_docs'] ?> / <?= (int)$statement['overdue_docs'] ?></div></div></div>
        </div>
        <div class="table-responsive mb-3">
          <table class="table table-sm table-striped align-middle">
            <thead class="table-dark"><tr><th>Sale #</th><th>Date</th><th>Due</th><th>Total Due</th><th>Paid</th><th>Interest/Penalty</th><th>Balance</th><th>Status</th><th></th></tr></thead>
            <tbody>
              <?php foreach($statementRows as $sr): ?>
                <?php $bal = (float)$sr['balance']; $penaltyDue = (float)$sr['penalty_due']; $totalDue = $bal + $penaltyDue; $overdue = $totalDue > 0 && !empty($sr['due_date']) && strtotime($sr['due_date']) < strtotime(date('Y-m-d')); ?>
                <tr>
                  <td class="fw-bold">#<?= (int)$sr['sales_id'] ?></td>
                  <td><?= !empty($sr['sale_date']) ? h(date('M d, Y', strtotime($sr['sale_date']))) : '-' ?></td>
                  <td><?= !empty($sr['due_date']) ? h(date('M d, Y', strtotime($sr['due_date']))) : '-' ?></td>
                  <td>₱<?= number_format((float)$sr['total_amount'] + (float)$sr['penalty_amount'] - (float)$sr['penalty_waived'],2) ?></td>
                  <td>₱<?= number_format((float)$sr['amount_paid'] + (float)$sr['penalty_paid'],2) ?></td>
                  <td>₱<?= number_format((float)$sr['accrued_interest'] + (float)$sr['accrued_penalty'] + $penaltyDue,2) ?></td>
                  <td class="<?= $totalDue > 0 ? 'fw-bold text-danger' : 'text-muted' ?>">₱<?= number_format($totalDue,2) ?></td>
                  <td><span class="badge <?= $overdue ? 'bg-danger' : ($totalDue > 0 ? 'bg-warning text-dark' : 'bg-success') ?>"><?= $overdue ? 'OVERDUE' : ($totalDue > 0 ? h(strtoupper((string)$sr['status'])) : 'PAID') ?></span></td>
                  <td><?php if($totalDue > 0): ?><a class="btn btn-sm btn-outline-dark" href="payments.php?sale_id=<?= (int)$sr['sales_id'] ?>">Pay</a><?php endif; ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <h6 class="fw-bold">Recent Payments</h6>
        <div class="table-responsive">
          <table class="table table-sm align-middle mb-0">
            <thead><tr><th>Date</th><th>Sale #</th><th>Amount</th><th>Method</th><th>Reference</th></tr></thead>
            <tbody>
              <?php if(empty($statementPayments)): ?>
                <tr><td colspan="5" class="text-center text-muted">No payment history yet.</td></tr>
              <?php else: foreach($statementPayments as $sp): ?>
                <tr><td><?= h(date('M d, Y h:i A', strtotime($sp['paid_at']))) ?></td><td>#<?= (int)$sp['sale_id'] ?></td><td>₱<?= number_format((float)$sp['amount'],2) ?></td><td><?= h(strtoupper((string)$sp['method'])) ?></td><td><?= h($sp['external_ref'] ?? '') ?></td></tr>
              <?php endforeach; endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <div class="row g-4">

    <!-- LEFT: ADD PAYMENT -->
    <div class="col-12 col-xl-4">
      <button type="button" class="btn btn-sm btn-outline-dark mobile-payment-history mb-2"
        id="mobilePaymentHistoryBtn" aria-label="Open payment history">
        <i class="fa-solid fa-clock-rotate-left me-1"></i> Payment History
      </button>
      <div class="card modern-card">
        <div class="card-body">
          <h5 class="fw-bold mb-3">Record Payment</h5>

          <?php if($prefill): ?>
            <div class="alert alert-info py-2 small">
              Selected Sale #<?= (int)$prefill['sales_id'] ?> —
              <?= h(trim(($prefill['first_name'] ?? '').' '.($prefill['last_name'] ?? '')) ?: 'Customer') ?> —
              Total due: <b>₱<?= number_format((float)$prefill['balance'] + (float)$prefill['penalty_due'],2) ?></b>
            </div>
          <?php endif; ?>

          <form method="POST" id="paymentForm">
            <input type="hidden" name="add_payment" value="1">
            <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">

            <div class="mb-3">
              <label class="form-label">Sale ID</label>
              <input type="number" class="form-control" name="sale_id" required
                value="<?= $prefill ? (int)$prefill['sales_id'] : '' ?>" placeholder="e.g. 123">
            </div>

            <?php if($prefill): ?>
              <div class="payment-balance-card mb-3">
                <div class="metric-label">Selected Total Due</div>
                <div class="payment-balance">₱<?= number_format((float)$prefill['balance'] + (float)$prefill['penalty_due'],2) ?></div>
                <div class="small-muted">Receivable: ₱<?= number_format((float)$prefill['balance'],2) ?> · Penalty: ₱<?= number_format((float)$prefill['penalty_due'],2) ?></div>
              </div>
            <?php endif; ?>

            <div class="mb-3">
              <label class="form-label">Amount (₱)</label>
              <input type="number" step="0.01" min="0" class="form-control" name="amount" id="paymentAmount" required placeholder="e.g. 500.00" data-balance="<?= $prefill ? h((string)((float)$prefill['balance'] + (float)$prefill['penalty_due'])) : '' ?>">
              <div class="quick-pay-wrap mt-2">
                <?php if($prefill): ?>
                  <button type="button" class="btn btn-sm btn-outline-dark" data-pay-fill="full">Full Balance</button>
                  <button type="button" class="btn btn-sm btn-outline-dark" data-pay-fill="half">Half</button>
                <?php endif; ?>
                <button type="button" class="btn btn-sm btn-outline-secondary" data-pay-clear>Clear</button>
              </div>
              <div class="small-muted mt-1" id="paymentPreview">System blocks overpayment automatically.</div>
            </div>

            <div class="mb-3">
              <label class="form-label">Method</label>
              <div class="payment-method-grid mb-2" role="group" aria-label="Payment method">
                <button type="button" class="payment-method-card active" data-method="cash">
                  <i class="fa-solid fa-money-bill-wave"></i>
                  <span>Cash</span>
                </button>
                <button type="button" class="payment-method-card" data-method="gcash">
                  <i class="fa-solid fa-mobile-screen-button"></i>
                  <span>GCash</span>
                </button>
                <button type="button" class="payment-method-card" data-method="bank">
                  <i class="fa-solid fa-building-columns"></i>
                  <span>Bank</span>
                </button>
                <button type="button" class="payment-method-card" data-method="other">
                  <i class="fa-solid fa-ellipsis"></i>
                  <span>Other</span>
                </button>
              </div>
              <select class="form-select d-none" name="method" id="paymentMethod" required>
                <option value="cash">Cash</option>
                <option value="gcash">GCash</option>
                <option value="bank">Bank Transfer</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div class="mb-3 d-none" id="externalRefWrap">
              <label class="form-label" id="externalRefLabel">Reference No.</label>
              <input class="form-control" name="external_ref" id="externalRef"
                placeholder="GCash ref, bank ref, etc."
                pattern="[A-Za-z0-9]+"
                maxlength="100"
                title="Use letters and numbers only."
                autocomplete="off">
              <div class="small-muted mt-1">Reference is recommended for non-cash payments.</div>
            </div>

            <button class="btn btn-dark w-100">
              <i class="fa-solid fa-check me-1"></i> Save Payment
            </button>
          </form>
        </div>
      </div>
    </div>

    <!-- RIGHT: RECEIVABLES LIST -->
    <div class="col-12 col-xl-8">

      <div class="card modern-card mb-3">
        <div class="card-body">
          <form class="row g-2 align-items-end" method="GET">
            <div class="col-12 col-md-6">
              <label class="form-label" for="paymentSearch">Search (Sale ID / Customer)</label>
              <input class="form-control" id="paymentSearch" name="q" list="paymentSearchSuggestions" value="<?= h($q) ?>" placeholder="e.g. 100 or Maria" autocomplete="off">
              <datalist id="paymentSearchSuggestions">
                <?php foreach($searchSuggestions as $value => $label): ?>
                  <option value="<?= h($value) ?>" label="<?= h($label) ?>"></option>
                <?php endforeach; ?>
              </datalist>
            </div>
            <div class="col-12 col-md-3">
              <label class="form-label">Status</label>
              <select class="form-select" name="status">
                <option value="open" <?= $filter_status==='open'?'selected':'' ?>>Open (Unpaid/Partial)</option>
                <option value="overdue" <?= $filter_status==='overdue'?'selected':'' ?>>Overdue</option>
                <option value="all" <?= $filter_status==='all'?'selected':'' ?>>All</option>
                <option value="paid" <?= $filter_status==='paid'?'selected':'' ?>>Paid</option>
              </select>
            </div>
            <div class="col-12 col-md-3 d-grid">
              <button class="btn btn-outline-dark"><i class="fa-solid fa-filter me-1"></i> Filter</button>
            </div>
          </form>
        </div>
      </div>

      <div class="card modern-card">
        <div class="card-body table-responsive">
          <table class="table table-striped align-middle mb-0">
            <thead class="table-dark">
              <tr>
                <th>Sale #</th>
                <th>Customer</th>
                <th>Total Due</th>
                <th>Paid</th>
                <th>Balance</th>
                <th>Due</th>
                <th>Status</th>
                <th>History</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php if($ars && $ars->num_rows > 0): ?>
                <?php while($r = $ars->fetch_assoc()): ?>
                  <?php
                    $saleId = (int)$r['sales_id'];
                    $cust = trim(($r['first_name'] ?? '').' '.($r['last_name'] ?? ''));
                    if($cust === '') $cust = 'N/A';
                    $st = strtolower(trim($r['ar_status'] ?? ''));
                    $bal = (float)($r['balance'] ?? 0);
                    $penaltyDue = (float)($r['penalty_due'] ?? 0);
                    $totalDue = $bal + $penaltyDue;
                    $dueRaw = trim((string)($r['due_date'] ?? ''));
                    $isOverdue = ($totalDue > 0 && $dueRaw !== '' && strtotime($dueRaw) < strtotime(date('Y-m-d')));
                    $payments = get_payments($conn, $saleId);
                    $payCount = count($payments);
                  ?>
                  <tr class="history-row payment-row" data-sale-id="<?= $saleId ?>" data-payment-url="payments.php?sale_id=<?= $saleId ?>" tabindex="0" role="link" aria-label="Record payment for Sale #<?= $saleId ?>">
                    <td class="fw-bold"><?= $saleId ?></td>
                    <td><?= h($cust) ?></td>
                    <td>₱<?= number_format((float)$r['total_amount'] + (float)$r['penalty_amount'] - (float)$r['penalty_waived'],2) ?></td>
                    <td>₱<?= number_format((float)$r['amount_paid'] + (float)($r['penalty_paid'] ?? 0),2) ?></td>
                    <td class="<?= $totalDue>0 ? 'fw-bold text-danger' : 'text-muted' ?>">
                      ₱<?= number_format($totalDue,2) ?>
                      <?php if($penaltyDue > 0): ?><div class="small text-muted">Penalty: ₱<?= number_format($penaltyDue,2) ?></div><?php endif; ?>
                    </td>
                    <td><?= $r['due_date'] ? h($r['due_date']) : '-' ?></td>
                    <td>
                      <?php if($isOverdue): ?>
                        <span class="badge bg-danger">OVERDUE</span>
                      <?php elseif($st === 'paid' && $penaltyDue <= 0): ?>
                        <span class="badge bg-success">PAID</span>
                      <?php elseif($st === 'partial' || $penaltyDue > 0): ?>
                        <span class="badge bg-warning text-dark">PARTIAL</span>
                      <?php else: ?>
                        <span class="badge bg-danger">UNPAID</span>
                      <?php endif; ?>
                    </td>
                    <!-- ✅ VIEW HISTORY BUTTON - opens MODAL -->
                    <td class="text-center">
                      <button type="button" class="view-history-btn" 
                        data-bs-toggle="modal" data-bs-target="#historyModal"
                        data-sale-id="<?= $saleId ?>"
                        data-customer="<?= h($cust) ?>"
                        data-payments='<?= json_encode(array_map(function($p){
                          return [
                            'date' => !empty($p['paid_at']) ? date('M d, Y h:i A', strtotime($p['paid_at'])) : '-',
                            'amount' => number_format((float)$p['amount'], 2),
                            'method' => strtoupper($p['method']),
                            'ref' => $p['external_ref'] ?: '-'
                          ];
                        }, $payments)) ?>'>
                        <i class="fa-solid fa-clock-rotate-left"></i> <?= $payCount ?>
                      </button>
                    </td>
                    <td class="text-end">
                      <a class="btn btn-sm btn-outline-dark" href="payments.php?sale_id=<?= $saleId ?>">
                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                      </a>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="9" class="text-center text-muted py-4">No receivables found.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>

</div>
</main>

</div>
</div>

<!-- ✅ PAYMENT HISTORY MODAL POPUP -->
<div class="modal fade" id="historyModal" tabindex="-1" aria-labelledby="historyModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fw-bold" id="historyModalLabel">Payment History</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <div class="fw-bold">Sale #<span id="modalSaleId"></span></div>
          <div class="text-muted small">Customer: <span id="modalCustomer"></span></div>
        </div>
        <div id="modalHistoryContent"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(() => {
  document.getElementById('mobilePaymentHistoryBtn')?.addEventListener('click', () => {
    const saleId = document.querySelector('#paymentForm [name="sale_id"]')?.value?.trim();
    const rows = Array.from(document.querySelectorAll('.payment-row'));
    const targetRow = rows.find((row) => saleId && row.dataset.saleId === saleId) || rows[0];
    const historyButton = targetRow?.querySelector('.view-history-btn');
    if (!historyButton) return;

    const modalElement = document.getElementById('historyModal');
    if (!modalElement || !window.bootstrap?.Modal) return;
    modalElement.dataset.saleId = historyButton.dataset.saleId || '';
    modalElement.dataset.customer = historyButton.dataset.customer || '';
    modalElement.dataset.payments = historyButton.dataset.payments || '[]';
    bootstrap.Modal.getOrCreateInstance(modalElement).show();
  });

  document.querySelectorAll('.payment-row').forEach((row) => {
    const openPaymentForm = (event) => {
      if (event.target.closest('button, a, input, select, textarea, label')) return;
      window.location.href = row.dataset.paymentUrl;
    };
    row.addEventListener('click', openPaymentForm);
    row.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        window.location.href = row.dataset.paymentUrl;
      }
    });
  });

  const amount = document.getElementById('paymentAmount');
  const preview = document.getElementById('paymentPreview');
  const methodSelect = document.getElementById('paymentMethod');
  const methodCards = Array.from(document.querySelectorAll('.payment-method-card'));
  const refWrap = document.getElementById('externalRefWrap');
  const refLabel = document.getElementById('externalRefLabel');
  const refInput = document.getElementById('externalRef');
  const balance = Number(amount?.dataset.balance || 0);

  const peso = (n) => Number(n || 0).toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  function updateAmountPreview(){
    if(!amount || !preview) return;
    const paid = Number(amount.value || 0);
    if(balance <= 0){
      preview.textContent = 'System blocks overpayment automatically.';
      preview.className = 'small-muted mt-1';
      return;
    }
    if(paid <= 0){
      preview.textContent = `Balance: ₱${peso(balance)}`;
      preview.className = 'small-muted mt-1';
      return;
    }
    if(paid > balance){
      preview.textContent = `Amount exceeds balance by ₱${peso(paid - balance)}.`;
      preview.className = 'small mt-1 text-danger';
      return;
    }
    preview.textContent = `Remaining balance after payment: ₱${peso(balance - paid)}`;
    preview.className = 'small mt-1 text-success';
  }

  function setMethod(method){
    if(!methodSelect) return;
    methodSelect.value = method;
    methodCards.forEach((card) => card.classList.toggle('active', card.dataset.method === method));

    const needsRef = method !== 'cash';
    if(refWrap) refWrap.classList.toggle('d-none', !needsRef);
    if(refInput) refInput.required = needsRef;
    if(refLabel){
      if(method === 'gcash') refLabel.textContent = 'GCash Reference No.';
      else if(method === 'bank') refLabel.textContent = 'Bank Reference No.';
      else refLabel.textContent = 'Reference / Notes';
    }
  }

  document.querySelector('[data-pay-fill="full"]')?.addEventListener('click', () => {
    if(!amount || balance <= 0) return;
    amount.value = balance.toFixed(2);
    updateAmountPreview();
  });

  document.querySelector('[data-pay-fill="half"]')?.addEventListener('click', () => {
    if(!amount || balance <= 0) return;
    amount.value = (balance / 2).toFixed(2);
    updateAmountPreview();
  });

  document.querySelector('[data-pay-clear]')?.addEventListener('click', () => {
    if(!amount) return;
    amount.value = '';
    updateAmountPreview();
  });

  methodCards.forEach((card) => {
    card.addEventListener('click', () => setMethod(card.dataset.method || 'cash'));
  });

  amount?.addEventListener('input', updateAmountPreview);
  refInput?.addEventListener('input', () => {
    refInput.value = refInput.value.replace(/[^A-Za-z0-9]/g, '');
  });
  setMethod(methodSelect?.value || 'cash');
  updateAmountPreview();
})();

// ✅ MODAL POPULATION — loads payment history when button clicked
document.addEventListener('DOMContentLoaded', () => {
  const historyModal = document.getElementById('historyModal');
  if(!historyModal) return;

  historyModal.addEventListener('show.bs.modal', (event) => {
    const button = event.relatedTarget || historyModal;
    const saleId = button.dataset.saleId;
    const customer = button.dataset.customer;
    const payments = JSON.parse(button.dataset.payments || '[]');

    document.getElementById('modalSaleId').textContent = saleId;
    document.getElementById('modalCustomer').textContent = customer;

    const content = document.getElementById('modalHistoryContent');
    if(payments.length === 0){
      content.innerHTML = '<p class="text-muted text-center py-3">No payments recorded yet.</p>';
    } else {
      content.innerHTML = `
        <h6 class="mb-2">${payments.length} Payment${payments.length !== 1 ? 's' : ''}</h6>
        <div class="table-responsive">
          <table class="table table-sm table-striped align-middle mb-0">
            <thead class="table-dark">
              <tr>
                <th>Date Paid</th>
                <th>Amount</th>
                <th>Method</th>
                <th>Reference</th>
              </tr>
            </thead>
            <tbody>
              ${payments.map(p => `
                <tr>
                  <td>${p.date}</td>
                  <td>₱${p.amount}</td>
                  <td>${p.method}</td>
                  <td>${p.ref}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    }
  });
});
</script>

</body>
</html>
