<?php
session_start();
if(!isset($_SESSION['user_id'])) { header("Location: ../login.php"); exit; }
if(strtolower($_SESSION['role'] ?? '') !== 'cashier'){ header("Location: ../login.php"); exit; }

include '../config/db.php';
require_once __DIR__ . '/../includes/receivable_penalty.php';
ensurePenaltyPaymentColumn($conn);
$penaltyOutstandingSql = receivablePenaltyOutstandingSql();

$DEFAULT_LOW  = 10.0;
$DEFAULT_OVER = 1000.0;

$settingsRow = null;
$settingsRes = $conn->query("SELECT low_threshold_kg, over_threshold_kg FROM stock_settings WHERE id=1 LIMIT 1");
if($settingsRes){
    $settingsRow = $settingsRes->fetch_assoc();
}

$LOW_STOCK_THRESHOLD  = (float)($settingsRow['low_threshold_kg'] ?? $DEFAULT_LOW);
$OVERSTOCK_THRESHOLD  = (float)($settingsRow['over_threshold_kg'] ?? $DEFAULT_OVER);

$username = $_SESSION['username'] ?? 'Cashier';
$user_id = (int)($_SESSION['user_id'] ?? 0);

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$todayStart = date('Y-m-d 00:00:00');
$todayEnd = date('Y-m-d 00:00:00', strtotime('+1 day'));
$weekStart = date('Y-m-d 00:00:00', strtotime('-6 days'));

$stmt = $conn->prepare("\nSELECT\n  COUNT(*) AS total_sales,\n  IFNULL(SUM(total_amount),0) AS revenue,\n  SUM(CASE WHEN LOWER(IFNULL(status,''))='unpaid' THEN 1 ELSE 0 END) AS unpaid_docs\nFROM sales\nWHERE user_id = ?\nAND sale_date >= ? AND sale_date < ?\nAND LOWER(IFNULL(status,'')) <> 'cancelled'\n");
$stmt->bind_param("iss", $user_id, $todayStart, $todayEnd);
$stmt->execute();
$today = $stmt->get_result()->fetch_assoc() ?: ['total_sales'=>0,'revenue'=>0,'unpaid_docs'=>0];
$stmt->close();

$stmt = $conn->prepare("\nSELECT IFNULL(SUM(si.qty_kg),0) AS sold_kg\nFROM sales_items si\nJOIN sales s ON si.sale_id = s.sale_id\nWHERE s.user_id = ?\nAND s.sale_date >= ? AND s.sale_date < ?\nAND LOWER(IFNULL(s.status,'')) <> 'cancelled'\n");
$stmt->bind_param("iss", $user_id, $todayStart, $todayEnd);
$stmt->execute();
$kgToday = $stmt->get_result()->fetch_assoc() ?: ['sold_kg'=>0];
$stmt->close();

$stmt = $conn->prepare("\nSELECT\n  IFNULL(SUM(IFNULL(ar.balance,0) + ({$penaltyOutstandingSql})),0) AS ar_balance,\n  SUM(CASE WHEN ar.balance > 0 OR ({$penaltyOutstandingSql}) > 0 THEN 1 ELSE 0 END) AS open_ar_count,\n  SUM(CASE WHEN (ar.balance > 0 OR ({$penaltyOutstandingSql}) > 0) AND ar.due_date IS NOT NULL AND ar.due_date < CURDATE() THEN 1 ELSE 0 END) AS overdue_count\nFROM account_receivable ar\nJOIN sales s ON ar.sales_id = s.sale_id\nLEFT JOIN penalties p ON p.reference_id = ar.ar_id AND p.reference_type = 'receivable'\nWHERE s.user_id = ?\nAND LOWER(IFNULL(s.status,'')) <> 'cancelled'\n");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$ar = $stmt->get_result()->fetch_assoc() ?: ['ar_balance'=>0,'open_ar_count'=>0,'overdue_count'=>0];
$stmt->close();

$stockAggregateSql = "\nSELECT\n  p.product_id,\n  p.variety,\n  p.grade,\n  IFNULL(SUM(CASE\n    WHEN LOWER(it.type)='in' THEN it.qty_kg\n    WHEN LOWER(it.type)='out' THEN -it.qty_kg\n    WHEN LOWER(it.type)='adjust' THEN it.qty_kg\n    ELSE 0 END),0) AS stock_kg\nFROM products p\nLEFT JOIN inventory_transactions it ON it.product_id = p.product_id\nWHERE p.archived=0\nGROUP BY p.product_id\n";

$stmt = $conn->prepare("SELECT COUNT(*) AS low_count FROM ({$stockAggregateSql}) x WHERE x.stock_kg <= ?");
$stmt->bind_param("d", $LOW_STOCK_THRESHOLD);
$stmt->execute();
$lowCount = (int)($stmt->get_result()->fetch_assoc()['low_count'] ?? 0);
$stmt->close();

$stmt = $conn->prepare("SELECT COUNT(*) AS over_count FROM ({$stockAggregateSql}) x WHERE x.stock_kg >= ?");
$stmt->bind_param("d", $OVERSTOCK_THRESHOLD);
$stmt->execute();
$overCount = (int)($stmt->get_result()->fetch_assoc()['over_count'] ?? 0);
$stmt->close();

$stmt = $conn->prepare("\nSELECT x.product_id, x.variety, x.grade, x.stock_kg\nFROM ({$stockAggregateSql}) x\nWHERE x.stock_kg <= ?\nORDER BY x.stock_kg ASC\nLIMIT 8\n");
$stmt->bind_param("d", $LOW_STOCK_THRESHOLD);
$stmt->execute();
$lowStock = $stmt->get_result();
$stmt->close();

$stmt = $conn->prepare("\nSELECT\n  p.variety,\n  p.grade,\n  IFNULL(SUM(si.qty_kg),0) AS sold_kg\nFROM sales_items si\nJOIN sales s ON s.sale_id = si.sale_id\nJOIN products p ON p.product_id = si.product_id\nWHERE s.user_id = ?\nAND s.sale_date >= ? AND s.sale_date < ?\nAND LOWER(IFNULL(s.status,'')) <> 'cancelled'\nGROUP BY p.product_id\nORDER BY sold_kg DESC\nLIMIT 5\n");
$stmt->bind_param("iss", $user_id, $weekStart, $todayEnd);
$stmt->execute();
$fastMoving = $stmt->get_result();
$stmt->close();

$stmt = $conn->prepare("\nSELECT\n  s.sale_id,\n  s.sale_date,\n  s.total_amount,\n  (IFNULL(ar.balance,0) + ({$penaltyOutstandingSql})) AS balance,\n  ar.due_date,\n  c.first_name,\n  c.last_name\nFROM account_receivable ar\nJOIN sales s ON s.sale_id = ar.sales_id\nLEFT JOIN customers c ON c.customer_id = s.customer_id\nLEFT JOIN penalties p ON p.reference_id = ar.ar_id AND p.reference_type = 'receivable'\nWHERE s.user_id = ?\nAND (ar.balance > 0 OR ({$penaltyOutstandingSql}) > 0)\nAND LOWER(IFNULL(s.status,'')) <> 'cancelled'\nORDER BY\n  CASE WHEN ar.due_date IS NOT NULL AND ar.due_date < CURDATE() THEN 0 ELSE 1 END,\n  IFNULL(ar.due_date, '9999-12-31') ASC,\n  balance DESC\nLIMIT 8\n");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$followUps = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cashier Dashboard | DOHIVES</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="../css/layout.css" rel="stylesheet">
<link href="../css/cashier-dashboard.css" rel="stylesheet">
<link href="../css/cashier-mobile.css" rel="stylesheet">
</head>
<body>

<?php
$profileLink = 'cashier_profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>

<div class="container-fluid">
<div class="row">

<?php include '../includes/cashier_sidebar.php'; ?>

<main class="col-lg-10 ms-sm-auto px-4 main-content">
<div class="py-4">
<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
  <div>
    <div class="section-subtitle mb-1">Cashier Dashboard</div>
    <h3 class="fw-bold mb-1">Cashier Operations Dashboard</h3>
    <div class="text-muted">Daily monitoring for stock releases, receivables, and follow-ups.</div>
  </div>
  <a class="btn btn-dark" href="sales_history.php"><i class="fa-solid fa-list me-1"></i>View Transactions</a>
</div>

<div class="row g-3">
  <div class="col-12 col-md-6 col-xl-3">
    <div class="card modern-card card-kpi h-100">
      <div class="card-body">
        <div class="d-flex align-items-start justify-content-between gap-3">
          <div class="flex-grow-1 min-w-0">
            <div class="kpi-label">Transactions Today</div>
            <div class="kpi-value"><?= (int)$today['total_sales'] ?></div>
            <div class="kpi-sub">Handled by your account</div>
          </div>
          <span class="kpi-icon"><i class="fa-solid fa-receipt"></i></span>
        </div>
      </div>
    </div>
  </div>
  <div class="col-12 col-md-6 col-xl-3">
    <div class="card modern-card card-kpi h-100">
      <div class="card-body">
        <div class="d-flex align-items-start justify-content-between gap-3">
          <div class="flex-grow-1 min-w-0">
            <div class="kpi-label">Value Released Today</div>
            <div class="kpi-value">₱<?= number_format((float)$today['revenue'],2) ?></div>
            <div class="kpi-sub">Excludes cancelled documents</div>
          </div>
          <span class="kpi-icon"><i class="fa-solid fa-coins"></i></span>
        </div>
      </div>
    </div>
  </div>
  <div class="col-12 col-md-6 col-xl-3">
    <div class="card modern-card card-kpi h-100">
      <div class="card-body">
        <div class="d-flex align-items-start justify-content-between gap-3">
          <div class="flex-grow-1 min-w-0">
            <div class="kpi-label">Rice Released Today</div>
            <div class="kpi-value"><?= number_format((float)$kgToday['sold_kg'],2) ?> <span>kg</span></div>
            <div class="kpi-sub">Total volume served</div>
          </div>
          <span class="kpi-icon"><i class="fa-solid fa-boxes-stacked"></i></span>
        </div>
      </div>
    </div>
  </div>
  <div class="col-12 col-md-6 col-xl-3">
    <div class="card modern-card card-kpi h-100">
      <div class="card-body">
        <div class="d-flex align-items-start justify-content-between gap-3">
          <div class="flex-grow-1 min-w-0">
            <div class="kpi-label">Open Receivables</div>
            <div class="kpi-value">₱<?= number_format((float)$ar['ar_balance'],2) ?></div>
            <div class="kpi-sub"><?= (int)$ar['open_ar_count'] ?> document(s), <?= (int)$ar['overdue_count'] ?> overdue</div>
          </div>
          <span class="kpi-icon"><i class="fa-solid fa-file-invoice-dollar"></i></span>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="row g-4 mt-1">
  <div class="col-12 col-xl-7">
    <div class="card modern-card h-100">
      <div class="card-body">
        <div class="section-title mb-3">
          <h5 class="fw-bold mb-0">Receivable Follow-up Queue</h5>
          <a href="payments.php" class="btn btn-sm btn-outline-dark">Record Payment</a>
        </div>
        <div class="table-responsive">
          <table class="table table-striped align-middle mb-0">
            <thead class="table-dark">
              <tr>
                <th>Sale #</th>
                <th>Customer</th>
                <th>Due Date</th>
                <th>Balance</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php if($followUps && $followUps->num_rows): ?>
                <?php while($row = $followUps->fetch_assoc()): ?>
                  <?php
                    $customer = trim((string)($row['first_name'] ?? '').' '.(string)($row['last_name'] ?? ''));
                    if($customer === '') $customer = 'Walk-in / N/A';
                    $dueRaw = trim((string)($row['due_date'] ?? ''));
                    $isOverdue = ($dueRaw !== '' && strtotime($dueRaw) < strtotime(date('Y-m-d')));
                  ?>
                  <tr>
                    <td class="fw-semibold">#<?= (int)$row['sale_id'] ?></td>
                    <td><?= h($customer) ?></td>
                    <td><?= $dueRaw !== '' ? h(date('M d, Y', strtotime($dueRaw))) : '<span class="text-muted">No due date</span>' ?></td>
                    <td class="fw-semibold">₱<?= number_format((float)$row['balance'],2) ?></td>
                    <td>
                      <?php if($isOverdue): ?>
                        <span class="badge text-bg-danger">Overdue</span>
                      <?php else: ?>
                        <span class="badge text-bg-warning">Open</span>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="5" class="text-center text-muted">No open receivables for your account.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 col-xl-5">
    <div class="card modern-card mb-4">
      <div class="card-body">
        <div class="section-title mb-3">
          <h5 class="fw-bold mb-0">Stock Risk Monitor</h5>
          <a href="inventory_view.php" class="btn btn-sm btn-outline-dark">Open Stocks View</a>
        </div>
        <div class="d-flex flex-wrap gap-2 mb-3">
          <span class="badge-soft">Low Stock: <?= (int)$lowCount ?></span>
          <span class="badge-soft">Overstock: <?= (int)$overCount ?></span>
          <span class="badge-soft">Low Threshold: <?= number_format($LOW_STOCK_THRESHOLD,0) ?> kg</span>
        </div>
        <div class="table-responsive">
          <table class="table table-sm align-middle mb-0">
            <thead class="table-dark">
              <tr>
                <th>Variety</th>
                <th class="text-end">On-hand (kg)</th>
              </tr>
            </thead>
            <tbody>
              <?php if($lowStock && $lowStock->num_rows): ?>
                <?php while($p = $lowStock->fetch_assoc()): ?>
                  <tr>
                    <td><?= h($p['variety'].' - '.$p['grade']) ?></td>
                    <td class="text-end fw-semibold"><?= number_format((float)$p['stock_kg'],2) ?></td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="2" class="text-center text-muted">No low stock items.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="card modern-card">
      <div class="card-body">
        <h5 class="fw-bold mb-3">Fast-moving Varieties (Last 7 Days)</h5>
        <div class="table-responsive">
          <table class="table table-sm align-middle mb-0">
            <thead class="table-dark">
              <tr>
                <th>Variety</th>
                <th class="text-end">Released (kg)</th>
              </tr>
            </thead>
            <tbody>
              <?php if($fastMoving && $fastMoving->num_rows): ?>
                <?php while($f = $fastMoving->fetch_assoc()): ?>
                  <tr>
                    <td><?= h($f['variety'].' - '.$f['grade']) ?></td>
                    <td class="text-end fw-semibold"><?= number_format((float)$f['sold_kg'],2) ?></td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="2" class="text-center text-muted">No movement in the last 7 days.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

</div>
</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
