<?php

session_start();

header(
    'Content-Type: application/json; charset=utf-8'
);


// ============================================================
// AUTH CHECK
// ============================================================

if(
    !isset($_SESSION['user_id']) ||
    strtolower(
        trim($_SESSION['role'] ?? '')
    ) !== 'cashier'
){

    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'Unauthorized'
    ]);

    exit;
}


// ============================================================
// DATABASE CONNECTION
// ============================================================

include '../config/db.php';


if(!isset($conn) || !$conn){

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Database connection failed'
    ]);

    exit;
}


// ============================================================
// CUSTOMER ID
// ============================================================

$customer_id =
    (int)($_GET['customer_id'] ?? 0);


if($customer_id <= 0){

    echo json_encode([
        'success' => false,
        'error' => 'Invalid customer ID'
    ]);

    exit;
}


// ============================================================
// PURCHASE HISTORY QUERY
// ============================================================

$sql = "

    SELECT

        s.sale_id,

        s.sale_date,

        s.total_amount,

        s.status,


        COUNT(
            DISTINCT si.sales_item_id
        ) AS item_count,


        GROUP_CONCAT(

            DISTINCT CONCAT(

                p.variety,

                ' - ',

                p.grade

            )

            ORDER BY
                p.variety,
                p.grade

            SEPARATOR '|||'

        ) AS item_names


    FROM sales s


    LEFT JOIN sales_items si

        ON si.sale_id = s.sale_id


    LEFT JOIN products p

        ON p.product_id = si.product_id


    WHERE s.customer_id = ?


    GROUP BY

        s.sale_id,

        s.sale_date,

        s.total_amount,

        s.status


    ORDER BY

        s.sale_date DESC,

        s.sale_id DESC


    LIMIT 100

";


// ============================================================
// PREPARE
// ============================================================

$stmt =
    $conn->prepare($sql);


if(!$stmt){

    http_response_code(500);

    echo json_encode([

        'success' => false,

        'error' =>
            'Prepare failed',

        'details' =>
            $conn->error

    ]);

    exit;
}


// ============================================================
// BIND
// ============================================================

$stmt->bind_param(
    "i",
    $customer_id
);


// ============================================================
// EXECUTE
// ============================================================

if(!$stmt->execute()){

    http_response_code(500);

    echo json_encode([

        'success' => false,

        'error' =>
            'Execute failed',

        'details' =>
            $stmt->error

    ]);

    $stmt->close();

    exit;
}


// ============================================================
// RESULTS
// ============================================================

$result =
    $stmt->get_result();


$purchases = [];


while(
    $row =
        $result->fetch_assoc()
){

    $purchases[] = [

        'sale_id' =>
            (int)$row['sale_id'],


        'sale_date' =>
            !empty($row['sale_date'])

                ? date(
                    'F d, Y',
                    strtotime(
                        $row['sale_date']
                    )
                )

                : 'N/A',


        'total_amount' =>
            (float)$row['total_amount'],


        'payment_status' =>
            !empty($row['status'])

                ? strtolower(
                    trim(
                        $row['status']
                    )
                )

                : 'Unknown',


        'item_count' =>
            (int)$row['item_count'],


        'item_names' =>
            !empty($row['item_names'])

                ? $row['item_names']

                : 'No items'

    ];
}


$stmt->close();


// ============================================================
// RESPONSE
// ============================================================

echo json_encode([

    'success' =>
        true,

    'purchases' =>
        $purchases

]);

?>