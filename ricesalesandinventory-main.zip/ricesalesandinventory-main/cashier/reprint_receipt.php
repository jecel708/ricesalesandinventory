<?php
session_start();
if(!isset($_SESSION['user_id'])){ header("Location: ../login.php"); exit; }
if(strtolower($_SESSION['role'] ?? '') !== 'cashier'){ header("Location: ../login.php"); exit; }

include '../config/db.php';
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$sale_id = (int)($_GET['sale_id'] ?? 0);
if($sale_id <= 0){ die("Invalid sale."); }

$companyName = "DE ORO HIYS GENERAL MERCHANDISE";
$companyAddr = "V Castro St, Carmen";
$vatTin      = "000-000-000-000";
$posSn       = "POS01-SN: XXXXXXXX";
$minNo       = "MIN#XXXXXXXXXXXX";

$VAT_MODE = "EXEMPT"; // EXEMPT | VATABLE
$VAT_RATE = 0.12;

$stmt = $conn->prepare("
  SELECT s.sale_id, s.sale_date, s.total_amount, s.status,
         c.customer_id, c.first_name, c.last_name, c.phone, c.address,
         u.username AS cashier_name
  FROM sales s
  LEFT JOIN customers c ON s.customer_id = c.customer_id
  LEFT JOIN users u ON s.user_id = u.user_id
  WHERE s.sale_id = ?
  LIMIT 1
");
if(!$stmt){ die("DB error (sale): ".$conn->error); }
$stmt->bind_param("i", $sale_id);
$stmt->execute();
$sale = $stmt->get_result()->fetch_assoc();
$stmt->close();

if(!$sale){ die("Sale not found."); }

$stmt = $conn->prepare("
  SELECT
    si.sales_item_id,
    si.product_id,
    si.qty_kg,
    si.unit_price,
    si.line_total,
    si.unit_type,
    si.qty_input,
    si.discount_kg,
    si.regular_kg,
    p.variety,
    p.grade,
    p.unit_weight_kg,
    p.price_per_kg,
    p.price_per_sack
  FROM sales_items si
  LEFT JOIN products p ON si.product_id = p.product_id
  WHERE si.sale_id = ?
  ORDER BY si.sales_item_id ASC
");
if(!$stmt){ die("DB error (items): ".$conn->error); }
$stmt->bind_param("i", $sale_id);
$stmt->execute();
$resItems = $stmt->get_result();
$items = [];
while($r = $resItems->fetch_assoc()){ $items[] = $r; }
$stmt->close();

$isUtang = (strtolower((string)$sale['status']) === 'unpaid');
$ar = null;

if($isUtang){
  $stmt = $conn->prepare("
    SELECT total_amount, amount_paid, balance, due_date, status
    FROM account_receivable
    WHERE sales_id = ?
    LIMIT 1
  ");
  if($stmt){
    $stmt->bind_param("i", $sale_id);
    $stmt->execute();
    $ar = $stmt->get_result()->fetch_assoc();
    $stmt->close();
  }
}

$payment = null;
if(!$isUtang){
  $stmt = $conn->prepare("
    SELECT payment_id, amount, method, paid_at
    FROM payments
    WHERE sale_id = ?
    ORDER BY paid_at DESC
    LIMIT 1
  ");
  if($stmt){
    $stmt->bind_param("i", $sale_id);
    $stmt->execute();
    $payment = $stmt->get_result()->fetch_assoc();
    $stmt->close();
  }
}

/*
  Reprint should not depend on session data.
  It uses the saved database values only.
*/
$discType = 'none';
$discRate = 0.0;
$discAmt  = 0.0;
$discName = '';
$discIdNo = '';

$subtotal = 0.0;
foreach($items as $it){
  $line = (float)($it['line_total'] ?? 0);
  if($line <= 0) $line = (float)$it['qty_kg'] * (float)$it['unit_price'];
  $subtotal += $line;
}
if($subtotal < 0) $subtotal = 0;

$gross = $subtotal;
$net   = (float)($sale['total_amount'] ?? 0);
if($net <= 0) $net = $gross;

if($gross > 0 && $net < $gross){
  $discAmt = max(0, round($gross - $net, 2));
}

/*
|--------------------------------------------------------------------------
| VAT breakdown
|--------------------------------------------------------------------------
*/
$vatableSales = 0.0;
$vatExemptSales = 0.0;
$vatZeroRatedSales = 0.0;
$vatAmount = 0.0;
$lessVat = 0.0;

if($VAT_MODE === "VATABLE"){
  $salesWithoutVat = $net / (1 + $VAT_RATE);
  $lessVat = $net - $salesWithoutVat;

  if(in_array($discType, ['pwd','sc'], true)){
    $vatableSales = 0.0;
    $vatAmount = 0.0;
    $vatExemptSales = $salesWithoutVat;
  } else {
    $vatableSales = $salesWithoutVat;
    $vatAmount = $lessVat;
    $vatExemptSales = 0.0;
  }
} else {
  $vatExemptSales = $net;
}

$receiptTitle = $isUtang ? "SALES INVOICE (UTANG)" : "OFFICIAL RECEIPT (CASH)";
$customerName = trim(($sale['first_name'] ?? '').' '.($sale['last_name'] ?? ''));
if($customerName === '') $customerName = 'Walk-in';

function peso($n){
  return number_format((float)$n, 2);
}

/*
|--------------------------------------------------------------------------
| Optional audit log for reprint
|--------------------------------------------------------------------------
| Create this table if you want logging:
|
| CREATE TABLE receipt_reprints (
|   id INT AUTO_INCREMENT PRIMARY KEY,
|   sale_id INT NOT NULL,
|   user_id INT NOT NULL,
|   reprinted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
| );
|
*/
$logCheck = $conn->query("SHOW TABLES LIKE 'receipt_reprints'");
if($logCheck && $logCheck->num_rows > 0){
  $uid = (int)($_SESSION['user_id'] ?? 0);
  $stmt = $conn->prepare("
    INSERT INTO receipt_reprints (sale_id, user_id)
    VALUES (?, ?)
  ");
  if($stmt){
    $stmt->bind_param("ii", $sale_id, $uid);
    $stmt->execute();
    $stmt->close();
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reprint Receipt #<?= (int)$sale_id ?></title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="../css/cashier-receipt.css" rel="stylesheet">

<style>
.reprint-badge{
  display:inline-block;
  margin-top:8px;
  padding:4px 10px;
  border:1px solid #dc2626;
  color:#dc2626;
  font-weight:700;
  border-radius:999px;
  font-size:12px;
  letter-spacing:.5px;
}
@media print{
  .no-print{ display:none !important; }
}
</style>
</head>

<body>
<div class="paper mono">

  <div class="text-center">
    <div class="fw-bold"><?= h($companyName) ?></div>
    <div class="small3"><?= h($companyAddr) ?></div>
    <div class="small3">VAT REG TIN: <?= h($vatTin) ?></div>
    <div class="small3"><?= h($posSn) ?> • <?= h($minNo) ?></div>

    <div class="mt-2 fw-bold"><?= h($receiptTitle) ?></div>
    <div class="reprint-badge">REPRINT COPY</div>

    <div class="mt-2 d-flex justify-content-center gap-2 flex-wrap">
      <?php if(!$isUtang): ?>
        <span class="badge-pill badge-paid">PAID</span>
      <?php else: ?>
        <span class="badge-pill badge-ut">UTANG / UNPAID</span>
      <?php endif; ?>
    </div>
  </div>

  <div class="hr-dash"></div>

  <div class="small2">
    <div class="kv"><span>Sale #</span><span><b><?= (int)$sale['sale_id'] ?></b></span></div>
    <div class="kv"><span>Date</span><span><?= h(date("m/d/Y h:i A", strtotime($sale['sale_date']))) ?></span></div>
    <div class="kv"><span>Cashier</span><span><?= h($sale['cashier_name'] ?: 'Cashier') ?></span></div>
    <div class="kv"><span>Customer</span><span><?= h($customerName) ?></span></div>
    <?php if(!empty($sale['phone'])): ?>
      <div class="kv"><span>Phone</span><span><?= h($sale['phone']) ?></span></div>
    <?php endif; ?>
  </div>

  <div class="hr-dash"></div>

  <div class="small2 fw-bold d-flex justify-content-between">
    <span>ITEMS</span><span>AMOUNT</span>
  </div>

  <table class="tableMini small2 mt-1">
    <?php foreach($items as $it): ?>
      <?php
        $name = trim(($it['variety'] ?? 'Rice') . ' - ' . ($it['grade'] ?? ''));

        $qtyKg = (float)($it['qty_kg'] ?? 0);
        $unitPrice = (float)($it['unit_price'] ?? 0);
        $line = (float)($it['line_total'] ?? 0);
        if($line <= 0) $line = $qtyKg * $unitPrice;

        $sackW = (float)($it['unit_weight_kg'] ?? 0);
        $regularPriceKg = (float)($it['price_per_kg'] ?? 0);

        $uType = strtolower((string)($it['unit_type'] ?? 'kg'));
        if(!in_array($uType, ['kg','sack'], true)) $uType = 'kg';

        $qtyInput = (float)($it['qty_input'] ?? 0);
        $discountKg = (float)($it['discount_kg'] ?? 0);
        $regularKg = (float)($it['regular_kg'] ?? 0);

        if($qtyInput <= 0){
          if($uType === 'sack' && $sackW > 0){
            $qtyInput = $qtyKg / $sackW;
          } else {
            $uType = 'kg';
            $qtyInput = $qtyKg;
          }
        }

        $qtyLabel = ($uType === 'sack')
          ? (number_format($qtyInput,0) . " sack(s)")
          : (number_format($qtyInput,2) . " kg");

        $unitLabel = ($uType === 'sack') ? "/sack" : "/kg";

        $mixText = '';
        if($discountKg > 0 && $regularKg > 0){
          $mixText = "Mix: ".number_format($discountKg,2)." kg discounted + ".number_format($regularKg,2)." kg regular";
        } elseif($discountKg > 0){
          $mixText = "All from discounted stock";
        } elseif($regularKg > 0){
          $mixText = "All from regular stock";
        }

        $effectivePerKg = ($qtyKg > 0) ? ($line / $qtyKg) : 0;
      ?>
      <tr>
        <td style="padding-right:8px;">
          <div class="fw-semibold"><?= h($name) ?></div>
          <div class="small3">
            <?= h($qtyLabel) ?>
            <?php if($uType === 'sack'): ?>
              • <?= number_format($qtyKg,2) ?> kg total
            <?php endif; ?>
          </div>
          <div class="small3">
            Effective price: <?= peso($effectivePerKg) ?>/kg
            <?php if($uType === 'sack'): ?>
              • <?= peso($unitPrice) ?><?= h($unitLabel) ?>
            <?php endif; ?>
          </div>
          <?php if($mixText !== ''): ?>
            <div class="small3"><?= h($mixText) ?></div>
          <?php endif; ?>
          <?php if($discountKg > 0 && $regularKg > 0): ?>
            <div class="small3 text-muted">
              Regular price: <?= peso($regularPriceKg) ?>/kg
            </div>
          <?php endif; ?>
        </td>
        <td class="amount fw-bold"><?= peso($line) ?></td>
      </tr>
    <?php endforeach; ?>
  </table>

  <div class="hr-dash"></div>

  <div class="totalBox">
    <div class="small2 kv"><span>Subtotal</span><span><?= peso($gross) ?></span></div>

    <?php if($discAmt > 0.00001): ?>
      <div class="small2 kv text-danger">
        <span><?= ($discType === 'others' && $discRate > 0) ? 'Less Custom Discount' : 'Less Discount' ?></span>
        <span>- <?= peso($discAmt) ?></span>
      </div>
    <?php endif; ?>

    <?php if($VAT_MODE === "VATABLE"): ?>
      <div class="small2 kv">
        <span>VAT (12%)</span>
        <span><?= peso($lessVat) ?></span>
      </div>
    <?php endif; ?>

    <div class="hr-dash"></div>

    <div class="d-flex justify-content-between align-items-end">
      <div class="small2 text-muted">TOTAL DUE</div>
      <div class="totalDue">₱ <?= peso($net) ?></div>
    </div>

    <?php if(!$isUtang): ?>
      <div class="small3 mt-2">
        Payment: <?= h(strtoupper($payment['method'] ?? 'CASH')) ?>
      </div>
    <?php else: ?>
      <div class="small3 mt-2">
        Paid: <?= peso((float)($ar['amount_paid'] ?? 0)) ?>
        • Balance: <b><?= peso((float)($ar['balance'] ?? $net)) ?></b>
        <?php if(!empty($ar['due_date'])): ?>
          • Due: <?= h(date("m/d/Y", strtotime($ar['due_date']))) ?>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </div>

  <div class="hr-dash"></div>

  <div class="small2">
    <div class="kv"><span>VATable Sales</span><span><?= peso($vatableSales) ?></span></div>
    <div class="kv"><span>VAT-Exempt Sales</span><span><?= peso($vatExemptSales) ?></span></div>
    <div class="kv"><span>VAT Zero-Rated Sales</span><span><?= peso($vatZeroRatedSales) ?></span></div>
    <div class="kv"><span>VAT Amount</span><span><?= peso($vatAmount) ?></span></div>
  </div>

  <div class="text-center small3 mt-3">
    — END OF REPRINT RECEIPT —
  </div>

  <div class="no-print d-grid gap-2 mt-3">
    <button class="btn btn-dark" onclick="window.print()">Print Receipt</button>
    <a href="sales_history.php" class="btn btn-outline-secondary">Back to Sales History</a>
  </div>

</div>
</body>
</html>