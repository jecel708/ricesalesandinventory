<?php
session_start();
if(!isset($_SESSION['user_id'])){
  header("Location: ../login.php");
  exit;
}
if(strtolower($_SESSION['role'] ?? '') !== 'cashier'){
  header("Location: ../login.php");
  exit;
}

$username = $_SESSION['username'] ?? 'Cashier';
$user_id = (int)($_SESSION['user_id'] ?? 0);

include '../config/db.php';

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$view_id = isset($_GET['view']) ? (int)$_GET['view'] : 0;

if(empty($_SESSION['csrf_token'])){
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function require_csrf_or_redirect(string $target): void {
  $posted = (string)($_POST['csrf_token'] ?? '');
  $stored = (string)($_SESSION['csrf_token'] ?? '');
  if($posted === '' || $stored === '' || !hash_equals($stored, $posted)){
    header("Location: {$target}?error=" . urlencode("Invalid request token. Please refresh and try again."));
    exit;
  }
}

function restore_voided_sale_stock(mysqli $conn, int $sale_id): void {
  $stmt = $conn->prepare("
    SELECT product_id, batch_id, qty_kg, discount_kg, regular_kg
    FROM sales_items
    WHERE sale_id = ?
    ORDER BY sales_item_id ASC
  ");
  if(!$stmt){
    throw new Exception("Unable to load sale items for voiding.");
  }
  $stmt->bind_param("i", $sale_id);
  $stmt->execute();
  $res = $stmt->get_result();
  $items = [];
  while($row = $res->fetch_assoc()){
    $items[] = $row;
  }
  $stmt->close();

  foreach($items as $it){
    $productId = (int)($it['product_id'] ?? 0);
    $batchId = (int)($it['batch_id'] ?? 0);
    $qtyKg = (float)($it['qty_kg'] ?? 0);
    $discountKg = (float)($it['discount_kg'] ?? 0);
    $regularKg = (float)($it['regular_kg'] ?? 0);

    if($productId <= 0 || $batchId <= 0 || $qtyKg <= 0){
      continue;
    }

    if($regularKg > 0){
      $stmt = $conn->prepare("
        UPDATE stock_batches
        SET regular_qty_kg = regular_qty_kg + ?,
            remaining_qty_kg = remaining_qty_kg + ?,
            updated_at = NOW()
        WHERE batch_id = ? AND product_id = ?
      ");
      if(!$stmt){
        throw new Exception("Unable to restore regular stock.");
      }
      $stmt->bind_param("ddii", $regularKg, $regularKg, $batchId, $productId);
      $stmt->execute();
      $stmt->close();
    }

    if($discountKg > 0){
      $stmt = $conn->prepare("
        UPDATE stock_batches
        SET discounted_qty_kg = discounted_qty_kg + ?,
            remaining_qty_kg = remaining_qty_kg + ?,
            updated_at = NOW()
        WHERE batch_id = ? AND product_id = ?
      ");
      if(!$stmt){
        throw new Exception("Unable to restore discounted stock.");
      }
      $stmt->bind_param("ddii", $discountKg, $discountKg, $batchId, $productId);
      $stmt->execute();
      $stmt->close();

      $stmt = $conn->prepare("
        INSERT INTO product_discount_stock (product_id, qty_kg)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE qty_kg = qty_kg + VALUES(qty_kg)
      ");
      if(!$stmt){
        throw new Exception("Unable to restore discounted stock bucket.");
      }
      $stmt->bind_param("id", $productId, $discountKg);
      $stmt->execute();
      $stmt->close();
    }

    $stmt = $conn->prepare("
      INSERT INTO inventory_transactions
        (product_id, batch_id, qty_kg, reference_id, reference_type, type, note, created_at)
      VALUES (?, ?, ?, ?, 'sale', 'in', ?, NOW())
    ");
    if(!$stmt){
      throw new Exception("Unable to record stock reversal.");
    }
    $note = "Void Sale #{$sale_id} - stock restored";
    $stmt->bind_param("iidis", $productId, $batchId, $qtyKg, $sale_id, $note);
    $stmt->execute();
    $stmt->close();
  }
}

if(isset($_POST['void_sale'])){
  require_csrf_or_redirect('sales_history.php');
  $sale_id = (int)($_POST['sale_id'] ?? 0);
  if($sale_id <= 0){
    header("Location: sales_history.php?error=" . urlencode("Invalid sale."));
    exit;
  }

  $conn->begin_transaction();
  try {
    $stmt = $conn->prepare("
      SELECT sale_id, status
      FROM sales
      WHERE sale_id = ? AND user_id = ?
      FOR UPDATE
    ");
    if(!$stmt){
      throw new Exception("Unable to load sale.");
    }
    $stmt->bind_param("ii", $sale_id, $user_id);
    $stmt->execute();
    $sale = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if(!$sale){
      throw new Exception("Sale not found.");
    }
    if(strtolower(trim((string)($sale['status'] ?? ''))) === 'cancelled'){
      throw new Exception("This sale is already voided.");
    }

    restore_voided_sale_stock($conn, $sale_id);

    $stmt = $conn->prepare("UPDATE sales SET status = 'cancelled' WHERE sale_id = ? AND user_id = ?");
    if(!$stmt){
      throw new Exception("Unable to update sale status.");
    }
    $stmt->bind_param("ii", $sale_id, $user_id);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare("UPDATE account_receivable SET status = 'voided', balance = 0, amount_paid = total_amount WHERE sales_id = ?");
    if($stmt){
      $stmt->bind_param("i", $sale_id);
      $stmt->execute();
      $stmt->close();
    }

    $stmt = $conn->prepare("UPDATE payments SET status = 'voided' WHERE sale_id = ?");
    if($stmt){
      $stmt->bind_param("i", $sale_id);
      $stmt->execute();
      $stmt->close();
    }

    $conn->commit();
    header("Location: sales_history.php?success=" . urlencode("Sale #{$sale_id} has been voided."));
    exit;
  } catch(Throwable $e){
    $conn->rollback();
    header("Location: sales_history.php?error=" . urlencode($e->getMessage()));
    exit;
  }
}

function fetch_sale_details(mysqli $conn, int $sale_id, int $user_id): ?array {
  $stmt = $conn->prepare("
    SELECT s.*, c.first_name, c.last_name,
           ar.due_date AS ar_due_date,
           IFNULL(ar.balance, 0) AS ar_balance
    FROM sales s
    LEFT JOIN customers c ON s.customer_id = c.customer_id
    LEFT JOIN account_receivable ar ON ar.sales_id = s.sale_id
    WHERE s.sale_id=? AND s.user_id=?
    LIMIT 1
  ");
  $stmt->bind_param("ii", $sale_id, $user_id);
  $stmt->execute();
  $saleInfo = $stmt->get_result()->fetch_assoc();
  $stmt->close();

  if(!$saleInfo){
    return null;
  }

  $items = [];
  $stmt = $conn->prepare("
    SELECT
      si.sales_item_id,
      si.sale_id,
      si.product_id,
      si.qty_kg,
      si.unit_price,
      si.line_total,
      si.unit_type,
      si.qty_input,
      si.discount_kg,
      si.regular_kg,
      p.variety,
      p.grade,
      p.unit_weight_kg,
      p.price_per_kg,
      p.price_per_sack
    FROM sales_items si
    LEFT JOIN products p ON si.product_id = p.product_id
    WHERE si.sale_id=?
    ORDER BY si.sales_item_id ASC
  ");
  $stmt->bind_param("i", $sale_id);
  $stmt->execute();
  $itemsRes = $stmt->get_result();
  while($r = $itemsRes->fetch_assoc()) $items[] = $r;
  $stmt->close();

  return ['sale' => $saleInfo, 'items' => $items];
}

function render_reprint_button(array $saleInfo): void {
  $sale_id = (int)($saleInfo['sale_id'] ?? 0);
  $status = strtolower(trim((string)($saleInfo['status'] ?? '')));
  if($sale_id <= 0 || $status !== 'paid'){
    return;
  }
  ?>
  <div class="mt-2 d-grid">
    <a class="btn btn-primary"
       href="reprint_receipt.php?sale_id=<?= $sale_id ?>"
       target="_blank">
      <i class="fa-solid fa-print me-1"></i> Reprint Receipt
    </a>
  </div>
  <?php
}

function render_void_button(array $saleInfo): void {
  $sale_id = (int)($saleInfo['sale_id'] ?? 0);
  $status = strtolower(trim((string)($saleInfo['status'] ?? '')));
  if($sale_id <= 0 || !in_array($status, ['paid', 'unpaid'], true)){
    return;
  }
  ?>
  <form method="post" class="d-grid" onsubmit="return confirm('Void Sale #<?= $sale_id ?>? This will restore stock and mark the sale cancelled.');">
    <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token'] ?? '') ?>">
    <input type="hidden" name="sale_id" value="<?= $sale_id ?>">
    <input type="hidden" name="void_sale" value="1">
    <button type="submit" class="btn btn-outline-danger">
      <i class="fa-solid fa-ban me-1"></i> Void Sale
    </button>
  </form>
  <?php
}

function render_sale_details_html(array $saleInfo, array $items): void {
  $detailStatus = strtolower(trim((string)($saleInfo['status'] ?? '')));
  $cust = trim(($saleInfo['first_name'] ?? '').' '.($saleInfo['last_name'] ?? ''));
  if($detailStatus !== 'unpaid' || $cust === ''){
    $cust = 'Walk-in Customer';
  }
  $detailDueDate = trim((string)($saleInfo['ar_due_date'] ?? ''));

  $gross = 0.0;
  $totalDiscountedKg = 0.0;
  $totalRegularKg = 0.0;

  foreach($items as $it){
    $gross += (float)($it['line_total'] ?? 0);
    $totalDiscountedKg += (float)($it['discount_kg'] ?? 0);
    $totalRegularKg += (float)($it['regular_kg'] ?? 0);
  }

  $net = (float)($saleInfo['total_amount'] ?? 0);
  $discAmt = max(0, round($gross - $net, 2));
  ?>
  <div class="d-flex align-items-start justify-content-between gap-3 flex-wrap mb-3">
    <div>
      <div class="text-muted small">Invoice #</div>
      <div class="h4 mb-0">INV-<?= str_pad((string)(int)$saleInfo['sale_id'], 6, '0', STR_PAD_LEFT) ?></div>
    </div>
    <div class="text-end">
      <div class="text-muted small">Net Total</div>
      <div class="h5 fw-bold mb-0">₱<?= number_format($net,2) ?></div>
    </div>
  </div>

  <div class="row g-2 mb-3">
    <div class="col-md-4">
      <div class="border rounded p-2 bg-light">
        <div class="small text-muted">Customer</div>
        <div class="fw-semibold"><?= h($cust) ?></div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="border rounded p-2 bg-light">
        <div class="small text-muted">Date</div>
        <div class="fw-semibold"><?= $saleInfo['sale_date'] ? date("M d, Y h:i A", strtotime($saleInfo['sale_date'])) : '' ?></div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="border rounded p-2 bg-light">
        <div class="small text-muted">Status</div>
        <div class="fw-semibold">
          <?php if($detailStatus === 'paid'): ?>
            <span class="badge bg-success">PAID</span>
          <?php elseif($detailStatus === 'unpaid'): ?>
            <span class="badge bg-warning text-dark">UNPAID</span>
          <?php elseif($detailStatus === 'cancelled'): ?>
            <span class="badge bg-secondary">VOIDED</span>
          <?php else: ?>
            <span class="badge bg-secondary"><?= h(strtoupper($detailStatus ?: 'N/A')) ?></span>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="border rounded p-2 bg-light">
        <div class="small text-muted">Gross</div>
        <div class="fw-bold">₱<?= number_format($gross,2) ?></div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="border rounded p-2 bg-light">
        <div class="small text-muted">Header Discount</div>
        <div class="fw-bold text-danger">₱<?= number_format($discAmt,2) ?></div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="border rounded p-2 bg-light">
        <div class="small text-muted">Balance</div>
        <div class="fw-bold">₱<?= number_format((float)($saleInfo['ar_balance'] ?? 0),2) ?></div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="border rounded p-2 bg-light">
        <div class="small text-muted">Discounted Qty Sold</div>
        <div class="fw-bold"><?= number_format($totalDiscountedKg,2) ?> kg</div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="border rounded p-2 bg-light">
        <div class="small text-muted">Regular Qty Sold</div>
        <div class="fw-bold"><?= number_format($totalRegularKg,2) ?> kg</div>
      </div>
    </div>
  </div>

  <?php if(in_array($detailStatus, ['paid', 'unpaid'], true)): ?>
    <div class="d-grid gap-2 mb-3">
      <?php render_reprint_button($saleInfo); ?>
      <?php render_void_button($saleInfo); ?>
    </div>
  <?php endif; ?>

  <?php if($detailStatus === 'unpaid' && $detailDueDate !== ''): ?>
    <div class="alert alert-warning py-2">
      Due Date: <b><?= date("M d, Y", strtotime($detailDueDate)) ?></b>
    </div>
  <?php endif; ?>

  <div class="table-responsive">
    <table class="table table-sm align-middle mb-0">
      <thead class="table-dark">
        <tr>
          <th>Item</th>
          <th class="text-end">Qty</th>
          <th class="text-end">Effective Price</th>
          <th class="text-end">Line</th>
        </tr>
      </thead>
      <tbody>
        <?php if(count($items) > 0): ?>
          <?php foreach($items as $it): ?>
            <?php
              $qtyKg = (float)($it['qty_kg'] ?? 0);
              $lineTotal = (float)($it['line_total'] ?? 0);
              $effectivePrice = $qtyKg > 0 ? ($lineTotal / $qtyKg) : 0;
              $sackWeight = (float)($it['unit_weight_kg'] ?? 0);

              $unitType = strtolower((string)($it['unit_type'] ?? 'kg'));
              if(!in_array($unitType, ['kg','sack'], true)) $unitType = 'kg';

              $qtyInput = (float)($it['qty_input'] ?? 0);
              $discountKg = (float)($it['discount_kg'] ?? 0);
              $regularKg = (float)($it['regular_kg'] ?? 0);

              if($qtyInput <= 0){
                if($unitType === 'sack' && $sackWeight > 0){
                  $qtyInput = $qtyKg / $sackWeight;
                } else {
                  $unitType = 'kg';
                  $qtyInput = $qtyKg;
                }
              }

              $qtyLabel = ($unitType === 'sack')
                ? number_format($qtyInput, 0) . " sack(s)"
                : number_format($qtyInput, 2) . " kg";

              $mixLabel = '';
              $mixClass = 'text-muted';
              if($discountKg > 0 && $regularKg > 0){
                $mixLabel = number_format($discountKg,2)." kg discounted + ".number_format($regularKg,2)." kg regular";
                $mixClass = 'text-primary';
              } elseif($discountKg > 0){
                $mixLabel = "All discounted";
                $mixClass = 'text-warning';
              } elseif($regularKg > 0){
                $mixLabel = "All regular";
              }
            ?>
            <tr>
              <td>
                <div class="fw-semibold"><?= h(($it['variety'] ?? 'N/A').' - '.($it['grade'] ?? '')) ?></div>
                <?php if($mixLabel !== ''): ?>
                  <div class="small <?= h($mixClass) ?>"><?= h($mixLabel) ?></div>
                <?php endif; ?>
              </td>
              <td class="text-end">
                <?= h($qtyLabel) ?>
                <?php if($unitType === 'sack'): ?>
                  <div class="small text-muted"><?= number_format($qtyKg,2) ?> kg</div>
                <?php endif; ?>
              </td>
              <td class="text-end">₱<?= number_format($effectivePrice,2) ?>/kg</td>
              <td class="text-end">₱<?= number_format($lineTotal,2) ?></td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr><td colspan="4" class="text-center text-muted">No items found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php render_reprint_button($saleInfo); ?>

  <div class="mt-3 d-grid">
    <a class="btn btn-outline-dark" href="payments.php?sale_id=<?= (int)$saleInfo['sale_id'] ?>">
      <i class="fa-solid fa-hand-holding-dollar me-1"></i> Record Payment (if Utang)
    </a>
  </div>
  <?php
}

if(isset($_GET['ajax']) && $view_id > 0){
  header('Content-Type: application/json; charset=utf-8');
  $detail = fetch_sale_details($conn, $view_id, (int)$user_id);
  if(!$detail){
    echo json_encode(['ok' => false, 'message' => 'Sale not found.']);
    exit;
  }
  ob_start();
  render_sale_details_html($detail['sale'], $detail['items']);
  $html = ob_get_clean();
  echo json_encode(['ok' => true, 'html' => $html]);
  exit;
}

$q = trim($_GET['q'] ?? '');
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$status = strtolower(trim($_GET['status'] ?? 'all'));

$where = "WHERE s.user_id = ?";
$params = [$user_id];
$types = "i";

if($q !== ''){
  $where .= " AND (s.sale_id LIKE CONCAT('%',?,'%') OR c.first_name LIKE CONCAT('%',?,'%') OR c.last_name LIKE CONCAT('%',?,'%'))";
  $params[] = $q;
  $params[] = $q;
  $params[] = $q;
  $types .= "sss";
}

if($date_from !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_from)){
  $where .= " AND DATE(s.sale_date) >= ?";
  $params[] = $date_from;
  $types .= "s";
}
if($date_to !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_to)){
  $where .= " AND DATE(s.sale_date) <= ?";
  $params[] = $date_to;
  $types .= "s";
}

if(in_array($status, ['paid','unpaid','cancelled'], true)){
  $where .= " AND LOWER(IFNULL(s.status,'')) = ?";
  $params[] = $status;
  $types .= "s";
}

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;

$countSql = "
SELECT COUNT(*) AS cnt
FROM sales s
LEFT JOIN customers c ON s.customer_id = c.customer_id
{$where}
";
$stmt = $conn->prepare($countSql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$totalRows = (int)($stmt->get_result()->fetch_assoc()['cnt'] ?? 0);
$stmt->close();

$sumSql = "
SELECT COALESCE(SUM(s.total_amount), 0) AS total_sum
FROM sales s
LEFT JOIN customers c ON s.customer_id = c.customer_id
{$where}
";
$stmt = $conn->prepare($sumSql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$reportTotalSum = (float)($stmt->get_result()->fetch_assoc()['total_sum'] ?? 0);
$stmt->close();

$totalPages = max(1, (int)ceil($totalRows / $perPage));

$listSql = "
SELECT
  s.sale_id,
  s.sale_date,
  s.total_amount,
  s.status,
  s.customer_id,
  c.first_name,
  c.last_name,
  IFNULL(ar.balance, 0) AS ar_balance
FROM sales s
LEFT JOIN customers c ON s.customer_id = c.customer_id
LEFT JOIN account_receivable ar ON ar.sales_id = s.sale_id
{$where}
ORDER BY s.sale_date DESC, s.sale_id DESC
LIMIT {$perPage} OFFSET {$offset}
";
$stmt = $conn->prepare($listSql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$salesRes = $stmt->get_result();
$stmt->close();

if(isset($_GET['ajax']) && $_GET['ajax'] === 'live'){
  header('Content-Type: application/json; charset=utf-8');

  $salesRows = [];
  if($salesRes){
    while($row = $salesRes->fetch_assoc()){
      $salesRows[] = [
        'sale_id' => (int)($row['sale_id'] ?? 0),
        'sale_date' => (string)($row['sale_date'] ?? ''),
        'total_amount' => (float)($row['total_amount'] ?? 0),
        'status' => (string)($row['status'] ?? ''),
        'customer_name' => trim((string)($row['first_name'] ?? '') . ' ' . (string)($row['last_name'] ?? '')),
        'ar_balance' => (float)($row['ar_balance'] ?? 0),
      ];
    }
  }

  echo json_encode([
    'ok' => true,
    'summary' => [
      'total_rows' => $totalRows,
      'report_total_sum' => $reportTotalSum,
      'page' => $page,
      'total_pages' => $totalPages,
    ],
    'rows' => $salesRows,
    'view_id' => $view_id,
  ]);
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sales History | Cashier</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="../css/layout.css" rel="stylesheet">
<link href="../css/cashier-sales-history.css" rel="stylesheet">
<link href="../css/cashier-mobile.css" rel="stylesheet">
</head>

<body>

<?php
$profileLink = 'cashier_profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>

<div class="container-fluid">
<div class="row">

<?php include '../includes/cashier_sidebar.php'; ?>

<main class="col-lg-10 ms-sm-auto px-4 main-content">
<div class="py-4">

<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3 no-print">
<div>
<h3 class="fw-bold mb-1">Sales Report</h3>
<div class="text-muted">Filter by date range, then print if needed.</div>
</div>
<a class="btn btn-dark no-print" href="pos.php"><i class="fa-solid fa-plus me-1"></i> New Sale</a>
</div>

<div class="report-frame modern-card mb-4" id="salesReportFrame">
  <div class="report-header" id="salesReportHeader">
    <?php if($date_from !== '' || $date_to !== '' || $q !== '' || $status !== 'all'): ?>
      <div class="report-subtitle">
        From: <?= h($date_from ?: 'All') ?> | To: <?= h($date_to ?: 'All') ?>
        <?php if($status !== 'all'): ?> | Status: <?= h(strtoupper($status)) ?><?php endif; ?>
        <?php if($q !== ''): ?> | Search: <?= h($q) ?><?php endif; ?>
      </div>
    <?php endif; ?>
  </div>

  <div class="report-toolbar no-print" id="salesReportToolbar">
    <form class="row g-2 align-items-end" method="GET">
      <div class="col-12 col-sm-6 col-md-3">
        <label class="form-label mb-1">Date From:</label>
        <input type="date" class="form-control" name="date_from" value="<?= h($date_from) ?>">
      </div>
      <div class="col-12 col-sm-6 col-md-3">
        <label class="form-label mb-1">Date To:</label>
        <input type="date" class="form-control" name="date_to" value="<?= h($date_to) ?>">
      </div>

      <div class="col-12 col-md-3">
        <label class="form-label mb-1">Search:</label>
        <input class="form-control" name="q" value="<?= h($q) ?>" placeholder="Sale ID / Customer">
      </div>
      <div class="col-12 col-md-2">
        <label class="form-label mb-1">Status:</label>
        <select class="form-select" name="status">
          <option value="all" <?= $status==='all'?'selected':'' ?>>All</option>
          <option value="paid" <?= $status==='paid'?'selected':'' ?>>Paid</option>
          <option value="unpaid" <?= $status==='unpaid'?'selected':'' ?>>Unpaid (Utang)</option>
          <option value="cancelled" <?= $status==='cancelled'?'selected':'' ?>>Cancelled</option>
        </select>
      </div>

      <div class="col-12 col-md-auto d-grid">
        <button class="btn report-btn text-nowrap" type="submit"><i class="fa-solid fa-magnifying-glass me-1"></i> Show</button>
      </div>
      <div class="col-12 col-md-auto d-grid">
        <button class="btn report-btn text-nowrap" type="button" onclick="window.print()"><i class="fa-solid fa-print me-1"></i> Print</button>
      </div>
      <div class="col-12 col-md-auto d-grid">
        <a class="btn report-btn text-nowrap" href="sales_history.php"><i class="fa-solid fa-rotate-left me-1"></i> Reset</a>
      </div>
    </form>
  </div>

  <div class="card-body table-responsive p-0" id="salesReportTableWrap">
    <table class="table report-table align-middle mb-0">
      <thead>
        <tr>
          <th>Invoice #</th>
          <th>Date Recorded</th>
          <th>Customer</th>
          <th>Sale Type</th>
          <th>Total (₱)</th>
          <th>Status</th>
          <th>Balance</th>
          <th class="no-print"></th>
        </tr>
      </thead>
      <tbody>
<?php if($salesRes && $salesRes->num_rows > 0): ?>
<?php while($s = $salesRes->fetch_assoc()): ?>
<?php
$st = strtolower(trim($s['status'] ?? ''));
$cust = trim(($s['first_name'] ?? '').' '.($s['last_name'] ?? ''));
if($st !== 'unpaid' || $cust === ''){
  $cust = 'Walk-in Customer';
}
?>
<tr>
<td class="fw-bold">INV-<?= str_pad((string)(int)$s['sale_id'], 6, '0', STR_PAD_LEFT) ?></td>
<td><?= $s['sale_date'] ? date("M d, Y h:i A", strtotime($s['sale_date'])) : '' ?></td>
<td><?= h($cust) ?></td>
<td>
<?php if($st === 'unpaid'): ?>
<span class="badge bg-warning text-dark">UTANG</span>
<?php elseif($st === 'paid'): ?>
<span class="badge bg-success">CASH</span>
<?php elseif($st === 'cancelled'): ?>
<span class="badge bg-secondary">CANCELLED</span>
<?php else: ?>
<span class="badge bg-dark"><?= h(strtoupper($st ?: 'N/A')) ?></span>
<?php endif; ?>
</td>
<td><?= number_format((float)$s['total_amount'],2) ?></td>
<td>
<?php if($st === 'paid'): ?>
<span class="badge bg-success">PAID</span>
<?php elseif($st === 'unpaid'): ?>
<span class="badge bg-warning text-dark">UNPAID</span>
<?php elseif($st === 'cancelled'): ?>
<span class="badge bg-secondary">CANCELLED</span>
<?php else: ?>
<span class="badge bg-dark"><?= h(strtoupper($st ?: 'N/A')) ?></span>
<?php endif; ?>
</td>
<td>
<?php
$bal = (float)($s['ar_balance'] ?? 0);
echo $bal > 0 ? ('₱'.number_format($bal,2)) : '-';
?>
</td>
<td class="text-end no-print">
  <div class="d-inline-flex gap-1">
    <a class="btn btn-sm btn-outline-dark js-sale-view"
       href="sales_history.php?<?= http_build_query(array_merge($_GET, ['view'=>$s['sale_id']])) ?>"
       data-sale-id="<?= (int)$s['sale_id'] ?>"
       aria-label="View sale details">
      <i class="fa-solid fa-eye"></i>
    </a>

    <?php if($st === 'paid'): ?>
      <a class="btn btn-sm btn-outline-primary"
         href="reprint_receipt.php?sale_id=<?= (int)$s['sale_id'] ?>"
         target="_blank"
         aria-label="Reprint receipt">
        <i class="fa-solid fa-print"></i>
      </a>
    <?php endif; ?>
  </div>
</td>
</tr>
<?php endwhile; ?>
<?php else: ?>
<tr><td colspan="8" class="text-center text-muted py-4">No sales found.</td></tr>
<?php endif; ?>
      </tbody>
    </table>
  </div>

<?php if($totalPages > 1): ?>
<nav class="mt-3 px-3 no-print">
<ul class="pagination">
<?php
$base = $_GET;
for($p=1; $p<=$totalPages; $p++):
  $base['page'] = $p;
  $link = 'sales_history.php?'.http_build_query($base);
?>
<li class="page-item <?= $p===$page?'active':'' ?>">
<a class="page-link" href="<?= h($link) ?>"><?= $p ?></a>
</li>
<?php endfor; ?>
</ul>
</nav>
<?php endif; ?>

  <div class="report-footer" id="salesReportFooter">
    <div class="meta">Records: <?= (int)$totalRows ?></div>
    <div>Total: ₱<?= number_format($reportTotalSum, 2) ?></div>
  </div>
</div>

</div>
</main>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<div class="modal fade" id="saleDetailsModal" tabindex="-1" aria-labelledby="saleDetailsModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fw-bold" id="saleDetailsModalLabel">Sale Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="saleDetailsModalBody">
        <div class="text-muted">Select a sale to view details.</div>
      </div>
    </div>
  </div>
</div>

<script>
(function(){
  const modalEl = document.getElementById('saleDetailsModal');
  const modalBody = document.getElementById('saleDetailsModalBody');
  if(!modalEl || !modalBody || typeof bootstrap === 'undefined') return;

  const modal = new bootstrap.Modal(modalEl);
  const initialViewId = <?= (int)$view_id ?>;
  function setViewParam(saleId){
    const url = new URL(window.location.href);
    if(saleId){
      url.searchParams.set('view', String(saleId));
    }else{
      url.searchParams.delete('view');
    }
    window.history.replaceState({}, '', url.toString());
  }

  async function openSaleDetails(saleId){
    if(!saleId) return;
    modalBody.innerHTML = '<div class="py-4 text-center text-muted"><span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Loading...</div>';
    modal.show();
    setViewParam(saleId);

    try{
      const url = new URL(window.location.href);
      url.searchParams.set('ajax', '1');
      url.searchParams.set('view', String(saleId));
      const res = await fetch(url.toString(), { credentials: 'same-origin' });
      const data = await res.json();
      if(!data || !data.ok){
        modalBody.innerHTML = '<div class="alert alert-warning mb-0">' + (data && data.message ? data.message : 'Failed to load details.') + '</div>';
        return;
      }
      modalBody.innerHTML = data.html;
    }catch(e){
      modalBody.innerHTML = '<div class="alert alert-danger mb-0">Failed to load details.</div>';
    }
  }

  document.addEventListener('click', function(ev){
    const a = ev.target.closest && ev.target.closest('a.js-sale-view');
    if(!a) return;
    ev.preventDefault();
    const saleId = parseInt(a.getAttribute('data-sale-id') || '', 10);
    openSaleDetails(saleId);
  });

  document.addEventListener('click', function(ev){
    const btn = ev.target.closest && ev.target.closest('button.js-sale-void');
    if(!btn) return;
    ev.preventDefault();
    const saleId = parseInt(btn.getAttribute('data-sale-id') || '', 10);
    if(!saleId) return;
    if(confirm(`Void Sale #${saleId}? This will restore stock and mark the sale cancelled.`)){
      const form = document.createElement('form');
      form.method = 'post';
      form.action = 'sales_history.php';
      form.innerHTML = `
        <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token'] ?? '') ?>">
        <input type="hidden" name="sale_id" value="${saleId}">
        <input type="hidden" name="void_sale" value="1">
      `;
      document.body.appendChild(form);
      form.submit();
    }
  });

  modalEl.addEventListener('hidden.bs.modal', function(){
    setViewParam(null);
  });

  if(initialViewId > 0){
    window.addEventListener('DOMContentLoaded', function(){
      openSaleDetails(initialViewId);
    });
  }

})();
</script>
</body>
</html>
