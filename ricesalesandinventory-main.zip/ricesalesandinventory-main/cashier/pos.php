<?php
session_start();
if(!isset($_SESSION['user_id'])){
  header("Location: ../login.php");
  exit;
}
if(strtolower($_SESSION['role'] ?? '') !== 'cashier'){
  header("Location: ../login.php");
  exit;
}

$username = $_SESSION['username'] ?? 'Cashier';
$user_id  = (int)($_SESSION['user_id'] ?? 0);

include '../config/db.php';
$cashierDisplayName = (string)$username;
$cashierNameStmt = $conn->prepare('SELECT display_name, first_name, last_name FROM users WHERE user_id = ? LIMIT 1');
if($cashierNameStmt){
  $cashierNameStmt->bind_param('i', $user_id);
  if($cashierNameStmt->execute()){
    $cashierNameRow = $cashierNameStmt->get_result()->fetch_assoc();
    if($cashierNameRow){
      $savedCashierName = trim((string)($cashierNameRow['display_name'] ?? ''));
      if($savedCashierName === ''){
        $savedCashierName = trim((string)($cashierNameRow['first_name'] ?? '') . ' ' . (string)($cashierNameRow['last_name'] ?? ''));
      }
      if($savedCashierName !== '') $cashierDisplayName = $savedCashierName;
    }
  }
  $cashierNameStmt->close();
}
require_once __DIR__ . '/../includes/receivable_penalty.php';
ensurePenaltyPaymentColumn($conn);
$penaltyOutstandingSql = receivablePenaltyOutstandingSql();

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

if(empty($_SESSION['csrf_token'])){
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function require_csrf_or_redirect(string $target): void {
  $posted = (string)($_POST['csrf_token'] ?? '');
  $stored = (string)($_SESSION['csrf_token'] ?? '');
  if($posted === '' || $stored === '' || !hash_equals($stored, $posted)){
    header("Location: {$target}?error=" . urlencode("Invalid request token. Please refresh and try again."));
    exit;
  }
}

function get_owner_password_hash(): string {
  $envHash = trim((string)(getenv('OWNER_PASSWORD_HASH') ?: ''));
  if($envHash !== '') return $envHash;

  return '';
}

function get_owner_password_plain(): string {
  $envPassword = trim((string)(getenv('OWNER_PASSWORD') ?: ''));
  if($envPassword !== '') return $envPassword;

  return '';
}

function verify_owner_password(string $plainPassword): bool {
  $plainPassword = trim((string)$plainPassword);
  if($plainPassword === '') return false;

  $storedHash = get_owner_password_hash();
  if($storedHash !== ''){
    return password_verify($plainPassword, $storedHash);
  }

  $envPassword = get_owner_password_plain();
  if($envPassword !== ''){
    return hash_equals($envPassword, $plainPassword);
  }

  // Fallback to the owner account password stored in the users table.
  global $conn;
  if(isset($conn) && $conn instanceof mysqli){
    $stmt = $conn->prepare("SELECT password FROM users WHERE LOWER(TRIM(role))='owner'");
    if(!$stmt){
      throw new RuntimeException("Unable to prepare owner password lookup: " . $conn->error);
    }

    if(!$stmt->execute()){
      $error = $stmt->error;
      $stmt->close();
      throw new RuntimeException("Unable to execute owner password lookup: " . $error);
    }

    $stmt->bind_result($ownerHash);
    while($stmt->fetch()){
      $ownerHash = trim((string)$ownerHash);
      if($ownerHash !== '' && password_verify($plainPassword, $ownerHash)){
        $stmt->close();
        return true;
      }
    }
    $stmt->close();
  }

  return false;
}

function pos_save_old($customer_id, $sale_type, $due_date, $term_days, $discount_type, $discount_name, $discount_idno){
  $_SESSION['pos_old'] = [
    'customer_id'     => (int)$customer_id,
    'sale_type'       => (string)$sale_type,
    'due_date'        => (string)$due_date,
    'term_days'       => (int)$term_days,
    'discount_type'   => (string)$discount_type,
    'discount_name'   => (string)$discount_name,
    'discount_idno'   => (string)$discount_idno,
    'discount_percent' => (string)($_POST['discount_percent'] ?? ''),
  ];
}

function compute_due_date_by_days(int $days): string {
  if($days <= 0) $days = 15;
  $due = new DateTime();
  $due->modify("+{$days} days");
  return $due->format('Y-m-d');
}

/* Ensure sales_items has the needed columns */
$conn->query("
  ALTER TABLE sales_items
  ADD COLUMN IF NOT EXISTS batch_id INT NULL AFTER product_id
");
$conn->query("
  ALTER TABLE sales_items
  ADD COLUMN IF NOT EXISTS unit_type ENUM('kg','sack') DEFAULT 'kg'
");
$conn->query("
  ALTER TABLE sales_items
  ADD COLUMN IF NOT EXISTS qty_input DECIMAL(12,2) DEFAULT 0
");
$conn->query("
  ALTER TABLE sales_items
  ADD COLUMN IF NOT EXISTS discount_kg DECIMAL(12,2) DEFAULT 0
");
$conn->query("
  ALTER TABLE sales_items
  ADD COLUMN IF NOT EXISTS regular_kg DECIMAL(12,2) DEFAULT 0
");

if(!isset($_SESSION['sale_discount']) || !is_array($_SESSION['sale_discount'])){
  $_SESSION['sale_discount'] = [];
}

$products = [];
$sqlProducts = "
SELECT
  p.product_id,
  p.variety,
  p.grade,
  p.unit_weight_kg,
  p.price_per_sack,
  p.price_per_kg,
  IFNULL(SUM(sb.discounted_qty_kg), 0) AS discounted_kg,
  MAX(sb.discounted_price_per_kg) AS discounted_price_per_kg,
  IFNULL(SUM(sb.remaining_qty_kg), 0) AS stock_kg
FROM products p
LEFT JOIN stock_batches sb ON sb.product_id = p.product_id
WHERE p.archived = 0
GROUP BY
  p.product_id,
  p.variety,
  p.grade,
  p.unit_weight_kg,
  p.price_per_sack,
  p.price_per_kg
ORDER BY p.variety ASC, p.grade ASC
";
$resP = $conn->query($sqlProducts);
if($resP){
  while($row = $resP->fetch_assoc()){
    $row['unit_weight_kg'] = (float)($row['unit_weight_kg'] ?? 0);
    $row['price_per_sack'] = (float)($row['price_per_sack'] ?? 0);
    $row['price_per_kg']   = (float)($row['price_per_kg'] ?? 0);
    $row['discounted_kg']  = (float)($row['discounted_kg'] ?? 0);
    $row['discounted_price_per_kg'] = (float)($row['discounted_price_per_kg'] ?? 0);
    $row['stock_kg']       = (float)($row['stock_kg'] ?? 0);
    $row['batches']        = [];
    $products[] = $row;
  }
} else {
  error_log('POS product query failed: ' . $conn->error);
}

$productIndex = [];
foreach($products as $idx => $pRow){
  $productIndex[(int)$pRow['product_id']] = $idx;
}

if(count($productIndex) > 0){
  $idListForBatches = implode(',', array_map('intval', array_keys($productIndex)));
  $batchRes = $conn->query("
    SELECT
      batch_id,
      product_id,
      batch_code,
      arrived_at,
      unit_weight_kg,
      remaining_qty_kg,
      regular_qty_kg,
      discounted_qty_kg,
      regular_price_per_kg,
      discounted_price_per_kg
    FROM stock_batches
    WHERE product_id IN ({$idListForBatches}) AND remaining_qty_kg > 0.00001
    ORDER BY product_id ASC, arrived_at ASC, batch_id ASC
  ");
  if($batchRes){
    while($b = $batchRes->fetch_assoc()){
      $pid = (int)$b['product_id'];
      if(!isset($productIndex[$pid])) continue;
      $products[$productIndex[$pid]]['batches'][] = [
        'batch_id' => (int)$b['batch_id'],
        'batch_code' => (string)($b['batch_code'] ?: ('B' . str_pad((string)$b['batch_id'], 6, '0', STR_PAD_LEFT))),
        'arrived_at' => (string)($b['arrived_at'] ?? ''),
        'unit_weight_kg' => (float)$b['unit_weight_kg'],
        'remaining_qty_kg' => (float)$b['remaining_qty_kg'],
        'regular_qty_kg' => (float)$b['regular_qty_kg'],
        'discounted_qty_kg' => (float)$b['discounted_qty_kg'],
        'regular_price_per_kg' => (float)$b['regular_price_per_kg'],
        'discounted_price_per_kg' => (float)($b['discounted_price_per_kg'] ?? 0),
      ];
    }
  }

  foreach($products as $idx => $pRow){
    if(!empty($pRow['batches'])){
      usort($products[$idx]['batches'], function($a, $b){
        $aDate = (string)($a['arrived_at'] ?? '');
        $bDate = (string)($b['arrived_at'] ?? '');
        $aTime = $aDate === '' ? PHP_INT_MAX : strtotime($aDate);
        $bTime = $bDate === '' ? PHP_INT_MAX : strtotime($bDate);
        if($aTime === false) $aTime = PHP_INT_MAX;
        if($bTime === false) $bTime = PHP_INT_MAX;
        if($aTime < $bTime) return -1;
        if($aTime > $bTime) return 1;
        return ((int)$a['batch_id'] <=> (int)$b['batch_id']);
      });
    }
  }

  usort($products, function($a, $b){
    $findEarliest = function($product) {
      $earliest = null;
      foreach(($product['batches'] ?? []) as $batch){
        $date = (string)($batch['arrived_at'] ?? '');
        if($date === '') continue;
        $time = strtotime($date);
        if($time === false) continue;
        if($earliest === null || $time < $earliest){
          $earliest = $time;
        }
      }
      return $earliest;
    };

    $aEarliest = $findEarliest($a);
    $bEarliest = $findEarliest($b);

    if($aEarliest === null && $bEarliest === null){
      $aName = strtolower(trim((string)($a['variety'] ?? '') . ' ' . (string)($a['grade'] ?? '')));
      $bName = strtolower(trim((string)($b['variety'] ?? '') . ' ' . (string)($b['grade'] ?? '')));
      return $aName <=> $bName;
    }

    if($aEarliest === null) return 1;
    if($bEarliest === null) return -1;
    return $aEarliest <=> $bEarliest;
  });
}

$productIndex = [];
foreach($products as $idx => $pRow){
  $productIndex[(int)$pRow['product_id']] = $idx;
}

$customers = [];
$resC = $conn->query("
SELECT
  c.customer_id,
  c.first_name,
  c.last_name,
  c.phone,
  IFNULL(SUM(IFNULL(ar.balance,0) + IFNULL({$penaltyOutstandingSql},0)),0) AS open_balance,
  SUM(CASE WHEN ar.balance > 0 OR ({$penaltyOutstandingSql}) > 0 THEN 1 ELSE 0 END) AS open_docs
FROM customers c
LEFT JOIN account_receivable ar ON ar.customer_id = c.customer_id
LEFT JOIN penalties p ON p.reference_id = ar.ar_id AND p.reference_type = 'receivable'
GROUP BY c.customer_id
ORDER BY c.created_at DESC
");
if($resC){
  while($r = $resC->fetch_assoc()) $customers[] = $r;
}

$recentSales = [];
$resRecentSales = $conn->query("
  SELECT
    s.sale_id,
    s.sale_date,
    s.total_amount,
    s.status,
    s.customer_id,
    COALESCE(CONCAT(c.first_name, ' ', c.last_name), 'Walk-in') AS customer_name
  FROM sales s
  LEFT JOIN customers c ON c.customer_id = s.customer_id
  ORDER BY s.sale_id DESC
  LIMIT 50
");
if($resRecentSales){
  while($r = $resRecentSales->fetch_assoc()){
    $recentSales[] = $r;
  }
}

if(isset($_POST['add_customer'])){
  require_csrf_or_redirect('pos.php');

  $fn = trim($_POST['first_name'] ?? '');
  $ln = trim($_POST['last_name'] ?? '');
  $ph = trim($_POST['phone'] ?? '');
  $ad = trim($_POST['address'] ?? '');

  if($fn !== '' && $ln !== ''){
    $stmt = $conn->prepare("INSERT INTO customers (first_name,last_name,phone,address,created_at) VALUES (?,?,?,?,NOW())");
    $stmt->bind_param("ssss", $fn, $ln, $ph, $ad);
    $stmt->execute();
    $stmt->close();
  }
  header("Location: pos.php?success=" . urlencode("Customer added."));
  exit;
}

if(isset($_POST['verify_draft_void'])){
  header('Content-Type: application/json; charset=utf-8');

  $postedToken = (string)($_POST['csrf_token'] ?? '');
  $storedToken = (string)($_SESSION['csrf_token'] ?? '');
  if($postedToken === '' || $storedToken === '' || !hash_equals($storedToken, $postedToken)){
    http_response_code(403);
    echo json_encode([
      'ok' => false,
      'message' => 'Your session expired. Refresh the page and try again.',
    ]);
    exit;
  }

  try {
    $owner_password = (string)($_POST['owner_password'] ?? '');
    $ok = verify_owner_password($owner_password);

    echo json_encode([
      'ok' => $ok,
      'message' => $ok ? 'Owner password verified.' : 'Owner password is incorrect.',
    ]);
  } catch(Throwable $e) {
    error_log('Draft void owner-password verification failed: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
      'ok' => false,
      'message' => 'Server could not verify the owner password. Check the hosting PHP error log.',
    ]);
  }
  exit;
}

if(isset($_POST['void_sale'])){
  require_csrf_or_redirect('pos.php');

  $sale_id = (int)($_POST['void_sale_id'] ?? 0);
  $owner_password = (string)($_POST['owner_password'] ?? '');
  $void_reason = trim((string)($_POST['void_reason'] ?? ''));

  if($sale_id <= 0){
    header("Location: pos.php?error=" . urlencode("Please enter a valid sale number."));
    exit;
  }

  if(!verify_owner_password($owner_password)){
    header("Location: pos.php?error=" . urlencode("Owner password is incorrect."));
    exit;
  }

  $conn->begin_transaction();
  try {
    $stmt = $conn->prepare("SELECT sale_id, status, total_amount, customer_id FROM sales WHERE sale_id = ? FOR UPDATE");
    if(!$stmt) throw new Exception("Unable to load sale.");
    $stmt->bind_param("i", $sale_id);
    if(!$stmt->execute()) throw new Exception("Unable to load sale.");
    $stmt->bind_result($saleId, $saleStatus, $saleTotal, $saleCustomerId);
    $sale = $stmt->fetch()
      ? [
          'sale_id' => $saleId,
          'status' => $saleStatus,
          'total_amount' => $saleTotal,
          'customer_id' => $saleCustomerId,
        ]
      : null;
    $stmt->close();

    if(!$sale){
      throw new Exception("Sale #{$sale_id} not found.");
    }
    if(strtolower((string)($sale['status'] ?? '')) === 'void'){
      throw new Exception("Sale #{$sale_id} is already voided.");
    }

    $stmt = $conn->prepare("
      SELECT si.product_id, si.batch_id, si.qty_kg, si.discount_kg, si.regular_kg
      FROM sales_items si
      WHERE si.sale_id = ?
      FOR UPDATE
    ");
    if(!$stmt) throw new Exception("Unable to load sale items.");
    $stmt->bind_param("i", $sale_id);
    if(!$stmt->execute()) throw new Exception("Unable to load sale items.");
    $stmt->bind_result($itemProductId, $itemBatchId, $itemQtyKg, $itemDiscountKg, $itemRegularKg);
    $saleItems = [];
    while($stmt->fetch()){
      $saleItems[] = [
        'product_id' => $itemProductId,
        'batch_id' => $itemBatchId,
        'qty_kg' => $itemQtyKg,
        'discount_kg' => $itemDiscountKg,
        'regular_kg' => $itemRegularKg,
      ];
    }
    $stmt->close();

    if(count($saleItems) === 0){
      throw new Exception("Sale #{$sale_id} has no items to void.");
    }

    $batchIds = [];
    foreach($saleItems as $it){
      $batchIds[] = (int)($it['batch_id'] ?? 0);
    }
    $batchIds = array_values(array_unique(array_filter($batchIds, fn($v) => $v > 0)));
    if(count($batchIds) > 0){
      $batchList = implode(',', array_map('intval', $batchIds));
      $conn->query("SELECT batch_id FROM stock_batches WHERE batch_id IN ({$batchList}) FOR UPDATE");
    }

    foreach($saleItems as $it){
      $product_id = (int)$it['product_id'];
      $batch_id = (int)$it['batch_id'];
      $qty_kg = (float)$it['qty_kg'];
      $discount_kg = (float)$it['discount_kg'];
      $regular_kg = (float)$it['regular_kg'];

      if($batch_id > 0){
        if($regular_kg > 0){
          $stmt = $conn->prepare("
            UPDATE stock_batches
            SET regular_qty_kg = regular_qty_kg + ?,
                remaining_qty_kg = remaining_qty_kg + ?,
                updated_at = NOW()
            WHERE batch_id = ? AND product_id = ?
          ");
          if(!$stmt) throw new Exception("Unable to restore regular stock.");
          $stmt->bind_param("ddii", $regular_kg, $regular_kg, $batch_id, $product_id);
          $stmt->execute();
          $stmt->close();
        }

        if($discount_kg > 0){
          $stmt = $conn->prepare("
            UPDATE stock_batches
            SET discounted_qty_kg = discounted_qty_kg + ?,
                remaining_qty_kg = remaining_qty_kg + ?,
                updated_at = NOW()
            WHERE batch_id = ? AND product_id = ?
          ");
          if(!$stmt) throw new Exception("Unable to restore discounted stock.");
          $stmt->bind_param("ddii", $discount_kg, $discount_kg, $batch_id, $product_id);
          $stmt->execute();
          $stmt->close();

          $stmt = $conn->prepare("
            INSERT INTO product_discount_stock (product_id, qty_kg, created_at, updated_at)
            VALUES (?, ?, NOW(), NOW())
            ON DUPLICATE KEY UPDATE qty_kg = qty_kg + VALUES(qty_kg), updated_at = NOW()
          ");
          if(!$stmt) throw new Exception("Unable to restore discounted stock bucket.");
          $stmt->bind_param("id", $product_id, $discount_kg);
          $stmt->execute();
          $stmt->close();
        }

        $note = "Void sale #{$sale_id}" . ($void_reason !== '' ? " - {$void_reason}" : '');
        $stmt = $conn->prepare("
          INSERT INTO inventory_transactions
            (product_id, batch_id, qty_kg, reference_id, reference_type, type, note, created_at)
          VALUES (?, ?, ?, ?, 'sale', 'in', ?, NOW())
        ");
        if(!$stmt) throw new Exception("Unable to log stock restoration.");
        $stmt->bind_param("iidis", $product_id, $batch_id, $qty_kg, $sale_id, $note);
        $stmt->execute();
        $stmt->close();
      }
    }

    $stmt = $conn->prepare("DELETE FROM payments WHERE sale_id = ?");
    if($stmt){
      $stmt->bind_param("i", $sale_id);
      $stmt->execute();
      $stmt->close();
    }

    $stmt = $conn->prepare("DELETE FROM account_receivable WHERE sales_id = ?");
    if($stmt){
      $stmt->bind_param("i", $sale_id);
      $stmt->execute();
      $stmt->close();
    }

    $stmt = $conn->prepare("
      UPDATE sales
      SET status = 'void'
      WHERE sale_id = ?
    ");
    if(!$stmt) throw new Exception("Unable to void sale.");
    $stmt->bind_param("i", $sale_id);
    $stmt->execute();
    $stmt->close();

    $desc = "Voided sale #{$sale_id}" . ($void_reason !== '' ? " ({$void_reason})" : '');
    $stmt = $conn->prepare("
      INSERT INTO activity_logs (user_id, activity_type, description, created_at)
      VALUES (?, 'SALE_VOID', ?, NOW())
    ");
    if(!$stmt) throw new Exception("Unable to log void activity.");
    $stmt->bind_param("is", $user_id, $desc);
    $stmt->execute();
    $stmt->close();

    $conn->commit();
    header("Location: pos.php?success=" . urlencode("Sale #{$sale_id} has been voided."));
    exit;
  } catch(Exception $e){
    $conn->rollback();
    header("Location: pos.php?error=" . urlencode($e->getMessage()));
    exit;
  }
}

$err = $_GET['error'] ?? '';
$success = $_GET['success'] ?? '';

$old = $_SESSION['pos_old'] ?? [];
unset($_SESSION['pos_old']);

$old_customer_id   = (int)($old['customer_id'] ?? 0);
$old_sale_type     = strtolower(trim($old['sale_type'] ?? 'cash'));
$old_due_date      = (string)($old['due_date'] ?? '');
$old_term_days     = (int)($old['term_days'] ?? 15);
if(!in_array($old_term_days, [7,15,30], true)) $old_term_days = 15;

$old_discount_type = strtolower(trim($old['discount_type'] ?? 'none'));
$old_discount_name = (string)($old['discount_name'] ?? '');
$old_discount_idno = (string)($old['discount_idno'] ?? '');
$old_discount_percent = trim((string)($old['discount_percent'] ?? ''));

if($old_sale_type === 'utang' && $old_due_date === ''){
  $old_due_date = compute_due_date_by_days($old_term_days);
}

if(isset($_POST['checkout'])){
  require_csrf_or_redirect('pos.php');

  $customer_id = (int)($_POST['customer_id'] ?? 0);
  $sale_type   = strtolower(trim($_POST['sale_type'] ?? 'cash'));
  $status      = ($sale_type === 'utang') ? 'unpaid' : 'paid';
  $payment_method = strtolower(trim((string)($_POST['payment_method'] ?? 'cash')));
  $payment_external_ref = trim((string)($_POST['payment_external_ref'] ?? ''));
  $cash_received = (float)($_POST['cash_received'] ?? 0);
  $term_days   = (int)($_POST['term_days'] ?? 15);
  if(!in_array($term_days, [7,15,30], true)) $term_days = 15;

  $discount_type = strtolower(trim($_POST['discount_type'] ?? 'none'));
  $discount_name = trim($_POST['discount_name'] ?? '');
  $discount_idno = trim($_POST['discount_idno'] ?? '');
  $discount_percent = trim((string)($_POST['discount_percent'] ?? ''));

  if(!in_array($discount_type, ['none','pwd','sc','others'], true)){
    $discount_type = 'none';
  }
  if($discount_type === 'others'){
    $discount_percent = str_replace([',',' '], '', $discount_percent);
    if($discount_percent === '' || !is_numeric($discount_percent)){
      pos_save_old($customer_id, $sale_type, $due_date_post, $term_days, $discount_type, $discount_name, $discount_idno);
      header("Location: pos.php?error=" . urlencode("Please enter a valid discount percentage for Others."));
      exit;
    }
    $discount_percent_value = (float)$discount_percent;
    if($discount_percent_value < 0 || $discount_percent_value > 100){
      pos_save_old($customer_id, $sale_type, $due_date_post, $term_days, $discount_type, $discount_name, $discount_idno);
      header("Location: pos.php?error=" . urlencode("Discount percentage must be between 0 and 100."));
      exit;
    }
    $discount_percent = (string)number_format($discount_percent_value, 2, '.', '');
  } else {
    $discount_percent = '';
  }
  if(!in_array($payment_method, ['cash','gcash','bank'], true)){
    $payment_method = 'cash';
  }

  $due_date_post = '';
  if($sale_type === 'utang'){
    $due_date_post = compute_due_date_by_days($term_days);
  }

  $product_ids = $_POST['product_id'] ?? [];
  $batch_ids   = $_POST['batch_id'] ?? [];
  $stock_types = $_POST['stock_type'] ?? [];
  $units       = $_POST['unit_type'] ?? [];
  $qty_inputs  = $_POST['qty'] ?? [];

  if($sale_type === 'cash'){
    $customer_id = null;
  }

  if($sale_type === 'utang' && (int)$customer_id <= 0){
    pos_save_old($customer_id, $sale_type, $due_date_post, $term_days, $discount_type, $discount_name, $discount_idno);
    header("Location: pos.php?error=" . urlencode("Please select a customer for utang."));
    exit;
  }
  if(!is_array($product_ids) || count($product_ids) === 0){
    pos_save_old($customer_id, $sale_type, $due_date_post, $term_days, $discount_type, $discount_name, $discount_idno);
    header("Location: pos.php?error=" . urlencode("Please add at least one item."));
    exit;
  }

  $pmap = [];
  foreach($products as $p){
    $pmap[(int)$p['product_id']] = $p;
  }

  $items = [];
  $gross_total = 0.0;

  for($i=0; $i<count($product_ids); $i++){
    $pid        = (int)($product_ids[$i] ?? 0);
    $batch_id   = (int)($batch_ids[$i] ?? 0);
    $unit       = strtolower(trim((string)($units[$i] ?? 'kg')));
    $qIn        = (float)($qty_inputs[$i] ?? 0);
    $stock_type = strtolower(trim((string)($stock_types[$i] ?? 'regular')));

    if($pid <= 0 || $qIn <= 0) continue;
    if(!isset($pmap[$pid])) continue;
    if($batch_id <= 0){
      pos_save_old($customer_id, $sale_type, $due_date_post, $term_days, $discount_type, $discount_name, $discount_idno);
      header("Location: pos.php?error=" . urlencode("Please select a stock batch for each item."));
      exit;
    }
    if(!in_array($unit, ['kg','sack'], true)) $unit = 'kg';
    if(!in_array($stock_type, ['regular','discounted'], true)) $stock_type = 'regular';

    $prod = $pmap[$pid];
    $selectedBatch = null;
    foreach(($prod['batches'] ?? []) as $batchRow){
      if((int)($batchRow['batch_id'] ?? 0) === $batch_id){
        $selectedBatch = $batchRow;
        break;
      }
    }
    if(!$selectedBatch){
      pos_save_old($customer_id, $sale_type, $due_date_post, $term_days, $discount_type, $discount_name, $discount_idno);
      header("Location: pos.php?error=" . urlencode("Selected batch is no longer available."));
      exit;
    }

    $unit_weight_kg = (float)$prod['unit_weight_kg'];

    if($unit === 'sack'){
      if($unit_weight_kg <= 0){
        pos_save_old($customer_id, $sale_type, $due_date_post, $term_days, $discount_type, $discount_name, $discount_idno);
        header("Location: pos.php?error=" . urlencode("Product sack size is missing. Please set unit_weight_kg in Products."));
        exit;
      }
      $qty_kg = $qIn * $unit_weight_kg;
    } else {
      $qty_kg = $qIn;
    }

    if($qty_kg <= 0) continue;

    $discounted_available = (float)($selectedBatch['discounted_qty_kg'] ?? 0);
    $regular_available    = (float)($selectedBatch['regular_qty_kg'] ?? 0);

    $discount_price_kg = (float)($selectedBatch['discounted_price_per_kg'] ?? 0);
    $regular_price_kg  = (float)($selectedBatch['regular_price_per_kg'] ?? 0);
    $regular_price_sack = ($unit_weight_kg > 0) ? ($regular_price_kg * $unit_weight_kg) : 0;

    $discount_kg = 0.0;
    $regular_kg  = 0.0;
    $line_total  = 0.0;
    $display_unit_price = 0.0;

    if($stock_type === 'discounted'){
      if($discounted_available < $qty_kg){
        pos_save_old($customer_id, $sale_type, $due_date_post, $term_days, $discount_type, $discount_name, $discount_idno);
        header("Location: pos.php?error=" . urlencode("Not enough discounted stock for selected product."));
        exit;
      }
      if($discount_price_kg <= 0){
        pos_save_old($customer_id, $sale_type, $due_date_post, $term_days, $discount_type, $discount_name, $discount_idno);
        header("Location: pos.php?error=" . urlencode("Discounted price is missing for the selected product."));
        exit;
      }

      $discount_kg = $qty_kg;
      $regular_kg = 0.0;
      $line_total = $discount_kg * $discount_price_kg;

      if($unit === 'sack'){
        $display_unit_price = ($qIn > 0) ? ($line_total / $qIn) : ($discount_price_kg * $unit_weight_kg);
      } else {
        $display_unit_price = $discount_price_kg;
      }

    } else {
      if($regular_available < $qty_kg){
        pos_save_old($customer_id, $sale_type, $due_date_post, $term_days, $discount_type, $discount_name, $discount_idno);
        header("Location: pos.php?error=" . urlencode("Not enough regular stock for selected product."));
        exit;
      }

      $discount_kg = 0.0;
      $regular_kg = $qty_kg;
      $line_total = $regular_kg * $regular_price_kg;

      if($unit === 'sack'){
        $display_unit_price = ($regular_price_sack > 0)
          ? $regular_price_sack
          : (($qIn > 0) ? ($line_total / $qIn) : 0);
      } else {
        $display_unit_price = $regular_price_kg;
      }
    }

    $gross_total += $line_total;

    $items[] = [
      'product_id'        => $pid,
      'batch_id'          => $batch_id,
      'batch_code'        => (string)($selectedBatch['batch_code'] ?? ''),
      'stock_type'        => $stock_type,
      'unit_type'         => $unit,
      'qty_input'         => $qIn,
      'qty_kg'            => $qty_kg,
      'discount_kg'       => $discount_kg,
      'regular_kg'        => $regular_kg,
      'discount_price_kg' => $discount_price_kg,
      'regular_price_kg'  => $regular_price_kg,
      'unit_price'        => $display_unit_price,
      'line_total'        => $line_total
    ];
  }

  if(count($items) === 0){
    pos_save_old($customer_id, $sale_type, $due_date_post, $term_days, $discount_type, $discount_name, $discount_idno);
    header("Location: pos.php?error=" . urlencode("No valid items found. Check quantities."));
    exit;
  }

  $discRate = 0.0;
  if($discount_type === 'pwd' || $discount_type === 'sc'){
    $discRate = 0.05;
  } elseif($discount_type === 'others'){
    $discRate = ((float)$discount_percent / 100.0);
  }
  $discount_amount = round($gross_total * $discRate, 2);
  $net_total = round($gross_total - $discount_amount, 2);
  if($net_total < 0) $net_total = 0;

  if($sale_type !== 'utang' && $payment_method === 'cash' && $cash_received <= 0){
    pos_save_old($customer_id, $sale_type, $due_date_post, $term_days, $discount_type, $discount_name, $discount_idno);
    header("Location: pos.php?error=" . urlencode("Cash received is required for cash payments."));
    exit;
  }

  if($sale_type !== 'utang' && $payment_method === 'cash' && $cash_received > 0 && $cash_received < $net_total){
    pos_save_old($customer_id, $sale_type, $due_date_post, $term_days, $discount_type, $discount_name, $discount_idno);
    header("Location: pos.php?error=" . urlencode("Cash received is less than the total amount."));
    exit;
  }

  $conn->begin_transaction();

  try {
    $neededKgByProduct = [];
    $neededDiscountKgByProduct = [];
    $neededRegularKgByProduct = [];
    $neededRegularKgByBatch = [];
    $neededDiscountKgByBatch = [];

    foreach($items as $it){
      $pid = (int)$it['product_id'];
      $bid = (int)$it['batch_id'];

      if(!isset($neededKgByProduct[$pid])) $neededKgByProduct[$pid] = 0.0;
      $neededKgByProduct[$pid] += (float)$it['qty_kg'];

      if(!isset($neededDiscountKgByProduct[$pid])) $neededDiscountKgByProduct[$pid] = 0.0;
      $neededDiscountKgByProduct[$pid] += (float)$it['discount_kg'];

      if(!isset($neededRegularKgByProduct[$pid])) $neededRegularKgByProduct[$pid] = 0.0;
      $neededRegularKgByProduct[$pid] += (float)$it['regular_kg'];

      if(!isset($neededRegularKgByBatch[$bid])) $neededRegularKgByBatch[$bid] = 0.0;
      $neededRegularKgByBatch[$bid] += (float)$it['regular_kg'];

      if(!isset($neededDiscountKgByBatch[$bid])) $neededDiscountKgByBatch[$bid] = 0.0;
      $neededDiscountKgByBatch[$bid] += (float)$it['discount_kg'];
    }

    $productIds = array_keys($neededKgByProduct);
    if(count($productIds) === 0){
      throw new Exception("No valid products to process.");
    }

    $idList = implode(',', array_map('intval', $productIds));

    if(!$conn->query("SELECT product_id FROM products WHERE product_id IN ({$idList}) FOR UPDATE")){
      throw new Exception("Unable to lock product rows for stock validation.");
    }

    $conn->query("SELECT product_id FROM product_discount_stock WHERE product_id IN ({$idList}) FOR UPDATE");

    $batchIds = array_values(array_unique(array_map('intval', array_merge(array_keys($neededRegularKgByBatch), array_keys($neededDiscountKgByBatch)))));
    $batchIds = array_values(array_filter($batchIds, fn($v) => $v > 0));
    if(count($batchIds) === 0){
      throw new Exception("No stock batches selected.");
    }
    $batchIdList = implode(',', $batchIds);
    $batchNow = [];
    $resBatch = $conn->query("
      SELECT batch_id, product_id, regular_qty_kg, discounted_qty_kg
      FROM stock_batches
      WHERE batch_id IN ({$batchIdList})
      FOR UPDATE
    ");
    if($resBatch){
      while($r = $resBatch->fetch_assoc()){
        $batchNow[(int)$r['batch_id']] = $r;
      }
    }

    foreach($batchIds as $bid){
      if(!isset($batchNow[$bid])){
        throw new Exception("Selected stock batch #{$bid} is no longer available.");
      }

      $needRegular = (float)($neededRegularKgByBatch[$bid] ?? 0);
      $needDiscount = (float)($neededDiscountKgByBatch[$bid] ?? 0);
      $availableRegular = (float)($batchNow[$bid]['regular_qty_kg'] ?? 0);
      $availableDiscount = (float)($batchNow[$bid]['discounted_qty_kg'] ?? 0);

      if($availableRegular < $needRegular){
        throw new Exception("Insufficient regular stock in batch #{$bid}. Available: ".number_format($availableRegular,2)." kg, required: ".number_format($needRegular,2)." kg");
      }
      if($availableDiscount < $needDiscount){
        throw new Exception("Insufficient discounted stock in batch #{$bid}. Available: ".number_format($availableDiscount,2)." kg, required: ".number_format($needDiscount,2)." kg");
      }
    }

    $stmt = $conn->prepare("
      INSERT INTO sales (user_id, customer_id, sale_date, total_amount, status, created_at)
      VALUES (?, ?, NOW(), ?, ?, NOW())
    ");
    $stmt->bind_param("iids", $user_id, $customer_id, $net_total, $status);
    $stmt->execute();
    $sale_id = $stmt->insert_id;
    $stmt->close();

    foreach($items as $it){
      $stmt = $conn->prepare("
        INSERT INTO sales_items
        (sale_id, product_id, batch_id, qty_kg, unit_price, line_total, unit_type, qty_input, discount_kg, regular_kg)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ");
      $stmt->bind_param(
        "iiidddsddd",
        $sale_id,
        $it['product_id'],
        $it['batch_id'],
        $it['qty_kg'],
        $it['unit_price'],
        $it['line_total'],
        $it['unit_type'],
        $it['qty_input'],
        $it['discount_kg'],
        $it['regular_kg']
      );
      $stmt->execute();
      $stmt->close();

      $unitLabel = ($it['unit_type'] === 'sack')
        ? ($it['qty_input']." sack(s)")
        : (number_format($it['qty_input'],2)." kg");

      $stockTypeLabel = ($it['stock_type'] === 'discounted') ? 'discounted' : 'regular';
      $batchLabel = !empty($it['batch_code']) ? " batch {$it['batch_code']}" : " batch #{$it['batch_id']}";
      $note = "Sale #{$sale_id} - {$unitLabel} deducted from {$stockTypeLabel}{$batchLabel}";

      $stmt = $conn->prepare("
        INSERT INTO inventory_transactions
          (product_id, batch_id, qty_kg, reference_id, reference_type, type, note, created_at)
        VALUES (?, ?, ?, ?, 'sale', 'out', ?, NOW())
      ");
      $stmt->bind_param("iidis", $it['product_id'], $it['batch_id'], $it['qty_kg'], $sale_id, $note);
      $stmt->execute();
      $stmt->close();

      if(($it['regular_kg'] ?? 0) > 0){
        $stmt = $conn->prepare("
          UPDATE stock_batches
          SET regular_qty_kg = regular_qty_kg - ?,
              remaining_qty_kg = remaining_qty_kg - ?,
              updated_at = NOW()
          WHERE batch_id = ? AND product_id = ? AND regular_qty_kg >= ?
        ");
        if(!$stmt){
          throw new Exception("Unable to update regular batch stock.");
        }
        $stmt->bind_param("ddiid", $it['regular_kg'], $it['regular_kg'], $it['batch_id'], $it['product_id'], $it['regular_kg']);
        $stmt->execute();
        if($stmt->affected_rows !== 1){
          $stmt->close();
          throw new Exception("Regular batch stock changed. Please retry.");
        }
        $stmt->close();
      }

      if(($it['discount_kg'] ?? 0) > 0){
        $stmt = $conn->prepare("
          UPDATE stock_batches
          SET discounted_qty_kg = discounted_qty_kg - ?,
              remaining_qty_kg = remaining_qty_kg - ?,
              updated_at = NOW()
          WHERE batch_id = ? AND product_id = ? AND discounted_qty_kg >= ?
        ");
        if(!$stmt){
          throw new Exception("Unable to update discounted batch stock.");
        }
        $stmt->bind_param("ddiid", $it['discount_kg'], $it['discount_kg'], $it['batch_id'], $it['product_id'], $it['discount_kg']);
        $stmt->execute();
        if($stmt->affected_rows !== 1){
          $stmt->close();
          throw new Exception("Discounted batch stock changed. Please retry.");
        }
        $stmt->close();

        $stmt = $conn->prepare("
          UPDATE product_discount_stock
          SET qty_kg = qty_kg - ?
          WHERE product_id = ? AND qty_kg >= ?
        ");
        if(!$stmt){
          throw new Exception("Unable to update discounted stock bucket.");
        }
        $stmt->bind_param("did", $it['discount_kg'], $it['product_id'], $it['discount_kg']);
        $stmt->execute();

        if($stmt->affected_rows !== 1){
          $stmt->close();
          throw new Exception("Discounted stock was modified by another transaction. Please retry.");
        }
        $stmt->close();

        $stmt = $conn->prepare("
          DELETE FROM product_discount_stock
          WHERE product_id = ? AND qty_kg <= 0.00001
        ");
        if($stmt){
          $stmt->bind_param("i", $it['product_id']);
          $stmt->execute();
          $stmt->close();
        }
      }
    }

    $_SESSION['sale_discount'][$sale_id] = [
      'type'   => $discount_type,
      'rate'   => $discRate,
      'gross'  => round($gross_total, 2),
      'disc'   => round($discount_amount, 2),
      'net'    => round($net_total, 2),
      'name'   => $discount_name,
      'idno'   => $discount_idno,
      'units'  => array_map(function($x){
        return [
          'product_id'   => (int)$x['product_id'],
          'batch_id'     => (int)($x['batch_id'] ?? 0),
          'batch_code'   => (string)($x['batch_code'] ?? ''),
          'stock_type'   => (string)$x['stock_type'],
          'unit_type'    => (string)$x['unit_type'],
          'qty_input'    => (float)$x['qty_input'],
          'qty_kg'       => (float)$x['qty_kg'],
          'discount_kg'  => (float)$x['discount_kg'],
          'regular_kg'   => (float)$x['regular_kg'],
          'line_total'   => (float)$x['line_total'],
        ];
      }, $items),
    ];

    if($sale_type === 'utang'){
      $amount_paid = 0.0;
      $balance     = $net_total;

      $due_date = $due_date_post ?: null;
      if($due_date && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $due_date)){
        $due_date = null;
      }

      $stmt = $conn->prepare("
        INSERT INTO account_receivable
          (sales_id, customer_id, total_amount, amount_paid, balance, due_date, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, 'unpaid', NOW())
      ");
      $stmt->bind_param("iiddds", $sale_id, $customer_id, $net_total, $amount_paid, $balance, $due_date);
      $stmt->execute();
      $stmt->close();

      $message = "Hi! You have an unpaid balance of ₱".number_format($balance,2)." for Sale #{$sale_id}. Please settle it by ".($due_date ? $due_date : 'the due date').". Thank you!";

      $stmt = $conn->prepare("
        INSERT INTO push_notif_logs (payment_id, customer_id, message, sent_at, status)
        VALUES (NULL, ?, ?, NOW(), 'SENT')
      ");
      $stmt->bind_param("is", $customer_id, $message);
      $stmt->execute();
      $stmt->close();
    } else {
      $payStatus = 'paid';
      $stmt = $conn->prepare("
        INSERT INTO payments (sale_id, amount, method, status, paid_at, external_ref)
        VALUES (?, ?, ?, ?, NOW(), ?)
      ");
      if(!$stmt){
        throw new Exception("Unable to record payment.");
      }
      $stmt->bind_param("idsss", $sale_id, $net_total, $payment_method, $payStatus, $payment_external_ref);
      $stmt->execute();
      $stmt->close();
    }

    $conn->commit();

    $desc = "Created sale #{$sale_id} (".$status.") gross ₱".number_format($gross_total,2)." disc ₱".number_format($discount_amount,2)." net ₱".number_format($net_total,2);
    $stmt = $conn->prepare("
      INSERT INTO activity_logs (user_id, activity_type, description, created_at)
      VALUES (?, 'SALE_CREATE', ?, NOW())
    ");
    $stmt->bind_param("is", $user_id, $desc);
    $stmt->execute();
    $stmt->close();

    $receiptUrl = "receipt.php?sale_id=".(int)$sale_id;
    if($sale_type !== 'utang' && $payment_method === 'cash' && $cash_received > 0){
      $receiptUrl .= "&cash=" . urlencode((string)$cash_received);
    }
    header("Location: {$receiptUrl}");
    exit;

  } catch (Exception $e){
    $conn->rollback();
    pos_save_old($customer_id, $sale_type, $due_date_post, $term_days, $discount_type, $discount_name, $discount_idno);
    header("Location: pos.php?error=" . urlencode($e->getMessage()));
    exit;
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sale | Cashier</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="../css/layout.css" rel="stylesheet">
<link href="../css/cashier-pos.css?v=pos-terminal-1" rel="stylesheet">
<link href="../css/cashier-mobile.css" rel="stylesheet">
<style>
  .pos-product-browser{
    background: linear-gradient(180deg, #ffffff 0%, #f5f7fb 100%);
    border: 1px solid rgba(15, 23, 42, 0.08);
    border-radius: 18px;
    padding: 14px;
  }
  .pos-tile-grid{
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 10px;
    max-height: 420px;
    overflow: auto;
    padding-right: 4px;
  }
  .pos-product-tile{
    border: 1px solid rgba(15, 23, 42, 0.08);
    border-radius: 16px;
    padding: 12px;
    min-height: 138px;
    text-align: left;
    background: linear-gradient(180deg, #fff 0%, #eef3ff 100%);
    box-shadow: 0 4px 16px rgba(15, 23, 42, 0.06);
    transition: transform .14s ease, box-shadow .14s ease, border-color .14s ease;
  }
  .pos-product-tile:hover{
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(15, 23, 42, 0.12);
    border-color: rgba(15, 23, 42, 0.18);
  }
  .pos-product-tile .tile-code{
    font-size: .78rem;
    font-weight: 700;
    letter-spacing: .03em;
    color: #0f172a;
    opacity: .75;
  }
  .pos-product-tile .tile-name{
    font-size: .95rem;
    font-weight: 800;
    line-height: 1.15;
    color: #0f172a;
    margin-top: 6px;
  }
  .pos-product-tile .tile-meta{
    font-size: .8rem;
    color: #475569;
    margin-top: 4px;
  }
  .pos-product-tile .tile-price{
    font-size: .72rem;
    line-height: 1.2;
    font-weight: 800;
    color: #166534;
    margin-top: 4px;
    white-space: normal;
  }
  .pos-product-tile .tile-stock{
    display: inline-block;
    margin-top: 6px;
    padding: 3px 7px;
    border-radius: 999px;
    background: rgba(15, 23, 42, .08);
    font-size: .75rem;
    font-weight: 700;
  }
  .quick-qty-btn{
    min-height: 54px;
    font-size: 1.05rem;
    font-weight: 700;
  }
  .pos-summary-panel.is-hidden{
    display: none !important;
  }
  #showAllTilesBtn{
    position: relative;
    z-index: 3;
    pointer-events: auto;
    cursor: pointer;
  }
  #productTileSearch{
    position: relative;
    z-index: 3;
  }
  #selectedCustomerDisplay{
    min-height: 38px;
    display: flex;
    align-items: center;
    gap: .15rem;
    overflow: hidden;
  }
  #selectedCustomerDisplay .text-muted{
    margin-left: .25rem;
    white-space: nowrap;
  }
  .customer-picker-option{
    border-radius: 10px !important;
    margin-bottom: 6px;
  }
  .customer-picker-option:hover{
    transform: translateY(-1px);
  }
  .pos-product-browser{
    position: relative;
    z-index: 1;
  }
  /* Touchscreen counter layout: product grid beside the live ticket. */
  .pos-shell{align-items:stretch;}
  .pos-shell-left,.pos-shell-right{min-height:0;}
  .pos-shell-left .pos-card,.pos-shell-right .pos-card{height:calc(100vh - 144px);max-height:calc(100vh - 144px);}
  .pos-shell-left .card-body,.pos-shell-right .card-body{height:100%;min-height:0;overflow:hidden;}
  .pos-shell-left .sales-form-frame{height:100%;overflow:hidden;}
  .pos-shell-left .sales-form-frame > .p-3{height:100%;padding:14px!important;}
  #saleForm,.pos-compact{height:100%;min-height:0;}
  #saleForm .pos-terminal-strip{margin-bottom:12px!important;}
  #saleForm .pos-section-head,#saleForm .pos-active-product,#saleForm .pos-cart-note,#saleForm .pos-divider{display:none;}
  #saleForm .items-wrap{height:calc(100% - 56px);max-height:none;overflow:hidden;display:flex;flex-direction:column;}
  .pos-product-browser{padding:16px;background:#fff;border-radius:18px;display:flex;flex-direction:column;flex:0 0 62%;min-height:0;margin-bottom:0!important;}
  .pos-tile-grid{grid-template-columns:repeat(4,minmax(0,1fr));max-height:none;flex:1 1 auto;min-height:0;gap:11px;overflow-y:auto;}
  .pos-product-tile{position:relative;min-height:148px;padding:12px;border-radius:18px;background:#fff;text-align:left;}
  .pos-product-tile:focus-visible,.pos-product-tile:hover{outline:3px solid rgba(50,69,89,.18);transform:translateY(-2px);}
  .pos-product-tile .tile-name{font-size:.96rem;min-height:2.1em;}
  .pos-product-tile .tile-meta{font-size:.74rem;margin-top:3px;}
  .pos-product-tile .tile-price{font-size:.68rem;margin-top:3px;}
  .pos-product-tile .tile-stock{font-size:.7rem;margin-top:5px;padding:3px 7px;}
  .pos-tile-grid .pos-empty-stock{opacity:.65;}
  .pos-active-product{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:16px;padding:18px 20px;margin-bottom:14px;border:1px solid rgba(50,69,89,.16);border-radius:18px;background:linear-gradient(110deg,#f3f7fb,#fff);}
  .pos-active-product .active-title{font-size:1.25rem;font-weight:800;color:#243446;}
  .pos-active-product .active-detail{font-size:.9rem;color:#66788a;}
  .pos-active-product .active-qty{font-size:1.8rem;font-weight:800;color:#243446;white-space:nowrap;}
  .pos-cart-heading{display:flex;justify-content:space-between;align-items:center;margin:8px 0;}
  .pos-cart-heading h5{font-weight:800;margin:0;}
  .pos-shell-right .pos-card{height:calc(100vh - 144px);max-height:calc(100vh - 144px);}
  .pos-shell-right .card-body{overflow:auto;}
  .pos-summary-panel{display:flex;flex-direction:column;min-height:100%;}
  .pos-summary-panel .pos-receipt-head{flex:0 0 auto;}
  .pos-summary-panel .pos-ticket-wrap{flex:1 1 auto;min-height:110px;overflow:auto;border:1px solid rgba(50,69,89,.12);border-radius:12px;background:#fff;margin-bottom:12px;}
  .pos-ticket{width:100%;margin:0;}
  .pos-ticket thead th{position:sticky;top:0;z-index:1;background:#324559!important;color:#fff!important;padding:9px 7px;font-size:.72rem;}
  .pos-ticket tbody td{vertical-align:middle;padding:8px 7px;font-size:.82rem;}
  .pos-ticket-item{font-weight:800;color:#243446;line-height:1.15;}
  .pos-ticket-sub{font-size:.7rem;color:#66788a;margin-top:3px;}
  .ticket-qty-control{display:flex;align-items:center;justify-content:center;gap:4px;}
  .ticket-qty-control button{width:30px;height:30px;padding:0;border-radius:8px;font-weight:800;}
  .ticket-qty-control input{width:54px!important;min-width:48px!important;padding:4px;text-align:center;font-weight:800;}
  .ticket-remove{border:0;background:transparent;color:#b42318;padding:5px;}
  .ticket-actions{display:flex;justify-content:center;gap:3px;white-space:nowrap;}
  .ticket-actions button{width:27px;height:30px;padding:0;border:0;border-radius:7px;background:transparent;color:#475569;}
  .ticket-actions .ticket-remove{color:#b42318;}
  .ticket-actions button:hover{background:#f1f5f9;}
  .pos-total-box{text-align:left;padding:14px;margin-bottom:10px!important;}
  .pos-total-box .summary-total{font-size:2rem;}
  #totalsPanel{padding:10px!important;}
  .pos-shell-right .pos-payment-box{margin-bottom:10px!important;}
  .pos-summary-panel #transactionPanel{margin-bottom:10px!important;padding:10px!important;}
  .pos-summary-panel .pos-menu-btn{min-height:52px;text-align:center;}
  @media(min-width:992px){
    .pos-shell{flex-wrap:nowrap;}
    .pos-shell-left{flex:0 0 62%;max-width:62%;}
    .pos-shell-right{flex:0 0 38%;max-width:38%;position:static;top:auto;}
  }
  @media(max-width:991.98px){
    .pos-page-main{height:auto;overflow:visible;}
    .pos-shell-left .pos-card,.pos-shell-right .pos-card{height:auto;max-height:none;}
    .pos-shell-left .card-body,.pos-shell-right .card-body{height:auto;overflow:visible;}
    .pos-shell-left .sales-form-frame,.pos-shell-left .sales-form-frame > .p-3,#saleForm,.pos-compact{height:auto;}
    #saleForm .items-wrap{height:auto;overflow:visible;display:block;}
    .pos-product-browser{min-height:320px;flex:auto;}
    .pos-tile-grid{max-height:400px;}
    .pos-summary-panel .pos-ticket-wrap{max-height:320px;}
  }
  .pos-tile-grid .pos-product-tile.is-selected{border-color:#324559;box-shadow:0 0 0 3px rgba(50,69,89,.15),0 10px 24px rgba(36,52,70,.1);}
  .items-table tbody td{vertical-align:middle;padding:.7rem .65rem;}
  .items-table tbody tr{transition:background-color .2s ease,opacity .2s ease;}
  .items-table .batch-select{font-size:.78rem;}
  .pos-product-browser .form-control-lg{border-radius:14px;}
  .pos-checkout-btn{min-height:54px;font-size:1.02rem;}
  .pos-cart-heading{margin:0 0 6px;}
  .pos-cart-heading .btn{font-weight:700;}
  .pos-details-panel{flex:0 0 auto;max-height:38%;overflow:auto;border:1px solid rgba(50,69,89,.14);border-radius:12px;background:#fff;margin-top:8px;}
  .pos-details-panel:not(.show){display:none;}
  .pos-details-panel .items-table{margin:0;}
  .pos-details-panel .items-table thead th{position:sticky;top:0;z-index:1;}
  @media(min-width:992px){
    .pos-shell-left .sales-form-frame > .p-3{overflow-y:auto;}
    .pos-shell-left #saleForm,.pos-shell-left .pos-compact,.pos-shell-left #saleForm .items-wrap{height:auto;min-height:0;overflow:visible;}
    .pos-shell-left .pos-product-browser{flex:0 0 420px;}
    .pos-shell-left .pos-details-panel{max-height:min(38vh,320px);overflow-y:auto;}
  }
  @media(max-width:575.98px){.pos-tile-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.pos-product-tile{padding:12px;min-height:116px}.pos-product-tile .tile-name{font-size:.92rem}.pos-product-tile .tile-stock{font-size:.68rem}.pos-cart-heading{align-items:flex-start;flex-direction:column;gap:3px}}
</style>
</head>

<body>

<?php
$profileLink = 'cashier_profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>

<div class="container-fluid">
  <div class="row">

   <?php include '../includes/cashier_sidebar.php'; ?>

    <main class="col-lg-10 px-4 main-content pos-page-main">
      <div class="py-4 pos-page-scroll">

        <div class="pos-topbar no-print">
          <div>
            <div class="pos-kicker">Cashier Terminal</div>
            <h3 class="fw-bold mb-1">Point of Sale</h3>
            <div class="text-muted">Ring up rice sales, choose batch stock, and print the receipt.</div>
          </div>
          <div class="pos-clock">
            <div><span>Date</span><strong id="posDate">--</strong></div>
            <div><span>Time</span><strong id="posTime">--</strong></div>
          </div>
        </div>

        <?php if($success): ?>
          <div class="alert alert-success py-2"><?= h($success) ?></div>
        <?php endif; ?>
        <?php if($err): ?>
          <div class="alert alert-danger py-2"><?= h($err) ?></div>
        <?php endif; ?>

        <div class="row g-3 pos-shell">
          <div class="col-12 col-lg-8 pos-shell-left">
            <div class="card modern-card pos-card pos-combined-card">
              <div class="card-body p-0">
                <div class="sales-form-frame h-100">
                  <div class="p-3">
                    <form method="POST" id="saleForm">
                      <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">

                      <div class="pos-compact">
                        <div class="pos-terminal-strip mb-3">
                          <div>
                            <span>Invoice #</span>
                            <strong>DRAFT</strong>
                          </div>
                          <div>
                            <span>Cashier</span>
                            <strong><?= h($cashierDisplayName) ?></strong>
                          </div>
                          <div>
                            <span>Status</span>
                            <strong>Open Transaction</strong>
                          </div>
                        </div>

                        <div class="pos-section-head mb-2">
                          <div>
                            <div class="pos-section-title mb-0">Cart</div>
                            <h5 class="mb-0">Order Items</h5>
                            <div class="text-muted small">Click a product tile to add it to the cart instantly.</div>
                          </div>
                          <div class="d-flex flex-wrap gap-2 align-items-center justify-content-end">
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="clearRows()">
                              <i class="fa-solid fa-trash-can me-1"></i>Clear
                            </button>
                            <button type="button" class="btn btn-sm btn-dark" onclick="addRow()">
                              <i class="fa-solid fa-plus me-1"></i>Add Item
                            </button>
                          </div>
                        </div>

                        <div class="items-wrap">
                          <div class="pos-product-browser mb-3">
                            <div class="d-flex flex-wrap gap-2 align-items-center mb-2">
                              <div class="flex-grow-1">
                                <input type="search" class="form-control" id="productTileSearch" placeholder="Search rice, variety, or grade" aria-label="Search products">
                              </div>
                            </div>
                            <div class="pos-tile-grid" id="productTileGrid"></div>
                          </div>
                          <section class="pos-active-product" id="posActiveProduct" aria-live="polite">
                            <div>
                              <div class="pos-section-title mb-1">Selected product</div>
                              <div class="active-title" id="activeProductName">Choose a rice tile to start</div>
                              <div class="active-detail" id="activeProductDetail">Available stock and price will appear here.</div>
                            </div>
                            <div class="active-qty" id="activeProductQty">0 items</div>
                          </section>
                          <div class="pos-cart-heading">
                            <div>
                              <h5>Current order</h5>
                              <span class="text-muted small">Adjust quantities in the ticket.</span>
                            </div>
                            <div class="d-flex align-items-center gap-1">
                              <button type="button" class="btn btn-sm btn-outline-secondary py-0 px-1" onclick="clearCurrentOrder()" aria-label="Clear current order items" title="Clear current order items">
                                <i class="fa-solid fa-eraser"></i> Clear items
                              </button>
                              <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="collapse" data-bs-target="#posItemDetails" aria-expanded="false" aria-controls="posItemDetails">
                                <i class="fa-solid fa-sliders me-1"></i>Item details
                              </button>
                            </div>
                          </div>
                          <div class="collapse pos-details-panel" id="posItemDetails">
                            <table class="table table-sm align-middle items-table" id="itemsTable">
                              <thead class="table-dark">
                                <tr>
                                  <th style="width:48%">Stock Left</th>
                                  <th style="width:24%">Type</th>
                                  <th style="width:28%">Unit</th>
                                </tr>
                              </thead>
                              <tbody></tbody>
                            </table>
                          </div>
                        </div>
                        <div class="pos-cart-note mt-2">
                          <i class="fa-solid fa-circle-info"></i>
                          Tap a rice tile to add it. Batch selection and stock validation happen automatically; choose discounted stock only when needed.
                        </div>

                        <div class="pos-divider"></div>

                        <input type="hidden" name="checkout" value="1">
                        <button type="submit" id="checkoutBtn" class="d-none"></button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-12 col-lg-4 pos-shell-right">
            <div class="card modern-card pos-card">
              <div class="card-body p-3">
                <div class="pos-summary-panel" id="posSummaryPanel">
                    <div class="pos-receipt-head">
                      <div>
                        <div class="sidebar-card-title">Order Summary</div>
                        <div class="text-muted small">Review totals before checkout</div>
                      </div>
                      <span class="badge text-bg-secondary" id="ticketStatusBadge">Draft sale</span>
                    </div>
                    <div class="sidebar-sep"></div>

                    <div id="stockWarningBox" class="alert alert-danger py-2 d-none mt-2 mb-2"></div>

                    <div class="pos-total-box mb-3">
                      <div class="d-flex justify-content-between align-items-center">
                        <div><div class="metric-label">Amount Due</div><div class="summary-total">₱ <span id="grandTotal">0.00</span></div></div>
                        <span class="badge text-bg-dark" id="lineCountBadge">0 line(s)</span>
                      </div>
                    </div>

                    <div class="pos-ticket-wrap" aria-label="Current transaction items">
                      <table class="table table-sm align-middle pos-ticket">
                        <thead><tr><th>Item</th><th class="text-center">Qty</th><th class="text-end">Total</th><th></th></tr></thead>
                        <tbody id="posTicketBody"><tr><td colspan="4" class="text-center text-muted py-4">Tap a rice tile to add items</td></tr></tbody>
                      </table>
                    </div>

                    <div class="soft-box p-3 mb-3" id="transactionPanel">
                      <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="metric-label">Transaction</span>
                        <button class="btn btn-sm btn-outline-secondary options-toggle" type="button" data-bs-toggle="collapse" data-bs-target="#saleOptions" aria-expanded="false" aria-controls="saleOptions">
                          <i class="fa-solid fa-sliders me-1"></i> More
                        </button>
                      </div>
                      <div class="row g-2">
                        <div class="col-12">
                          <label class="form-label mb-0" for="sale_type">Sale Type</label>
                          <select name="sale_type" id="sale_type" class="form-select" form="saleForm" required onchange="toggleDueDate()">
                            <option value="cash" <?= $old_sale_type==='cash'?'selected':'' ?>>Cash (Paid)</option>
                            <option value="utang" <?= $old_sale_type==='utang'?'selected':'' ?>>Utang (Unpaid)</option>
                          </select>
                        </div>

                        <!-- Customer is required only for Utang transactions -->
                        <div class="col-12 d-none" id="customerInfoWrap">
                          <div class="d-flex justify-content-between align-items-center mb-1">
                            <label class="form-label mb-0 fw-semibold">Customer for Utang</label>
                            <button
                              type="button"
                              id="addCustomerMenuBtn"
                              class="btn btn-sm btn-dark"
                              data-bs-toggle="modal"
                              data-bs-target="#customerPickerModal">
                              <i class="fa-solid fa-user-check me-1"></i> Choose Customer
                            </button>
                          </div>

                          <input
                            type="hidden"
                            name="customer_id"
                            id="customer_id"
                            form="saleForm"
                            value="<?= $old_customer_id > 0 ? (int)$old_customer_id : '' ?>">

                          <div id="selectedCustomerDisplay" class="form-control bg-light text-muted">
                            No customer selected
                          </div>

                          <div id="customerBalanceHint" class="small mt-1"></div>
                        </div>

                        <div class="col-12" id="paymentMethodWrap">
                          <label class="form-label mb-0" for="payment_method">Payment Method</label>
                          <select name="payment_method" id="payment_method" class="form-select" form="saleForm" onchange="togglePaymentFields()">
                            <option value="cash">Cash</option>
                            <option value="gcash">GCash</option>
                            <option value="bank">Bank Transfer</option>
                          </select>
                        </div>
                        <div class="col-12">
                          <label class="form-label mb-0" for="discount_type">Discount</label>
                          <select name="discount_type" id="discount_type" class="form-select" form="saleForm" onchange="toggleDiscountFields(); recalcAll();">
                            <option value="none" <?= $old_discount_type==='none'?'selected':'' ?>>None</option>
                            <option value="pwd"  <?= $old_discount_type==='pwd'?'selected':''  ?>>PWD (5%)</option>
                            <option value="sc"   <?= $old_discount_type==='sc'?'selected':''   ?>>Senior Citizen (5%)</option>
                            <option value="others" <?= $old_discount_type==='others'?'selected':'' ?>>Others (Custom %)</option>
                          </select>
                        </div>
                      </div>
                      <div class="collapse mt-2" id="saleOptions">
                        <div class="options-box">
                          <div class="row g-2">
                            <div class="col-12 col-md-6 d-none" id="termDaysWrap">
                              <label class="form-label fw-semibold" for="term_days">Credit Terms</label>
                              <select name="term_days" id="term_days" class="form-select" form="saleForm" onchange="toggleDueDate()">
                                <option value="7" <?= $old_term_days===7 ? 'selected' : '' ?>>7 days</option>
                                <option value="15" <?= $old_term_days===15 ? 'selected' : '' ?>>15 days</option>
                                <option value="30" <?= $old_term_days===30 ? 'selected' : '' ?>>30 days</option>
                              </select>
                            </div>
                            <div class="col-12 col-md-6 d-none" id="dueDateWrap">
                              <label class="form-label fw-semibold" for="dueDateText">Auto Due Date</label>
                              <input type="text" class="form-control" id="dueDateText" form="saleForm" readonly value="<?= h($old_due_date ?: '—') ?>">
                            </div>
                            <div class="col-12 d-none" id="discountFields">
                              <div class="row g-2">
                                <div class="col-md-4">
                                  <label class="form-label" for="discount_name">Discount Name (optional)</label>
                                  <input class="form-control" name="discount_name" id="discount_name" form="saleForm" value="<?= h($old_discount_name) ?>" placeholder="e.g., Juan Dela Cruz">
                                </div>
                                <div class="col-md-4">
                                  <label class="form-label" for="discount_idno">ID No. (optional)</label>
                                  <input class="form-control" name="discount_idno" id="discount_idno" form="saleForm" value="<?= h($old_discount_idno) ?>" placeholder="PWD/SC ID">
                                </div>
                                <div class="col-md-4 d-none" id="customDiscountWrap">
                                  <label class="form-label" for="discount_percent">Custom Discount %</label>
                                  <input type="number" step="0.01" min="0" max="100" class="form-control" name="discount_percent" id="discount_percent" form="saleForm" value="<?= h($old_discount_percent) ?>" placeholder="e.g., 10" oninput="recalcAll()">
                                </div>
                              </div>
                              <div class="hintline">Use only if customer is eligible. For custom discounts, enter the percentage for returning customers.</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="pos-payment-box mb-3" id="paymentPanel">
                      <div id="cashReceivedWrap">
                        <label class="form-label fw-semibold" for="cash_received">Cash Received</label>
                        <input type="number" step="0.01" min="0" class="form-control" name="cash_received" id="cash_received" form="saleForm" placeholder="Enter cash received" oninput="updatePaymentPreview()">
                        <div class="small text-danger mt-1 d-none" id="cashReceivedError">Cash received is required for cash payments.</div>
                      </div>

                      <div class="d-none" id="paymentRefWrap">
                        <label class="form-label fw-semibold" for="payment_external_ref">Payment Ref</label>
                        <input class="form-control" name="payment_external_ref" id="payment_external_ref" form="saleForm" placeholder="GCash or bank reference no.">
                      </div>
                    </div>

                    <div class="soft-box p-3 mb-2" id="totalsPanel">
                      <div class="d-flex justify-content-between mb-2">
                        <span class="metric-label">Subtotal</span>
                        <span class="metric-value">₱ <span id="subTotal">0.00</span></span>
                      </div>
                      <div class="d-flex justify-content-between mb-2">
                        <span class="metric-label">Discount</span>
                        <span class="metric-value text-danger">- ₱ <span id="discountAmt">0.00</span></span>
                      </div>
                      <div class="d-flex justify-content-between">
                        <span class="metric-label">Invoice No.</span>
                        <span class="metric-value">DRAFT</span>
                      </div>
                    </div>

                    <div class="sidebar-sep"></div>
                    <div class="text-center fw-bold mb-2">POS Actions</div>

                    <div class="d-grid gap-2">
                      <button type="button" id="checkoutProxyBtn" class="pos-menu-btn pos-checkout-btn">
                        <span class="ic"><i class="fa-solid fa-receipt"></i></span>Checkout & Print
                      </button>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>

  </div>
</div>

<div class="modal fade" id="recentSalesModal" tabindex="-1" aria-labelledby="recentSalesModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <div>
          <h5 class="modal-title fw-bold mb-0" id="recentSalesModalLabel">Recent Receipts</h5>
          <div class="text-muted small">Select a receipt to fill the void sale number.</div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="input-group mb-3">
          <span class="input-group-text"><i class="fa-solid fa-magnifying-glass"></i></span>
          <input type="search" class="form-control" id="recentSalesSearch" placeholder="Search by sale number, customer, or status">
        </div>
        <div class="table-responsive">
          <table class="table table-sm align-middle">
            <thead class="table-light">
              <tr>
                <th>Sale #</th>
                <th>Customer</th>
                <th>Date</th>
                <th class="text-end">Amount</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody id="recentSalesBody">
              <?php if(empty($recentSales)): ?>
                <tr><td colspan="6" class="text-center text-muted py-3">No recent sales found.</td></tr>
              <?php else: ?>
                <?php foreach($recentSales as $sale): ?>
                  <?php
                    $saleId = (int)$sale['sale_id'];
                    $saleDate = (string)($sale['sale_date'] ?? '');
                    $saleStatus = strtolower((string)($sale['status'] ?? ''));
                    $statusClass = $saleStatus === 'void' ? 'bg-danger' : (($saleStatus === 'paid') ? 'bg-success' : 'bg-warning text-dark');
                  ?>
                  <tr class="recent-sale-row" data-sale-id="<?= $saleId ?>" data-search="<?= h(strtolower($saleId . ' ' . $sale['customer_name'] . ' ' . $saleDate . ' ' . $saleStatus)) ?>">
                    <td>#<?= $saleId ?></td>
                    <td><?= h($sale['customer_name']) ?></td>
                    <td><?= h($saleDate) ?></td>
                    <td class="text-end">₱<?= h(number_format((float)$sale['total_amount'], 2)) ?></td>
                    <td><span class="badge <?= $statusClass ?>"><?= h(strtoupper($saleStatus ?: 'PAID')) ?></span></td>
                    <td class="text-end">
                      <button type="button" class="btn btn-sm btn-dark choose-receipt-btn">Choose</button>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="checkoutConfirmModal" tabindex="-1" aria-labelledby="checkoutConfirmModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg checkout-preview-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <div>
          <h5 class="modal-title fw-bold mb-0" id="checkoutConfirmModalLabel">Confirm Checkout</h5>
          <div class="text-muted small">Review the sale before posting and printing the receipt.</div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="checkout-preview-note alert alert-warning py-2 mb-3">
          Checkout will deduct stock and generate the receipt.
        </div>

        <div class="checkout-preview-grid mb-3">
          <div class="checkout-mini-card">
            <span class="checkout-mini-label">Customer</span>
            <strong id="confirmCustomer">-</strong>
          </div>
          <div class="checkout-mini-card">
            <span class="checkout-mini-label">Sale Type</span>
            <strong id="confirmSaleType">-</strong>
          </div>
          <div class="checkout-mini-card">
            <span class="checkout-mini-label">Payment</span>
            <strong id="confirmPaymentMethod">-</strong>
          </div>
          <div class="checkout-mini-card">
            <span class="checkout-mini-label">Lines</span>
            <strong id="confirmLines">0</strong>
          </div>
          <div class="checkout-mini-card d-none" id="confirmDueDateRow">
            <span class="checkout-mini-label">Due Date</span>
            <strong id="confirmDueDate">-</strong>
          </div>
          <div class="checkout-mini-card d-none" id="confirmPaymentRefRow">
            <span class="checkout-mini-label">Payment Ref</span>
            <strong id="confirmPaymentRef">-</strong>
          </div>
          <div class="checkout-mini-card d-none" id="confirmBalanceRow">
            <span class="checkout-mini-label">Balance After Checkout</span>
            <strong class="text-danger">₱ <span id="confirmBalance">0.00</span></strong>
          </div>
        </div>

        <div class="checkout-receipt-panel">
          <div class="checkout-receipt-head d-flex justify-content-between align-items-center gap-2 mb-2">
            <div>
              <div class="fw-bold">Receipt Preview</div>
              <div class="text-muted small">Items that will be posted</div>
            </div>
            <span class="badge text-bg-dark" id="confirmTotalBadge">₱ 0.00</span>
          </div>
          <div class="table-responsive checkout-items-table-wrap">
            <table class="table table-sm align-middle mb-0 checkout-items-table">
              <thead>
                <tr>
                  <th>Item</th>
                  <th class="text-end">Deduct</th>
                  <th class="text-end">Line</th>
                </tr>
              </thead>
              <tbody id="confirmItemsBody">
                <tr><td colspan="3" class="text-center text-muted py-3">No items</td></tr>
              </tbody>
            </table>
          </div>
          <div class="checkout-summary-grid mt-3">
            <div class="checkout-summary-row">
              <span class="text-muted">Subtotal</span>
              <strong>₱ <span id="confirmSubtotal">0.00</span></strong>
            </div>
            <div class="checkout-summary-row">
              <span class="text-muted">Discount</span>
              <strong class="text-danger">- ₱ <span id="confirmDiscount">0.00</span></strong>
            </div>
            <div class="checkout-summary-row checkout-total-row">
              <span class="fw-bold">Total</span>
              <strong>₱ <span id="confirmTotal">0.00</span></strong>
            </div>
          </div>
          <div id="confirmCashBlock" class="checkout-cash-block mt-3 d-none">
            <div class="checkout-summary-row">
              <span class="text-muted">Cash Received</span>
              <strong>₱ <span id="confirmCashReceived">0.00</span></strong>
            </div>
            <div class="checkout-summary-row">
              <span class="text-muted">Change</span>
              <strong>₱ <span id="confirmChange">0.00</span></strong>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-dark" id="confirmCheckoutBtn" data-loading data-loading-label="Printing receipt...">
          <i class="fa-solid fa-receipt me-1"></i> Confirm & Print Receipt
        </button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="customerPickerModal" tabindex="-1" aria-labelledby="customerPickerModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <div>
          <h5 class="modal-title fw-bold mb-0" id="customerPickerModalLabel">Choose Customer</h5>
          <div class="text-muted small">Select the registered customer who will owe this sale.</div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <div class="input-group mb-3">
          <span class="input-group-text"><i class="fa-solid fa-magnifying-glass"></i></span>
          <input type="search" class="form-control" id="customerPickerSearch" placeholder="Search customer name or phone">
        </div>

        <div class="list-group" id="customerPickerList">
          <?php if(empty($customers)): ?>
            <div class="text-center text-muted py-4">No registered customers found.</div>
          <?php else: ?>
            <?php foreach($customers as $customer): ?>
              <?php
                $customerId = (int)($customer['customer_id'] ?? 0);
                $customerName = trim((string)($customer['first_name'] ?? '') . ' ' . (string)($customer['last_name'] ?? ''));
                $customerPhone = trim((string)($customer['phone'] ?? ''));
                $openBalance = (float)($customer['open_balance'] ?? 0);
                $openDocs = (int)($customer['open_docs'] ?? 0);
              ?>
              <button
                type="button"
                class="list-group-item list-group-item-action customer-picker-option text-start"
                data-customer-id="<?= $customerId ?>"
                data-customer-name="<?= h($customerName) ?>"
                data-customer-phone="<?= h($customerPhone) ?>"
                data-open-balance="<?= h($openBalance) ?>"
                data-open-docs="<?= $openDocs ?>">
                <div class="d-flex justify-content-between align-items-start gap-2">
                  <div>
                    <div class="fw-bold"><?= h($customerName) ?></div>
                    <?php if($customerPhone !== ''): ?>
                      <div class="small text-muted"><i class="fa-solid fa-phone me-1"></i><?= h($customerPhone) ?></div>
                    <?php endif; ?>
                  </div>
                  <span class="badge <?= $openBalance > 0 ? 'text-bg-danger' : 'text-bg-success' ?>">
                    <?= $openBalance > 0 ? '₱'.number_format($openBalance, 2).' due' : 'No open utang' ?>
                  </span>
                </div>
              </button>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>

        <div id="customerPickerEmpty" class="text-center text-muted py-3 d-none">
          No customer matches your search.
        </div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-outline-dark" data-bs-target="#addCustomerModal" data-bs-toggle="modal">
          <i class="fa-solid fa-user-plus me-1"></i> Add New Customer
        </button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="addCustomerModal" tabindex="-1" aria-labelledby="addCustomerModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fw-bold" id="addCustomerModalLabel">Add Customer</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="POST">
          <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">
          <input type="hidden" name="add_customer" value="1">
          <div class="row g-2">
            <div class="col-md-6">
              <label class="form-label">First Name</label>
              <input class="form-control" name="first_name" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Last Name</label>
              <input class="form-control" name="last_name" required>
            </div>
            <div class="col-12">
              <label class="form-label">Phone</label>
              <input class="form-control" name="phone">
            </div>
            <div class="col-12">
              <label class="form-label">Address</label>
              <input class="form-control" name="address">
            </div>
            <div class="col-12 d-grid mt-2">
              <button class="btn btn-dark">
                <i class="fa-solid fa-user-plus me-1"></i> Add Customer
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="allItemsModal" tabindex="-1" aria-labelledby="allItemsModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <div>
          <h5 class="modal-title fw-bold" id="allItemsModalLabel">All Items</h5>
          <div class="text-muted small">Pick a product to load it into the active line</div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="input-group mb-3">
          <span class="input-group-text"><i class="fa-solid fa-magnifying-glass"></i></span>
          <input type="search" class="form-control" id="allItemsModalSearch" placeholder="Search by product, variety, or grade">
        </div>
        <div class="all-items-modal-list" id="allItemsModalList"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="draftVoidItemModal" tabindex="-1" aria-labelledby="draftVoidItemModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <div>
          <h5 class="modal-title fw-bold mb-0" id="draftVoidItemModalLabel">Void Item</h5>
          <div class="text-muted small">Owner password required before the item is removed from the cart.</div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="alert alert-warning py-2">
          This will remove the selected draft item from the cart only after owner approval.
        </div>
        <label class="form-label fw-semibold" for="draftVoidOwnerPassword">Owner Password</label>
        <input type="password" class="form-control" id="draftVoidOwnerPassword" placeholder="Enter owner password">
        <div class="small text-danger mt-2 d-none" id="draftVoidError"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-danger" id="confirmDraftVoidBtn">
          <i class="fa-solid fa-ban me-1"></i> Confirm Void
        </button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
const products = <?= json_encode($products) ?>;

function peso(n){
  return (Number(n||0)).toLocaleString(undefined,{minimumFractionDigits:2, maximumFractionDigits:2});
}

function productLabel(p){
  return `${p.variety} - ${p.grade} (${peso(p.unit_weight_kg)}kg/sack)`;
}

function normalizeProductText(text){
  return String(text || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}

function htmlText(value){
  return String(value ?? '').replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[char]));
}

function getOldestBatchTime(product){
  const batchTimes = (product?.batches || []).map((batch) => {
    const value = String(batch?.arrived_at || '');
    if(!value) return Number.POSITIVE_INFINITY;
    const time = Date.parse(value);
    return Number.isNaN(time) ? Number.POSITIVE_INFINITY : time;
  });
  const valid = batchTimes.filter((time) => Number.isFinite(time));
  return valid.length ? Math.min(...valid) : Number.POSITIVE_INFINITY;
}

function getProductAgeDays(product){
  const oldest = getOldestBatchTime(product);
  if(!Number.isFinite(oldest)) return null;
  return Math.max(0, Math.floor((Date.now() - oldest) / 86400000));
}

function isAgingProduct(product){
  const ageDays = getProductAgeDays(product);
  return ageDays !== null && ageDays >= 30;
}

function getPrioritizedProducts(){
  return [...products].sort((a, b) => {
    const aTime = getOldestBatchTime(a);
    const bTime = getOldestBatchTime(b);
    if(aTime < bTime) return -1;
    if(aTime > bTime) return 1;
    const aName = normalizeProductText(productLabel(a));
    const bName = normalizeProductText(productLabel(b));
    return aName.localeCompare(bName);
  });
}

function findProductByText(text){
  const needle = normalizeProductText(text);
  if(!needle) return null;

  const exact = products.find((p) => normalizeProductText(productLabel(p)) === needle);
  if(exact) return exact;

  const starts = products.find((p) => normalizeProductText(productLabel(p)).startsWith(needle));
  if(starts) return starts;

  const partial = products.find((p) => normalizeProductText(productLabel(p)).includes(needle));
  if(partial) return partial;

  return null;
}

const productOptionsList = document.createElement('datalist');
productOptionsList.id = 'productOptionsList';
productOptionsList.innerHTML = getPrioritizedProducts().map((p) => {
  const label = productLabel(p);
  return `<option value="${label}" data-product-id="${p.product_id}">${label}</option>`;
}).join('');
document.body.appendChild(productOptionsList);

function sackSummary(kg, unitWeight){
  const stockKg = Number(kg || 0);
  const weight = Number(unitWeight || 0);
  if(weight <= 0) return `${peso(stockKg)} kg`;
  const sacks = Math.floor(stockKg / weight);
  const loose = Math.max(0, stockKg - (sacks * weight));
  return `${sacks} sack(s)` + (loose > 0.004 ? ` + ${peso(loose)} kg loose` : '');
}

function getProductById(productId){
  const id = Number(productId || 0);
  return products.find(p => Number(p.product_id) === id) || null;
}

function productTilePrice(product){
  const stockType = getAutomaticStockType(product);
  const oldestFirst = [...(product?.batches || [])].sort((a, b) => {
    const aTime = a?.arrived_at ? Date.parse(a.arrived_at) : Number.MAX_SAFE_INTEGER;
    const bTime = b?.arrived_at ? Date.parse(b.arrived_at) : Number.MAX_SAFE_INTEGER;
    if(Number.isNaN(aTime) || Number.isNaN(bTime)) return 0;
    if(aTime !== bTime) return aTime - bTime;
    return Number(a?.batch_id || 0) - Number(b?.batch_id || 0);
  });
  const fifoBatch = oldestFirst.find((batch) => {
    const available = Number(stockType === 'discounted' ? batch?.discounted_qty_kg : batch?.regular_qty_kg) || 0;
    const price = Number(stockType === 'discounted' ? batch?.discounted_price_per_kg : batch?.regular_price_per_kg) || 0;
    return available > 0 && price > 0;
  });
  const pricePerKg = Number(stockType === 'discounted'
    ? fifoBatch?.discounted_price_per_kg
    : fifoBatch?.regular_price_per_kg) || Number(product?.price_per_kg || 0);
  if(pricePerKg <= 0) return 'Price unavailable';

  const weight = Number(product?.unit_weight_kg || 0);
  const perKg = `₱${peso(pricePerKg)}/kg`;
  return weight > 0 ? `${perKg} · ₱${peso(pricePerKg * weight)}/sack` : perKg;
}

function getVisibleProducts(){
  return getPrioritizedProducts();
}

function tileLabel(p){
  const name = `${p.variety} ${p.grade}`.trim();
  return name.length > 22 ? name.slice(0, 22) + '…' : name;
}

function getRowProduct(tr){
  const productId = Number(tr?.querySelector('select[name="product_id[]"]')?.value || 0);
  return getProductById(productId);
}

function hideProductSuggestions(tr){
  const box = tr?.querySelector('.product-suggestions');
  if(box) box.classList.add('d-none');
}

function openDraftVoidConfirmation(tr){
  if(tr){
    draftVoidTargetRow = tr;
  }else{
    const rows = Array.from(document.querySelectorAll('#itemsTable tbody tr')).filter((row) => {
      return Number(row.querySelector('select[name="product_id[]"]')?.value || 0) > 0 &&
        Number(row.querySelector('input[name="qty[]"]')?.value || 0) > 0;
    });
    if(!rows.length) return;
    draftVoidTargetRow = 'all';
  }
  const modalEl = document.getElementById('draftVoidItemModal');
  const passwordInput = document.getElementById('draftVoidOwnerPassword');
  const errorBox = document.getElementById('draftVoidError');
  if(passwordInput) passwordInput.value = '';
  if(errorBox){
    errorBox.classList.add('d-none');
    errorBox.textContent = '';
  }
  if(modalEl && typeof bootstrap !== 'undefined'){
    bootstrap.Modal.getOrCreateInstance(modalEl).show();
    setTimeout(() => passwordInput?.focus(), 100);
  }
}

async function verifyDraftVoidPassword(password){
  const formData = new FormData();
  formData.append('verify_draft_void', '1');
  formData.append('csrf_token', document.querySelector('#saleForm input[name="csrf_token"]')?.value || '');
  formData.append('owner_password', password || '');

  const response = await fetch('pos.php', {
    method: 'POST',
    body: formData,
    headers: {
      'X-Requested-With': 'fetch',
      'Accept': 'application/json',
    },
  });

  const contentType = response.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) {
    throw new Error(`The server returned a non-JSON response (HTTP ${response.status}).`);
  }

  const result = await response.json();
  if (!response.ok) {
    throw new Error(result.message || `Password verification failed (HTTP ${response.status}).`);
  }

  return result;
}

let activeProductRow = null;
let draftVoidTargetRow = null;

function getAllItemsModal(){
  return document.getElementById('allItemsModal');
}

function renderAllItemsModal(filterText = ''){
  const list = document.getElementById('allItemsModalList');
  if(!list) return;

  const typed = normalizeProductText(filterText);
  const items = getPrioritizedProducts().filter((p) => {
    if(!typed) return true;
    const label = normalizeProductText(productLabel(p));
    const variety = normalizeProductText(p.variety);
    const grade = normalizeProductText(p.grade);
    return label.includes(typed) || variety.includes(typed) || grade.includes(typed);
  });

  if(!items.length){
    list.innerHTML = '<div class="text-muted small px-2 py-3">No items found.</div>';
    return;
  }

  list.innerHTML = items.map((p) => `
    <button type="button" class="all-items-row btn btn-light w-100 text-start mb-2"
      data-product-id="${p.product_id}">
      <div class="d-flex justify-content-between align-items-start gap-2">
        <div>
          <div class="fw-semibold">${productLabel(p)}</div>
          <div class="small text-muted">${peso(p.stock_kg)} kg on hand</div>
        </div>
        <div class="d-flex flex-column align-items-end gap-1">
          ${isAgingProduct(p) ? '<span class="badge rounded-pill bg-warning text-dark product-aging-badge">AGING</span>' : ''}
          <span class="badge rounded-pill bg-secondary-subtle text-dark">${peso(p.stock_kg)} kg</span>
        </div>
      </div>
    </button>
  `).join('');

  list.querySelectorAll('.all-items-row').forEach((btn) => {
    btn.onclick = () => {
      if(activeProductRow){
        selectProductFromSuggestion(activeProductRow, btn.getAttribute('data-product-id'));
      }
      const modalEl = getAllItemsModal();
      const inst = modalEl && bootstrap?.Modal ? bootstrap.Modal.getInstance(modalEl) : null;
      inst?.hide();
    };
  });
}

function openAllItemsModal(tr){
  activeProductRow = tr || null;
  renderAllItemsModal('');
  const modalEl = getAllItemsModal();
  if(!modalEl || typeof bootstrap === 'undefined') return;
  const inst = bootstrap.Modal.getOrCreateInstance(modalEl);
  inst.show();
  setTimeout(() => document.getElementById('allItemsModalSearch')?.focus(), 100);
}

function showProductSuggestions(tr, forceAll = false){
  const input = tr?.querySelector('input.product-picker');
  const box = tr?.querySelector('.product-suggestions');
  if(!input || !box) return;

  const typed = normalizeProductText(input.value);
  const prioritized = getPrioritizedProducts();
  let matches = prioritized;

  if(!forceAll && typed){
    matches = prioritized.filter((p) => normalizeProductText(productLabel(p)).includes(typed));
  } else if(!forceAll && !typed){
    matches = [];
    box.innerHTML = '';
    box.classList.add('d-none');
    return;
  }

  matches = matches.slice(0, 12);
  if(!matches.length){
    box.innerHTML = `<div class="px-2 py-2 text-muted small">No matches found</div>`;
    box.classList.remove('d-none');
    return;
  }

  box.innerHTML = matches.map((p) => `
    <button type="button" class="dropdown-item product-match-item"
      data-product-id="${p.product_id}">
      <div class="d-flex align-items-center justify-content-between gap-2">
        <div class="fw-semibold product-match-title">${productLabel(p)}</div>
        ${isAgingProduct(p) ? '<span class="badge rounded-pill bg-warning text-dark product-aging-badge">AGING</span>' : ''}
      </div>
      <div class="small text-muted product-match-sub">${peso(p.stock_kg)} kg on hand</div>
    </button>
  `).join('');
  box.querySelectorAll('.product-match-item').forEach((btn) => {
    btn.onmousedown = (e) => {
      e.preventDefault();
      selectProductFromSuggestion(tr, btn.getAttribute('data-product-id'));
    };
  });
  box.classList.remove('d-none');
}

function getAutomaticStockType(product){
  const oldestFirst = [...(product?.batches || [])].sort((a, b) => {
    const aTime = a?.arrived_at ? Date.parse(a.arrived_at) : Number.MAX_SAFE_INTEGER;
    const bTime = b?.arrived_at ? Date.parse(b.arrived_at) : Number.MAX_SAFE_INTEGER;
    if(Number.isNaN(aTime) || Number.isNaN(bTime)) return 0;
    if(aTime !== bTime) return aTime - bTime;
    return Number(a?.batch_id || 0) - Number(b?.batch_id || 0);
  });

  // Prefer discounted stock from the oldest batch when that stock has a price.
  const oldestDiscountedBatch = oldestFirst.find((batch) =>
    Number(batch?.discounted_qty_kg || 0) > 0 &&
    Number(batch?.discounted_price_per_kg || 0) > 0
  );
  return oldestDiscountedBatch ? 'discounted' : 'regular';
}

function selectProductFromSuggestion(tr, productId){
  const sel = tr?.querySelector('select[name="product_id[]"]');
  const match = getProductById(productId);
  if(!sel || !match) return null;

  sel.value = String(match.product_id);
  const stockTypeInput = tr.querySelector('input[name="stock_type[]"]');
  const stockType = getAutomaticStockType(match);
  if(stockTypeInput) stockTypeInput.value = stockType;
  const typeBadge = tr.querySelector('.stock-type-badge');
  if(typeBadge){
    typeBadge.textContent = stockType === 'discounted' ? 'Discounted' : 'Regular';
    typeBadge.className = `badge ${stockType === 'discounted' ? 'text-bg-warning' : 'text-bg-primary'} stock-type-badge`;
  }
  hideProductSuggestions(tr);
  updateBatchOptions(tr);
  fillRow(tr);
  return match;
}

function syncProductFromInput(tr){
  const input = tr?.querySelector('input.product-picker');
  const sel = tr?.querySelector('select[name="product_id[]"]');
  if(!input || !sel) return null;

  const typed = normalizeProductText(input.value);
  if(!typed){
    sel.value = '';
    updateBatchOptions(tr);
    fillRow(tr);
    hideProductSuggestions(tr);
    return null;
  }

  const exact = products.find((p) => normalizeProductText(productLabel(p)) === typed) || null;
  if(exact){
    return selectProductFromSuggestion(tr, exact.product_id);
  }

  sel.value = '';
  updateBatchOptions(tr);
  fillRow(tr);
  showProductSuggestions(tr);
  return null;
}

function getSelectedBatch(tr){
  const batchSelect = tr.querySelector('select[name="batch_id[]"]');
  const batchId = Number(batchSelect?.value || 0);
  const productId = Number(tr.querySelector('select[name="product_id[]"]')?.value || 0);
  const product = getProductById(productId);
  return (product?.batches || []).find(b => Number(b.batch_id) === batchId) || null;
}

function batchHasFullSackStock(batch, stockType){
  const unitWeight = Number(batch?.unit_weight_kg || 0);
  const availableKg = Number(stockType === 'discounted' ? batch?.discounted_qty_kg : batch?.regular_qty_kg) || 0;
  return unitWeight > 0 && availableKg >= unitWeight;
}

function updateBatchOptions(tr){
  const productId = Number(tr.querySelector('select[name="product_id[]"]')?.value || 0);
  const stockType = tr.querySelector('input[name="stock_type[]"]')?.value || 'regular';
  const unit = tr.querySelector('select[name="unit_type[]"]')?.value || 'kg';
  const batchSelect = tr.querySelector('select[name="batch_id[]"]');
  if(!batchSelect) return;

  const product = getProductById(productId);
  const previous = batchSelect.value;
  batchSelect.innerHTML = '<option value="">Select batch</option>';

  const sortedBatches = [...(product?.batches || [])].sort((a, b) => {
    const aDate = (a?.arrived_at || '');
    const bDate = (b?.arrived_at || '');
    const aTime = aDate ? Date.parse(aDate) : Number.MAX_SAFE_INTEGER;
    const bTime = bDate ? Date.parse(bDate) : Number.MAX_SAFE_INTEGER;
    if(Number.isNaN(aTime) || Number.isNaN(bTime)) return 0;
    if(aTime < bTime) return -1;
    if(aTime > bTime) return 1;
    return (Number(a?.batch_id || 0) - Number(b?.batch_id || 0));
  });

  sortedBatches.forEach(b => {
    const regularKg = Number(b.regular_qty_kg || 0);
    const discountedKg = Number(b.discounted_qty_kg || 0);
    const available = stockType === 'discounted' ? discountedKg : regularKg;
    if(available <= 0) return;

    const arrived = b.arrived_at ? `Arrived ${b.arrived_at}` : 'No date';
    const price = stockType === 'discounted'
      ? Number(b.discounted_price_per_kg || 0)
      : Number(b.regular_price_per_kg || 0);
    const opt = document.createElement('option');
    opt.value = b.batch_id;
    opt.textContent = `${b.batch_code} - ${arrived} - ${sackSummary(available, b.unit_weight_kg)} @ ₱${peso(price)}/kg`;
    batchSelect.appendChild(opt);
  });

  if(batchSelect.options.length > 1){
    const firstSuitableBatch = sortedBatches.find((batch) => {
      const hasSelectedStock = Array.from(batchSelect.options)
        .some((option) => Number(option.value) === Number(batch.batch_id));
      return hasSelectedStock && (unit !== 'sack' || batchHasFullSackStock(batch, stockType));
    });
    batchSelect.value = firstSuitableBatch ? String(firstSuitableBatch.batch_id) : batchSelect.options[1].value;
  } else {
    batchSelect.value = '';
  }
  if(batchSelect.options.length > 1 && !batchSelect.value) batchSelect.selectedIndex = 1;

}

document.addEventListener('click', (e) => {
  const btn = e.target.closest?.('.options-toggle');
  if(!btn) return;
  if(typeof bootstrap !== 'undefined') return;

  e.preventDefault();
  const sel = btn.getAttribute('data-bs-target');
  const el = sel ? document.querySelector(sel) : null;
  if(!el) return;
  const isOpen = el.classList.toggle('show');
  btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
});

document.addEventListener('click', (e) => {
  if(e.target.closest?.('.product-picker') || e.target.closest?.('.product-suggestions') || e.target.closest?.('.product-list-btn') || e.target.closest?.('.product-input-shell')) return;
  document.querySelectorAll('.product-suggestions').forEach((box) => box.classList.add('d-none'));
});

document.getElementById('confirmDraftVoidBtn')?.addEventListener('click', async function(){
  const passwordInput = document.getElementById('draftVoidOwnerPassword');
  const errorBox = document.getElementById('draftVoidError');
  const modalEl = document.getElementById('draftVoidItemModal');
  const password = String(passwordInput?.value || '').trim();

  if(password === ''){
    if(errorBox){
      errorBox.textContent = 'Owner password is required.';
      errorBox.classList.remove('d-none');
    }
    passwordInput?.focus();
    return;
  }

  this.disabled = true;
  try {
    const result = await verifyDraftVoidPassword(password);
    if(result && result.ok && draftVoidTargetRow){
      if(draftVoidTargetRow === 'all'){
        clearRows();
      }else{
        draftVoidTargetRow.remove();
        if(!document.querySelector('#itemsTable tbody tr')) addRow();
        recalcAll();
      }
      renderPosTicket();
      if(modalEl && typeof bootstrap !== 'undefined'){
        bootstrap.Modal.getOrCreateInstance(modalEl).hide();
      }
      draftVoidTargetRow = null;
      return;
    }

    if(errorBox){
      errorBox.textContent = result?.message || 'Owner password is incorrect.';
      errorBox.classList.remove('d-none');
    }
    passwordInput?.focus();
  } catch (e) {
    if(errorBox){
      errorBox.textContent = e instanceof Error
        ? e.message
        : 'Unable to verify owner password. Please try again.';
      errorBox.classList.remove('d-none');
    }
  } finally {
    this.disabled = false;
  }
});

function formatISODate(y, m, d){
  const mm = String(m).padStart(2,'0');
  const dd = String(d).padStart(2,'0');
  return `${y}-${mm}-${dd}`;
}

function computeDueDateClient(days){
  const n = Number(days || 15);
  const due = new Date();
  due.setDate(due.getDate() + n);
  return formatISODate(due.getFullYear(), due.getMonth() + 1, due.getDate());
}

function toggleDueDate(){
  const t = document.getElementById('sale_type').value;
  const termsWrap = document.getElementById('termDaysWrap');
  const wrap = document.getElementById('dueDateWrap');
  const paymentWrap = document.getElementById('paymentMethodWrap');
  const customerWrap = document.getElementById('customerInfoWrap');
  const customerInput = document.getElementById('customer_id');
  const addCustomerMenuBtn = document.getElementById('addCustomerMenuBtn');

  if(customerWrap) customerWrap.classList.toggle('d-none', t !== 'utang');
  if(addCustomerMenuBtn) addCustomerMenuBtn.classList.toggle('d-none', t !== 'utang');

  if(customerInput && t !== 'utang'){
    customerInput.value = '';
    updateSelectedCustomerDisplay('', '', '', 0, 0);
  }

  termsWrap.classList.toggle('d-none', t !== 'utang');
  wrap.classList.toggle('d-none', t !== 'utang');
  if(paymentWrap) paymentWrap.classList.toggle('d-none', t === 'utang');

  if(t === 'utang'){
    const terms = Number(document.getElementById('term_days')?.value || 15);
    const due = computeDueDateClient(terms);
    const dueInput = document.getElementById('dueDateText');
    if(dueInput) dueInput.value = due;
  } else {
    const dueInput = document.getElementById('dueDateText');
    if(dueInput) dueInput.value = "—";
  }

  togglePaymentFields();
  ensureOptionsVisibility();
}

function updateSelectedCustomerDisplay(id, name, phone, balance, docs){
  const input = document.getElementById('customer_id');
  const display = document.getElementById('selectedCustomerDisplay');

  if(input){
    input.value = id || '';
    input.dataset.openBalance = String(balance || 0);
    input.dataset.openDocs = String(docs || 0);
  }

  if(display){
    if(id && name){
      const phoneText = phone ? ` • ${phone}` : '';
      display.className = 'form-control bg-light';
      display.innerHTML = `<i class="fa-solid fa-user-check text-success me-2"></i><strong>${escapeHtml(name)}</strong><span class="text-muted">${escapeHtml(phoneText)}</span>`;
    }else{
      display.className = 'form-control bg-light text-muted';
      display.innerHTML = '<i class="fa-regular fa-user me-2"></i>No customer selected';
    }
  }

  updateCustomerBalanceHint();
}

function escapeHtml(value){
  return String(value ?? '').replace(/[&<>"']/g, (char) => ({
    '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#039;'
  }[char]));
}

function selectCustomerFromPicker(button){
  if(!button) return;

  updateSelectedCustomerDisplay(
    button.dataset.customerId || '',
    button.dataset.customerName || '',
    button.dataset.customerPhone || '',
    Number(button.dataset.openBalance || 0),
    Number(button.dataset.openDocs || 0)
  );

  const modal = document.getElementById('customerPickerModal');
  if(modal && typeof bootstrap !== 'undefined'){
    bootstrap.Modal.getOrCreateInstance(modal).hide();
  }
}

function initCustomerPicker(){
  document.querySelectorAll('.customer-picker-option').forEach((button) => {
    button.addEventListener('click', () => selectCustomerFromPicker(button));
  });

  const search = document.getElementById('customerPickerSearch');
  const empty = document.getElementById('customerPickerEmpty');

  search?.addEventListener('input', function(){
    const q = String(this.value || '').trim().toLowerCase();
    let visible = 0;

    document.querySelectorAll('.customer-picker-option').forEach((button) => {
      const haystack = [
        button.dataset.customerName || '',
        button.dataset.customerPhone || ''
      ].join(' ').toLowerCase();

      const show = !q || haystack.includes(q);
      button.classList.toggle('d-none', !show);
      if(show) visible++;
    });

    empty?.classList.toggle('d-none', visible !== 0);
  });
}

function togglePaymentFields(){
  const saleType = document.getElementById('sale_type')?.value || 'cash';
  const method = document.getElementById('payment_method')?.value || 'cash';
  const cashWrap = document.getElementById('cashReceivedWrap');
  const refWrap = document.getElementById('paymentRefWrap');

  if(cashWrap) cashWrap.classList.toggle('d-none', saleType === 'utang' || method !== 'cash');
  if(refWrap) refWrap.classList.toggle('d-none', saleType === 'utang' || method === 'cash');

  updateCashReceivedRequirement();
  updatePaymentPreview();
  ensureOptionsVisibility();
}

function updateCashReceivedRequirement(){
  const saleType = document.getElementById('sale_type')?.value || 'cash';
  const method = document.getElementById('payment_method')?.value || 'cash';
  const cashInput = document.getElementById('cash_received');
  const cashError = document.getElementById('cashReceivedError');
  if(!cashInput) return;

  const required = saleType !== 'utang' && method === 'cash';
  cashInput.required = required;
  cashInput.min = required ? '0.01' : '0';
  cashInput.placeholder = 'Enter cash received';
  if(cashError){
    cashError.classList.toggle('d-none', true);
    cashError.textContent = 'Cash received is required for cash payments.';
  }

  if(!required){
    cashInput.value = '';
  }
}

function updatePaymentPreview(){
  const total = Number((document.getElementById('grandTotal')?.innerText || '0').replace(/,/g, '')) || 0;
  const cashInput = document.getElementById('cash_received');
  const cash = Number(cashInput?.value || 0);
  const change = Math.max(0, cash - total);
  const changeEl = document.getElementById('confirmChange');
  if(changeEl) changeEl.textContent = peso(change);
}

function updateCustomerBalanceHint(){
  const input = document.getElementById('customer_id');
  const hint = document.getElementById('customerBalanceHint');
  if(!input || !hint) return;

  if(!input.value){
    hint.className = 'small mt-1';
    hint.innerHTML = '';
    return;
  }

  const bal = Number(input.dataset.openBalance || 0);
  const docs = Number(input.dataset.openDocs || 0);

  if(bal > 0){
    hint.className = 'small mt-1 text-danger';
    hint.innerHTML = `Current open utang: <b>₱${peso(bal)}</b> across <b>${docs}</b> document(s).`;
  } else {
    hint.className = 'small mt-1 text-success';
    hint.innerHTML = 'No open utang for this customer.';
  }
}

function canProceedToCheckout(){
  const saleType = document.getElementById('sale_type')?.value || 'cash';
  const method = document.getElementById('payment_method')?.value || 'cash';
  const totalText = document.getElementById('grandTotal')?.innerText || '0.00';
  const total = Number(String(totalText).replace(/,/g, '')) || 0;
  const cashInput = document.getElementById('cash_received');
  const cashValue = String(cashInput?.value ?? '').trim();
  const activeLines = Array.from(document.querySelectorAll('#itemsTable tbody tr')).filter((tr) => {
    return Number(tr.querySelector('select[name="product_id[]"]')?.value || 0) > 0 &&
      Number(tr.querySelector('input[name="qty[]"]')?.value || 0) > 0;
  });

  if(activeLines.length === 0){
    alert('Please add at least one item before checkout.');
    return false;
  }

  if(total <= 0){
    alert('Total amount must be greater than zero before checkout.');
    return false;
  }

  if(saleType !== 'utang' && method === 'cash' && cashValue === ''){
    const cashError = document.getElementById('cashReceivedError');
    if(cashError){
      cashError.textContent = 'Cash received is required for cash payments.';
      cashError.classList.remove('d-none');
    }
    alert('Cash received is required for cash payments.');
    cashInput?.focus();
    return false;
  }

  const cashError = document.getElementById('cashReceivedError');
  if(cashError){
    cashError.classList.add('d-none');
  }

  if(saleType === 'utang'){
    const customerInput = document.getElementById('customer_id');
    if(!customerInput?.value){
      alert('Please choose a registered customer for utang.');
      document.getElementById('addCustomerMenuBtn')?.focus();
      return false;
    }
  }

  return true;
}

function toggleDiscountFields(){
  const dt = document.getElementById('discount_type').value;
  const fields = document.getElementById('discountFields');
  const customWrap = document.getElementById('customDiscountWrap');
  const showFields = dt === 'pwd' || dt === 'sc' || dt === 'others';

  fields.classList.toggle('d-none', !showFields);
  customWrap?.classList.toggle('d-none', dt !== 'others');

  ensureOptionsVisibility();
}

function ensureOptionsVisibility(){
  const optionsEl = document.getElementById('saleOptions');
  if(!optionsEl || typeof bootstrap === 'undefined') return;

  const need =
    !document.getElementById('termDaysWrap')?.classList.contains('d-none') ||
    !document.getElementById('dueDateWrap')?.classList.contains('d-none') ||
    !document.getElementById('discountFields')?.classList.contains('d-none');

  const inst = bootstrap.Collapse.getOrCreateInstance(optionsEl, { toggle: false });
  if(need){
    inst.show();
  }else{
    inst.hide();
  }
}

function clearRows(){
  const tbody = document.querySelector('#itemsTable tbody');
  if(!tbody) return;
  tbody.innerHTML = '';
  addRow();
  recalcAll();
}

function clearCurrentOrder(){
  const tbody = document.querySelector('#itemsTable tbody');
  if(!tbody) return;
  const hasAnyData = Array.from(tbody.querySelectorAll('tr')).some((tr) => {
    return Number(tr.querySelector('select[name="product_id[]"]')?.value || 0) > 0 ||
      Number(tr.querySelector('input[name="qty[]"]')?.value || 0) > 0;
  });
  if(!hasAnyData) return;
  if(!window.confirm('Clear all items from the current order?')) return;
  clearRows();
  renderPosTicket();
}

function addRow(){
  const tbody = document.querySelector('#itemsTable tbody');
  const tr = document.createElement('tr');

  // Keep product and batch values in the form for checkout, but don't show a Product column.
  const tdData = document.createElement('td');
  tdData.className = 'd-none';
  const sel = document.createElement('select');
  sel.name = "product_id[]";
  sel.className = "d-none prod-select";
  sel.required = false; // Products are added from the product tile grid.

  sel.innerHTML = `<option value="">Select product</option>` + getVisibleProducts().map(p => {
    const tag = productLabel(p);
    return `<option value="${p.product_id}"
      data-stock="${p.stock_kg}"
      data-dstock="${p.discounted_kg || 0}"
      data-w="${p.unit_weight_kg}"
      data-pkg="${p.price_per_kg}"
      data-psack="${p.price_per_sack}"
      data-dpkg="${p.discounted_price_per_kg || 0}"
    >${tag}</option>`;
  }).join('');

  tdData.appendChild(sel);

  const batchSel = document.createElement('select');
  batchSel.name = "batch_id[]";
  batchSel.className = "d-none batch-select";
  batchSel.required = false;
  batchSel.innerHTML = `<option value="">Select batch</option>`;
  batchSel.onchange = () => fillRow(tr);
  tdData.appendChild(batchSel);

  const tdStock = document.createElement('td');
  tdStock.setAttribute('data-label', 'Stock Left');
  tdStock.innerHTML = `<span class="badge bg-secondary stock-pill">0 sack(s)</span>`;

  const tdType = document.createElement('td');
  tdType.setAttribute('data-label', 'Type');
  const stockTypeInput = document.createElement('input');
  stockTypeInput.type = 'hidden';
  stockTypeInput.name = 'stock_type[]';
  stockTypeInput.value = 'regular';
  tdType.appendChild(stockTypeInput);
  const typeBadge = document.createElement('span');
  typeBadge.className = 'badge text-bg-secondary stock-type-badge';
  typeBadge.textContent = 'Choose product';
  tdType.appendChild(typeBadge);

  const tdUnit = document.createElement('td');
  tdUnit.setAttribute('data-label', 'Unit');
  const unitSel = document.createElement('select');
  unitSel.name = "unit_type[]";
  unitSel.className = "form-select form-select-sm unit-select";
  unitSel.innerHTML = `
    <option value="kg">Per Kilo</option>
    <option value="sack">Per Sack</option>
  `;
  unitSel.onchange = () => unitChanged(tr);
  tdUnit.appendChild(unitSel);

  // Keep the submitted quantity alongside the row; the visible editor is in the ticket.
  const qty = document.createElement('input');
  qty.type = 'hidden';
  qty.name = 'qty[]';
  qty.className = 'qty-input';
  qty.value = '1';
  tdUnit.appendChild(qty);

  tr.appendChild(tdData);
  tr.appendChild(tdStock);
  tr.appendChild(tdType);
  tr.appendChild(tdUnit);

  tbody.appendChild(tr);

  unitChanged(tr);
  setTimeout(() => {
    const activeQty = tr.querySelector('input[name="qty[]"]');
    if(activeQty && !activeQty.value) activeQty.value = '1';
    recalc(tr);
  }, 0);
}

function refreshProductSelects(){
  const rows = Array.from(document.querySelectorAll('#itemsTable tbody tr'));
  rows.forEach((tr) => {
    const sel = tr.querySelector('select[name="product_id[]"]');
    const current = sel?.value || '';
    if (!sel) return;

    sel.innerHTML = `<option value="">Select product</option>` + getVisibleProducts().map(p => {
      const tag = `${p.variety} - ${p.grade} (${peso(p.unit_weight_kg)}kg/sack)`;
      return `<option value="${p.product_id}"
        data-stock="${p.stock_kg}"
        data-dstock="${p.discounted_kg || 0}"
        data-w="${p.unit_weight_kg}"
        data-pkg="${p.price_per_kg}"
        data-psack="${p.price_per_sack}"
        data-dpkg="${p.discounted_price_per_kg || 0}"
      >${tag}</option>`;
    }).join('');

    if (current && Array.from(sel.options).some(o => o.value === current)) {
      sel.value = current;
    }
    fillRow(tr);
  });
}

function applyQuickSack(tr, sacks){
  const unitSel = tr.querySelector('select[name="unit_type[]"]');
  const qtyInput = tr.querySelector('input[name="qty[]"]');
  if(!unitSel || !qtyInput) return;
  unitSel.value = 'sack';
  unitChanged(tr);
  const current = Number(qtyInput.value || 0);
  qtyInput.value = current + Number(sacks || 0);
  recalc(tr);
}

function duplicateRow(tr){
  const tbody = document.querySelector('#itemsTable tbody');
  if(!tbody || !tr) return;
  const clone = tr.cloneNode(true);
  const sourceControls = tr.querySelectorAll('input, select, textarea');
  const clonedControls = clone.querySelectorAll('input, select, textarea');
  sourceControls.forEach((source, index) => {
    const target = clonedControls[index];
    if(!target) return;
    if(source instanceof HTMLInputElement && target instanceof HTMLInputElement){
      target.value = source.value;
      target.checked = source.checked;
    } else if(source instanceof HTMLSelectElement && target instanceof HTMLSelectElement){
      target.value = source.value;
    } else if(source instanceof HTMLTextAreaElement && target instanceof HTMLTextAreaElement){
      target.value = source.value;
    }
  });

  tbody.appendChild(clone);

  const sel = clone.querySelector('select[name="product_id[]"]');
  const productInput = clone.querySelector('input.product-picker');
  const suggestionBox = clone.querySelector('.product-suggestions');
  const batchSel = clone.querySelector('select[name="batch_id[]"]');
  const unitSel = clone.querySelector('select[name="unit_type[]"]');
  const removeBtn = clone.querySelector('.action-remove');
  const dupBtn = clone.querySelector('.action-dup');

  if(sel) sel.onchange = () => fillRow(clone);
  if(productInput){
    productInput.oninput = () => syncProductFromInput(clone);
    productInput.onfocus = () => showProductSuggestions(clone);
    productInput.onblur = () => setTimeout(() => hideProductSuggestions(clone), 120);
  }
  if(suggestionBox){
    suggestionBox.onmousedown = (e) => e.preventDefault();
  }
  if(batchSel) batchSel.onchange = () => fillRow(clone);
  if(unitSel) unitSel.onchange = () => unitChanged(clone);
  if(removeBtn) removeBtn.onclick = () => openDraftVoidConfirmation(clone);
  if(dupBtn) dupBtn.onclick = () => duplicateRow(clone);

  fillRow(clone);
}

function fillRow(tr){
  const sel = tr.querySelector('select[name="product_id[]"]');
  const opt = sel?.options?.[sel.selectedIndex];

  if(!sel || !opt || !sel.value){
    const typeBadge = tr.querySelector('.stock-type-badge');
    if(typeBadge){
      typeBadge.textContent = 'Choose product';
      typeBadge.className = 'badge text-bg-secondary stock-type-badge';
    }
    const tdStock = tr.children[1];
    if(tdStock){
      tdStock.innerHTML = `<span class="badge bg-secondary stock-pill">Choose a product tile</span>`;
    }

    const batchSel = tr.querySelector('select[name="batch_id[]"]');
    if(batchSel){
      batchSel.innerHTML = `<option value="">Select batch</option>`;
      batchSel.value = '';
    }

    recalc(tr);
    return;
  }

  updateBatchOptions(tr);
  const batch = getSelectedBatch(tr);
  const product = getProductById(sel.value);
  markProductTileSelected(sel.value);

  const stock = Number(opt.getAttribute('data-stock') || 0);
  const dstock = Number(opt.getAttribute('data-dstock') || 0);
  const w = Number(opt.getAttribute('data-w') || 0);
  const regularStock = Math.max(0, stock - dstock);
  const stockType = tr.querySelector('input[name="stock_type[]"]')?.value || 'regular';
  const batchAvailable = batch
    ? (stockType === 'discounted' ? Number(batch.discounted_qty_kg || 0) : Number(batch.regular_qty_kg || 0))
    : 0;
  const batchDate = batch?.arrived_at ? new Date(batch.arrived_at).toLocaleDateString() : 'Date unavailable';
  const batchLabel = batch
    ? `<div class="small text-dark mt-1">${htmlText(batch.batch_code)} · Delivered ${htmlText(batchDate)} · ${sackSummary(batchAvailable, batch.unit_weight_kg || w)}</div>`
    : `<div class="small text-danger mt-1">Select batch</div>`;

  let cls = 'bg-secondary';
  if(stock > 0 && stock < 30) cls = 'bg-warning text-dark';
  if(stock >= 30) cls = 'bg-info text-dark';

  tr.children[1].innerHTML =
    `<span class="badge ${cls} stock-pill">Total: ${sackSummary(stock, w)}</span>` +
    `<div class="small text-muted mt-1">Regular: ${sackSummary(regularStock, w)}</div>` +
    `<div class="small text-muted">Discounted: ${sackSummary(dstock, w)}</div>` +
    batchLabel;

  updateActiveProductSummary(product);

  recalc(tr);
}

function updateActiveProductSummary(product = null){
  const rows = Array.from(document.querySelectorAll('#itemsTable tbody tr'));
  const activeRow = rows.slice().reverse().find((row) => Number(row.querySelector('select[name="product_id[]"]')?.value || 0) > 0);
  const picked = product || getRowProduct(activeRow);
  const name = document.getElementById('activeProductName');
  const detail = document.getElementById('activeProductDetail');
  const count = document.getElementById('activeProductQty');
  if(name) name.textContent = picked ? productLabel(picked) : 'Choose a rice tile to start';
  if(detail) detail.textContent = picked
    ? `${sackSummary(picked.stock_kg, picked.unit_weight_kg)} available · ${picked.unit_weight_kg} kg per sack`
    : 'Available stock and price will appear here.';
  const qty = Number(activeRow?.querySelector('input[name="qty[]"]')?.value || 0);
  const unit = activeRow?.querySelector('select[name="unit_type[]"]')?.value || 'kg';
  if(count) count.textContent = picked ? `${peso(qty)} ${unit === 'sack' ? 'sack(s)' : 'kg'}` : '0 items';
}

function markProductTileSelected(productId){
  document.querySelectorAll('.pos-product-tile').forEach((tile) => {
    const selected = Number(tile.dataset.productId || 0) === Number(productId || 0);
    tile.classList.toggle('is-selected', selected);
    tile.setAttribute('aria-pressed', selected ? 'true' : 'false');
  });
}

function unitChanged(tr){
  const unitSel = tr.querySelector('select[name="unit_type[]"]');
  const unit = unitSel.value;

  const qtyInput = tr.querySelector('input[name="qty[]"]');
  const quick = tr.querySelector('.qty-quick');
  if(quick) quick.classList.toggle('d-none', unit !== 'sack');

  if(unit === 'sack'){
    qtyInput.step = "1";
    qtyInput.placeholder = "0";
  } else {
    qtyInput.step = "0.01";
    qtyInput.placeholder = "0.00";
  }

  updateBatchOptions(tr);
  recalc(tr);
}

function recalc(tr){
  tr.classList.remove('table-danger');

  const qty = Number(tr.querySelector('input[name="qty[]"]').value || 0);
  const unit = tr.querySelector('select[name="unit_type[]"]').value;
  const stockType = tr.querySelector('input[name="stock_type[]"]').value;
  const prodSel = tr.querySelector('select[name="product_id[]"]');
  const opt = prodSel?.options?.[prodSel.selectedIndex];
  const batch = getSelectedBatch(tr);

  if(!prodSel || !prodSel.value || !opt){
    tr.dataset.lineTotal = '0.00';
    tr.dataset.deductKg = '0.00';
    recalcAll();
    return;
  }

  const stock = Number(opt?.getAttribute('data-stock') || 0);
  const dstock = Number(opt?.getAttribute('data-dstock') || 0);
  const w = Number(batch?.unit_weight_kg || opt?.getAttribute('data-w') || 0);
  const pKg = Number(batch?.regular_price_per_kg || opt?.getAttribute('data-pkg') || 0);
  const dPkg = Number(batch?.discounted_price_per_kg || opt?.getAttribute('data-dpkg') || 0);

  const regularStock = batch ? Number(batch.regular_qty_kg || 0) : Math.max(0, stock - dstock);
  const discountedStock = batch ? Number(batch.discounted_qty_kg || 0) : dstock;
  const requiredKg = (unit === 'sack') ? (qty * w) : qty;

  let line = 0;
  let available = 0;

  if(stockType === 'discounted'){
    available = discountedStock;
    line = requiredKg * dPkg;
  } else {
    available = regularStock;
    line = requiredKg * pKg;
  }

  tr.dataset.lineTotal = line.toFixed(2);
  tr.dataset.deductKg = requiredKg.toFixed(2);

  if(requiredKg > available || (qty > 0 && !batch)){
    tr.classList.add('table-danger');
  }

  updateActiveProductSummary(getProductById(prodSel.value));

  recalcAll();
}

function recalcAll(){
  let subtotal = 0;
  let hasStockError = false;
  let hasAnyRow = false;
  let activeLines = 0;

  document.querySelectorAll('#itemsTable tbody tr').forEach(tr => {
    const pid = Number(tr.querySelector('select[name="product_id[]"]').value || 0);
    const qty = Number(tr.querySelector('input[name="qty[]"]').value || 0);
    const unit = tr.querySelector('select[name="unit_type[]"]').value;
    const stockType = tr.querySelector('input[name="stock_type[]"]').value;
    const prodSel = tr.querySelector('select[name="product_id[]"]');
    const opt = prodSel.options[prodSel.selectedIndex];
    const batch = getSelectedBatch(tr);

    const regularStock = batch ? Number(batch.regular_qty_kg || 0) : 0;
    const discountedStock = batch ? Number(batch.discounted_qty_kg || 0) : 0;
    const w = Number(batch?.unit_weight_kg || opt?.getAttribute('data-w') || 0);
    const pKg = Number(batch?.regular_price_per_kg || opt?.getAttribute('data-pkg') || 0);
    const dPkg = Number(batch?.discounted_price_per_kg || opt?.getAttribute('data-dpkg') || 0);

    const requiredKg = (unit === 'sack') ? (qty * w) : qty;

    let line = 0;
    let available = 0;

    if(stockType === 'discounted'){
      available = discountedStock;
      line = requiredKg * dPkg;
    } else {
      available = regularStock;
      line = requiredKg * pKg;
    }

    if(pid > 0 && qty > 0) hasAnyRow = true;
    if(pid > 0 && qty > 0) activeLines++;
    if(pid > 0 && qty > 0 && (!batch || requiredKg > available)) hasStockError = true;

    subtotal += line;
  });

  const dt = document.getElementById('discount_type').value;
  const customInput = document.getElementById('discount_percent');
  let rate = 0.0;

  if(dt === 'pwd' || dt === 'sc'){
    rate = 0.05;
  } else if(dt === 'others'){
    const custom = Number(customInput?.value || 0);
    rate = Number.isFinite(custom) ? Math.max(0, Math.min(custom / 100, 1)) : 0;
  }

  const disc = +(subtotal * rate).toFixed(2);
  const net  = Math.max(0, +(subtotal - disc).toFixed(2));

  document.getElementById('subTotal').innerText = peso(subtotal);
  document.getElementById('discountAmt').innerText = peso(disc);
  document.getElementById('grandTotal').innerText = peso(net);

  const warn = document.getElementById('stockWarningBox');
  const checkoutBtn = document.getElementById('checkoutBtn');
  const checkoutProxyBtn = document.getElementById('checkoutProxyBtn');
  const lineBadge = document.getElementById('lineCountBadge');

  if(hasStockError){
    warn.classList.remove('d-none');
    warn.innerText = "Some rows exceed available selected stock type. Adjust quantity before checkout.";
  } else {
    warn.classList.add('d-none');
    warn.innerText = "";
  }

  if(checkoutBtn){
    checkoutBtn.disabled = hasStockError || !hasAnyRow || net <= 0;
  }
  if(checkoutProxyBtn){
    checkoutProxyBtn.disabled = hasStockError || !hasAnyRow || net <= 0;
  }
  if(lineBadge){
    lineBadge.textContent = `${activeLines} line(s)`;
  }
  updatePaymentPreview();
  renderPosTicket();
  syncSummaryVisibility();
}

addRow();
initCustomerPicker();

const initialCustomerId = document.getElementById('customer_id')?.value || '';
if(initialCustomerId){
  const initialCustomerButton = document.querySelector(
    `.customer-picker-option[data-customer-id="${CSS.escape(initialCustomerId)}"]`
  );
  if(initialCustomerButton){
    updateSelectedCustomerDisplay(
      initialCustomerButton.dataset.customerId || '',
      initialCustomerButton.dataset.customerName || '',
      initialCustomerButton.dataset.customerPhone || '',
      Number(initialCustomerButton.dataset.openBalance || 0),
      Number(initialCustomerButton.dataset.openDocs || 0)
    );
  }
}

toggleDueDate();
toggleDiscountFields();
updateCashReceivedRequirement();
recalcAll();
updateCustomerBalanceHint();
ensureOptionsVisibility();

function renderProductTiles(filterText = ''){
  const grid = document.getElementById('productTileGrid');
  if(!grid) return;
  const typed = normalizeProductText(filterText);
  const items = getPrioritizedProducts().filter((p) => {
    if(!typed) return true;
    return normalizeProductText(productLabel(p)).includes(typed) ||
      normalizeProductText(p.variety).includes(typed) ||
      normalizeProductText(p.grade).includes(typed);
  });

  if(!items.length){
    grid.innerHTML = '<div class="text-muted small py-3">No products match your search.</div>';
    return;
  }

  items.sort((a, b) => {
    const aTime = getOldestBatchTime(a);
    const bTime = getOldestBatchTime(b);
    if(aTime < bTime) return -1;
    if(aTime > bTime) return 1;
    return normalizeProductText(productLabel(a)).localeCompare(normalizeProductText(productLabel(b)));
  });

  grid.innerHTML = items.map((p) => {
    const stock = Number(p.stock_kg || 0);
    const stockText = sackSummary(stock, p.unit_weight_kg);
    const hasLooseStock = stockText.includes(' + ');
    const badge = stock <= 0 ? 'bg-danger' : (stock < 30 ? 'bg-warning text-dark' : 'bg-success');
    return `
      <button type="button" class="pos-product-tile ${stock <= 0 ? 'pos-empty-stock' : ''}" data-product-id="${p.product_id}" ${stock <= 0 ? 'disabled' : ''} aria-label="Add ${htmlText(productLabel(p))}, ${peso(stock)} kilograms available">
        <div class="tile-code">${peso(p.unit_weight_kg)} kg sack</div>
        <div class="tile-name">${htmlText(tileLabel(p))}</div>
        <div class="tile-price">${htmlText(productTilePrice(p))}</div>
        <div class="tile-stock ${badge}">${htmlText(stockText)}${hasLooseStock ? '' : ' available'}</div>
      </button>
    `;
  }).join('');

  grid.querySelectorAll('.pos-product-tile').forEach((btn) => {
    btn.addEventListener('click', function(){
      const pid = this.getAttribute('data-product-id');
      let tr = Array.from(document.querySelectorAll('#itemsTable tbody tr')).find((row) => {
        return Number(row.querySelector('select[name="product_id[]"]')?.value || 0) === Number(pid);
      });
      let isNewLine = false;
      if(tr){
        const qtyInput = tr.querySelector('input[name="qty[]"]');
        const unit = tr.querySelector('select[name="unit_type[]"]')?.value || 'kg';
        if(qtyInput) qtyInput.value = String((Number(qtyInput.value || 0) + 1).toFixed(unit === 'sack' ? 0 : 2));
      } else {
        tr = document.querySelector('#itemsTable tbody tr:last-child');
        if(!tr || tr.querySelector('select[name="product_id[]"]')?.value){
          addRow();
          tr = document.querySelector('#itemsTable tbody tr:last-child');
        }
        isNewLine = true;
      }
      const match = getProductById(pid);
      if(tr && match){
        selectProductFromSuggestion(tr, pid);
        const qtyInput = tr.querySelector('input[name="qty[]"]');
        const unitSel = tr.querySelector('select[name="unit_type[]"]');
        if(isNewLine && unitSel && qtyInput){
          const defaultUnit = Number(match.unit_weight_kg) > 0 ? 'sack' : 'kg';
          unitSel.value = defaultUnit;
          qtyInput.value = defaultUnit === 'sack' ? '1' : '1.00';
          unitChanged(tr);
        }
        tr.classList.add('row-flash');
        setTimeout(() => tr.classList.remove('row-flash'), 700);
        fillRow(tr);
        recalc(tr);
        renderPosTicket();
      }
    });
  });
}

function syncSummaryVisibility(){
  const panel = document.getElementById('posSummaryPanel');
  panel?.classList.remove('is-hidden');
}

function renderPosTicket(){
  const body = document.getElementById('posTicketBody');
  if(!body) return;
  const rows = Array.from(document.querySelectorAll('#itemsTable tbody tr')).filter((tr) => {
    return Number(tr.querySelector('select[name="product_id[]"]')?.value || 0) > 0 &&
      Number(tr.querySelector('input[name="qty[]"]')?.value || 0) > 0;
  });
  if(!rows.length){
    body.innerHTML = '<tr><td colspan="4" class="text-center text-muted py-4">Tap a rice tile to add items</td></tr>';
    return;
  }
  body.innerHTML = rows.map((tr, index) => {
    const productId = tr.querySelector('select[name="product_id[]"]')?.value || '';
    const product = getProductById(productId);
    const unit = tr.querySelector('select[name="unit_type[]"]')?.value || 'kg';
    const qty = Number(tr.querySelector('input[name="qty[]"]')?.value || 0);
    const batch = getSelectedBatch(tr);
    const type = tr.querySelector('input[name="stock_type[]"]')?.value || 'regular';
    const line = `₱${peso(tr.dataset.lineTotal || 0)}`;
    const name = product ? productLabel(product) : 'Rice';
    const batchText = batch ? `${batch.batch_code} · ${type}` : 'Batch not available';
    return `<tr>
      <td><div class="pos-ticket-item">${htmlText(name)}</div><div class="pos-ticket-sub">${htmlText(batchText)}</div></td>
      <td><div class="ticket-qty-control">
        <button type="button" class="btn btn-sm btn-outline-secondary ticket-minus" data-row="${index}" aria-label="Decrease quantity">−</button>
        <input class="form-control form-control-sm" inputmode="decimal" value="${qty}" aria-label="Quantity" data-unit="${unit}" data-product-id="${productId}">
        <button type="button" class="btn btn-sm btn-outline-secondary ticket-plus" data-row="${index}" aria-label="Increase quantity">+</button>
      </div></td>
      <td class="text-end fw-bold text-nowrap">${htmlText(line)}</td>
      <td><div class="ticket-actions">
        <button type="button" class="ticket-duplicate" data-row="${index}" aria-label="Duplicate item" title="Duplicate item"><i class="fa-solid fa-copy"></i></button>
        <button type="button" class="ticket-remove" data-row="${index}" aria-label="Void item" title="Void item"><i class="fa-solid fa-ban"></i></button>
      </div></td>
    </tr>`;
  }).join('');

  body.querySelectorAll('.ticket-minus,.ticket-plus,.ticket-remove,.ticket-duplicate').forEach((button) => {
    button.addEventListener('click', () => {
      const tr = rows[Number(button.dataset.row)];
      if(!tr) return;
      if(button.classList.contains('ticket-duplicate')){
        duplicateRow(tr);
        return;
      }
      if(button.classList.contains('ticket-remove')){
        openDraftVoidConfirmation(tr);
        return;
      }
      const qtyInput = tr.querySelector('input[name="qty[]"]');
      const unit = tr.querySelector('select[name="unit_type[]"]')?.value || 'kg';
      const step = unit === 'sack' ? 1 : 0.25;
      const delta = button.classList.contains('ticket-plus') ? step : -step;
      const next = Math.max(0, Number(qtyInput.value || 0) + delta);
      if(next <= 0 && rows.length > 1) tr.remove();
      else qtyInput.value = String(next.toFixed(unit === 'sack' ? 0 : 2));
      if(!document.querySelector('#itemsTable tbody tr')) addRow();
      recalcAll();
      renderPosTicket();
    });
  });

  body.querySelectorAll('.ticket-qty-control input').forEach((input, index) => {
    input.addEventListener('focus', () => {
      const unit = input.dataset.unit || 'kg';
      const productId = input.dataset.productId || '';
      const row = rows.find((tr) => tr.querySelector('select[name="product_id[]"]')?.value === productId &&
        tr.querySelector('select[name="unit_type[]"]')?.value === unit);
      if(row){
        const type = row.querySelector('input[name="stock_type[]"]')?.value || 'regular';
        const batch = getSelectedBatch(row);
        const product = getProductById(productId);
        const unitWeight = Number(product?.unit_weight_kg || 0);
        const unitPrice = Number(type === 'discounted' ? batch?.discounted_price_per_kg : batch?.regular_price_per_kg) || 0;
        const displayPrice = unit === 'sack' ? unitPrice * unitWeight : unitPrice;
        const stock = type === 'discounted' ? Number(batch?.discounted_qty_kg || 0) : Number(batch?.regular_qty_kg || 0);
        input.closest('tr').querySelector('.pos-ticket-sub').textContent = `${batch?.batch_code || 'No batch'} · ${type} · ₱${peso(displayPrice)}/${unit} · ${sackSummary(stock, unitWeight)} available`;
      }
    });
    input.addEventListener('change', () => {
      const productId = input.dataset.productId || '';
      const unit = input.dataset.unit || 'kg';
      const tr = rows.find((candidate) => candidate.querySelector('select[name="product_id[]"]')?.value === productId &&
        candidate.querySelector('select[name="unit_type[]"]')?.value === unit) || rows[index];
      const source = tr?.querySelector('input[name="qty[]"]');
      if(!source) return;
      const rowUnit = tr.querySelector('select[name="unit_type[]"]')?.value || 'kg';
      source.value = String(Math.max(0, Number(input.value || 0)).toFixed(rowUnit === 'sack' ? 0 : 2));
      recalc(tr);
      renderPosTicket();
    });
  });
}

document.getElementById('productTileSearch')?.addEventListener('input', function(){
  renderProductTiles(this.value);
});

document.getElementById('productTileSearch')?.addEventListener('keydown', function(event){
  if(event.key !== 'Enter') return;
  const firstTile = document.querySelector('#productTileGrid .pos-product-tile:not(:disabled)');
  if(firstTile){ event.preventDefault(); firstTile.click(); }
});

renderProductTiles('');
syncSummaryVisibility();
updateActiveProductSummary();

window.syncSummaryVisibility = function(){
  const panel = document.getElementById('posSummaryPanel');
  panel?.classList.remove('is-hidden');
};

function openCheckoutConfirmation(){
  const btn = document.getElementById('checkoutBtn');
  if(!btn || btn.disabled) return;
  if(!canProceedToCheckout()) return;

  const saleType = document.getElementById('sale_type')?.value || 'cash';
  const method = document.getElementById('payment_method')?.value || 'cash';
  const customerInput = document.getElementById('customer_id');
  const selectedCustomerDisplay = document.getElementById('selectedCustomerDisplay');
  const customerText = saleType === 'utang'
    ? (selectedCustomerDisplay?.textContent?.trim() || '-')
    : 'Walk-in / Cash Sale';
  const subtotal = document.getElementById('subTotal')?.innerText || '0.00';
  const discount = document.getElementById('discountAmt')?.innerText || '0.00';
  const totalText = document.getElementById('grandTotal')?.innerText || '0.00';
  const total = Number(totalText.replace(/,/g, '')) || 0;
  const cashInput = document.getElementById('cash_received');
  const cashValue = String(cashInput?.value ?? '').trim();
  const cash = cashValue === '' ? 0 : Number(cashValue);
  const activeLines = Array.from(document.querySelectorAll('#itemsTable tbody tr')).filter((tr) => {
    return tr.querySelector('select[name="product_id[]"]')?.value && Number(tr.querySelector('input[name="qty[]"]')?.value || 0) > 0;
  });
  const activeLineCount = activeLines.length;

  if(saleType !== 'utang' && method === 'cash' && cashValue === ''){
    alert('Cash received is required for cash payments.');
    cashInput?.focus();
    return;
  }
  if(saleType !== 'utang' && method === 'cash' && cash > 0 && cash < total){
    alert('Cash received is less than the total amount.');
    return;
  }
  if(saleType === 'utang' && !customerInput?.value){
    alert('Please choose a registered customer for utang.');
    return;
  }

  const paymentLabel = saleType === 'utang'
    ? 'Utang'
    : (method === 'gcash' ? 'GCash' : (method === 'bank' ? 'Bank Transfer' : 'Cash'));
  const dueDateText = document.getElementById('dueDateText')?.value || '-';
  const paymentRef = document.getElementById('payment_external_ref')?.value?.trim() || '-';

  document.getElementById('confirmCustomer').textContent = customerText;
  document.getElementById('confirmSaleType').textContent = saleType === 'utang' ? 'Utang (Unpaid)' : 'Cash/Paid';
  document.getElementById('confirmPaymentMethod').textContent = paymentLabel;
  document.getElementById('confirmLines').textContent = `${activeLineCount} line(s)`;
  document.getElementById('confirmSubtotal').textContent = subtotal;
  document.getElementById('confirmDiscount').textContent = discount;
  document.getElementById('confirmTotal').textContent = totalText;
  document.getElementById('confirmBalance').textContent = saleType === 'utang' ? totalText : '0.00';

  const dueDateRow = document.getElementById('confirmDueDateRow');
  const balanceRow = document.getElementById('confirmBalanceRow');
  const refRow = document.getElementById('confirmPaymentRefRow');
  if(dueDateRow) dueDateRow.classList.toggle('d-none', saleType !== 'utang');
  if(balanceRow) balanceRow.classList.toggle('d-none', saleType !== 'utang');
  if(refRow) refRow.classList.toggle('d-none', saleType === 'utang' || method === 'cash');
  document.getElementById('confirmDueDate').textContent = dueDateText;
  document.getElementById('confirmPaymentRef').textContent = paymentRef;

  const itemsBody = document.getElementById('confirmItemsBody');
  if(itemsBody){
    itemsBody.innerHTML = '';
    activeLines.forEach((tr) => {
      const product = tr.querySelector('select[name="product_id[]"]')?.selectedOptions?.[0]?.textContent?.trim() || 'Item';
      const stockType = tr.querySelector('input[name="stock_type[]"]')?.value || 'regular';
      const deduct = `${peso(tr.dataset.deductKg || 0)} kg`;
      const line = `₱${peso(tr.dataset.lineTotal || 0)}`;
      const stockBadge = stockType === 'discounted'
        ? '<span class="checkout-item-type bg-warning text-dark">Discounted</span>'
        : '<span class="checkout-item-type">Regular</span>';
      const row = document.createElement('tr');
      row.innerHTML = `<td><div class="checkout-item-name">${product}</div>${stockBadge}</td><td class="text-end">${deduct}</td><td class="text-end fw-bold">${line}</td>`;
      itemsBody.appendChild(row);
    });
    if(activeLines.length === 0){
      itemsBody.innerHTML = '<tr><td colspan="3" class="text-center text-muted">No items</td></tr>';
    }
  }

  const cashBlock = document.getElementById('confirmCashBlock');
  if(cashBlock) cashBlock.classList.toggle('d-none', !(saleType !== 'utang' && method === 'cash' && cash > 0));
  document.getElementById('confirmCashReceived').textContent = peso(cash);
  document.getElementById('confirmChange').textContent = peso(Math.max(0, cash - total));
  const confirmTotalBadge = document.getElementById('confirmTotalBadge');
  if(confirmTotalBadge) confirmTotalBadge.textContent = `₱ ${totalText}`;

  const modalEl = document.getElementById('checkoutConfirmModal');
  if(modalEl && typeof bootstrap !== 'undefined'){
    bootstrap.Modal.getOrCreateInstance(modalEl).show();
  } else if(confirm('Confirm checkout and generate receipt?')){
    btn.click();
  }
}

document.getElementById('checkoutProxyBtn')?.addEventListener('click', openCheckoutConfirmation);

document.getElementById('confirmCheckoutBtn')?.addEventListener('click', function(event){
  const btn = document.getElementById('checkoutBtn');
  if(!canProceedToCheckout()){
    event.stopPropagation();
    return;
  }
  if(btn && !btn.disabled){
    btn.click();
  }
});

document.getElementById('cash_received')?.addEventListener('input', function(){
  const cashError = document.getElementById('cashReceivedError');
  if(cashError && String(this.value || '').trim() !== ''){
    cashError.classList.add('d-none');
  }
});

document.getElementById('allItemsModalSearch')?.addEventListener('input', function(){
  renderAllItemsModal(this.value);
});

document.getElementById('allItemsModal')?.addEventListener('hidden.bs.modal', function(){
  activeProductRow = null;
  const search = document.getElementById('allItemsModalSearch');
  if(search) search.value = '';
  const list = document.getElementById('allItemsModalList');
  if(list) list.innerHTML = '';
});

document.getElementById('recentSalesSearch')?.addEventListener('input', function(){
  const needle = String(this.value || '').toLowerCase().trim();
  document.querySelectorAll('.recent-sale-row').forEach((row) => {
    const hay = String(row.getAttribute('data-search') || '');
    row.classList.toggle('d-none', needle !== '' && !hay.includes(needle));
  });
});

document.querySelectorAll('.choose-receipt-btn').forEach((btn) => {
  btn.addEventListener('click', function(){
    const row = this.closest('.recent-sale-row');
    const saleId = row?.getAttribute('data-sale-id') || '';
    if(saleId){
      const input = document.getElementById('void_sale_id');
      if(input) input.value = saleId;
    }
    const recentModalEl = document.getElementById('recentSalesModal');
    if(recentModalEl && typeof bootstrap !== 'undefined'){
      bootstrap.Modal.getOrCreateInstance(recentModalEl).hide();
    }
  });
});

function pad2(n){ return String(n).padStart(2,'0'); }
function tickPosClock(){
  const now = new Date();
  const m = pad2(now.getMonth() + 1);
  const d = pad2(now.getDate());
  const y = now.getFullYear();
  const hh = pad2(now.getHours());
  const mm = pad2(now.getMinutes());
  const ss = pad2(now.getSeconds());
  const dateEl = document.getElementById('posDate');
  const timeEl = document.getElementById('posTime');
  if(dateEl) dateEl.textContent = `${m}-${d}-${y}`;
  if(timeEl) timeEl.textContent = `${hh}:${mm}:${ss}`;
}
tickPosClock();
setInterval(tickPosClock, 1000);
</script>

</body>
</html>
