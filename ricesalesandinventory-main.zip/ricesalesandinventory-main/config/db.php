<?php
$appTimezone = 'Asia/Manila';
date_default_timezone_set($appTimezone);

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "rice_inventory";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed");
}

// User controlled label shown in the shared account menu.
$conn->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS display_name VARCHAR(100) DEFAULT NULL");

// Keep database-generated timestamps aligned with the application's local time.
$conn->query("SET time_zone = '+08:00'");

$returnDateColumn = $conn->query("
    SELECT DATA_TYPE
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'returns'
      AND COLUMN_NAME = 'return_date'
    LIMIT 1
");
if ($returnDateColumn && ($returnDateColumn->fetch_assoc()['DATA_TYPE'] ?? '') !== 'datetime') {
    $conn->query("ALTER TABLE returns MODIFY COLUMN return_date DATETIME DEFAULT NULL");
}

$conn->query("
CREATE TABLE IF NOT EXISTS product_discount_stock (
  product_id INT(11) NOT NULL,
  qty_kg DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  price_per_kg DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
");

$conn->query("
CREATE TABLE IF NOT EXISTS stock_batches (
  batch_id INT(11) NOT NULL AUTO_INCREMENT,
  product_id INT(11) NOT NULL,
  batch_code VARCHAR(50) DEFAULT NULL,
  source_reference_id INT(11) DEFAULT NULL,
  source_reference_type VARCHAR(30) DEFAULT NULL,
  arrived_at DATE DEFAULT NULL,
  unit_weight_kg DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  initial_qty_kg DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  remaining_qty_kg DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  regular_qty_kg DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  discounted_qty_kg DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  cost_per_kg DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  regular_price_per_kg DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  discounted_price_per_kg DECIMAL(12,2) DEFAULT NULL,
  note VARCHAR(255) DEFAULT NULL,
  created_by INT(11) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (batch_id),
  KEY idx_batch_product_arrived (product_id, arrived_at),
  KEY idx_batch_remaining (product_id, remaining_qty_kg),
  KEY idx_batch_discounted (product_id, discounted_qty_kg)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
");

$batchColumnAdds = [
    'inventory_transactions' => "ALTER TABLE inventory_transactions ADD COLUMN batch_id INT(11) NULL AFTER product_id",
    'sales_items' => "ALTER TABLE sales_items ADD COLUMN batch_id INT(11) NULL AFTER product_id",
    'stock_condition' => "ALTER TABLE stock_condition ADD COLUMN batch_id INT(11) NULL AFTER product_id",
    'adjust_logs' => "ALTER TABLE adjust_logs ADD COLUMN batch_id INT(11) NULL AFTER product_id",
];

foreach ($batchColumnAdds as $table => $alterSql) {
    $tableEsc = $conn->real_escape_string($table);
    $colRes = $conn->query("
      SELECT 1
      FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '{$tableEsc}' AND COLUMN_NAME = 'batch_id'
      LIMIT 1
    ");
    if ($colRes && $colRes->num_rows === 0) {
        $conn->query($alterSql);
    }
}

$conn->query("
  ALTER TABLE adjust_logs
  MODIFY COLUMN adjust_type ENUM('add','damaged','unsellable','discounted','in','out') NOT NULL
");

$conn->query("
INSERT INTO stock_batches
  (product_id, batch_code, source_reference_id, source_reference_type, arrived_at, unit_weight_kg,
   initial_qty_kg, remaining_qty_kg, regular_qty_kg, discounted_qty_kg, cost_per_kg,
   regular_price_per_kg, discounted_price_per_kg, note, created_by, created_at, updated_at)
SELECT
  x.product_id,
  CONCAT('Batch ', x.product_id),
  NULL,
  'legacy',
  x.arrived_at,
  x.unit_weight_kg,
  x.stock_qty,
  x.stock_qty,
  GREATEST(x.stock_qty - x.discount_qty, 0),
  LEAST(x.discount_qty, x.stock_qty),
  x.cost_per_kg,
  x.regular_price_per_kg,
  CASE WHEN x.discount_qty > 0 THEN x.discount_price_per_kg ELSE NULL END,
  'Legacy stock balance before batch tracking',
  NULL,
  NOW(),
  NOW()
FROM (
  SELECT
    p.product_id,
    COALESCE(p.delivery_date, DATE(p.created_at), CURDATE()) AS arrived_at,
    IFNULL(p.unit_weight_kg, 0) AS unit_weight_kg,
    IFNULL(inv.stock_kg, 0) AS stock_qty,
    IFNULL(pds.qty_kg, 0) AS discount_qty,
    IFNULL(pds.price_per_kg, 0) AS discount_price_per_kg,
    CASE
      WHEN IFNULL(p.unit_weight_kg, 0) > 0 THEN IFNULL(p.price_per_sack, 0) / p.unit_weight_kg
      ELSE IFNULL(p.price_per_kg, 0)
    END AS cost_per_kg,
    IFNULL(p.price_per_kg, 0) AS regular_price_per_kg
  FROM products p
  LEFT JOIN (
    SELECT
      product_id,
      IFNULL(SUM(
        CASE
          WHEN LOWER(type) = 'in' THEN qty_kg
          WHEN LOWER(type) = 'out' THEN -qty_kg
          WHEN LOWER(type) = 'adjust' THEN qty_kg
          ELSE 0
        END
      ), 0) AS stock_kg
    FROM inventory_transactions
    GROUP BY product_id
  ) inv ON inv.product_id = p.product_id
  LEFT JOIN product_discount_stock pds ON pds.product_id = p.product_id
) x
WHERE x.stock_qty > 0
  AND NOT EXISTS (
    SELECT 1 FROM stock_batches sb WHERE sb.product_id = x.product_id LIMIT 1
  )
");

$conn->query("
CREATE TABLE IF NOT EXISTS user_notif_state (
  user_id INT(11) NOT NULL,
  last_seen_push_notif_id INT(11) NOT NULL DEFAULT 0,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
");

$resetTokenCols = [
    'reset_token' => "ALTER TABLE users ADD COLUMN reset_token VARCHAR(255) NULL AFTER password",
    'reset_token_expires_at' => "ALTER TABLE users ADD COLUMN reset_token_expires_at DATETIME NULL AFTER reset_token",
];

foreach ($resetTokenCols as $col => $alterSql) {
    $colEsc = $conn->real_escape_string($col);
    $colRes = $conn->query("
      SELECT 1
      FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = '{$colEsc}'
      LIMIT 1
    ");
    if (!$colRes || $colRes->num_rows === 0) {
        $conn->query($alterSql);
    }
}

$dbNameRes = $conn->query("SELECT DATABASE() AS dbname");
$dbName = $dbNameRes ? (string)($dbNameRes->fetch_assoc()['dbname'] ?? '') : '';
$dbNameEsc = $conn->real_escape_string($dbName);
$purchaseTableRes = $conn->query("
  SELECT 1
  FROM information_schema.TABLES
  WHERE TABLE_SCHEMA = '{$dbNameEsc}' AND TABLE_NAME = 'purchases'
  LIMIT 1
");
if ($purchaseTableRes && $purchaseTableRes->num_rows > 0) {
    $purchaseApprovalCols = [
        'po_approved' => "ALTER TABLE purchases ADD COLUMN po_approved TINYINT(1) NOT NULL DEFAULT 0 AFTER status",
        'po_approved_by' => "ALTER TABLE purchases ADD COLUMN po_approved_by INT NULL AFTER po_approved",
        'po_approved_at' => "ALTER TABLE purchases ADD COLUMN po_approved_at DATETIME NULL AFTER po_approved_by",
    ];

    foreach ($purchaseApprovalCols as $col => $alterSql) {
        $colEsc = $conn->real_escape_string($col);
        $colRes = $conn->query("
          SELECT 1
          FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = '{$dbNameEsc}' AND TABLE_NAME = 'purchases' AND COLUMN_NAME = '{$colEsc}'
          LIMIT 1
        ");
        if (!$colRes || $colRes->num_rows === 0) {
            $conn->query($alterSql);
        }
    }

    $conn->query("
      UPDATE purchases
      SET po_approved = 1
      WHERE po_approved = 0 AND status IN ('ordered', 'partial', 'received', 'cancelled')
    ");
}

$apStatusColumn = $conn->query("
    SELECT DATA_TYPE, COLUMN_TYPE
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'account_payable'
      AND COLUMN_NAME = 'status'
    LIMIT 1
");
$apApprovedColumn = $conn->query("
    SELECT 1
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'account_payable'
      AND COLUMN_NAME = 'approved'
    LIMIT 1
");
if ($apStatusColumn && ($apStatus = $apStatusColumn->fetch_assoc())) {
    if (
        strtolower((string)$apStatus['DATA_TYPE']) === 'enum'
        && strpos((string)$apStatus['COLUMN_TYPE'], "'pending'") === false
    ) {
        $conn->query("
            ALTER TABLE account_payable
            MODIFY status ENUM('paid','unpaid','partial','overdue','pending') DEFAULT 'pending'
        ");
    }

    if (
        $apApprovedColumn
        && $apApprovedColumn->num_rows > 0
        && in_array(
            strtolower((string)$apStatus['DATA_TYPE']),
            ['enum', 'varchar', 'char'],
            true
        )
    ) {
        $conn->query("
            UPDATE account_payable
            SET balance = 0, status = 'pending'
            WHERE COALESCE(approved,0) = 0
        ");
    }
}

require_once __DIR__ . '/../includes/automation.php';
if (function_exists('runDailyAutomation')) {
    runDailyAutomation($conn);
}
?>
