const supplierModalAlert = document.getElementById("supplierModalAlert");
const productSelect = document.getElementById("productSelect");
const qtySacks = document.getElementById("qtySacks");
const supplierPrice = document.getElementById("supplierPrice");
const transportCost = document.getElementById("transportCost");
const markupKg = document.getElementById("markupKg");

const previewUnitWeight = document.getElementById("previewUnitWeight");
const previewTotalKg = document.getElementById("previewTotalKg");
const previewAmount = document.getElementById("previewAmount");
const previewSellKg = document.getElementById("previewSellKg");
const previewBuyPrice = document.getElementById("previewBuyPrice");
const previewMarkupKg = document.getElementById("previewMarkupKg");
const previewMarkupHint = document.getElementById("previewMarkupHint");
const previewSellPrice = document.getElementById("previewSellPrice");
const previewSellPriceSack = document.getElementById("previewSellPriceSack");
const previewSellSackText = document.getElementById("previewSellSackText");

const gridVariety = document.getElementById("gridVariety");
const gridSacks = document.getElementById("gridSacks");
const gridPrice = document.getElementById("gridPrice");
const gridSubtotal = document.getElementById("gridSubtotal");

const supplierAddressPreview = document.getElementById("supplierAddressPreview");
const supplierPhonePreview = document.getElementById("supplierPhonePreview");
const supplierSelectEl = document.getElementById("supplierSelect");
const saveSupplierBtn = document.getElementById("saveSupplierBtn");

function num(value) {
  const number = parseFloat(value);
  return Number.isFinite(number) ? number : 0;
}

function updatePreview() {
  if (!productSelect) return;

  const option = productSelect.options[productSelect.selectedIndex];
  const unitWeight = num(option?.getAttribute("data-weight"));
  const variety = (option?.getAttribute("data-variety") || "").trim();
  const grade = (option?.getAttribute("data-grade") || "").trim();

  const sacks = Math.max(0, num(qtySacks?.value));
  const pricePerSack = Math.max(0, num(supplierPrice?.value));
  const transport = Math.max(0, num(transportCost?.value));
  const markup = Math.max(0, num(markupKg?.value));

  const totalKg = sacks * unitWeight;
  const subtotal = sacks * pricePerSack;
  const totalAmount = subtotal + transport;

  const perSackTransport = sacks > 0 ? transport / sacks : 0;
  const landedPerSack = pricePerSack + perSackTransport;
  const costPerKg = unitWeight > 0 ? landedPerSack / unitWeight : 0;
  const suggestedSellKg = costPerKg + markup;
  const suggestedSellPerSack = suggestedSellKg * unitWeight;

  if (previewUnitWeight) previewUnitWeight.textContent = unitWeight.toFixed(2);
  if (previewTotalKg) previewTotalKg.textContent = totalKg.toFixed(2);
  if (previewAmount) previewAmount.textContent = totalAmount.toFixed(2);
  if (previewSellKg) previewSellKg.textContent = suggestedSellKg.toFixed(2);
  if (previewBuyPrice) previewBuyPrice.textContent = pricePerSack.toFixed(2);
  if (previewMarkupKg) previewMarkupKg.textContent = markup.toFixed(2);
  if (previewMarkupHint) previewMarkupHint.textContent = markup.toFixed(2);
  if (previewSellPrice) previewSellPrice.textContent = suggestedSellKg.toFixed(2);
  if (previewSellPriceSack) previewSellPriceSack.textContent = suggestedSellPerSack.toFixed(2);
  if (previewSellSackText) previewSellSackText.textContent = suggestedSellPerSack.toFixed(2);

  if (gridVariety) {
    gridVariety.textContent = [variety, grade].filter(Boolean).join(" - ") || "-";
  }
  if (gridSacks) gridSacks.textContent = sacks.toFixed(0);
  if (gridPrice) gridPrice.textContent = pricePerSack.toFixed(2);
  if (gridSubtotal) gridSubtotal.textContent = subtotal.toFixed(2);
}

function updateSupplierInfo() {
  if (!supplierSelectEl) return;

  const option = supplierSelectEl.options[supplierSelectEl.selectedIndex];
  const phone = (option?.getAttribute("data-phone") || "").trim();
  const address = (option?.getAttribute("data-address") || "").trim();

  if (supplierPhonePreview) supplierPhonePreview.value = phone;
  if (supplierAddressPreview) supplierAddressPreview.value = address;
}

async function fillLastPriceForProductSupplier() {
  const productId = productSelect?.value || "";
  const supplierId = supplierSelectEl?.value || "";

  if (!productId || !supplierId) {
    updatePreview();
    return;
  }

  const currentPrice = supplierPrice ? supplierPrice.value : "";

  const formData = new FormData();
  formData.append("ajax", "last_supplier_price");
  formData.append("product_id", productId);
  formData.append("supplier_id", supplierId);

  try {
    const response = await fetch("add_stock.php", {
      method: "POST",
      body: formData
    });

    const data = await response.json();

    if (data.ok && data.found && data.price !== null) {
      if (supplierPrice) {
        supplierPrice.value = Number(data.price).toFixed(2);
      }
    } else {
      if (supplierPrice) {
        supplierPrice.value = currentPrice;
      }
    }
  } catch (error) {
    if (supplierPrice) {
      supplierPrice.value = currentPrice;
    }
  }

  updatePreview();
}

function showModalAlert(type, message) {
  if (!supplierModalAlert) return;

  supplierModalAlert.className = "alert alert-" + type;
  supplierModalAlert.textContent = message;
  supplierModalAlert.classList.remove("d-none");
}

if (saveSupplierBtn) {
  saveSupplierBtn.addEventListener("click", async () => {
    if (supplierModalAlert) supplierModalAlert.classList.add("d-none");

    const modalSupplierName = document.getElementById("modalSupplierName");
    const modalSupplierPhone = document.getElementById("modalSupplierPhone");
    const modalSupplierAddress = document.getElementById("modalSupplierAddress");

    const name = modalSupplierName?.value.trim() || "";
    const phone = modalSupplierPhone?.value.trim() || "";
    const address = modalSupplierAddress?.value.trim() || "";

    if (!name) {
      showModalAlert("danger", "Supplier name is required.");
      return;
    }

    const formData = new FormData();
    formData.append("ajax", "add_supplier");
    formData.append("supplier_name", name);
    formData.append("supplier_phone", phone);
    formData.append("supplier_address", address);

    try {
      const response = await fetch("add_stock.php", {
        method: "POST",
        body: formData
      });

      const data = await response.json();

      if (!data.ok) {
        showModalAlert("danger", data.message || "Failed to add supplier.");
        return;
      }

      if (!supplierSelectEl) return;

      let option = supplierSelectEl.querySelector(`option[value="${data.supplier_id}"]`);

      if (!option) {
        option = document.createElement("option");
        option.value = data.supplier_id;
        option.textContent = data.supplier_name;
        supplierSelectEl.appendChild(option);
      }

      option.setAttribute("data-phone", phone);
      option.setAttribute("data-address", address);
      option.selected = true;

      updateSupplierInfo();
      await fillLastPriceForProductSupplier();

      showModalAlert("success", data.message || "Supplier added!");

      setTimeout(() => {
        const modalElement = document.getElementById("addSupplierModal");
        const modal = bootstrap.Modal.getInstance(modalElement);
        if (modal) modal.hide();

        if (modalSupplierName) modalSupplierName.value = "";
        if (modalSupplierPhone) modalSupplierPhone.value = "";
        if (modalSupplierAddress) modalSupplierAddress.value = "";
        if (supplierModalAlert) supplierModalAlert.classList.add("d-none");
      }, 600);
    } catch (error) {
      showModalAlert("danger", "Network/Server error. Please try again.");
    }
  });
}

[productSelect, qtySacks, supplierPrice, transportCost, markupKg].forEach((element) => {
  if (!element) return;
  element.addEventListener("input", updatePreview);
  element.addEventListener("change", updatePreview);
});

if (productSelect) {
  productSelect.addEventListener("change", () => {
    fillLastPriceForProductSupplier();
  });
}

if (supplierSelectEl) {
  supplierSelectEl.addEventListener("change", () => {
    updateSupplierInfo();
    fillLastPriceForProductSupplier();
  });
}

updateSupplierInfo();
updatePreview();
