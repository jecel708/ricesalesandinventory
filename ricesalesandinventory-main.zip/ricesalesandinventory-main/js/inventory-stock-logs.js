function showStockLogPanel(panelId) {
  const cards = Array.from(document.querySelectorAll(".log-card"));
  const panels = ["panel-in", "panel-out", "panel-return", "panel-adjust"].map((id) => document.getElementById(id));
  const placeholder = document.getElementById("logsPlaceholder");

  cards.forEach((card) => {
    card.classList.toggle("active", card.dataset.target === panelId);
  });

  panels.forEach((panel) => {
    if (!panel) {
      return;
    }
    panel.classList.toggle("d-none", panel.id !== panelId);
  });

  if (placeholder) {
    placeholder.classList.add("d-none");
  }
}

document.addEventListener("click", (event) => {
  const card = event.target.closest(".log-card");
  if (!card) {
    return;
  }

  const panelId = card.dataset.target;
  if (!panelId) {
    return;
  }

  showStockLogPanel(panelId);
});

window.showStockLogPanel = showStockLogPanel;
