document.addEventListener('DOMContentLoaded', function () {
  const shell = document.querySelector('[data-otp-shell]');
  if (!shell) {
    return;
  }

  const isVerified = shell.getAttribute('data-verified') === '1';
  const redirectTarget = shell.getAttribute('data-redirect') || '';
  const resendBtn = document.querySelector('button[name="resend_otp"]');
  const resendCountdown = document.getElementById('resendBtnCountdown');
  const resendText = document.getElementById('resendCountdownText');
  const resendRemainStart = Number(shell.getAttribute('data-resend-remain') || 0);

  if (isVerified && redirectTarget !== '') {
    window.setTimeout(function () {
      window.location.href = redirectTarget;
    }, 1800);
    return;
  }

  const otpInput = document.getElementById('otpInput');
  if (!otpInput) {
    return;
  }

  otpInput.focus();
  otpInput.addEventListener('input', function () {
    otpInput.value = otpInput.value.replace(/\D/g, '').slice(0, 6);
  });

  let remaining = Number.isFinite(resendRemainStart) ? resendRemainStart : 0;

  function renderCountdown() {
    if (remaining > 0) {
      if (resendBtn) {
        resendBtn.disabled = true;
      }
      if (resendCountdown) {
        resendCountdown.textContent = `(${remaining}s)`;
        resendCountdown.classList.remove('d-none');
      }
      if (resendText) {
        resendText.textContent = `You can resend in ${remaining} second${remaining === 1 ? '' : 's'}.`;
      }
    } else {
      if (resendBtn) {
        resendBtn.disabled = false;
      }
      if (resendCountdown) {
        resendCountdown.classList.add('d-none');
      }
      if (resendText) {
        resendText.textContent = 'You can resend a new OTP now.';
      }
    }
  }

  renderCountdown();
  if (remaining > 0) {
    window.setInterval(function () {
      remaining = Math.max(0, remaining - 1);
      renderCountdown();
    }, 1000);
  }
});
