let qty = 1;
const productSelect = document.getElementById("productSelect");
const qtyInput = document.getElementById("qtyInput");
const actionType = document.getElementById("actionType");
const conditionType = document.getElementById("conditionType");
const modeAdd = document.getElementById("modeAdd");
const modeReduce = document.getElementById("modeReduce");
const modeDiscount = document.getElementById("modeDiscount");
const discountPriceWrap = document.getElementById("discountPriceWrap");
const discountPrice = document.getElementById("discountPrice");
const modeText = document.getElementById("modeText");
const modeChip = document.getElementById("modeChip");
const stockValue = document.getElementById("stockValue");
const weightValue = document.getElementById("weightValue");
const sacksLeftValue = document.getElementById("sacksLeftValue");
const totalKgValue = document.getElementById("totalKgValue");

function updateProductStats() {
  const option = productSelect.options[productSelect.selectedIndex];
  const stock = parseFloat(option?.getAttribute("data-stock") || 0);
  const weight = parseFloat(option?.getAttribute("data-weight") || 0);
  const sacksLeft = weight > 0 ? (stock / weight) : 0;
  const total = qty * weight;

  stockValue.textContent = stock.toFixed(2);
  weightValue.textContent = weight.toFixed(2);
  sacksLeftValue.textContent = sacksLeft.toFixed(2);
  totalKgValue.textContent = total.toFixed(2);
}

function refreshQtyAndTotals() {
  qtyInput.value = qty;
  updateProductStats();
}

function syncQtyFromInput() {
  const parsed = parseInt(qtyInput.value, 10);
  qty = Number.isFinite(parsed) && parsed > 0 ? parsed : 1;
  qtyInput.value = qty;
  updateProductStats();
}

function setMode(mode) {
  if (mode === "out") {
    actionType.value = "out";
    conditionType.disabled = false;
    conditionType.required = true;
    discountPriceWrap.classList.add("d-none");
    discountPrice.disabled = true;
    discountPrice.required = false;
    modeText.innerHTML = "Mode: REDUCE";
    modeText.className = "fw-bold text-danger mb-0";
    modeChip.textContent = "REDUCE";
    modeChip.className = "mode-chip mode-reduce";
    modeReduce.checked = true;
    modeDiscount.checked = false;
  } else if (mode === "discount") {
    actionType.value = "discount";
    conditionType.value = "";
    conditionType.disabled = true;
    conditionType.required = false;
    discountPriceWrap.classList.remove("d-none");
    discountPrice.disabled = false;
    discountPrice.required = true;
    modeText.innerHTML = "Mode: DISCOUNT";
    modeText.className = "fw-bold mb-0";
    modeChip.textContent = "DISCOUNT";
    modeChip.className = "mode-chip mode-discount";
    modeDiscount.checked = true;
    modeReduce.checked = false;
  } else {
    actionType.value = "in";
    discountPriceWrap.classList.add("d-none");
    discountPrice.disabled = true;
    discountPrice.required = false;
    conditionType.value = "";
    conditionType.disabled = true;
    conditionType.required = false;
    modeText.innerHTML = "Mode: ADD";
    modeText.className = "fw-bold text-success mb-0";
    modeChip.textContent = "ADD";
    modeChip.className = "mode-chip mode-add";
    modeAdd.checked = true;
    modeReduce.checked = false;
    modeDiscount.checked = false;
  }
}

function increaseQty() {
  qty++;
  refreshQtyAndTotals();
}

function decreaseQty() {
  qty = Math.max(1, qty - 1);
  refreshQtyAndTotals();
}

productSelect.addEventListener("change", updateProductStats);
qtyInput.addEventListener("input", syncQtyFromInput);
qtyInput.addEventListener("blur", syncQtyFromInput);
modeAdd.addEventListener("change", () => setMode("in"));
modeReduce.addEventListener("change", () => setMode("out"));
modeDiscount.addEventListener("change", () => setMode("discount"));
document.querySelector("form")?.addEventListener("submit", (event) => {
  if (actionType.value === "out" && !conditionType.value) {
    event.preventDefault();
    alert("Please select a classification for Reduce Stock.");
    conditionType.focus();
  }

  if (actionType.value === "discount" && !(Number(discountPrice.value || 0) > 0)) {
    event.preventDefault();
    alert("Please enter a valid discounted price per kg.");
    discountPrice.focus();
  }
});

window.increaseQty = increaseQty;
window.decreaseQty = decreaseQty;

setMode("in");
refreshQtyAndTotals();
