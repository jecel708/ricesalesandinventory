const editModalEl = document.getElementById('editCustomerModal');
if(editModalEl){
  editModalEl.addEventListener('show.bs.modal', function(event){
    const btn = event.relatedTarget;
    if(!btn) return;
    document.getElementById('edit_customer_id').value = btn.getAttribute('data-customer-id') || '';
    document.getElementById('edit_first_name').value = btn.getAttribute('data-first-name') || '';
    document.getElementById('edit_last_name').value = btn.getAttribute('data-last-name') || '';
    document.getElementById('edit_phone').value = btn.getAttribute('data-phone') || '';
    document.getElementById('edit_address').value = btn.getAttribute('data-address') || '';
  });
}