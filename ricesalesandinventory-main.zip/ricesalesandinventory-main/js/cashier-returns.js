const saleSelect = document.getElementById('saleSelect');
const productSelect = document.getElementById('productSelect');
const qtyInput = document.getElementById('qtyInput');
const maxHint = document.getElementById('maxHint');
const maxQtyText = document.getElementById('maxQtyText');

let productMeta = {}; // product_id => {max_qty}

saleSelect.addEventListener('change', async () => {
const saleId = saleSelect.value;

productSelect.innerHTML = '<option value="">Loading...</option>';
productSelect.disabled = true;
maxHint.style.display = 'none';
qtyInput.value = '';
qtyInput.removeAttribute('max');

if(!saleId){
productSelect.innerHTML = '<option value="">Select Sale first</option>';
return;
}

const res = await fetch(`returns.php?ajax=sale_items&sale_id=${encodeURIComponent(saleId)}`);
const data = await res.json();

productMeta = {};
if(!Array.isArray(data) || data.length === 0){
productSelect.innerHTML = '<option value="">No returnable items for this sale</option>';
productSelect.disabled = true;
return;
}

productSelect.innerHTML = '<option value="">Select Product</option>';
data.forEach(item => {
productMeta[item.product_id] = { max_qty: Number(item.max_qty || 0) };
const opt = document.createElement('option');
opt.value = item.product_id;
opt.textContent = `${item.label} (max ${Number(item.max_qty).toFixed(2)} kg)`;
productSelect.appendChild(opt);
});

productSelect.disabled = false;
});

productSelect.addEventListener('change', () => {
const pid = productSelect.value;
maxHint.style.display = 'none';
qtyInput.value = '';
qtyInput.removeAttribute('max');

if(!pid || !productMeta[pid]) return;

const mx = productMeta[pid].max_qty;
maxQtyText.textContent = mx.toFixed(2);
maxHint.style.display = 'block';

// Client-side guard (server-side still enforced)
qtyInput.setAttribute('max', mx.toFixed(2));
});

qtyInput.addEventListener('input', () => {
const max = Number(qtyInput.getAttribute('max') || 0);
const v = Number(qtyInput.value || 0);
if(max > 0 && v > max){
qtyInput.value = max.toFixed(2);
}
});

// Reason modal handler
const reasonModal = document.getElementById('reasonModal');
reasonModal.addEventListener('show.bs.modal', (event) => {
const btn = event.relatedTarget;
const reason = btn.getAttribute('data-reason') || '';
document.getElementById('reasonBody').textContent = reason;
});