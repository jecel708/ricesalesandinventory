(function(){
  document.querySelectorAll('.toggle-password').forEach(function(btn){
    btn.addEventListener('click', function(){
      const id = btn.getAttribute('data-target');
      const input = document.getElementById(id);
      if(!input) return;

      const icon = btn.querySelector('i');

      if(input.type === 'password'){
        input.type = 'text';
        if(icon){ icon.classList.remove('fa-eye'); icon.classList.add('fa-eye-slash'); }
      }else{
        input.type = 'password';
        if(icon){ icon.classList.remove('fa-eye-slash'); icon.classList.add('fa-eye'); }
      }
    });
  });
})();
