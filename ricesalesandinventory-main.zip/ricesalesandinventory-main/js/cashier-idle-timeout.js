(function () {
  var timeoutMinutes = Number(window.CASHIER_IDLE_TIMEOUT_MINUTES || 10);
  var warningSeconds = Number(window.CASHIER_IDLE_WARNING_SECONDS || 60);
  var timeoutMs = Math.max(1, timeoutMinutes) * 60 * 1000;
  var warningMs = Math.max(0, warningSeconds) * 1000;
  var warningDelayMs = Math.max(0, timeoutMs - warningMs);

  var warningModalEl = null;
  var warningModal = null;
  var countdownEl = null;
  var countdownTextEl = null;
  var activityTimer = null;
  var logoutTimer = null;
  var countdownTimer = null;
  var remainingSeconds = Math.max(1, Math.ceil(warningMs / 1000));
  var lastActivityAt = Date.now();

  function ensureModal() {
    if (warningModalEl) return;

    warningModalEl = document.createElement('div');
    warningModalEl.className = 'modal fade';
    warningModalEl.id = 'idleTimeoutModal';
    warningModalEl.tabIndex = -1;
    warningModalEl.setAttribute('aria-hidden', 'true');
    warningModalEl.innerHTML = '' +
      '<div class="modal-dialog modal-dialog-centered">' +
        '<div class="modal-content border-0 shadow">' +
          '<div class="modal-header bg-warning-subtle">' +
            '<h5 class="modal-title fw-bold">Session expiring soon</h5>' +
          '</div>' +
          '<div class="modal-body">' +
            '<p class="mb-2">You have been inactive for a while.</p>' +
            '<p class="mb-0 fw-semibold">You will be logged out in <span id="idleTimeoutCountdown"></span>.</p>' +
            '<div id="idleTimeoutCountdownText" class="small text-muted mt-2"></div>' +
          '</div>' +
          '<div class="modal-footer">' +
            '<button type="button" class="btn btn-outline-secondary" id="idleStayBtn">Stay logged in</button>' +
            '<a href="../logout.php" class="btn btn-dark">Logout now</a>' +
          '</div>' +
        '</div>' +
      '</div>';
    document.body.appendChild(warningModalEl);
    countdownEl = warningModalEl.querySelector('#idleTimeoutCountdown');
    countdownTextEl = warningModalEl.querySelector('#idleTimeoutCountdownText');
  }

  function logoutNow() {
    window.location.href = '../logout.php';
  }

  function showWarning() {
    ensureModal();
    if (countdownEl) {
      countdownEl.textContent = remainingSeconds + (remainingSeconds === 1 ? ' second' : ' seconds');
    }
    if (countdownTextEl) {
      countdownTextEl.textContent = 'Move your mouse, press a key, or click Stay logged in to keep working.';
    }

    if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
      warningModal = bootstrap.Modal.getOrCreateInstance(warningModalEl, { backdrop: 'static', keyboard: false });
      warningModal.show();
    } else {
      warningModalEl.classList.add('show');
      warningModalEl.style.display = 'block';
    }

    clearInterval(countdownTimer);
    countdownTimer = setInterval(function () {
      remainingSeconds -= 1;
      if (countdownEl) {
        countdownEl.textContent = remainingSeconds + (remainingSeconds === 1 ? ' second' : ' seconds');
      }
      if (remainingSeconds <= 0) {
        clearInterval(countdownTimer);
        logoutNow();
      }
    }, 1000);
  }

  function hideWarning() {
    if (warningModal && typeof warningModal.hide === 'function') {
      warningModal.hide();
    } else if (warningModalEl) {
      warningModalEl.classList.remove('show');
      warningModalEl.style.display = 'none';
    }
    clearInterval(countdownTimer);
  }

  function resetTimers() {
    lastActivityAt = Date.now();
    remainingSeconds = Math.max(1, Math.ceil(warningMs / 1000));
    hideWarning();
    clearTimeout(activityTimer);
    clearTimeout(logoutTimer);

    activityTimer = setTimeout(showWarning, warningDelayMs);
    logoutTimer = setTimeout(logoutNow, timeoutMs);
  }

  function onActivity() {
    if (document.hidden) return;
    resetTimers();
  }

  function onVisibilityChange() {
    if (document.hidden) {
      return;
    }
    var elapsed = Date.now() - lastActivityAt;
    if (elapsed >= timeoutMs) {
      logoutNow();
    } else if (elapsed >= warningDelayMs) {
      remainingSeconds = Math.max(1, Math.ceil((timeoutMs - elapsed) / 1000));
      showWarning();
    } else {
      resetTimers();
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    ensureModal();
    resetTimers();

    ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll', 'click'].forEach(function (eventName) {
      document.addEventListener(eventName, onActivity, { passive: true });
    });

    document.addEventListener('visibilitychange', onVisibilityChange);

    document.addEventListener('click', function (e) {
      var stayBtn = e.target.closest && e.target.closest('#idleStayBtn');
      if (!stayBtn) return;
      e.preventDefault();
      resetTimers();
    });
  });
})();
