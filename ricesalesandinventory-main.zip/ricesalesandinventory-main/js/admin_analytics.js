(function () {
    const el = document.getElementById('adminAnalyticsData');
    if (!el) return;

    let analytics = {};
    try {
        analytics = JSON.parse(el.textContent || '{}');
    } catch (err) {
        console.error('Invalid analytics JSON data.', err);
        return;
    }

    const {
        months = [],
        salesKgData = [],
        trendLabels = [],
        trendSalesData = [],
        allProductSalesLabels = [],
        allProductSalesKg = [],
        fastRestockLabels = [],
        fastRestockSoldKg = [],
        fastRestockSuggestedKg = [],
        combinedLabels = [],
        actualPadded = [],
        forecastPadded = [],
        daySalesLabels = [],
        daySalesData = [],
        topProdLabels = [],
        topProdKg = [],
        stockLabels = [],
        stockData = []
    } = analytics;

    const fontFamily = "system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif";

    Chart.defaults.font.family = fontFamily;
    /* Match dark dashboard cards used by admin analytics */
    Chart.defaults.color = '#ffffff';
    Chart.defaults.borderColor = 'rgba(255, 255, 255, 0.16)';

    const commonGrid = {
        color: 'rgba(255, 255, 255, 0.12)',
        drawBorder: false
    };

    const commonTicks = {
        color: '#ffffff',
        font: {
            size: 11,
            weight: '600'
        }
    };

    const commonPlugins = {
        legend: {
            labels: {
                usePointStyle: true,
                pointStyle: 'circle',
                boxWidth: 10,
                boxHeight: 10,
                padding: 16,
                color: '#ffffff',
                font: {
                    size: 12,
                    weight: '600'
                }
            }
        },
        tooltip: {
            backgroundColor: 'rgba(15, 23, 42, 0.96)',
            titleColor: '#ffffff',
            bodyColor: '#e5e7eb',
            padding: 12,
            cornerRadius: 12,
            displayColors: true,
            boxPadding: 6,
            titleFont: {
                size: 12,
                weight: '700'
            },
            bodyFont: {
                size: 12,
                weight: '600'
            }
        }
    };

    function makeLineChart(canvasId, labels, datasets) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return;

        new Chart(canvas, {
            type: 'line',
            data: {
                labels,
                datasets
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false
                },
                plugins: commonPlugins,
                elements: {
                    line: {
                        tension: 0.35,
                        borderWidth: 3
                    },
                    point: {
                        radius: 4,
                        hoverRadius: 6,
                        borderWidth: 2,
                        backgroundColor: '#ffffff'
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: commonTicks
                    },
                    y: {
                        beginAtZero: true,
                        grid: commonGrid,
                        ticks: commonTicks
                    }
                }
            }
        });
    }

    function makeBarChart(canvasId, labels, datasets, horizontal = false) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return;

        new Chart(canvas, {
            type: 'bar',
            data: {
                labels,
                datasets
            },
            options: {
                indexAxis: horizontal ? 'y' : 'x',
                responsive: true,
                maintainAspectRatio: false,
                plugins: commonPlugins,
                elements: {
                    bar: {
                        borderRadius: 10,
                        borderSkipped: false
                    }
                },
                scales: {
                    x: horizontal
                        ? {
                            beginAtZero: true,
                            grid: commonGrid,
                            ticks: commonTicks
                        }
                        : {
                            grid: {
                                display: false
                            },
                            ticks: commonTicks
                        },
                    y: horizontal
                        ? {
                            grid: {
                                display: false
                            },
                            ticks: commonTicks
                        }
                        : {
                            beginAtZero: true,
                            grid: commonGrid,
                            ticks: commonTicks
                        }
                }
            }
        });
    }

    const colorPrimary = 'rgba(13, 110, 253, 1)';
    const colorPrimaryFill = 'rgba(13, 110, 253, 0.20)';
    const colorSuccess = 'rgba(25, 135, 84, 1)';
    const colorSuccessFill = 'rgba(25, 135, 84, 0.18)';
    const colorWarning = 'rgba(245, 158, 11, 1)';
    const colorWarningFill = 'rgba(245, 158, 11, 0.18)';

    makeLineChart('monthlyKgChart', trendLabels, [
        {
            label: 'Sales (kg)',
            data: trendSalesData,
            borderColor: colorPrimary,
            backgroundColor: colorPrimaryFill,
            fill: true
        }
    ]);

    makeBarChart('allProductSalesChart', allProductSalesLabels, [
        {
            label: 'Sales (kg)',
            data: allProductSalesKg,
            backgroundColor: 'rgba(13, 110, 253, 0.78)',
            borderColor: colorPrimary
        }
    ], true);

    makeBarChart('fastRestockChart', fastRestockLabels, [
        {
            label: 'Sold in lookback period (kg)',
            data: fastRestockSoldKg,
            backgroundColor: 'rgba(13, 110, 253, 0.78)',
            borderColor: colorPrimary
        },
        {
            label: 'Suggested order (kg)',
            data: fastRestockSuggestedKg,
            backgroundColor: 'rgba(25, 135, 84, 0.78)',
            borderColor: colorSuccess
        }
    ], true);

    makeLineChart('salesChart', combinedLabels, [
        {
            label: 'Actual Sales',
            data: actualPadded,
            borderColor: colorSuccess,
            backgroundColor: colorSuccessFill,
            fill: true,
            spanGaps: false
        },
        {
            label: 'Forecast',
            data: forecastPadded,
            borderColor: colorWarning,
            backgroundColor: colorWarningFill,
            borderDash: [7, 5],
            fill: false,
            spanGaps: false
        }
    ]);

    makeBarChart('topProductsChart', topProdLabels, [
        {
            label: 'KG Sold',
            data: topProdKg,
            backgroundColor: 'rgba(13, 110, 253, 0.78)',
            borderColor: colorPrimary
        }
    ], true);

    makeBarChart('stockChart', stockLabels, [
        {
            label: 'Current Stock (kg)',
            data: stockData,
            backgroundColor: 'rgba(25, 135, 84, 0.78)',
            borderColor: colorSuccess
        }
    ], true);

    makeBarChart('dowChart', daySalesLabels, [
        {
            label: 'Sales by Day (kg)',
            data: daySalesData,
            backgroundColor: 'rgba(245, 158, 11, 0.78)',
            borderColor: colorWarning
        }
    ], false);
})();
