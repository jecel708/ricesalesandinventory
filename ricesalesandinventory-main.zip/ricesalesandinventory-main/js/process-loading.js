(function () {
  'use strict';

  const processingClass = 'is-processing';

  function setLoading(button, label) {
    if (!button || button.disabled || button.classList.contains(processingClass)) return;

    if (!button.dataset.loadingOriginal) {
      button.dataset.loadingOriginal = button.innerHTML;
    }

    button.classList.add(processingClass);
    button.disabled = true;
    button.setAttribute('aria-busy', 'true');
    button.innerHTML = '<span class="process-spinner" aria-hidden="true"></span>' + (label || 'Processing...');
  }

  document.addEventListener('submit', function (event) {
    if (event.defaultPrevented) return;

    const form = event.target;
    if (!(form instanceof HTMLFormElement) || form.dataset.loading === 'false') return;

    const submitter = event.submitter || form.querySelector('button[type="submit"], input[type="submit"]');
    if (!submitter || submitter.dataset.loading === 'false' || submitter.dataset.noLoading !== undefined) return;

    // Disabled submit controls are excluded from the POST payload. Preserve
    // the clicked button's name/value before showing the loading state.
    if (submitter.name) {
      const hiddenSubmitter = document.createElement('input');
      hiddenSubmitter.type = 'hidden';
      hiddenSubmitter.name = submitter.name;
      hiddenSubmitter.value = submitter.value || '';
      hiddenSubmitter.dataset.loadingSubmitter = 'true';
      form.appendChild(hiddenSubmitter);
    }

    setLoading(submitter, submitter.dataset.loadingLabel || 'Processing...');
  }, true);

  document.addEventListener('click', function (event) {
    const target = event.target.closest('button[data-loading], a[data-loading]');
    if (!target || event.defaultPrevented || target.dataset.loading === 'false') return;

    setLoading(target, target.dataset.loadingLabel || 'Processing...');
  });

  window.addEventListener('pageshow', function () {
    document.querySelectorAll('.' + processingClass).forEach(function (button) {
      button.classList.remove(processingClass);
      button.removeAttribute('aria-busy');
      button.disabled = false;
      if (button.dataset.loadingOriginal) {
        button.innerHTML = button.dataset.loadingOriginal;
      }
    });
  });
})();
