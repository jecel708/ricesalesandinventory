document.addEventListener("DOMContentLoaded", function () {
  const productSearch = document.getElementById("productSearch");
  const productTable = document.querySelector(".products-table");
  if (productSearch && productTable) {
    const rows = Array.from(productTable.querySelectorAll("tbody tr")).filter(
      (tr) => !tr.querySelector("td[colspan]")
    );
    const norm = (v) => (v || "").toString().toLowerCase().trim();

    productSearch.addEventListener("input", () => {
      const q = norm(productSearch.value);
      rows.forEach((tr) => {
        const txt = norm(tr.textContent);
        tr.style.display = q === "" || txt.includes(q) ? "" : "none";
      });
    });
  }

  const overstockModal = document.getElementById("overStockModal");
  if (!overstockModal || typeof bootstrap === "undefined") {
    return;
  }

  const modal = new bootstrap.Modal(overstockModal, {
    backdrop: "static",
    keyboard: false
  });
  modal.show();

  const searchEl = document.getElementById("overStockSearch");
  const rows = Array.from(overstockModal.querySelectorAll("tbody tr"));
  if (searchEl) {
    const norm = (v) => (v || "").toString().toLowerCase().trim();
    searchEl.addEventListener("input", () => {
      const q = norm(searchEl.value);
      rows.forEach((tr) => {
        const txt = norm(tr.textContent);
        tr.style.display = q === "" || txt.includes(q) ? "" : "none";
      });
    });
  }

  overstockModal.addEventListener("click", (e) => {
    const btn = e.target.closest(".js-overstock-jump");
    if (!btn) return;

    const productId = parseInt(btn.getAttribute("data-product-id") || "0", 10);
    if (!Number.isFinite(productId) || productId <= 0) return;

    modal.hide();
    setTimeout(() => {
      const row = document.getElementById("product-row-" + productId);
      if (!row) return;
      row.scrollIntoView({ behavior: "smooth", block: "center" });
      row.classList.add("product-jump-highlight");
      setTimeout(() => row.classList.remove("product-jump-highlight"), 1600);
    }, 260);
  });
});
