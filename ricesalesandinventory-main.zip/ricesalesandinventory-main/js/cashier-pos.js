const products = <?= json_encode($products) ?>;

function peso(n){
  return (Number(n||0)).toLocaleString(undefined,{minimumFractionDigits:2, maximumFractionDigits:2});
}

// Fallback: if Bootstrap JS fails to load (e.g., offline), make the Options collapse still work.
document.addEventListener('click', (e) => {
  const btn = e.target.closest?.('.options-toggle');
  if(!btn) return;
  if(typeof bootstrap !== 'undefined') return; // let Bootstrap handle it

  e.preventDefault();
  const sel = btn.getAttribute('data-bs-target');
  const el = (sel && sel.trim()) ? document.querySelector(sel) : null;
  if(!el) return;
  const isOpen = el.classList.toggle('show');
  btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
});

function formatISODate(y, m, d){
  const mm = String(m).padStart(2,'0');
  const dd = String(d).padStart(2,'0');
  return `${y}-${mm}-${dd}`;
}

function computeDueDateClient(days){
  const n = Number(days || 15);
  const due = new Date();
  due.setDate(due.getDate() + n);
  return formatISODate(due.getFullYear(), due.getMonth() + 1, due.getDate());
}

function toggleDueDate(){
  const t = document.getElementById('sale_type').value;
  const termsWrap = document.getElementById('termDaysWrap');
  const wrap = document.getElementById('dueDateWrap');
  termsWrap.classList.toggle('d-none', t !== 'utang');
  wrap.classList.toggle('d-none', t !== 'utang');

  if(t === 'utang'){
    const terms = Number(document.getElementById('term_days')?.value || 15);
    const due = computeDueDateClient(terms);
    const dueInput = document.getElementById('dueDateText');
    if(dueInput) dueInput.value = due;
  } else {
    const dueInput = document.getElementById('dueDateText');
    if(dueInput) dueInput.value = "—";
  }

  ensureOptionsVisibility();
}

function updateCustomerBalanceHint(){
  const sel = document.getElementById('customer_id');
  const hint = document.getElementById('customerBalanceHint');
  if(!sel || !hint) return;

  const opt = sel.options[sel.selectedIndex];
  if(!opt || !opt.value){
    hint.className = 'small mt-1';
    hint.innerHTML = '';
    return;
  }

  const bal = Number(opt.getAttribute('data-open-balance') || 0);
  const docs = Number(opt.getAttribute('data-open-docs') || 0);

  if(bal > 0){
    hint.className = 'small mt-1 text-danger';
    hint.innerHTML = `Current open utang: <b>₱${peso(bal)}</b> across <b>${docs}</b> document(s).`;
  } else {
    hint.className = 'small mt-1 text-success';
    hint.innerHTML = 'No open utang for this customer.';
  }
}

function hasDiscountedPriceRow(){
  return Array.from(document.querySelectorAll('#itemsTable tbody tr select[name="price_mode[]"]'))
    .some((sel) => sel && sel.value === 'discounted');
}

function toggleDiscountFields(){
  const dt = document.getElementById('discount_type').value;
  const fields = document.getElementById('discountFields');
  const hasDiscountedRow = hasDiscountedPriceRow();
  const showFields = !hasDiscountedRow && (dt === 'pwd' || dt === 'sc' || dt === 'others');

  fields.classList.toggle('d-none', !showFields);

  if(hasDiscountedRow && dt !== 'none'){
    const discountTypeSel = document.getElementById('discount_type');
    if(discountTypeSel) discountTypeSel.value = 'none';
    const customDiscount = document.getElementById('discount_percent');
    if(customDiscount) customDiscount.value = '';
  }

  ensureOptionsVisibility();
}

function ensureOptionsVisibility(){
  const optionsEl = document.getElementById('saleOptions');
  if(!optionsEl || typeof bootstrap === 'undefined') return;

  const need =
    !document.getElementById('termDaysWrap')?.classList.contains('d-none') ||
    !document.getElementById('dueDateWrap')?.classList.contains('d-none') ||
    !document.getElementById('discountFields')?.classList.contains('d-none');

  const inst = bootstrap.Collapse.getOrCreateInstance(optionsEl, { toggle: false });
  if(need){
    inst.show();
  }else{
    inst.hide();
  }
}

function clearRows(){
  const tbody = document.querySelector('#itemsTable tbody');
  if(!tbody) return;
  tbody.innerHTML = '';
  addRow();
  recalcAll();
}

function addRow(){
  const tbody = document.querySelector('#itemsTable tbody');
  const tr = document.createElement('tr');

  // Product select
  const tdProd = document.createElement('td');
  tdProd.setAttribute('data-label', 'Product');
  const sel = document.createElement('select');
  sel.name = "product_id[]";
  sel.className = "form-select form-select-sm prod-select";
  sel.required = true;

  sel.innerHTML = `<option value="">Select product</option>` + products.map(p => {
    const tag = `${p.variety} - ${p.grade} (${peso(p.unit_weight_kg)}kg/sack)`;
    return `<option value="${p.product_id}"
      data-stock="${p.stock_kg}"
      data-dstock="${p.discounted_kg || 0}"
      data-w="${p.unit_weight_kg}"
      data-pkg="${p.price_per_kg}"
      data-psack="${p.price_per_sack}"
      data-dpkg="${p.discounted_price_per_kg || 0}"
    >${tag}</option>`;
  }).join('');

  sel.onchange = () => fillRow(tr);
  tdProd.appendChild(sel);

  // Stock badge
  const tdStock = document.createElement('td');
  tdStock.setAttribute('data-label', 'Stock');
  tdStock.innerHTML = `<span class="badge bg-secondary stock-pill">0.00 kg</span>`;

  // Unit type
  const tdUnit = document.createElement('td');
  tdUnit.setAttribute('data-label', 'Unit');
  const unitSel = document.createElement('select');
  unitSel.name = "unit_type[]";
  unitSel.className = "form-select form-select-sm unit-select";
  unitSel.innerHTML = `
    <option value="kg">Per Kilo</option>
    <option value="sack">Per Sack</option>
  `;
  unitSel.onchange = () => unitChanged(tr);
  tdUnit.appendChild(unitSel);

  // Qty input (generic)
  const tdQty = document.createElement('td');
  tdQty.setAttribute('data-label', 'Qty');
  const qty = document.createElement('input');
  qty.type = "number";
  qty.step = "0.01";
  qty.min = "0";
  qty.name = "qty[]";
  qty.className = "form-control form-control-sm qty-input";
  qty.required = true;
  qty.placeholder = "0.00";
  qty.oninput = () => recalc(tr);
  tdQty.appendChild(qty);
  const quick = document.createElement('div');
  quick.className = "qty-quick d-flex gap-1 mt-2 d-none";
  quick.innerHTML = `
    <button type="button" class="btn btn-sm btn-outline-secondary" title="Add 1 sack">+1</button>
    <button type="button" class="btn btn-sm btn-outline-secondary" title="Add 5 sacks">+5</button>
    <button type="button" class="btn btn-sm btn-outline-secondary" title="Add 10 sacks">+10</button>
  `;
  const quickBtns = quick.querySelectorAll('button');
  quickBtns[0].onclick = () => applyQuickSack(tr, 1);
  quickBtns[1].onclick = () => applyQuickSack(tr, 5);
  quickBtns[2].onclick = () => applyQuickSack(tr, 10);
  tdQty.appendChild(quick);
  const deductNote = document.createElement('div');
  deductNote.className = "deduct-note mt-1";
  deductNote.textContent = "";
  tdQty.appendChild(deductNote);

  // Price (readonly)
  const tdPrice = document.createElement('td');
  tdPrice.setAttribute('data-label', 'Price');
  const priceWrap = document.createElement('div');
  priceWrap.className = "input-group input-group-sm";
  const pesoPrefix = document.createElement('span');
  pesoPrefix.className = "input-group-text";
  pesoPrefix.textContent = "₱";
  const price = document.createElement('input');
  price.type = "number";
  price.step = "0.01";
  price.min = "0";
  price.name = "unit_price[]";
  price.className = "form-control form-control-sm price-input";
  price.readOnly = true;
  price.tabIndex = -1;
  priceWrap.appendChild(pesoPrefix);
  priceWrap.appendChild(price);
  tdPrice.appendChild(priceWrap);

  const modeSel = document.createElement('select');
  modeSel.name = "price_mode[]";
  modeSel.className = "form-select form-select-sm mt-1 price-mode";
  modeSel.innerHTML = `
    <option value="regular">Regular</option>
    <option value="discounted">Discounted</option>
  `;
  modeSel.disabled = true; // enabled when product has discounted stock+price
  modeSel.onchange = () => applyPriceMode(tr);
  tdPrice.appendChild(modeSel);

  // Line total
  const tdDeduct = document.createElement('td');
  tdDeduct.setAttribute('data-label', 'Deduct (kg)');
  tdDeduct.className = "text-end";
  tdDeduct.innerHTML = `<span class="deduct-text text-muted">0.00</span>`;

  // Line total
  const tdLine = document.createElement('td');
  tdLine.setAttribute('data-label', 'Line');
  tdLine.className = "text-end";
  tdLine.innerHTML = `<span class="fw-bold line-text">₱0.00</span>`;

  // Remove btn
  const tdX = document.createElement('td');
  tdX.setAttribute('data-label', 'Actions');
  const wrapBtn = document.createElement('div');
  wrapBtn.className = 'd-flex justify-content-end gap-1';

  const dup = document.createElement('button');
  dup.type = "button";
  dup.className = "btn btn-sm btn-outline-secondary action-dup";
  dup.innerHTML = `<i class="fa-solid fa-copy"></i>`;
  dup.title = "Duplicate row";
  dup.onclick = () => duplicateRow(tr);

  const del = document.createElement('button');
  del.type = "button";
  del.className = "btn btn-sm btn-outline-danger action-remove";
  del.innerHTML = `<i class="fa-solid fa-xmark"></i>`;
  del.title = "Remove row";
  del.onclick = () => { tr.remove(); recalcAll(); if(!document.querySelector('#itemsTable tbody tr')) addRow(); };

  wrapBtn.appendChild(dup);
  wrapBtn.appendChild(del);
  tdX.appendChild(wrapBtn);

  tr.appendChild(tdProd);
  tr.appendChild(tdStock);
  tr.appendChild(tdUnit);
  tr.appendChild(tdQty);
  tr.appendChild(tdPrice);
  tr.appendChild(tdDeduct);
  tr.appendChild(tdLine);
  tr.appendChild(tdX);

  tbody.appendChild(tr);

  // default row values
  unitChanged(tr);
}

function applyQuickSack(tr, sacks){
  const unitSel = tr.querySelector('select[name="unit_type[]"]');
  const qtyInput = tr.querySelector('input[name="qty[]"]');
  if(!unitSel || !qtyInput) return;
  unitSel.value = 'sack';
  unitChanged(tr);
  const current = Number(qtyInput.value || 0);
  qtyInput.value = current + Number(sacks || 0);
  recalc(tr);
}

function duplicateRow(tr){
  const tbody = document.querySelector('#itemsTable tbody');
  if(!tbody || !tr) return;
  const clone = tr.cloneNode(true);
  tbody.appendChild(clone);

  const sel = clone.querySelector('select[name="product_id[]"]');
  const unitSel = clone.querySelector('select[name="unit_type[]"]');
  const qty = clone.querySelector('input[name="qty[]"]');
  const modeSel = clone.querySelector('select[name="price_mode[]"]');
  const removeBtn = clone.querySelector('.action-remove');
  const dupBtn = clone.querySelector('.action-dup');
  const quickBtns = clone.querySelectorAll('.qty-quick button');

  if(sel) sel.onchange = () => fillRow(clone);
  if(unitSel) unitSel.onchange = () => unitChanged(clone);
  if(qty) qty.oninput = () => recalc(clone);
  if(modeSel) modeSel.onchange = () => applyPriceMode(clone);
  if(removeBtn) removeBtn.onclick = () => { clone.remove(); recalcAll(); if(!document.querySelector('#itemsTable tbody tr')) addRow(); };
  if(dupBtn) dupBtn.onclick = () => duplicateRow(clone);
  if(quickBtns.length === 3){
    quickBtns[0].onclick = () => applyQuickSack(clone, 1);
    quickBtns[1].onclick = () => applyQuickSack(clone, 5);
    quickBtns[2].onclick = () => applyQuickSack(clone, 10);
  }

  fillRow(clone);
}

function fillRow(tr){
  const sel = tr.querySelector('select[name="product_id[]"]');
  const opt = sel.options[sel.selectedIndex];

  const stock = Number(opt.getAttribute('data-stock') || 0);
  const dstock = Number(opt.getAttribute('data-dstock') || 0);
  const regularStock = stock - dstock;
  let cls = 'bg-secondary';
  if(regularStock > 0 && regularStock < 30) cls = 'bg-warning text-dark';
  if(regularStock >= 30) cls = 'bg-info text-dark';
  tr.children[1].innerHTML =
    `<span class="badge ${cls} stock-pill">Total: ${peso(stock)} kg</span>` +
    (dstock > 0 ? `<div class="small text-muted mt-1">Discounted: ${peso(dstock)} kg</div>` : ``);

  const modeSel = tr.querySelector('select[name="price_mode[]"]');
  const dPkg = Number(opt.getAttribute('data-dpkg') || 0);
  const canDiscount = (dstock > 0 && dPkg > 0);
  if(modeSel){
    modeSel.disabled = !canDiscount;
    const discountedOption = modeSel.querySelector('option[value="discounted"]');
    if(discountedOption){
      discountedOption.disabled = !canDiscount;
      discountedOption.hidden = !canDiscount;
    }
    if(!canDiscount){
      modeSel.value = 'regular';
    }
  }

  unitChanged(tr);
}

function applyPriceMode(tr){
  const prodSel = tr.querySelector('select[name="product_id[]"]');
  const opt = prodSel.options[prodSel.selectedIndex];
  const unitSel = tr.querySelector('select[name="unit_type[]"]');
  const unit = unitSel.value;

  const w = Number(opt.getAttribute('data-w') || 0);
  const pKg = Number(opt.getAttribute('data-pkg') || 0);
  const pSack = Number(opt.getAttribute('data-psack') || 0);
  const dPkg = Number(opt.getAttribute('data-dpkg') || 0);
  const canDiscount = Number(opt.getAttribute('data-dstock') || 0) > 0 && dPkg > 0;

  const modeSel = tr.querySelector('select[name="price_mode[]"]');
  if(modeSel && !canDiscount){
    modeSel.value = 'regular';
    modeSel.disabled = true;
    const discountedOption = modeSel.querySelector('option[value="discounted"]');
    if(discountedOption){
      discountedOption.disabled = true;
      discountedOption.hidden = true;
    }
  }

  const mode = canDiscount ? (modeSel?.value || 'regular') : 'regular';
  const priceInput = tr.querySelector('input[name="unit_price[]"]');

  if(mode === 'discounted' && dPkg > 0){
    priceInput.value = (unit === 'sack') ? (dPkg * w) : dPkg;
  } else {
    priceInput.value = (unit === 'sack') ? (pSack ? pSack : 0) : (pKg ? pKg : 0);
  }

  recalc(tr);
}

function unitChanged(tr){
  const prodSel = tr.querySelector('select[name="product_id[]"]');
  const opt = prodSel.options[prodSel.selectedIndex];

  const unitSel = tr.querySelector('select[name="unit_type[]"]');
  const unit = unitSel.value;

  const qtyInput = tr.querySelector('input[name="qty[]"]');
  const quick = tr.querySelector('.qty-quick');
  if(quick) quick.classList.toggle('d-none', unit !== 'sack');

  if(unit === 'sack'){
    qtyInput.step = "1";
    qtyInput.placeholder = "0";
    // if user already typed decimals, keep but it will be treated as float; server will still recompute
  } else {
    qtyInput.step = "0.01";
    qtyInput.placeholder = "0.00";
  }

  applyPriceMode(tr);
}

function recalc(tr){
  tr.classList.remove('table-danger');
  const qty = Number(tr.querySelector('input[name="qty[]"]').value || 0);
  const prc = Number(tr.querySelector('input[name="unit_price[]"]').value || 0);
  const unit = tr.querySelector('select[name="unit_type[]"]').value;
  const prodSel = tr.querySelector('select[name="product_id[]"]');
  const opt = prodSel.options[prodSel.selectedIndex];

  const stock = Number(opt?.getAttribute('data-stock') || 0);
  const dstock = Number(opt?.getAttribute('data-dstock') || 0);
  const modeSel = tr.querySelector('select[name="price_mode[]"]');
  const mode = modeSel?.value || 'regular';
  const available = (mode === 'discounted') ? dstock : (stock - dstock);
  const w = Number(opt?.getAttribute('data-w') || 0);
  const requiredKg = (unit === 'sack') ? (qty * w) : qty;
  const line = qty * prc;

  tr.children[5].innerHTML = `<span class="fw-semibold">${peso(requiredKg)}</span>`;
  tr.children[6].innerHTML = `<span class="fw-bold">₱${peso(line)}</span>`;
  const note = tr.querySelector('.deduct-note');
  if(note){
    if(requiredKg <= 0){
      note.textContent = '';
    } else if(mode === 'discounted'){
      note.textContent = `From discounted: ${peso(requiredKg)} kg`;
    } else {
      note.textContent = `Deduct: ${peso(requiredKg)} kg`;
    }
  }

  if(requiredKg > available){
    tr.classList.add('table-danger');
  }
  recalcAll();
}

function recalcAll(){
  let subtotal = 0;
  let hasStockError = false;
  let hasAnyRow = false;
  let activeLines = 0;
  let hasDiscountedRow = false;
  document.querySelectorAll('#itemsTable tbody tr').forEach(tr => {
    const pid = Number(tr.querySelector('select[name="product_id[]"]').value || 0);
    const qty = Number(tr.querySelector('input[name="qty[]"]').value || 0);
    const prc = Number(tr.querySelector('input[name="unit_price[]"]').value || 0);
    const unit = tr.querySelector('select[name="unit_type[]"]').value;
    const prodSel = tr.querySelector('select[name="product_id[]"]');
    const opt = prodSel.options[prodSel.selectedIndex];
    const stock = Number(opt?.getAttribute('data-stock') || 0);
    const dstock = Number(opt?.getAttribute('data-dstock') || 0);
    const modeSel = tr.querySelector('select[name="price_mode[]"]');
    const mode = modeSel?.value || 'regular';
    if(mode === 'discounted' && pid > 0 && qty > 0){
      hasDiscountedRow = true;
    }
    const available = (mode === 'discounted') ? dstock : (stock - dstock);
    const w = Number(opt?.getAttribute('data-w') || 0);
    const requiredKg = (unit === 'sack') ? (qty * w) : qty;

    if(pid > 0 && qty > 0) hasAnyRow = true;
    if(pid > 0 && qty > 0) activeLines++;
    if(pid > 0 && qty > 0 && requiredKg > available) hasStockError = true;

    subtotal += qty * prc;
  });

  const dt = document.getElementById('discount_type').value;
  const rate = (dt === 'pwd' || dt === 'sc') ? 0.20 : 0.0;
  const disc = +(subtotal * rate).toFixed(2);
  const net  = Math.max(0, +(subtotal - disc).toFixed(2));

  const discountTypeSel = document.getElementById('discount_type');
  const discountFields = document.getElementById('discountFields');
  const customDiscountWrap = document.getElementById('customDiscountWrap');
  if(hasDiscountedRow){
    if(discountTypeSel && discountTypeSel.value !== 'none'){
      discountTypeSel.value = 'none';
    }
    if(discountFields) discountFields.classList.add('d-none');
    if(customDiscountWrap) customDiscountWrap.classList.add('d-none');
    const customDiscount = document.getElementById('discount_percent');
    if(customDiscount) customDiscount.value = '';
  } else {
    toggleDiscountFields();
  }

  document.getElementById('subTotal').innerText = peso(subtotal);
  document.getElementById('discountAmt').innerText = peso(disc);
  document.getElementById('grandTotal').innerText = peso(net);

  const warn = document.getElementById('stockWarningBox');
  const checkoutBtn = document.getElementById('checkoutBtn');
  const checkoutProxyBtn = document.getElementById('checkoutProxyBtn');
  const lineBadge = document.getElementById('lineCountBadge');
  if(hasStockError){
    warn.classList.remove('d-none');
    warn.innerText = "Some rows exceed available stock. Adjust quantity before checkout.";
  } else {
    warn.classList.add('d-none');
    warn.innerText = "";
  }

  if(checkoutBtn){
    checkoutBtn.disabled = hasStockError || !hasAnyRow || net <= 0;
  }
  if(checkoutProxyBtn){
    checkoutProxyBtn.disabled = hasStockError || !hasAnyRow || net <= 0;
  }
  if(lineBadge){
    lineBadge.textContent = `${activeLines} line(s)`;
  }
}

// Start with 1 row
addRow();
toggleDueDate();
toggleDiscountFields();
recalcAll();
updateCustomerBalanceHint();
ensureOptionsVisibility();

document.getElementById('checkoutProxyBtn')?.addEventListener('click', function(){
  const btn = document.getElementById('checkoutBtn');
  if(btn && !btn.disabled){
    btn.click();
  }
});

function pad2(n){ return String(n).padStart(2,'0'); }
function tickPosClock(){
  const now = new Date();
  const m = pad2(now.getMonth() + 1);
  const d = pad2(now.getDate());
  const y = now.getFullYear();
  const hh = pad2(now.getHours());
  const mm = pad2(now.getMinutes());
  const ss = pad2(now.getSeconds());
  const dateEl = document.getElementById('posDate');
  const timeEl = document.getElementById('posTime');
  if(dateEl) dateEl.textContent = `${m}-${d}-${y}`;
  if(timeEl) timeEl.textContent = `${hh}:${mm}:${ss}`;
}
tickPosClock();
setInterval(tickPosClock, 1000);
