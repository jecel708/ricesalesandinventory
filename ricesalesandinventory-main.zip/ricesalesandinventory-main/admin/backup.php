<?php
session_start();

$role = strtolower($_SESSION['role'] ?? '');

// ONLY Admin & Owner can access this page
if (!in_array($role, ['admin', 'owner'])) {
    header("HTTP/1.1 403 Forbidden");
    exit("Access Denied");
}

// DATABASE SETTINGS
$db_host = 'localhost';
$db_name = 'rice_inventory';
$db_user = 'root';
$db_pass = '';

$message = '';
$filename = '';

// When user clicks "Create & Download Backup"
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_backup'])) {

    try {
        // Connect to database
        $pdo = new PDO(
            "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4",
            $db_user,
            $db_pass
        );

        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Get all tables
        $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);

        // Build SQL content
        $sql = "-- Database Backup\n";
        $sql .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
        $sql .= "-- Database: $db_name\n";
        $sql .= "-- Created by: " . ucfirst($role) . "\n\n";

        foreach ($tables as $table) {

            $sql .= "-- Table: $table\n";
            $sql .= "DROP TABLE IF EXISTS `$table`;\n";

            // Table structure
            $stmt = $pdo->query("SHOW CREATE TABLE `$table`");
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            $sql .= $row['Create Table'] . ";\n\n";

            // Table data
            $rows = $pdo
                ->query("SELECT * FROM `$table`")
                ->fetchAll(PDO::FETCH_ASSOC);

            if (count($rows) > 0) {

                $columns = array_keys($rows[0]);

                $sql .= "INSERT INTO `$table` (`" .
                    implode("`, `", $columns) .
                    "`) VALUES\n";

                $valuesList = [];

                foreach ($rows as $r) {

                    $escaped = [];

                    foreach ($r as $val) {

                        if ($val === null) {
                            $escaped[] = 'NULL';
                        } else {
                            $escaped[] = "'" . addslashes($val) . "'";
                        }
                    }

                    $valuesList[] = "(" . implode(", ", $escaped) . ")";
                }

                $sql .= implode(",\n", $valuesList) . ";\n";
            }

            $sql .= "\n";
        }

        // Generate filename
        $filename =
            $db_name .
            '_backup_' .
            date('Y-m-d_His') .
            '.sql';

        // Download file directly
        header('Content-Type: application/octet-stream');
        header("Content-Disposition: attachment; filename=$filename");
        header('Content-Length: ' . strlen($sql));

        echo $sql;
        exit;

    } catch (Exception $e) {

        $message = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Database Backup</title>

    <!-- Bootstrap -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Font Awesome -->
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    >

    <style>

        :root {
            --primary: #2c3e50;
            --primary-light: #34495e;
            --accent: #3498db;
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
            --background: #edf1f5;
            --card: #ffffff;
            --border: #dfe5eb;
            --text: #2c3e50;
            --muted: #6c757d;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: var(--background);
            color: var(--text);
            font-family:
                "Segoe UI",
                Tahoma,
                Geneva,
                Verdana,
                sans-serif;
        }

        .page-wrapper {
            max-width: 1100px;
            margin: 0 auto;
            padding: 40px 20px 60px;
        }

        /* --------------------------------
           PAGE HEADER
        -------------------------------- */

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            margin-bottom: 28px;
        }

        .page-title {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .title-icon {
            width: 52px;
            height: 52px;
            border-radius: 12px;
            background: #eaf3fb;
            color: var(--accent);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }

        .page-title h2 {
            margin: 0;
            font-size: 25px;
            font-weight: 700;
            color: var(--primary);
        }

        .page-title p {
            margin: 4px 0 0;
            color: var(--muted);
            font-size: 14px;
        }

        .role-badge {
            background: #eef2f5;
            border: 1px solid var(--border);
            color: var(--primary);
            padding: 8px 13px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
        }

        /* --------------------------------
           CARDS
        -------------------------------- */

        .backup-card {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 14px;
            box-shadow: 0 4px 15px rgba(44, 62, 80, 0.06);
            overflow: hidden;
            margin-bottom: 22px;
        }

        .card-heading {
            padding: 20px 24px;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
        }

        .heading-left {
            display: flex;
            align-items: center;
            gap: 13px;
        }

        .heading-icon {
            width: 42px;
            height: 42px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 17px;
        }

        .manual-icon {
            background: #eaf3fb;
            color: var(--accent);
        }

        .automatic-icon {
            background: #eaf7ef;
            color: var(--success);
        }

        .heading-text h5 {
            margin: 0;
            font-weight: 700;
            color: var(--primary);
            font-size: 17px;
        }

        .heading-text span {
            font-size: 13px;
            color: var(--muted);
        }

        .card-content {
            padding: 24px;
        }

        /* --------------------------------
           INFO BOX
        -------------------------------- */

        .info-box {
            display: flex;
            align-items: flex-start;
            gap: 13px;
            padding: 16px;
            background: #f5f9fc;
            border: 1px solid #dceaf4;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .info-box i {
            color: var(--accent);
            margin-top: 2px;
        }

        .info-box strong {
            display: block;
            color: var(--primary);
            margin-bottom: 3px;
        }

        .info-box p {
            margin: 0;
            font-size: 13px;
            color: var(--muted);
            line-height: 1.5;
        }

        /* --------------------------------
           BACKUP BUTTON
        -------------------------------- */

        .backup-button {
            height: 50px;
            border: none;
            border-radius: 9px;
            background: var(--primary);
            color: white;
            font-weight: 600;
            transition: 0.2s ease;
        }

        .backup-button:hover {
            background: var(--primary-light);
            transform: translateY(-1px);
        }

        /* --------------------------------
           AUTOMATIC BACKUP
        -------------------------------- */

        .schedule-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .schedule-status {
            display: flex;
            align-items: center;
            gap: 9px;
            font-size: 13px;
            color: var(--muted);
        }

        /* Toggle */

        .switch {
            position: relative;
            width: 48px;
            height: 26px;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            inset: 0;
            background: #cbd3da;
            border-radius: 30px;
            transition: 0.25s;
        }

        .slider:before {
            content: "";
            position: absolute;
            width: 20px;
            height: 20px;
            left: 3px;
            top: 3px;
            background: white;
            border-radius: 50%;
            transition: 0.25s;
            box-shadow: 0 1px 3px rgba(0,0,0,.2);
        }

        .switch input:checked + .slider {
            background: var(--success);
        }

        .switch input:checked + .slider:before {
            transform: translateX(22px);
        }

        .schedule-fields {
            display: grid;
            grid-template-columns: 1.2fr 1fr 1fr;
            gap: 18px;
        }

        .form-label {
            font-size: 13px;
            font-weight: 600;
            color: var(--primary);
            margin-bottom: 7px;
        }

        .input-wrapper {
            position: relative;
        }

        .input-wrapper i {
            position: absolute;
            left: 13px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--muted);
            pointer-events: none;
            z-index: 2;
        }

        .form-control,
        .form-select {
            height: 46px;
            border: 1px solid #d5dde4;
            border-radius: 8px;
            font-size: 14px;
            color: var(--text);
            box-shadow: none !important;
        }

        .input-wrapper .form-control {
            padding-left: 39px;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: var(--accent);
        }

        /* --------------------------------
           NEXT BACKUP
        -------------------------------- */

        .next-backup {
            margin-top: 22px;
            padding: 18px;
            border-radius: 10px;
            background: #f7fbf8;
            border: 1px solid #d9eee1;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .next-icon {
            width: 42px;
            height: 42px;
            border-radius: 9px;
            background: #e4f4ea;
            color: var(--success);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .next-backup small {
            display: block;
            color: var(--muted);
            font-size: 12px;
            margin-bottom: 3px;
        }

        .next-backup strong {
            font-size: 14px;
            color: var(--primary);
        }

        /* --------------------------------
           SCHEDULE BUTTON
        -------------------------------- */

        .schedule-actions {
            display: flex;
            justify-content: flex-end;
            margin-top: 22px;
        }

        .save-button {
            border: none;
            border-radius: 8px;
            padding: 11px 20px;
            background: var(--success);
            color: white;
            font-size: 14px;
            font-weight: 600;
        }

        .save-button:hover {
            background: #219653;
        }

        /* --------------------------------
           SECURITY NOTE
        -------------------------------- */

        .security-note {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--muted);
            font-size: 12px;
            margin-top: 15px;
        }

        .security-note i {
            color: var(--success);
        }

        /* --------------------------------
           FOOTER
        -------------------------------- */

        .page-footer {
            text-align: center;
            margin-top: 25px;
        }

        .back-link {
            color: var(--muted);
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
        }

        .back-link:hover {
            color: var(--primary);
        }

        /* --------------------------------
           DISABLED STATE
        -------------------------------- */

        .schedule-disabled {
            opacity: 0.55;
            pointer-events: none;
        }

        /* --------------------------------
           RESPONSIVE
        -------------------------------- */

        @media (max-width: 768px) {

            .page-wrapper {
                padding: 25px 15px 40px;
            }

            .page-header {
                align-items: flex-start;
            }

            .role-badge {
                display: none;
            }

            .schedule-fields {
                grid-template-columns: 1fr;
            }

            .card-heading,
            .card-content {
                padding: 18px;
            }

            .schedule-header {
                align-items: flex-start;
            }
        }

    </style>

</head>

<body>

<div class="page-wrapper">

    <!-- PAGE HEADER -->

    <div class="page-header">

        <div class="page-title">

            <div class="title-icon">
                <i class="fas fa-database"></i>
            </div>

            <div>
                <h2>Database Backup</h2>

                <p>
                    Protect and manage your system database backups.
                </p>
            </div>

        </div>

        <div class="role-badge">
            <i class="fas fa-user-shield me-1"></i>
            <?= htmlspecialchars(ucfirst($role)) ?>
        </div>

    </div>


    <!-- ERROR MESSAGE -->

    <?php if ($message): ?>

        <div class="alert alert-danger border-0 shadow-sm mb-4">

            <i class="fas fa-circle-exclamation me-2"></i>

            <?= htmlspecialchars($message) ?>

        </div>

    <?php endif; ?>


    <!-- =========================
         MANUAL BACKUP
    ========================== -->

    <div class="backup-card">

        <div class="card-heading">

            <div class="heading-left">

                <div class="heading-icon manual-icon">
                    <i class="fas fa-download"></i>
                </div>

                <div class="heading-text">

                    <h5>Manual Backup</h5>

                    <span>
                        Create a complete database backup now
                    </span>

                </div>

            </div>

        </div>


        <div class="card-content">

            <div class="info-box">

                <i class="fas fa-circle-info"></i>

                <div>

                    <strong>Full Database Backup</strong>

                    <p>
                        This creates an SQL copy of your database,
                        including its tables, structure, and stored data.
                        The backup will be downloaded to your computer.
                    </p>

                </div>

            </div>


            <form method="POST">

                <button
                    type="submit"
                    name="create_backup"
                    class="btn backup-button w-100"
                >

                    <i class="fas fa-file-export me-2"></i>

                    Create & Download Backup

                </button>

            </form>


            <div class="security-note">

                <i class="fas fa-shield-halved"></i>

                <span>
                    Safe operation — creating a backup does not modify
                    or delete your existing database.
                </span>

            </div>

        </div>

    </div>


    <!-- =========================
         AUTOMATIC BACKUP
    ========================== -->

    <div class="backup-card">

        <div class="card-heading">

            <div class="heading-left">

                <div class="heading-icon automatic-icon">
                    <i class="fas fa-calendar-days"></i>
                </div>

                <div class="heading-text">

                    <h5>Automatic Backup</h5>

                    <span>
                        Schedule when backups should be created
                    </span>

                </div>

            </div>

        </div>


        <div class="card-content">

            <!-- Schedule Header -->

            <div class="schedule-header">

                <div>

                    <div class="fw-semibold">
                        Backup Schedule
                    </div>

                    <div class="text-muted small mt-1">
                        Turn on scheduling to configure automatic backups.
                    </div>

                </div>


                <div class="schedule-status">

                    <span id="scheduleStatus">
                        Disabled
                    </span>

                    <label class="switch">

                        <input
                            type="checkbox"
                            id="automaticBackup"
                        >

                        <span class="slider"></span>

                    </label>

                </div>

            </div>


            <!-- Schedule Fields -->

            <div
                id="scheduleFields"
                class="schedule-disabled"
            >

                <div class="schedule-fields">

                    <!-- START DATE -->

                    <div>

                        <label class="form-label">
                            Start Date
                        </label>

                        <div class="input-wrapper">

                            <i class="fas fa-calendar"></i>

                            <input
                                type="date"
                                id="startDate"
                                class="form-control"
                            >

                        </div>

                    </div>


                    <!-- TIME -->

                    <div>

                        <label class="form-label">
                            Backup Time
                        </label>

                        <div class="input-wrapper">

                            <i class="fas fa-clock"></i>

                            <input
                                type="time"
                                id="backupTime"
                                class="form-control"
                                value="23:00"
                            >

                        </div>

                    </div>


                    <!-- FREQUENCY -->

                    <div>

                        <label class="form-label">
                            Frequency
                        </label>

                        <div class="input-wrapper">

                            <i class="fas fa-repeat"></i>

                            <select
                                id="frequency"
                                class="form-select"
                                style="padding-left:39px;"
                            >

                                <option value="daily">
                                    Daily
                                </option>

                                <option value="weekly" selected>
                                    Weekly
                                </option>

                                <option value="monthly">
                                    Monthly
                                </option>

                            </select>

                        </div>

                    </div>

                </div>


                <!-- NEXT BACKUP -->

                <div class="next-backup">

                    <div class="next-icon">

                        <i class="fas fa-calendar-check"></i>

                    </div>

                    <div>

                        <small>
                            Next Scheduled Backup
                        </small>

                        <strong id="nextBackup">
                            Select a start date
                        </strong>

                    </div>

                </div>


                <!-- SAVE -->

                <div class="schedule-actions">

                    <button
                        type="button"
                        class="save-button"
                        id="saveSchedule"
                    >

                        <i class="fas fa-check me-2"></i>

                        Save Schedule

                    </button>

                </div>

            </div>

        </div>

    </div>


    <!-- FOOTER -->

    <div class="page-footer">

        <a
            href="dashboard.php"
            class="back-link"
        >

            <i class="fas fa-arrow-left me-1"></i>

            Back to Dashboard

        </a>

    </div>

</div>


<script>

    const automaticBackup =
        document.getElementById('automaticBackup');

    const scheduleFields =
        document.getElementById('scheduleFields');

    const scheduleStatus =
        document.getElementById('scheduleStatus');

    const startDate =
        document.getElementById('startDate');

    const backupTime =
        document.getElementById('backupTime');

    const frequency =
        document.getElementById('frequency');

    const nextBackup =
        document.getElementById('nextBackup');


    /*
     * SET DEFAULT DATE
     */

    const today = new Date();

    const year = today.getFullYear();

    const month =
        String(today.getMonth() + 1).padStart(2, '0');

    const day =
        String(today.getDate()).padStart(2, '0');

    startDate.min =
        `${year}-${month}-${day}`;


    /*
     * AUTOMATIC BACKUP TOGGLE
     */

    automaticBackup.addEventListener('change', function () {

        if (this.checked) {

            scheduleFields.classList.remove(
                'schedule-disabled'
            );

            scheduleStatus.textContent =
                'Enabled';

            scheduleStatus.style.color =
                '#27ae60';

            updateNextBackup();

        } else {

            scheduleFields.classList.add(
                'schedule-disabled'
            );

            scheduleStatus.textContent =
                'Disabled';

            scheduleStatus.style.color =
                '';

        }

    });


    /*
     * UPDATE NEXT BACKUP
     */

    function updateNextBackup() {

        if (!startDate.value) {

            nextBackup.textContent =
                'Select a start date';

            return;
        }

        const selectedDate =
            new Date(startDate.value + 'T00:00:00');

        const time =
            backupTime.value || '23:00';

        const frequencyValue =
            frequency.value;


        /*
         * If the selected date is in the past,
         * calculate the next available occurrence.
         */

        const now = new Date();

        let nextDate =
            new Date(selectedDate);


        if (frequencyValue === 'daily') {

            while (nextDate < now) {

                nextDate.setDate(
                    nextDate.getDate() + 1
                );

            }

        }


        if (frequencyValue === 'weekly') {

            while (nextDate < now) {

                nextDate.setDate(
                    nextDate.getDate() + 7
                );

            }

        }


        if (frequencyValue === 'monthly') {

            while (nextDate < now) {

                nextDate.setMonth(
                    nextDate.getMonth() + 1
                );

            }

        }


        /*
         * Format date
         */

        const formattedDate =
            nextDate.toLocaleDateString(
                'en-US',
                {
                    month: 'long',
                    day: 'numeric',
                    year: 'numeric'
                }
            );


        /*
         * Convert time
         */

        let [hours, minutes] =
            time.split(':');

        hours = parseInt(hours);

        const ampm =
            hours >= 12 ? 'PM' : 'AM';

        hours =
            hours % 12 || 12;

        const formattedTime =
            `${hours}:${minutes} ${ampm}`;


        nextBackup.textContent =
            `${formattedDate} • ${formattedTime}`;

    }


    /*
     * UPDATE WHEN FIELDS CHANGE
     */

    startDate.addEventListener(
        'change',
        updateNextBackup
    );

    backupTime.addEventListener(
        'change',
        updateNextBackup
    );

    frequency.addEventListener(
        'change',
        updateNextBackup
    );


    /*
     * SAVE SCHEDULE UI
     */

    document
        .getElementById('saveSchedule')
        .addEventListener('click', function () {

            if (!automaticBackup.checked) {

                alert(
                    'Please enable Automatic Backup first.'
                );

                return;
            }


            if (!startDate.value) {

                alert(
                    'Please select a start date.'
                );

                startDate.focus();

                return;
            }


            alert(
                'Backup schedule selected successfully.'
            );

        });

</script>


</body>
</html>