<?php
session_start();
if(!isset($_SESSION['user_id'])){ header("Location: ../login.php"); exit; }
if(strtolower($_SESSION['role'] ?? '') !== 'admin'){ header("Location: ../login.php"); exit; }
include '../config/db.php';
require_once '../includes/mfa.php';
$user_id = (int)$_SESSION['user_id'];
$success = $error = "";

if(isset($_POST['update_profile'])){
    $first = trim($_POST['first_name'] ?? '');
    $last = trim($_POST['last_name'] ?? '');
    $displayName = trim($_POST['display_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim(strtolower((string)($_POST['email'] ?? '')));
    if($first === '' || $last === '' || $displayName === ''){
        $error = "Display name, first name, and last name are required.";
    } elseif($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)){
        $error = "A valid email is required.";
    } else {
        $chk = $conn->prepare("SELECT user_id FROM users WHERE LOWER(email)=LOWER(?) AND user_id<>? LIMIT 1");
        if($chk){
            $chk->bind_param("si", $email, $user_id);
            $chk->execute();
            $dup = $chk->get_result()->fetch_assoc();
            $chk->close();
            if($dup){
                $error = "Email already exists. Please use another email.";
            }
        }
        if($error === ""){
            $stmt = $conn->prepare("UPDATE users SET display_name=?, first_name=?, last_name=?, phone=?, email=? WHERE user_id=?");
            $stmt->bind_param("sssssi", $displayName, $first, $last, $phone, $email, $user_id);
            $stmt->execute();
            $stmt->close();
            $_SESSION['username'] = $_SESSION['username'];
            $success = "Profile updated successfully.";
        }
    }
}

$stmt = $conn->prepare("SELECT username, display_name, first_name, last_name, phone, email, role, created_at FROM users WHERE user_id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (empty($user['display_name'])) {
    $user['display_name'] = trim((string)($user['first_name'] ?? '') . ' ' . (string)($user['last_name'] ?? ''));
}

if(isset($_POST['request_password_change_otp'])){
    $current = $_POST['current_password'] ?? '';
    $new1 = $_POST['new_password'] ?? '';
    $new2 = $_POST['confirm_password'] ?? '';
    if($new1 === '' || $new2 === '' || $current === ''){
        $error = "Please fill up all password fields.";
    } elseif($new1 !== $new2){
        $error = "New password and confirm password do not match.";
    } elseif(strlen($new1) < 6){
        $error = "New password must be at least 6 characters.";
    } else {
        $stmt = $conn->prepare("SELECT password, email FROM users WHERE user_id=? LIMIT 1");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $cred = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $hash = $cred['password'] ?? '';
        $email = trim((string)($cred['email'] ?? ''));
        if(!$hash || !password_verify($current, $hash)){
            $error = "Current password is incorrect.";
        } elseif($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)){
            $error = "No valid email found for your account. Please update your email first.";
        } else {
            $pendingHash = password_hash($new1, PASSWORD_DEFAULT);
            if($pendingHash === false){
                $error = "Unable to prepare password update. Try again.";
            } elseif(!mfa_send_otp_for_user($conn, $user_id, $email)){
                $error = "Unable to send OTP email right now. Please try again.";
            } else {
                $_SESSION['admin_pwd_change_pending'] = true;
                $_SESSION['admin_pwd_change_hash'] = $pendingHash;
                $_SESSION['admin_pwd_change_requested_at'] = time();
                $success = "OTP sent to your email. Enter it below to finish password change.";
            }
        }
    }
}

if(isset($_POST['verify_password_change_otp'])){
    $otp = trim((string)($_POST['otp'] ?? ''));
    $pending = (bool)($_SESSION['admin_pwd_change_pending'] ?? false);
    $pendingHash = (string)($_SESSION['admin_pwd_change_hash'] ?? '');
    if(!$pending || $pendingHash === ''){
        $error = "No pending password change request. Please start again.";
    } elseif(!preg_match('/^[0-9]{6}$/', $otp)){
        $error = "Enter a valid 6-digit OTP code.";
    } else {
        $stmt = $conn->prepare("SELECT id, otp_hash, expires_at, attempts, max_attempts, used_at FROM user_email_otp_challenges WHERE user_id=? ORDER BY id DESC LIMIT 1");
        if(!$stmt){
            $error = "Server error while validating OTP.";
        } else {
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $challenge = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if(!$challenge){
                $error = "No OTP challenge found. Please request a new OTP.";
            } elseif(!empty($challenge['used_at'])){
                $error = "This OTP has already been used. Please request a new OTP.";
            } elseif(strtotime((string)$challenge['expires_at']) < time()){
                $error = "OTP expired. Please request a new OTP.";
            } else {
                $attempts = (int)($challenge['attempts'] ?? 0);
                $maxAttempts = (int)($challenge['max_attempts'] ?? 5);
                if($attempts >= $maxAttempts){
                    $error = "Too many attempts. Please request a new OTP.";
                } elseif(!password_verify($otp, (string)$challenge['otp_hash'])){
                    $up = $conn->prepare("UPDATE user_email_otp_challenges SET attempts=attempts+1 WHERE id=?");
                    if($up){
                        $cid = (int)$challenge['id'];
                        $up->bind_param("i", $cid);
                        $up->execute();
                        $up->close();
                    }
                    $left = max(0, $maxAttempts - ($attempts + 1));
                    $error = "Incorrect OTP. {$left} attempt(s) left.";
                } else {
                    $cid = (int)$challenge['id'];
                    $mark = $conn->prepare("UPDATE user_email_otp_challenges SET used_at=NOW() WHERE id=?");
                    if($mark){
                        $mark->bind_param("i", $cid);
                        $mark->execute();
                        $mark->close();
                    }
                    $stmt = $conn->prepare("UPDATE users SET password=? WHERE user_id=?");
                    $stmt->bind_param("si", $pendingHash, $user_id);
                    $stmt->execute();
                    $stmt->close();
                    $wipe = $conn->prepare("DELETE FROM user_trusted_devices WHERE user_id=?");
                    if($wipe){
                        $wipe->bind_param("i", $user_id);
                        $wipe->execute();
                        $wipe->close();
                    }
                    mfa_clear_trusted_cookie();
                    if($conn->query("SHOW TABLES LIKE 'activity_logs'")->num_rows > 0){
                        $type = "PASSWORD_CHANGE";
                        $desc = "Changed admin password with OTP verification and revoked trusted devices";
                        $log = $conn->prepare("INSERT INTO activity_logs (user_id, activity_type, description, created_at) VALUES (?,?,?,NOW())");
                        if($log){
                            $log->bind_param("iss", $user_id, $type, $desc);
                            $log->execute();
                            $log->close();
                        }
                    }
                    unset($_SESSION['admin_pwd_change_pending'],$_SESSION['admin_pwd_change_hash'],$_SESSION['admin_pwd_change_requested_at']);
                    $success = "Password changed successfully. Trusted devices were revoked.";
                }
            }
        }
    }
}

if(isset($_POST['resend_password_change_otp'])){
    $pending = (bool)($_SESSION['admin_pwd_change_pending'] ?? false);
    $pendingHash = (string)($_SESSION['admin_pwd_change_hash'] ?? '');
    if(!$pending || $pendingHash === ''){
        $error = "No pending password change request. Please start again.";
    } else {
        $stmt = $conn->prepare("SELECT email FROM users WHERE user_id=? LIMIT 1");
        if($stmt){
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $cred = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            $email = trim((string)($cred['email'] ?? ''));
            if($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)){
                $error = "No valid email found for your account. Please update your email first.";
            } elseif(!mfa_send_otp_for_user($conn, $user_id, $email)){
                $error = "Unable to resend OTP email right now. Please try again.";
            } else {
                $_SESSION['admin_pwd_change_requested_at'] = time();
                $success = "A new OTP has been sent to your email.";
            }
        } else {
            $error = "Server error while preparing OTP resend.";
        }
    }
}

if(isset($_POST['cancel_password_change'])){
    unset($_SESSION['admin_pwd_change_pending'],$_SESSION['admin_pwd_change_hash'],$_SESSION['admin_pwd_change_requested_at']);
    $success = "Pending password change canceled.";
}

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$pendingPwdChange = (bool)($_SESSION['admin_pwd_change_pending'] ?? false);
$trustedDeviceExpiry = null;
try {
    if (isset($conn) && $conn instanceof mysqli) {
        $trustedDeviceExpiry = mfa_get_trusted_device_expiry($conn, $user_id);
    }
} catch (Throwable $e) {
    $trustedDeviceExpiry = null;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin Profile</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="../css/admin-mobile.css" rel="stylesheet">
<link href="../css/admin-profile.css" rel="stylesheet">
<style>
.strength-container { margin-top: 0.5rem; margin-bottom: 0.25rem; }
.strength-bar { height: 8px; border-radius: 4px; background: #e9ecef; overflow: hidden; }
.strength-fill { height: 100%; width: 0%; border-radius: 4px; transition: all 0.3s ease; }
.strength-text { font-size: 0.85rem; font-weight: 500; margin-top: 0.25rem; }
.strength-weak { background-color: #dc3545; width: 25%; }
.strength-fair { background-color: #ffc107; width: 50%; }
.strength-good { background-color: #0dcaf0; width: 75%; }
.strength-strong { background-color: #198754; width: 100%; }
.requirement-list { list-style: none; padding: 0; margin: 0.5rem 0; font-size: 0.85rem; }
.requirement-list li { padding: 0.15rem 0; }
.requirement-list li i { margin-right: 0.5rem; font-size: 0.9rem; }
.req-pass { color: #198754; }
.req-fail { color: #6c757d; }
.match-text { font-size: 0.85rem; margin-top: 0.25rem; }
.match-yes { color: #198754; }
.match-no { color: #dc3545; }
.password-wrapper { position: relative; }
.password-wrapper .password-toggle {
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    color: #6c757d;
    font-size: 18px;
    user-select: none;
}
</style>
</head>
<body>
<?php
$username = $_SESSION['username'] ?? ($user['username'] ?? 'User');
$profileLink = 'profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>
<main class="container main-content">
<div class="row justify-content-center">
<div class="col-lg-6">
<div class="card modern-card mb-4">
<div class="panel-head">
<div class="user-avatar"><i class="fa-solid fa-user"></i></div>
<h4 class="fw-bold mb-1">Admin Profile</h4>
<div class="small text-muted">Manage your account details and security settings.</div>
</div>
<div class="panel-body">
<?php if($success): ?><div class="alert alert-success"><?= h($success) ?></div><?php endif; ?>
<?php if($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>
<form method="POST">
<div class="mb-3">
<label class="form-label">Username</label>
<input class="form-control" value="<?= h($user['username']) ?>" disabled>
</div>
<div class="mb-3">
<label class="form-label">Display Name <span class="text-danger">*</span></label>
<input class="form-control" name="display_name" value="<?= h($user['display_name'] ?? '') ?>" maxlength="100" required>
</div>
<div class="row g-3">
<div class="col-md-6">
<label class="form-label">First Name <span class="text-danger">*</span></label>
<input class="form-control" name="first_name" value="<?= h($user['first_name']) ?>" required>
</div>
<div class="col-md-6">
<label class="form-label">Last Name <span class="text-danger">*</span></label>
<input class="form-control" name="last_name" value="<?= h($user['last_name']) ?>" required>
</div>
</div>
<div class="mb-3 mt-3">
<label class="form-label">Phone</label>
<input class="form-control" name="phone" value="<?= h($user['phone']) ?>">
</div>
<div class="mb-3">
<label class="form-label">Email <span class="text-danger">*</span></label>
<input type="email" class="form-control" name="email" value="<?= h($user['email'] ?? '') ?>" required>
</div>
<div class="row g-3 mt-1">
<div class="col-md-6">
<label class="form-label">Role</label>
<input class="form-control" value="<?= strtoupper($user['role']) ?>" disabled>
</div>
<div class="col-md-6">
<label class="form-label">Account Created</label>
<input class="form-control" value="<?= date("M d, Y", strtotime($user['created_at'])) ?>" disabled>
</div>
</div>
<div class="profile-meta">
  <span class="profile-badge">MFA Enabled</span>
  <span class="profile-badge">Role: <?= h(strtoupper((string)$user['role'])) ?></span>
  <?php if (is_array($trustedDeviceExpiry) && ($trustedDeviceExpiry['days_left'] ?? 0) > 0): ?>
    <span class="profile-badge" style="border:1px solid #dc3545;color:#dc3545;padding:6px 10px;border-radius:20px;font-weight:700;margin-left:8px;">
      Expires in <?= (int)$trustedDeviceExpiry['days_left'] ?> Day<?= ((int)$trustedDeviceExpiry['days_left'] === 1) ? '' : 's' ?>
    </span>
  <?php endif; ?>
</div>
<button class="btn btn-dark w-100 mt-4" name="update_profile">
<i class="fa-solid fa-save me-1"></i> Save Changes
</button>
</form>
</div>
</div>
<div class="card modern-card">
<div class="panel-head">
<h5 class="fw-bold mb-1"><i class="fa-solid fa-key me-2"></i>Change Password</h5>
<div class="small text-muted">OTP verification is required to complete password updates.</div>
</div>
<div class="panel-body">
<?php if(!$pendingPwdChange): ?>
<form method="POST" id="passwordChangeForm">
  <!-- CURRENT PASSWORD WITH EYE ICON -->
  <div class="mb-3 password-wrapper">
    <label class="form-label">Current Password <span class="text-danger">*</span></label>
    <input type="password" class="form-control" name="current_password" id="current_password" required>
    <span class="password-toggle" data-target="current_password" aria-label="Toggle password">
      <i class="fa-solid fa-eye"></i>
    </span>
  </div>

  <!-- NEW PASSWORD WITH EYE ICON + STRENGTH INDICATOR -->
  <div class="mb-3 password-wrapper">
    <label class="form-label">New Password <span class="text-danger">*</span></label>
    <input type="password" class="form-control" name="new_password" id="new_password" minlength="6" required oninput="checkPasswordStrength(this.value)">
    <span class="password-toggle" data-target="new_password" aria-label="Toggle password">
      <i class="fa-solid fa-eye"></i>
    </span>
    
    <div class="strength-container">
      <div class="strength-bar"><div id="strengthFill" class="strength-fill"></div></div>
      <div id="strengthText" class="strength-text text-muted">Start typing a password...</div>
    </div>

    <ul class="requirement-list">
      <li id="req-length" data-label="At least 6 characters" class="req-fail"><i class="fa-solid fa-circle-xmark"></i> At least 6 characters</li>
      <li id="req-upper" data-label="One uppercase letter (A-Z)" class="req-fail"><i class="fa-solid fa-circle-xmark"></i> One uppercase letter (A-Z)</li>
      <li id="req-lower" data-label="One lowercase letter (a-z)" class="req-fail"><i class="fa-solid fa-circle-xmark"></i> One lowercase letter (a-z)</li>
      <li id="req-number" data-label="One number (0-9)" class="req-fail"><i class="fa-solid fa-circle-xmark"></i> One number (0-9)</li>
      <li id="req-special" data-label="One special character (!@#$%^&* etc.)" class="req-fail"><i class="fa-solid fa-circle-xmark"></i> One special character (!@#$%^&* etc.)</li>
    </ul>
  </div>

  <!-- CONFIRM PASSWORD WITH EYE ICON + MATCH CHECK -->
  <div class="mb-3 password-wrapper">
    <label class="form-label">Confirm New Password <span class="text-danger">*</span></label>
    <input type="password" class="form-control" name="confirm_password" id="confirm_password" required oninput="checkPasswordMatch()">
    <span class="password-toggle" data-target="confirm_password" aria-label="Toggle password">
      <i class="fa-solid fa-eye"></i>
    </span>
    <div id="matchText" class="match-text"></div>
  </div>

  <button class="btn btn-outline-dark w-100" name="request_password_change_otp" value="1" id="submitBtn">
    <i class="fa-solid fa-paper-plane me-1"></i> Send OTP and Continue
  </button>
</form>
<?php else: ?>
<form method="POST" class="mb-2">
  <div class="mb-3">
    <label class="form-label">Enter OTP from Email <span class="text-danger">*</span></label>
    <input type="text" class="form-control" name="otp" maxlength="6" pattern="[0-9]{6}" placeholder="123456" required>
    <div class="form-text">OTP expires in 5 minutes.</div>
  </div>
  <button class="btn btn-dark w-100" name="verify_password_change_otp" value="1">
    <i class="fa-solid fa-shield-halved me-1"></i> Verify OTP and Update Password
  </button>
</form>
<form method="POST" class="mb-2">
  <button class="btn btn-outline-primary w-100" name="resend_password_change_otp" value="1">
    <i class="fa-solid fa-rotate-right me-1"></i> Request New Code
  </button>
</form>
<form method="POST">
  <button class="btn btn-outline-secondary w-100" name="cancel_password_change" value="1">
    Cancel Pending Password Change
  </button>
</form>
<?php endif; ?>
</div>
</div>
</div>
</div>
</main>

<!-- ===== JAVASCRIPT ===== -->
<script>
document.querySelectorAll('.password-toggle').forEach(function(btn){
  btn.addEventListener('click', function(){
    const id = btn.getAttribute('data-target');
    const input = document.getElementById(id);
    if(!input) return;
    const icon = btn.querySelector('i');
    if(input.type === 'password'){
      input.type = 'text';
      if(icon){ icon.classList.remove('fa-eye'); icon.classList.add('fa-eye-slash'); }
    } else {
      input.type = 'password';
      if(icon){ icon.classList.remove('fa-eye-slash'); icon.classList.add('fa-eye'); }
    }
  });
});

// ===== PASSWORD STRENGTH CHECK =====
function checkPasswordStrength(pwd) {
  const fill = document.getElementById('strengthFill');
  const text = document.getElementById('strengthText');
  if(!fill || !text) return;

  const hasLength = pwd.length >= 6;
  const hasUpper = /[A-Z]/.test(pwd);
  const hasLower = /[a-z]/.test(pwd);
  const hasNumber = /[0-9]/.test(pwd);
  const hasSpecial = /[^A-Za-z0-9]/.test(pwd);

  updateReq(document.getElementById('req-length'), hasLength);
  updateReq(document.getElementById('req-upper'), hasUpper);
  updateReq(document.getElementById('req-lower'), hasLower);
  updateReq(document.getElementById('req-number'), hasNumber);
  updateReq(document.getElementById('req-special'), hasSpecial);

  const score = [hasLength, hasUpper, hasLower, hasNumber, hasSpecial].filter(Boolean).length;
  fill.className = 'strength-fill';

  if (pwd.length === 0) {
    fill.style.width = '0%';
    text.textContent = 'Start typing a password...';
    text.className = 'strength-text text-muted';
  } else if (score <= 2) {
    fill.classList.add('strength-weak');
    text.textContent = 'Weak - add more variety';
    text.className = 'strength-text text-danger';
  } else if (score === 3) {
    fill.classList.add('strength-fair');
    text.textContent = 'Fair - could be stronger';
    text.className = 'strength-text text-warning';
  } else if (score === 4) {
    fill.classList.add('strength-good');
    text.textContent = 'Good password';
    text.className = 'strength-text text-info';
  } else {
    fill.classList.add('strength-strong');
    text.textContent = 'Strong password!';
    text.className = 'strength-text text-success';
  }

  checkPasswordMatch();
}

function updateReq(el, passed) {
  if(!el) return;
  const label = el.getAttribute('data-label') || el.textContent.trim();
  if (passed) {
    el.classList.remove('req-fail');
    el.classList.add('req-pass');
    el.innerHTML = '<i class="fa-solid fa-circle-check"></i> ' + label;
  } else {
    el.classList.remove('req-pass');
    el.classList.add('req-fail');
    el.innerHTML = '<i class="fa-solid fa-circle-xmark"></i> ' + label;
  }
}

// ===== PASSWORD MATCH CHECK =====
function checkPasswordMatch() {
  const p1 = document.getElementById('new_password');
  const p2 = document.getElementById('confirm_password');
  const matchText = document.getElementById('matchText');
  if(!p1 || !p2 || !matchText) return;
  
  if (p2.value.length === 0) {
    matchText.textContent = '';
    return;
  }

  if (p1.value === p2.value) {
    matchText.innerHTML = '<span class="match-yes"><i class="fa-solid fa-check"></i> Passwords match</span>';
  } else {
    matchText.innerHTML = '<span class="match-no"><i class="fa-solid fa-xmark"></i> Passwords do not match</span>';
  }
}

document.addEventListener('DOMContentLoaded', function(){
  const newPassword = document.getElementById('new_password');
  if(newPassword) checkPasswordStrength(newPassword.value || '');
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
