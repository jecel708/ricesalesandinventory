<?php
session_start();
$role = strtolower($_SESSION['role'] ?? '');

if ($role !== 'admin') {
    header("HTTP/1.1 403 Forbidden");
    exit("Access Denied — Administrators only");
}

$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "rice_inventory";

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['confirm_first']) || !isset($_POST['confirm_second'])) {
        $message = "⚠️ You must confirm both checkboxes to proceed!";
        $messageType = "warning";
    } elseif (!isset($_FILES['backup_file']) || $_FILES['backup_file']['error'] !== UPLOAD_ERR_OK) {
        $message = "❌ Please select a valid backup file (.sql)";
        $messageType = "danger";
    } else {
        try {
            $sqlFile = $_FILES['backup_file']['tmp_name'];
            $sqlContent = file_get_contents($sqlFile);
            if (!$sqlContent) throw new Exception("File is empty or invalid");

            $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $statements = preg_split('/;\s*\n/', $sqlContent);
            $executed = 0;
            foreach ($statements as $stmt) {
                $stmt = trim($stmt);
                if ($stmt === '' || str_starts_with($stmt, '--') || str_starts_with($stmt, '/*')) continue;
                $pdo->exec($stmt);
                $executed++;
            }

            $message = "✅ RESTORE SUCCESSFUL! $executed SQL statements executed. Database restored from backup.";
            $messageType = "success";
        } catch (Exception $e) {
            $message = "❌ Restore FAILED: " . $e->getMessage();
            $messageType = "danger";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Restore — Rice Inventory System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg-page: #edf2f7;
            --card-bg: #ffffff;
            --card-shadow: 0 2px 12px rgba(0,0,0,0.06);
            --card-radius: 16px;
            --btn-dark: #1e293b;
            --btn-dark-hover: #0f172a;
            --info-bg: #eff6ff;
            --danger-bg: #fef2f2;
            --accent-red: #dc2626;
            --accent-blue: #3b82f6;
            --accent-green: #10b981;
            --text-muted: #64748b;
        }
        body {
            background-color: var(--bg-page);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        .page-header {
            padding: 2rem 0 1.5rem;
        }
        .page-title {
            font-size: 1.75rem;
            font-weight: 700;
            color: #1e293b;
        }
        .page-subtitle {
            color: var(--text-muted);
            font-size: 0.95rem;
        }
        .admin-badge {
            background: #e2e8f0;
            color: #334155;
            font-size: 0.85rem;
            padding: 0.35rem 0.85rem;
            border-radius: 20px;
            font-weight: 500;
        }
        .card {
            background: var(--card-bg);
            border: none;
            border-radius: var(--card-radius);
            box-shadow: var(--card-shadow);
            margin-bottom: 1.5rem;
            overflow: hidden;
        }
        .card-section {
            padding: 1.75rem;
        }
        .section-icon-box {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
            margin-right: 1rem;
            flex-shrink: 0;
        }
        .section-icon-box.danger {
            background: var(--danger-bg);
            color: var(--accent-red);
        }
        .section-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: #1e293b;
            margin: 0;
        }
        .section-desc {
            color: var(--text-muted);
            font-size: 0.9rem;
            margin: 0.25rem 0 0 0;
        }
        .info-box {
            background: var(--danger-bg);
            border-radius: 10px;
            padding: 1.25rem;
            margin: 1.25rem 0;
            border-left: 3px solid var(--accent-red);
        }
        .info-box h6 {
            color: var(--accent-red);
            font-weight: 600;
            font-size: 0.95rem;
            margin-bottom: 0.5rem;
        }
        .info-box ul {
            margin: 0;
            padding-left: 1.25rem;
            font-size: 0.9rem;
            color: #475569;
        }
        .info-box li {
            margin-bottom: 0.25rem;
        }
        .btn-danger-custom {
            background-color: var(--accent-red);
            color: white;
            border: none;
            border-radius: 10px;
            padding: 0.85rem 1.5rem;
            font-weight: 600;
            font-size: 0.95rem;
            width: 100%;
            transition: background 0.2s ease;
        }
        .btn-danger-custom:hover {
            background-color: #b91c1c;
            color: white;
        }
        .form-label {
            font-weight: 600;
            color: #334155;
            font-size: 0.95rem;
        }
        .form-control, .form-check-input {
            border-radius: 8px;
            border: 1px solid #cbd5e1;
            padding: 0.65rem 0.9rem;
        }
        .form-control:focus {
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        .form-check-label {
            color: #475569;
            font-size: 0.9rem;
        }
        .alert {
            border-radius: 10px;
            border: none;
        }
        .card-footer-link {
            text-align: center;
            padding: 1rem;
            background: #f8fafc;
            border-top: 1px solid #f1f5f9;
        }
        .card-footer-link a {
            color: var(--text-muted);
            font-size: 0.9rem;
            text-decoration: none;
        }
        .card-footer-link a:hover {
            color: var(--accent-red);
        }
    </style>
</head>
<body>

<div class="container" style="max-width: 720px;">

    <div class="page-header d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
            <div class="me-3" style="width:44px;height:44px;background:#fef2f2;border-radius:12px;display:flex;align-items:center;justify-content:center;color:#dc2626;font-size:1.25rem;">
                <i class="fas fa-database"></i>
            </div>
            <div>
                <h1 class="page-title">Database Restore</h1>
                <p class="page-subtitle">Restore your database from a saved backup file</p>
            </div>
        </div>
        <span class="admin-badge"><i class="fas fa-user-shield me-1"></i> Admin</span>
    </div>

    <div class="card">
        <div class="card-section">
            <div class="d-flex align-items-start mb-4">
                <div class="section-icon-box danger">
                    <i class="fas fa-undo-alt"></i>
                </div>
                <div>
                    <h3 class="section-title">Manual Restore</h3>
                    <p class="section-desc">Restore database from a previously saved backup file</p>
                </div>
            </div>

            <div class="info-box">
                <h6><i class="fas fa-exclamation-triangle me-2"></i>Important — Read Before Restoring</h6>
                <ul>
                    <li>This will <strong>replace all current data</strong> with the backup file's contents.</li>
                    <li>Unsaved changes will be permanently lost — create a backup first!</li>
                    <li>Only proceed if you trust this backup file and understand the risks.</li>
                </ul>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-<?= $messageType ?> mt-4 mb-4">
                    <i class="fas fa-<?= $messageType === 'success' ? 'check-circle' : 'exclamation-circle' ?> me-2"></i>
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" onsubmit="return confirm('⚠️ FINAL WARNING: This will OVERWRITE ALL current data!\n\nAre you absolutely sure you want to continue?')">

                <div class="mb-4">
                    <label class="form-label">Select Backup File (.sql)</label>
                    <input type="file" name="backup_file" class="form-control" accept=".sql" required>
                    <small class="text-muted">Choose the .sql backup file you previously downloaded</small>
                </div>

                <hr style="margin: 1.5rem 0; border-color: #f1f5f9;">

                <h6 class="form-label mb-3">Confirm to Restore</h6>

                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" name="confirm_first" id="confirm_first" required>
                    <label class="form-check-label" for="confirm_first">
                        I understand this will overwrite and erase all current data
                    </label>
                </div>

                <div class="form-check mb-4">
                    <input class="form-check-input" type="checkbox" name="confirm_second" id="confirm_second" required>
                    <label class="form-check-label" for="confirm_second">
                        I confirm I have already saved a backup of the current database
                    </label>
                </div>

                <button type="submit" class="btn-danger-custom">
                    <i class="fas fa-undo-alt me-2"></i> Restore Database Now
                </button>

            </form>

        </div>

        <div class="card-footer-link">
            <a href="dashboard.php"><i class="fas fa-arrow-left me-1"></i> Go Back to Dashboard</a>
        </div>
    </div>

</div>

</body>
</html>