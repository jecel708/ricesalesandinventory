<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

if (strtolower($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: ../login.php");
    exit;
}

include '../config/db.php';

function redirect_error($message)
{
    header("Location: users.php?error=" . urlencode($message));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: users.php");
    exit;
}

$username         = trim($_POST['username'] ?? '');
$email            = trim($_POST['email'] ?? '');
$password         = $_POST['password'] ?? '';
$confirm_password = $_POST['confirm_password'] ?? '';
$first_name       = trim($_POST['first_name'] ?? '');
$last_name        = trim($_POST['last_name'] ?? '');
$phone            = trim($_POST['phone'] ?? '');
$role             = strtolower(trim($_POST['role'] ?? ''));
$status           = strtolower(trim($_POST['status'] ?? 'active'));

$allowedRoles  = ['cashier', 'owner'];
$allowedStatus = ['active', 'inactive'];

if (
    empty($username) ||
    empty($email) ||
    empty($password) ||
    !in_array($role, $allowedRoles, true)
) {
    redirect_error("Please complete all required fields.");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    redirect_error("Please enter a valid email address.");
}

if (!preg_match('/^[a-zA-Z0-9._-]+$/', $username)) {
    redirect_error("Username may only contain letters, numbers, dots, underscores, and hyphens.");
}

if ($password !== $confirm_password) {
    redirect_error("Passwords do not match.");
}

if (
    strlen($password) < 8 ||
    !preg_match('/[A-Z]/', $password) ||
    !preg_match('/[a-z]/', $password) ||
    !preg_match('/[0-9]/', $password) ||
    !preg_match('/[\W_]/', $password)
) {
    redirect_error(
        "Password must be at least 8 characters and contain uppercase, lowercase, number, and special character."
    );
}

if (!empty($phone) && !preg_match('/^09\d{9}$/', $phone)) {
    redirect_error("Phone number must be in the format 09XXXXXXXXX.");
}

if (!in_array($status, $allowedStatus, true)) {
    $status = 'active';
}

/* Check Username */
$checkUser = $conn->prepare(
    "SELECT user_id FROM users WHERE LOWER(username)=LOWER(?) LIMIT 1"
);
$checkUser->bind_param("s", $username);
$checkUser->execute();
$userExists = $checkUser->get_result()->fetch_assoc();
$checkUser->close();

if ($userExists) {
    redirect_error("Username already exists.");
}

/* Check Email */
$checkEmail = $conn->prepare(
    "SELECT user_id FROM users WHERE LOWER(email)=LOWER(?) LIMIT 1"
);
$checkEmail->bind_param("s", $email);
$checkEmail->execute();
$emailExists = $checkEmail->get_result()->fetch_assoc();
$checkEmail->close();

if ($emailExists) {
    redirect_error("Email already exists.");
}

/* Hash Password */
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

/* Insert User */
$stmt = $conn->prepare("
    INSERT INTO users (
        username,
        email,
        password,
        first_name,
        last_name,
        phone,
        role,
        created_at,
        status
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?)
");

$stmt->bind_param(
    "ssssssss",
    $username,
    $email,
    $hashedPassword,
    $first_name,
    $last_name,
    $phone,
    $role,
    $status
);

if (!$stmt->execute()) {
    redirect_error("Failed to create user.");
}

$newUserId = $stmt->insert_id;
$stmt->close();

/* Activity Log */
$admin_id = (int)$_SESSION['user_id'];

$description = "Created new user ($role): $username";

$log = $conn->prepare("
    INSERT INTO activity_logs
    (user_id, activity_type, description, created_at)
    VALUES (?, 'USER_CREATE', ?, NOW())
");

$log->bind_param("is", $admin_id, $description);
$log->execute();
$log->close();

header("Location: users.php?success=" . urlencode("User created successfully."));
exit;
?>