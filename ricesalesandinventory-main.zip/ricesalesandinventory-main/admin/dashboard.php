<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit;
}
if(strtolower($_SESSION['role'] ?? '') !== 'admin'){
    header("Location: ../login.php");
    exit;
}

$username = $_SESSION['username'] ?? 'User';
$role = $_SESSION['role'] ?? '';
$activePage = 'dashboard';
include '../config/db.php';

// === AUTO-BACKUP CHECK — RUNS WHEN SCHEDULE IS DUE ===
$scheduleFile = __DIR__ . '/admin/backup_schedule.json';
if (file_exists($scheduleFile)) {
    $s = json_decode(file_get_contents($scheduleFile), true);
    
    // Only run if enabled
    if (!empty($s['enabled'])) {
        $now = new DateTime();
        $lastRun = !empty($s['last_run']) ? new DateTime($s['last_run']) : null;
        
        // Determine if backup is due
        $due = false;
        switch ($s['frequency'] ?? 'weekly') {
            case 'daily':
                $due = !$lastRun || $now->diff($lastRun)->days >= 1;
                break;
            case 'weekly':
                $targetDay = $s['day'] ?? 'Sunday';
                $due = date('l') === $targetDay && (!$lastRun || $now->diff($lastRun)->days >= 7);
                break;
            case 'monthly':
                $due = !$lastRun || $now->diff($lastRun)->days >= 30;
                break;
        }

        // ✅ PERFORM BACKUP IF DUE
        if ($due) {
            $db_host = 'localhost';
            $db_name = 'rice_inventory';
            $db_user = 'root';
            $db_pass = '';
            
            try {
                $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
                $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
                
                $sql = "-- Auto Backup\n-- Generated: " . date('Y-m-d H:i:s') . "\n-- Database: $db_name\n\n";
                foreach ($tables as $table) {
                    $sql .= "DROP TABLE IF EXISTS `$table`;\n";
                    $row = $pdo->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_ASSOC);
                    $sql .= $row['Create Table'] . ";\n\n";
                    
                    $rows = $pdo->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
                    if ($rows) {
                        $cols = array_keys($rows[0]);
                        $sql .= "INSERT INTO `$table` (`" . implode("`, `", $cols) . "`) VALUES\n";
                        $vals = [];
                        foreach ($rows as $r) {
                            $esc = [];
                            foreach ($r as $val) {
                                $esc[] = $val === null ? 'NULL' : "'" . addslashes($val) . "'";
                            }
                            $vals[] = "(" . implode(", ", $esc) . ")";
                        }
                        $sql .= implode(",\n", $vals) . ";\n";
                    }
                    $sql .= "\n";
                }
                
                // Save backup to folder
                $backupDir = __DIR__ . '/backups/';
                if (!is_dir($backupDir)) mkdir($backupDir, 0755, true);
                $filename = $backupDir . $db_name . '_auto_' . date('Y-m-d_His') . '.sql';
                file_put_contents($filename, $sql);
                
                // Update last run time
                $s['last_run'] = date('Y-m-d H:i:s');
                file_put_contents($scheduleFile, json_encode($s));
                
            } catch (Exception $e) {
                // Silent fail — don't break dashboard
            }
        }
    }
}

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$DEFAULT_LOW  = 10.0;
$settingsRow = null;
$settingsRes = $conn->query("SELECT low_threshold_kg FROM stock_settings WHERE id=1 LIMIT 1");
if($settingsRes){
    $settingsRow = $settingsRes->fetch_assoc();
}
$LOW_STOCK_THRESHOLD = (float)($settingsRow['low_threshold_kg'] ?? $DEFAULT_LOW);

$totalProductsRow = $conn->query("
    SELECT COUNT(*) AS total_products
    FROM products
    WHERE archived=0
")->fetch_assoc();

$totalStockRow = $conn->query("
    SELECT IFNULL(SUM(stock_kg),0) AS total_stock
    FROM products
    WHERE archived=0
")->fetch_assoc();

$flowRow = $conn->query("
    SELECT
        IFNULL(SUM(CASE WHEN type='in' THEN qty_kg ELSE 0 END),0) AS total_in,
        IFNULL(SUM(CASE WHEN type='out' THEN qty_kg ELSE 0 END),0) AS total_out,
        IFNULL(SUM(CASE WHEN type='adjust' THEN qty_kg ELSE 0 END),0) AS total_adjust
    FROM inventory_transactions
")->fetch_assoc();

$inventory = [
    'total_products' => (int)($totalProductsRow['total_products'] ?? 0),
    'total_stock'    => (float)($totalStockRow['total_stock'] ?? 0),
    'total_in'       => (float)($flowRow['total_in'] ?? 0),
    'total_out'      => (float)($flowRow['total_out'] ?? 0),
    'total_adjust'   => (float)($flowRow['total_adjust'] ?? 0),
];

$ar_total = $conn->query("
SELECT 
    IFNULL(SUM(total_amount),0) AS total_ar
FROM account_receivable
")->fetch_assoc();

$ar_outstanding = $conn->query("
SELECT 
    IFNULL(SUM(balance),0) AS balance_ar
FROM account_receivable
WHERE LOWER(status) IN ('unpaid','partial','overdue','pending','approved')
")->fetch_assoc();

$apEligibility = automationColumnExists($conn, 'account_payable', 'approved')
  ? 'COALESCE(approved,0)=1'
  : '1=1';
if (automationColumnExists($conn, 'account_payable', 'rejected')) {
  $apEligibility .= ' AND COALESCE(rejected,0)=0';
}

$ap_total = $conn->query("
SELECT 
    IFNULL(SUM(CASE WHEN {$apEligibility} THEN total_amount ELSE 0 END),0) AS total_ap
FROM account_payable
")->fetch_assoc();

$ap_outstanding = $conn->query("
SELECT 
    IFNULL(SUM(balance),0) AS balance_ap
FROM account_payable
WHERE LOWER(status) IN ('unpaid','partial','overdue','pending','approved')
  AND {$apEligibility}
")->fetch_assoc();

$notif_summary = $conn->query("
SELECT COUNT(*) AS total_sent,
       SUM(CASE WHEN UPPER(status)='SENT' THEN 1 ELSE 0 END) AS successful,
       SUM(CASE WHEN UPPER(status)='FAILED' THEN 1 ELSE 0 END) AS failed
FROM push_notif_logs
")->fetch_assoc();

$product_status = $conn->query("
    SELECT
        SUM(CASE WHEN archived=0 THEN 1 ELSE 0 END) AS active_products,
        SUM(CASE WHEN archived=1 THEN 1 ELSE 0 END) AS archived_products
    FROM products
")->fetch_assoc();

$salesTodayRow = $conn->query("
    SELECT
        IFNULL(SUM(total_amount),0) AS daily_sales,
        COUNT(*) AS daily_transactions
    FROM sales
    WHERE DATE(sale_date) = CURDATE()
      AND LOWER(IFNULL(status,'')) <> 'cancelled'
      AND sale_date <> '0000-00-00 00:00:00'
")->fetch_assoc();

$salesMonthRow = $conn->query("
    SELECT
        IFNULL(SUM(total_amount),0) AS monthly_sales,
        COUNT(*) AS monthly_transactions
    FROM sales
    WHERE YEAR(sale_date) = YEAR(CURDATE())
      AND MONTH(sale_date) = MONTH(CURDATE())
      AND LOWER(IFNULL(status,'')) <> 'cancelled'
      AND sale_date <> '0000-00-00 00:00:00'
")->fetch_assoc();

$stockAggregateSql = "
    SELECT
        p.product_id,
        p.variety,
        p.grade,
        IFNULL(SUM(CASE
            WHEN LOWER(it.type)='in' THEN it.qty_kg
            WHEN LOWER(it.type)='out' THEN -it.qty_kg
            WHEN LOWER(it.type)='adjust' THEN it.qty_kg
            ELSE 0 END),0) AS stock_kg
    FROM products p
    LEFT JOIN inventory_transactions it ON it.product_id = p.product_id
    WHERE p.archived=0
    GROUP BY p.product_id
";

$lowStockRow = $conn->query("SELECT COUNT(*) AS low_count FROM ({$stockAggregateSql}) x WHERE x.stock_kg > 0 AND x.stock_kg <= " . (float)$LOW_STOCK_THRESHOLD)->fetch_assoc();
$outStockRow = $conn->query("SELECT COUNT(*) AS out_count FROM ({$stockAggregateSql}) x WHERE x.stock_kg <= 0")->fetch_assoc();

$lowStockItems = $conn->query("
    SELECT x.product_id, x.variety, x.grade, x.stock_kg
    FROM ({$stockAggregateSql}) x
    WHERE x.stock_kg > 0 AND x.stock_kg <= " . (float)$LOW_STOCK_THRESHOLD . "
    ORDER BY x.stock_kg ASC, x.variety ASC
    LIMIT 5
");

$outStockItems = $conn->query("
    SELECT x.product_id, x.variety, x.grade, x.stock_kg
    FROM ({$stockAggregateSql}) x
    WHERE x.stock_kg <= 0
    ORDER BY x.variety ASC
    LIMIT 5
");

$bestSellingRows = $conn->query("
    SELECT
        p.product_id,
        p.variety,
        p.grade,
        IFNULL(SUM(si.qty_kg),0) AS sold_kg
    FROM sales_items si
    JOIN sales s ON s.sale_id = si.sale_id
    JOIN products p ON p.product_id = si.product_id
    WHERE LOWER(IFNULL(s.status,'')) <> 'cancelled'
      AND s.sale_date <> '0000-00-00 00:00:00'
    GROUP BY p.product_id
    ORDER BY sold_kg DESC, p.variety ASC
    LIMIT 5
");

$recentTransactions = $conn->query("
    SELECT
        s.sale_id,
        s.sale_date,
        s.total_amount,
        s.status,
        u.username AS cashier_name,
        c.first_name,
        c.last_name
    FROM sales s
    LEFT JOIN users u ON u.user_id = s.user_id
    LEFT JOIN customers c ON c.customer_id = s.customer_id
    WHERE s.sale_date <> '0000-00-00 00:00:00'
      AND LOWER(IFNULL(s.status,'')) <> 'cancelled'
    ORDER BY s.sale_date DESC, s.sale_id DESC
    LIMIT 5
");

$top_stock = $conn->query("
    SELECT variety, IFNULL(stock_kg,0) AS stock_kg
    FROM products
    WHERE archived=0
    ORDER BY stock_kg DESC, variety ASC
    LIMIT 5
");
$top_stock_labels = [];
$top_stock_values = [];
if ($top_stock) {
    while ($row = $top_stock->fetch_assoc()) {
        $top_stock_labels[] = (string)($row['variety'] ?? 'Unknown');
        $top_stock_values[] = (float)($row['stock_kg'] ?? 0);
    }
}

// Stock movement for the last 14 days (fill missing days with 0s for smoother charts)
$movement_days = 14;
$movement_rows = $conn->query("
    SELECT
        DATE(created_at) AS day,
        IFNULL(SUM(CASE WHEN type='in' THEN qty_kg ELSE 0 END),0) AS in_kg,
        IFNULL(SUM(CASE WHEN type='out' THEN qty_kg ELSE 0 END),0) AS out_kg,
        IFNULL(SUM(CASE WHEN type='adjust' THEN qty_kg ELSE 0 END),0) AS adjust_kg
    FROM inventory_transactions
    WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL " . (int)($movement_days - 1) . " DAY)
    GROUP BY DATE(created_at)
    ORDER BY DATE(created_at) ASC
");
$movement_by_day = [];
if ($movement_rows) {
    while ($r = $movement_rows->fetch_assoc()) {
        $movement_by_day[$r['day']] = [
            'in' => (float)($r['in_kg'] ?? 0),
            'out' => (float)($r['out_kg'] ?? 0),
            'adjust' => (float)($r['adjust_kg'] ?? 0),
        ];
    }
}
$movement_labels = [];
$movement_in = [];
$movement_out = [];
$movement_adjust = [];
for ($i = $movement_days - 1; $i >= 0; $i--) {
    $day = date('Y-m-d', strtotime("-{$i} day"));
    $movement_labels[] = date('M d', strtotime($day));
    $movement_in[] = (float)($movement_by_day[$day]['in'] ?? 0);
    $movement_out[] = (float)($movement_by_day[$day]['out'] ?? 0);
    $movement_adjust[] = (float)($movement_by_day[$day]['adjust'] ?? 0);
}

$movement_in_total = array_sum($movement_in);
$movement_out_total = array_sum($movement_out);
$movement_adjust_total = array_sum($movement_adjust);
$movement_total = max(0.0, (float)$movement_in_total + (float)$movement_out_total);
$movement_in_pct = $movement_total > 0 ? (($movement_in_total / $movement_total) * 100) : 0;
$movement_out_pct = $movement_total > 0 ? (($movement_out_total / $movement_total) * 100) : 0;

$daily_sales_value = (float)($salesTodayRow['daily_sales'] ?? 0);
$monthly_sales_value = (float)($salesMonthRow['monthly_sales'] ?? 0);
$daily_transactions = (int)($salesTodayRow['daily_transactions'] ?? 0);
$monthly_transactions = (int)($salesMonthRow['monthly_transactions'] ?? 0);
$low_stock_count = (int)($lowStockRow['low_count'] ?? 0);
$out_stock_count = (int)($outStockRow['out_count'] ?? 0);

$bestSellingList = [];
if ($bestSellingRows && $bestSellingRows->num_rows > 0) {
    while ($row = $bestSellingRows->fetch_assoc()) {
        $bestSellingList[] = $row;
    }
    $bestSellingRows->data_seek(0);
}
$bestSellingTop = $bestSellingList[0] ?? null;

$ar_total_value = (float)($ar_total['total_ar'] ?? 0);
$ar_out_value = (float)($ar_outstanding['balance_ar'] ?? 0);
$ar_paid_value = max(0.0, $ar_total_value - $ar_out_value);

$ap_total_value = (float)($ap_total['total_ap'] ?? 0);
$ap_out_value = (float)($ap_outstanding['balance_ap'] ?? 0);
$ap_paid_value = max(0.0, $ap_total_value - $ap_out_value);

$recent_logins = $conn->query("
 SELECT l.*, u.username
 FROM login_logs l
 JOIN users u ON l.user_id = u.user_id
ORDER BY l.login_time DESC
LIMIT 5
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin Dashboard | DE ORO HIYS</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

<link href="../css/layout.css" rel="stylesheet">
<link href="../css/admin-mobile.css" rel="stylesheet">
<link href="../css/admin-dashboard.css" rel="stylesheet">
</head>

<body>

<?php include '../includes/topnav.php'; ?>

<div class="container-fluid">
<div class="row">


<?php include '../includes/admin_sidebar.php'; ?>

<!-- MAIN CONTENT -->
<main class="col-lg-10 ms-sm-auto px-4 main-content">

<h3 class="fw-bold mb-4" id="dashboardTitle">Dashboard Overview</h3>

<!-- Overview Layout -->
<div class="row g-4 align-items-start">
  <!-- Tall chart card (left) -->
  <div class="col-lg-4" id="movementCard">
    <div class="card modern-card bg-gradient-info text-white">
      <div class="card-body p-3 d-flex flex-column">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-2 pb-2 border-bottom border-white border-opacity-25">
          <div class="d-flex align-items-center gap-2">
            <span class="kpi-icon kpi-icon-sm"><i class="fa-solid fa-chart-column"></i></span>
            <h6 class="fw-bold mb-0 text-white kpi-title">Stock Movement</h6>
          </div>
          <small class="text-white-50">Last 14 days</small>
        </div>

        <div style="height: 320px;">
          <canvas id="stockMovementLineChart" aria-label="Stock movement bar chart" role="img"></canvas>
        </div>
      </div>
    </div>
  </div>

  <!-- KPI cards (right) -->
  <div class="col-lg-8" id="dashboardMetrics">
    <!-- Row 1: 4 small cards -->
    <div class="row g-4">
      <div class="col-md-6 col-xl-3" id="totalProductsCard">
        <div class="card modern-card card-kpi h-100">
          <div class="card-body">
            <div class="d-flex align-items-start justify-content-between gap-3">
              <div class="flex-grow-1 min-w-0">
                <div class="kpi-label">Total Products</div>
                <div class="kpi-value"><?= (int)$inventory['total_products'] ?></div>
                <div class="kpi-sub">
                  Active: <?= (int)($product_status['active_products'] ?? $inventory['total_products']) ?> |
                  Archived: <?= (int)($product_status['archived_products'] ?? 0) ?>
                </div>
              </div>
              <span class="kpi-icon"><i class="fa-solid fa-boxes-stacked"></i></span>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-6 col-xl-3" id="totalStockCard">
        <div class="card modern-card card-kpi h-100">
          <div class="card-body">
            <div class="d-flex align-items-start justify-content-between gap-3">
              <div class="flex-grow-1 min-w-0">
                <div class="kpi-label">Total Stock</div>
                <div class="kpi-value"><?= number_format((float)$inventory['total_stock'],2) ?> <span>kg</span></div>
                <div class="kpi-sub">Current on-hand stock</div>
              </div>
              <span class="kpi-icon"><i class="fa-solid fa-warehouse"></i></span>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-6 col-xl-3" id="dailySalesCard">
        <div class="card modern-card card-kpi h-100">
          <div class="card-body">
            <div class="d-flex align-items-start justify-content-between gap-3">
              <div class="flex-grow-1 min-w-0">
                <div class="kpi-label">Daily Sales</div>
                <div class="kpi-value">₱<?= number_format($daily_sales_value,2) ?></div>
                <div class="kpi-sub"><?= $daily_transactions ?> transaction(s) today</div>
              </div>
              <span class="kpi-icon"><i class="fa-solid fa-sack-dollar"></i></span>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-6 col-xl-3" id="monthlySalesCard">
        <div class="card modern-card card-kpi h-100">
          <div class="card-body">
            <div class="d-flex align-items-start justify-content-between gap-3">
              <div class="flex-grow-1 min-w-0">
                <div class="kpi-label">Monthly Sales</div>
                <div class="kpi-value">₱<?= number_format($monthly_sales_value,2) ?></div>
                <div class="kpi-sub"><?= $monthly_transactions ?> transaction(s) this month</div>
              </div>
              <span class="kpi-icon"><i class="fa-solid fa-chart-line"></i></span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Row 2: 3 medium cards -->
    <div class="row g-4 mt-1">
      <div class="col-md-6 col-xl-4" id="lowStockCard">
        <button type="button" class="card modern-card card-kpi h-100 text-start w-100 border-0" data-bs-toggle="modal" data-bs-target="#lowStockModal">
          <div class="card-body">
            <div class="d-flex align-items-start justify-content-between gap-3 mb-2">
              <div class="kpi-label">Low Stock Alert</div>
              <span class="kpi-icon"><i class="fa-solid fa-triangle-exclamation"></i></span>
            </div>
            <div class="kpi-list small">
              <div class="d-flex justify-content-between"><span class="kpi-list-label">Items</span><span class="kpi-list-value"><?= (int)$low_stock_count ?></span></div>
              <div class="d-flex justify-content-between"><span class="kpi-list-label">Threshold</span><span class="kpi-list-value"><?= number_format($LOW_STOCK_THRESHOLD,2) ?> kg</span></div>
            </div>
          </div>
        </button>
      </div>

      <div class="col-md-6 col-xl-4" id="outOfStockCard">
        <button type="button" class="card modern-card card-kpi h-100 text-start w-100 border-0" data-bs-toggle="modal" data-bs-target="#outOfStockModal">
          <div class="card-body">
            <div class="d-flex align-items-start justify-content-between gap-3 mb-2">
              <div class="kpi-label">Out of Stock Items</div>
              <span class="kpi-icon"><i class="fa-solid fa-box-open"></i></span>
            </div>
            <div class="kpi-list small">
              <div class="d-flex justify-content-between"><span class="kpi-list-label">Items</span><span class="kpi-list-value"><?= (int)$out_stock_count ?></span></div>
              <div class="d-flex justify-content-between"><span class="kpi-list-label">Status</span><span class="kpi-list-value">No stock on hand</span></div>
            </div>
          </div>
        </button>
      </div>

      <div class="col-md-12 col-xl-4" id="bestSellingCard">
        <button type="button" class="card modern-card card-kpi h-100 text-start w-100 border-0" data-bs-toggle="modal" data-bs-target="#bestSellingModal">
          <div class="card-body">
            <div class="d-flex align-items-start justify-content-between gap-3 mb-2">
              <div class="kpi-label">Best Selling Product</div>
              <span class="kpi-icon"><i class="fa-solid fa-fire"></i></span>
            </div>
            <?php if($bestSellingTop): ?>
              <div class="kpi-value" style="font-size:1.2rem;"><?= h($bestSellingTop['variety'] ?? 'N/A') ?></div>
              <div class="kpi-sub mb-2"><?= h((string)($bestSellingTop['grade'] ?? '')) ?></div>
              <div class="kpi-list small">
                <div class="d-flex justify-content-between"><span class="kpi-list-label">Sold</span><span class="kpi-list-value"><?= number_format((float)$bestSellingTop['sold_kg'],2) ?> kg</span></div>
              </div>
            <?php else: ?>
              <div class="text-muted small">No sales data available yet.</div>
            <?php endif; ?>
          </div>
        </button>
      </div>
    </div>

  </div>
</div>

<div class="row g-4 mt-1">
  <div class="col-lg-6">
    <div class="card shadow-sm modern-card" id="bestSellingProductsCard">
      <div class="card-body">
        <h5 class="fw-bold mb-3">Best Selling Products</h5>
        <div class="table-responsive">
          <table class="table table-striped align-middle mb-0">
            <thead class="table-dark">
              <tr>
                <th>Product</th>
                <th class="text-end">Sold (kg)</th>
              </tr>
            </thead>
            <tbody>
              <?php if($bestSellingRows && $bestSellingRows->num_rows > 0): ?>
                <?php while($bs = $bestSellingRows->fetch_assoc()): ?>
                  <tr>
                    <td><?= h(trim((string)$bs['variety'] . ' - ' . (string)$bs['grade'])) ?></td>
                    <td class="text-end fw-semibold"><?= number_format((float)$bs['sold_kg'],2) ?></td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="2" class="text-center text-muted">No sales records found.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="card shadow-sm modern-card" id="recentTransactionsCard">
      <div class="card-body">
        <h5 class="fw-bold mb-3">Recent Transactions</h5>
        <div class="table-responsive">
          <table class="table table-striped align-middle mb-0">
            <thead class="table-dark">
              <tr>
                <th>Sale #</th>
                <th>Date</th>
                <th>Cashier</th>
                <th class="text-end">Total</th>
              </tr>
            </thead>
            <tbody>
              <?php if($recentTransactions && $recentTransactions->num_rows > 0): ?>
                <?php while($tx = $recentTransactions->fetch_assoc()): ?>
                  <?php
                    $cashier = trim((string)($tx['cashier_name'] ?? ''));
                    if($cashier === '') $cashier = 'Cashier';
                    $customer = trim((string)($tx['first_name'] ?? '').' '.(string)($tx['last_name'] ?? ''));
                  ?>
                  <tr>
                    <td class="fw-semibold">#<?= (int)$tx['sale_id'] ?></td>
                    <td><?= h(date('M d, Y h:i A', strtotime((string)$tx['sale_date']))) ?></td>
                    <td><?= h($cashier) ?></td>
                    <td class="text-end fw-semibold">₱<?= number_format((float)$tx['total_amount'],2) ?></td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="4" class="text-center text-muted">No recent transactions found.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="card shadow-sm mt-5 modern-card" id="recentLoginsCard">
  <div class="card-body">
    <h5 class="fw-bold mb-3">Recent Logins</h5>
    <div class="table-responsive">
      <table class="table table-striped align-middle mb-0">
        <thead class="table-dark">
          <tr>
            <th>User</th>
            <th>Login Time</th>
            <th>Device</th>
            <th>IP Address</th>
          </tr>
        </thead>
        <tbody>
          <?php if($recent_logins && $recent_logins->num_rows > 0): ?>
            <?php while($log = $recent_logins->fetch_assoc()): ?>
              <tr>
                <td><?= htmlspecialchars($log['username']) ?></td>
                <td><?= date("M d, Y h:i A", strtotime($log['login_time'])) ?></td>
                <td><?= htmlspecialchars($log['device_info']) ?></td>
                <td><?= htmlspecialchars($log['ip_address']) ?></td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr><td colspan="4" class="text-center text-muted">No recent logins found.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

</main>
</div>
</div>

<!-- MODALS -->
<div class="modal fade" id="lowStockModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fw-bold">Low Stock Alert</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php if($low_stock_count <= 0): ?>
          <div class="alert alert-success mb-0">No low stock items right now.</div>
        <?php else: ?>
          <div class="alert alert-warning mb-3">
            There are <?= (int)$low_stock_count ?> product(s) at or below <?= number_format($LOW_STOCK_THRESHOLD,2) ?> kg.
          </div>
          <div class="list-group">
            <?php if($lowStockItems && $lowStockItems->num_rows > 0): ?>
              <?php while($item = $lowStockItems->fetch_assoc()): ?>
                <div class="list-group-item d-flex justify-content-between align-items-center">
                  <div class="fw-semibold"><?= h(trim((string)$item['variety'].' - '.(string)$item['grade'])) ?></div>
                  <div class="text-end">
                    <div class="fw-bold"><?= number_format((float)$item['stock_kg'],2) ?> kg</div>
                    <span class="badge bg-warning text-dark">LOW</span>
                  </div>
                </div>
              <?php endwhile; ?>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline-dark" data-bs-dismiss="modal">Close</button>
        <a class="btn btn-dark" href="#lowStockPanel">Go to section</a>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="outOfStockModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fw-bold">Out of Stock Alert</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php if($out_stock_count <= 0): ?>
          <div class="alert alert-success mb-0">No out of stock items right now.</div>
        <?php else: ?>
          <div class="alert alert-danger mb-3">
            There are <?= (int)$out_stock_count ?> product(s) with zero stock on hand.
          </div>
          <div class="list-group">
            <?php if($outStockItems && $outStockItems->num_rows > 0): ?>
              <?php while($item = $outStockItems->fetch_assoc()): ?>
                <div class="list-group-item d-flex justify-content-between align-items-center">
                  <div class="fw-semibold"><?= h(trim((string)$item['variety'].' - '.(string)$item['grade'])) ?></div>
                  <div class="text-end">
                    <div class="fw-bold text-danger">0.00 kg</div>
                    <span class="badge bg-secondary">OUT</span>
                  </div>
                </div>
              <?php endwhile; ?>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline-dark" data-bs-dismiss="modal">Close</button>
        <a class="btn btn-dark" href="#outOfStockPanel">Go to section</a>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="bestSellingModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fw-bold">Best Selling Products Ranks</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php if(empty($bestSellingList)): ?>
          <div class="alert alert-success mb-0">No sales records found yet.</div>
        <?php else: ?>
          <div class="alert alert-info mb-3">Showing the top <?= (int)count($bestSellingList) ?> selling products by quantity sold.</div>
          <div class="list-group">
            <?php foreach($bestSellingList as $index => $item): ?>
              <div class="list-group-item d-flex justify-content-between align-items-center">
                <div>
                  <div class="fw-bold">#<?= $index + 1 ?> <?= h(trim((string)$item['variety'].' - '.(string)$item['grade'])) ?></div>
                </div>
                <div class="text-end">
                  <div class="fw-bold"><?= number_format((float)$item['sold_kg'],2) ?> kg</div>
                  <?php if($index === 0): ?>
                    <span class="badge bg-danger">TOP SELLER</span>
                  <?php else: ?>
                    <span class="badge bg-secondary">RANK <?= $index + 1 ?></span>
                  <?php endif; ?>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline-dark" data-bs-dismiss="modal">Close</button>
        <a class="btn btn-dark" href="#bestSellingProductsCard">Go to table</a>
      </div>
    </div>
  </div>
</div>
 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
(() => {
  const pollIntervalMs = 3000;
  let pollingInFlight = false;

  async function pollDashboard() {
    if (pollingInFlight) return;
    pollingInFlight = true;

    try {
      const url = new URL(window.location.href);
      url.searchParams.set('ajax', 'live');

      const response = await fetch(url.toString(), {
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      });
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');

      ['dashboardTitle', 'workflowStrip', 'dashboardMetrics', 'bestSellingProductsCard', 'recentTransactionsCard', 'recentLoginsCard'].forEach((id) => {
        const source = doc.getElementById(id);
        const target = document.getElementById(id);
        if (source && target) {
          target.innerHTML = source.innerHTML;
        }
      });
    } catch (error) {
      console.error('Dashboard live poll failed:', error);
    } finally {
      pollingInFlight = false;
    }
  }

  if (!window.Chart) return;

  const chartDefaults = {
    responsive: true,
    maintainAspectRatio: false,
    animation: {
      duration: window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 650
    },
    plugins: {
      legend: { display: false },
      tooltip: { enabled: true }
    }
  };

  Chart.defaults.color = 'rgba(255,255,255,.85)';
  Chart.defaults.font.family = "system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif";

  const movementLabels = <?= json_encode($movement_labels) ?>;
  const movementIn = <?= json_encode($movement_in) ?>;
  const movementOut = <?= json_encode($movement_out) ?>;

  // Stock Movement: bar (daily in vs out over last 14 days)
  const movementEl = document.getElementById('stockMovementLineChart');
  if (movementEl) {
    new Chart(movementEl, {
      type: 'bar',
      data: {
        labels: movementLabels,
        datasets: [
          {
            label: 'Stock In',
            data: movementIn,
            backgroundColor: 'rgba(13,110,253,.75)',
            borderColor: 'rgba(13,110,253,.95)',
            borderWidth: 0,
            borderRadius: 6,
            barThickness: 14,
            maxBarThickness: 18,
            barPercentage: 0.95,
            categoryPercentage: 0.9
          },
          {
            label: 'Stock Out',
            data: movementOut,
            backgroundColor: 'rgba(253,126,20,.75)',
            borderColor: 'rgba(253,126,20,.95)',
            borderWidth: 0,
            borderRadius: 6,
            barThickness: 14,
            maxBarThickness: 18,
            barPercentage: 0.95,
            categoryPercentage: 0.9
          }
        ]
      },
      options: {
        ...chartDefaults,
        plugins: {
          ...chartDefaults.plugins,
          legend: {
            display: true,
            position: 'bottom',
            labels: { boxWidth: 10, padding: 8, color: 'rgba(255,255,255,.85)' }
          }
        },
        scales: {
          x: {
            ticks: { color: 'rgba(255,255,255,.65)', maxRotation: 0, autoSkip: true, autoSkipPadding: 14 },
            grid: { display: false }
          },
          y: {
            ticks: { color: 'rgba(255,255,255,.65)' },
            grid: { color: 'rgba(255,255,255,.08)' }
          }
        }
      }
    });
  }

  pollDashboard();
  window.setInterval(pollDashboard, pollIntervalMs);
})();
</script>
</body>
</html>
