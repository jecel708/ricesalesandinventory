<?php
session_start();
$role = strtolower($_SESSION['role'] ?? '');
if ($role !== 'admin') { exit("Access Denied"); }

// Database settings
$db_host = 'localhost';
$db_name = 'rice_inventory';
$db_user = 'root';
$db_pass = '';

// Settings file to store schedule
$settingsFile = 'backup_schedule.json';
$message = '';

// Save schedule
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $schedule = [
        'frequency' => $_POST['frequency'] ?? 'weekly',
        'day' => $_POST['day'] ?? 'Sunday',
        'time' => $_POST['time'] ?? '02:00',
        'enabled' => isset($_POST['enabled']),
        'last_run' => $_POST['last_run'] ?? ''
    ];
    file_put_contents($settingsFile, json_encode($schedule));
    $message = "✅ Schedule saved successfully!";
}

// Load current schedule
$schedule = file_exists($settingsFile) 
    ? json_decode(file_get_contents($settingsFile), true) 
    : ['frequency'=>'weekly','day'=>'Sunday','time'=>'02:00','enabled'=>true,'last_run'=>''];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Auto Backup Schedule</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/responsive.css?v=1" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5" style="max-width: 550px;">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0"><i class="fas fa-clock me-2"></i> Automatic Backup Schedule</h4>
        </div>
        <div class="card-body">
            <?php if ($message): ?><div class="alert alert-success"><?= $message ?></div><?php endif; ?>
            
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Backup Frequency</label>
                    <select name="frequency" class="form-select" required>
                        <option value="daily" <?= $schedule['frequency']==='daily'?'selected':'' ?>>Daily</option>
                        <option value="weekly" <?= $schedule['frequency']==='weekly'?'selected':'' ?>>Weekly</option>
                        <option value="monthly" <?= $schedule['frequency']==='monthly'?'selected':'' ?>>Monthly</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Day</label>
                    <select name="day" class="form-select">
                        <?php $days=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']; ?>
                        <?php foreach($days as $d): ?>
                        <option value="<?= $d ?>" <?= ($schedule['day']??'')===$d?'selected':'' ?>><?= $d ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Time</label>
                    <input type="time" name="time" value="<?= htmlspecialchars($schedule['time']??'02:00') ?>" class="form-control">
                </div>

                <div class="mb-4 form-check">
                    <input class="form-check-input" type="checkbox" name="enabled" id="enabled" <?= ($schedule['enabled']??true)?'checked':'' ?>>
                    <label class="form-check-label" for="enabled">✅ Enable automatic backups</label>
                </div>

                <button type="submit" class="btn btn-primary w-100">💾 Save Schedule</button>
            </form>

            <hr>
            <div class="alert alert-info small">
                <strong>Last auto-backup:</strong> <?= !empty($schedule['last_run']) ? $schedule['last_run'] : 'Not yet run' ?>
            </div>
        </div>
    </div>
</div>
</body>
</html>
