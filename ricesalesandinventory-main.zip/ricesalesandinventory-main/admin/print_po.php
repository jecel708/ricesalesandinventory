<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

include '../config/db.php';

function h($v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

$po_id = (int)($_GET['id'] ?? 0);

if ($po_id <= 0) {
    die("Invalid PO number.");
}

/*
|--------------------------------------------------------------------------
| Get PO Header
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        p.purchases_id,
        p.purchase_date,
        p.request_reason,
        p.po_approved,
        s.name AS supplier_name,
        s.phone,
        s.address,
        u.username AS created_by_name,
        approver.username AS approved_by_name
    FROM purchases p
    LEFT JOIN suppliers s
        ON s.supplier_id = p.supplier_id
    LEFT JOIN users u
        ON u.user_id = p.created_by
    LEFT JOIN users approver
        ON approver.user_id = p.po_approved_by
    WHERE p.purchases_id = ?
    LIMIT 1
");

$stmt->bind_param("i", $po_id);
$stmt->execute();

$po = $stmt->get_result()->fetch_assoc();

$stmt->close();

if (!$po) {
    die("Purchase Order not found.");
}

/*
|--------------------------------------------------------------------------
| Allow printing ONLY if owner approved
|--------------------------------------------------------------------------
*/

if ((int)$po['po_approved'] !== 1) {
    die("This Purchase Order has not yet been approved by the owner.");
}

/*
|--------------------------------------------------------------------------
| Get PO Items
|--------------------------------------------------------------------------
*/

$itemStmt = $conn->prepare("
    SELECT
        pi.quantity_sacks,
        pi.estimated_price,
        pi.supplier_price,
        pi.line_total,
        pr.variety,
        pr.grade,
        pr.unit_weight_kg,
        pr.price_per_sack,
        pr.sell_price_per_sack,
        pr.price_per_kg
    FROM purchase_items pi
    JOIN products pr
        ON pr.product_id = pi.product_id
    WHERE pi.purchases_id = ?
");

$itemStmt->bind_param("i", $po_id);
$itemStmt->execute();

$itemsResult = $itemStmt->get_result();
$items = [];

while ($row = $itemsResult->fetch_assoc()) {
    $items[] = $row;
}

$total = 0;

$pricingNote = '';
$supplierPriceNote = null;
$markupKg = null;
$sellKg = null;
$sellSack = null;

$noteStmt = $conn->prepare("
    SELECT note
    FROM inventory_transactions
    WHERE reference_id = ?
      AND reference_type = 'purchase'
      AND LOWER(type) = 'in'
    ORDER BY created_at DESC, inventTrans_id DESC
    LIMIT 1
");
if ($noteStmt) {
    $noteStmt->bind_param("i", $po_id);
    $noteStmt->execute();
    $noteRow = $noteStmt->get_result()->fetch_assoc();
    $noteStmt->close();
    $pricingNote = (string)($noteRow['note'] ?? '');

    if ($pricingNote !== '') {
        if (preg_match('/supplier\\/sack=₱\\s*([0-9,]+(?:\\.[0-9]+)?)/u', $pricingNote, $m)) {
            $supplierPriceNote = (float)str_replace(',', '', $m[1]);
        }
        if (preg_match('/markup\\/kg=₱\\s*([0-9,]+(?:\\.[0-9]+)?)/u', $pricingNote, $m)) {
            $markupKg = (float)str_replace(',', '', $m[1]);
        }
        if (preg_match('/sell\\/kg=₱\\s*([0-9,]+(?:\\.[0-9]+)?)/u', $pricingNote, $m)) {
            $sellKg = (float)str_replace(',', '', $m[1]);
        }
        if (preg_match('/sell\\/sack=₱\\s*([0-9,]+(?:\\.[0-9]+)?)/u', $pricingNote, $m)) {
            $sellSack = (float)str_replace(',', '', $m[1]);
        }
    }
}

if (!$items) {
    $batchStmt = $conn->prepare("
        SELECT
            sb.product_id,
            sb.initial_qty_kg,
            sb.unit_weight_kg,
            pr.variety,
            pr.grade,
            pr.price_per_sack,
            pr.sell_price_per_sack,
            pr.price_per_kg
        FROM stock_batches sb
        JOIN products pr
            ON pr.product_id = sb.product_id
        WHERE sb.source_reference_id = ?
          AND sb.source_reference_type = 'purchase'
        ORDER BY sb.batch_id ASC
    ");

    if ($batchStmt) {
        $batchStmt->bind_param("i", $po_id);
        $batchStmt->execute();
        $batchRes = $batchStmt->get_result();

        while ($batch = $batchRes->fetch_assoc()) {
            $unitWeight = (float)($batch['unit_weight_kg'] ?? 0);
            $qtyKg = (float)($batch['initial_qty_kg'] ?? 0);
            $qtySacks = $unitWeight > 0 ? ($qtyKg / $unitWeight) : 0;
            $unitPrice = $supplierPriceNote !== null
                ? $supplierPriceNote
                : (float)($batch['price_per_sack'] ?? 0);
            $lineTotal = $qtySacks * $unitPrice;

            $items[] = [
                'quantity_sacks' => $qtySacks,
                'supplier_price' => $unitPrice,
                'estimated_price' => $unitPrice,
                'line_total' => $lineTotal,
                'variety' => $batch['variety'],
                'grade' => $batch['grade'],
                'unit_weight_kg' => $unitWeight,
                'price_per_sack' => $batch['price_per_sack'],
                'sell_price_per_sack' => $batch['sell_price_per_sack'],
                'price_per_kg' => $batch['price_per_kg'],
            ];
        }

        $batchStmt->close();
    }
}

function peso($value): string
{
    return number_format((float)$value, 2);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Purchase Order #<?= (int)$po['purchases_id'] ?></title>
    <style>
        :root{
            --ink:#1f2937;
            --muted:#6b7280;
            --line:#d1d5db;
            --soft:#f8fafc;
            --accent:#111827;
        }
        *{ box-sizing:border-box; }
        body{
            margin:0;
            padding:24px 0;
            background:#eef2f7;
            color:var(--ink);
            font-family: "Segoe UI", Arial, sans-serif;
        }
        .receipt{
            width:min(820px, calc(100vw - 32px));
            margin:0 auto;
            background:#fff;
            border:1px solid var(--line);
            border-radius:16px;
            padding:22px;
            box-shadow:0 10px 30px rgba(15,23,42,.08);
        }
        .brand{
            text-align:center;
        }
        .brand h1{
            margin:0;
            font-size:24px;
            line-height:1.1;
            letter-spacing:.4px;
        }
        .brand .sub{
            margin-top:4px;
            color:var(--muted);
            font-size:13px;
        }
        .badge-row{
            display:flex;
            flex-wrap:wrap;
            gap:8px;
            justify-content:center;
            margin-top:14px;
        }
        .pill{
            display:inline-flex;
            align-items:center;
            gap:6px;
            border:1px solid var(--line);
            background:var(--soft);
            padding:6px 10px;
            border-radius:999px;
            font-size:12px;
            font-weight:700;
        }
        .pill strong{ color:var(--accent); }
        .dash{
            border-top:1px dashed var(--line);
            margin:16px 0;
        }
        .meta{
            display:grid;
            grid-template-columns:repeat(2, minmax(0, 1fr));
            gap:10px 16px;
            font-size:13px;
        }
        .meta .row{
            display:flex;
            justify-content:space-between;
            gap:12px;
            padding-bottom:4px;
            border-bottom:1px dotted rgba(209,213,219,.7);
        }
        .meta .label{ color:var(--muted); }
        .meta .value{ font-weight:600; text-align:right; }
        .section-title{
            display:flex;
            justify-content:space-between;
            align-items:center;
            font-size:12px;
            text-transform:uppercase;
            letter-spacing:.08em;
            font-weight:800;
            color:var(--muted);
            margin-bottom:8px;
        }
        table{
            width:100%;
            border-collapse:collapse;
            font-size:13px;
        }
        thead th{
            text-align:left;
            padding:10px 8px;
            border-bottom:2px solid var(--accent);
            color:var(--accent);
            font-size:12px;
            text-transform:uppercase;
            letter-spacing:.04em;
        }
        tbody td, tfoot th{
            padding:10px 8px;
            border-bottom:1px solid #e5e7eb;
            vertical-align:top;
        }
        .text-end{ text-align:right; }
        .muted{ color:var(--muted); }
        .totals{
            background:#fafafa;
            border:1px solid #e5e7eb;
            border-radius:14px;
            padding:14px 16px;
        }
        .totals .kv{
            display:flex;
            justify-content:space-between;
            gap:12px;
            margin:6px 0;
            font-size:13px;
        }
        .totals .grand{
            font-size:18px;
            font-weight:800;
            color:var(--accent);
        }
        .signatures{
            display:grid;
            grid-template-columns:repeat(2, minmax(0, 1fr));
            gap:18px;
            margin-top:22px;
            font-size:13px;
        }
        .sig-box{
            min-height:86px;
            border:1px solid var(--line);
            border-radius:12px;
            padding:14px;
            background:#fff;
        }
        .sig-line{
            margin-top:28px;
            border-top:1px solid #111827;
            width:100%;
        }
        .sig-label{
            color:var(--muted);
            font-size:12px;
        }
        .sig-name{
            margin-bottom:24px;
            color:#111827;
            font-weight:700;
            min-height:18px;
        }
        .no-print{
            display:grid;
            gap:8px;
            margin-top:18px;
            grid-template-columns:repeat(2, minmax(0, 1fr));
        }
        .btn{
            display:inline-flex;
            justify-content:center;
            align-items:center;
            gap:8px;
            padding:11px 14px;
            border-radius:10px;
            text-decoration:none;
            font-weight:700;
            border:1px solid transparent;
        }
        .btn-dark{
            background:#111827;
            color:#fff;
        }
        .btn-outline{
            background:#fff;
            color:#111827;
            border-color:#cbd5e1;
        }
        @media print{
            body{
                background:#fff;
                padding:0;
            }
            .receipt{
                width:100%;
                border:none;
                border-radius:0;
                box-shadow:none;
                padding:0;
            }
            .no-print{ display:none !important; }
        }
        @media (max-width: 640px){
            .meta, .signatures{
                grid-template-columns:1fr;
            }
        }
    </style>
</head>

<body onload="window.print()">
<div class="receipt">
    <div class="brand">
        <h1><?= htmlspecialchars('DE ORO HIYS GENERAL MERCHANDISE') ?></h1>
        <div class="sub">Purchase Order</div>

        <div class="badge-row">
            <span class="pill">PO No. <strong>#<?= (int)$po['purchases_id'] ?></strong></span>
            <span class="pill">Date <strong><?= !empty($po['purchase_date']) ? h(date('M d, Y', strtotime($po['purchase_date']))) : '-' ?></strong></span>
        </div>
    </div>

    <div class="dash"></div>

    <div class="meta">
        <div class="row"><span class="label">Supplier</span><span class="value"><?= htmlspecialchars($po['supplier_name'] ?? '-') ?></span></div>
        <div class="row"><span class="label">Requested By</span><span class="value">De Oro Hiys General Merchandise</span></div>
        <div class="row"><span class="label">Phone</span><span class="value"><?= htmlspecialchars($po['phone'] ?? '-') ?></span></div>
        <div class="row"><span class="label">Address</span><span class="value"><?= htmlspecialchars($po['address'] ?? '-') ?></span></div>
    </div>

    <div class="dash"></div>

    <div class="section-title">
        <span>Items</span>
        <span>Qty / Sacks</span>
    </div>

    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Grade</th>
                <th class="text-end">Qty</th>
                <th class="text-end">Supplier Price</th>
                <th class="text-end">Line Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $item): ?>
                <?php
                    $unitPrice = (float)($item['supplier_price'] ?: $item['estimated_price'] ?: $item['price_per_sack'] ?: 0);
                    $lineTotal = (float)($item['line_total'] ?? 0);
                    if ($lineTotal <= 0) {
                        $lineTotal = (float)$item['quantity_sacks'] * $unitPrice;
                    }
                    $total += $lineTotal;
                ?>
                <tr>
                    <td><?= htmlspecialchars($item['variety'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($item['grade'] ?? '-') ?></td>
                    <td class="text-end"><?= peso($item['quantity_sacks'] ?? 0) ?></td>
                    <td class="text-end">₱<?= peso($unitPrice) ?></td>
                    <td class="text-end">₱<?= peso($lineTotal) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="dash"></div>

    <div class="totals">
        <div class="kv"><span class="muted">Grand Total</span><span class="grand">₱<?= peso($total) ?></span></div>
        <div class="kv"><span class="muted">Total Items</span><span><?= count($items) ?></span></div>
    </div>

    <?php if ($markupKg !== null || $sellKg !== null || $sellSack !== null): ?>
        <div class="dash"></div>
        <div class="section-title">
            <span>Receiving Pricing</span>
            <span>Suggested Sell</span>
        </div>
        <div class="meta">
            <?php if ($markupKg !== null): ?>
                <div class="row"><span class="label">Markup / Kg</span><span class="value">₱<?= peso($markupKg) ?></span></div>
            <?php endif; ?>
            <?php if ($sellKg !== null): ?>
                <div class="row"><span class="label">Suggested Sell / Kg</span><span class="value">₱<?= peso($sellKg) ?></span></div>
            <?php endif; ?>
            <?php if ($sellSack !== null): ?>
                <div class="row"><span class="label">Suggested Sell / Sack</span><span class="value">₱<?= peso($sellSack) ?></span></div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div class="dash"></div>

    <div class="signatures">
        <div class="sig-box">
            <div class="sig-label">Requested By</div>
            <div class="sig-name"><?= htmlspecialchars($po['created_by_name'] ?? '-') ?></div>
            <div class="sig-line"></div>
        </div>
        <div class="sig-box">
            <div class="sig-label">Approved By</div>
            <div class="sig-name"><?= htmlspecialchars($po['approved_by_name'] ?? 'Owner') ?></div>
            <div class="sig-line"></div>
        </div>
    </div>

    <div class="no-print">
        <button class="btn btn-dark" onclick="window.print()">Print Again</button>
        <a href="suppliers.php" class="btn btn-outline">Back to Suppliers</a>
    </div>
</div>

</body>
</html>
