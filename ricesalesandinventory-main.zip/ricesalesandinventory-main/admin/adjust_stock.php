<?php
session_start();
if (!isset($_SESSION['user_id'])) {
header("Location: ../login.php");
exit;
}
if (strtolower($_SESSION['role'] ?? '') !== 'admin') {
header("Location: ../login.php");
exit;
}

$username = $_SESSION['username'] ?? 'User';
$role = $_SESSION['role'] ?? '';
$user_id = (int)($_SESSION['user_id'] ?? 0);
$activePage = 'adjust_stock';

include '../config/db.php';
$error = "";

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}
$csrf_token = (string)$_SESSION['csrf_token'];

/*
|--------------------------------------------------------------------------
| Ensure required tables exist
|--------------------------------------------------------------------------
*/
$conn->query("
CREATE TABLE IF NOT EXISTS stock_condition (
stock_condition_id INT(11) NOT NULL AUTO_INCREMENT,
product_id INT NOT NULL,
rice_name VARCHAR(150) NOT NULL,
variety VARCHAR(150) NOT NULL,
condition_type ENUM('Sellable','Discounted','Unsellable','Damaged') NOT NULL DEFAULT 'Sellable',
reason VARCHAR(255) DEFAULT NULL,
quantity DECIMAL(12,2) NOT NULL DEFAULT 0.00,
discount_price_per_kg DECIMAL(12,2) DEFAULT NULL,
adjusted_by INT NULL,
date_arrived DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY (stock_condition_id),
KEY idx_product_condition (product_id, condition_type),
KEY idx_rice_variety (rice_name, variety),
KEY idx_condition_date (condition_type, date_arrived)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
");

$conn->query("
CREATE TABLE IF NOT EXISTS product_discount_stock (
product_id INT NOT NULL PRIMARY KEY,
qty_kg DECIMAL(12,2) NOT NULL DEFAULT 0,
price_per_kg DECIMAL(12,2) NOT NULL DEFAULT 0,
updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
");

$conn->query("
CREATE TABLE IF NOT EXISTS adjust_logs (
adjust_log_id INT AUTO_INCREMENT PRIMARY KEY,
product_id INT NOT NULL,
adjust_type ENUM('add','damaged','unsellable','discounted') NOT NULL,
qty_sacks DECIMAL(12,2) NOT NULL DEFAULT 0,
qty_kg DECIMAL(12,2) NOT NULL DEFAULT 0,
before_stock_kg DECIMAL(12,2) NOT NULL DEFAULT 0,
after_stock_kg DECIMAL(12,2) NOT NULL DEFAULT 0,
note VARCHAR(255) NULL,
adjusted_by INT NULL,
created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
INDEX idx_product_created (product_id, created_at),
INDEX idx_type_created (adjust_type, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
");

/*
|--------------------------------------------------------------------------
| Safe migration for older tables
|--------------------------------------------------------------------------
*/
$stockConditionCols = [];
$resCols = $conn->query("SHOW COLUMNS FROM stock_condition");
if ($resCols) {
while ($col = $resCols->fetch_assoc()) {
$stockConditionCols[$col['Field']] = true;
}
}

if (!isset($stockConditionCols['product_id'])) {
$conn->query("ALTER TABLE stock_condition ADD COLUMN product_id INT NOT NULL DEFAULT 0 AFTER stock_condition_id");
}
if (!isset($stockConditionCols['discount_price_per_kg'])) {
$conn->query("ALTER TABLE stock_condition ADD COLUMN discount_price_per_kg DECIMAL(12,2) DEFAULT NULL AFTER quantity");
}
if (!isset($stockConditionCols['adjusted_by'])) {
$conn->query("ALTER TABLE stock_condition ADD COLUMN adjusted_by INT NULL AFTER discount_price_per_kg");
}
if (!isset($stockConditionCols['batch_id'])) {
$conn->query("ALTER TABLE stock_condition ADD COLUMN batch_id INT NULL AFTER product_id");
}
$conn->query("
ALTER TABLE stock_condition
MODIFY COLUMN condition_type ENUM('Sellable','Discounted','Unsellable','Damaged') NOT NULL DEFAULT 'Sellable'
");

$adjustLogCols = [];
$resAdjustCols = $conn->query("SHOW COLUMNS FROM adjust_logs");
if ($resAdjustCols) {
while ($col = $resAdjustCols->fetch_assoc()) {
$adjustLogCols[$col['Field']] = true;
}
}
if (!isset($adjustLogCols['batch_id'])) {
$conn->query("ALTER TABLE adjust_logs ADD COLUMN batch_id INT NULL AFTER product_id");
}
$conn->query("
ALTER TABLE adjust_logs
MODIFY COLUMN adjust_type ENUM('add','damaged','unsellable','discounted','in','out') NOT NULL
");

$productCols = [];
$resProductCols = $conn->query("SHOW COLUMNS FROM products");
if ($resProductCols) {
while ($col = $resProductCols->fetch_assoc()) {
$productCols[$col['Field']] = true;
}
}

if (!isset($productCols['price_per_kg'])) {
$conn->query("ALTER TABLE products ADD COLUMN price_per_kg DECIMAL(12,2) NOT NULL DEFAULT 0.00");
}

/*
|--------------------------------------------------------------------------
| Settings
|--------------------------------------------------------------------------
*/
$DEFAULT_OVERSTOCK_LIMIT_KG = 1000;
$OVERSTOCK_LIMIT_KG = $DEFAULT_OVERSTOCK_LIMIT_KG;

$settingsExists = $conn->query("SHOW TABLES LIKE 'stock_settings'");
if ($settingsExists && $settingsExists->num_rows > 0) {
$settingsRes = $conn->query("
SELECT over_threshold_kg
FROM stock_settings
WHERE id = 1
LIMIT 1
");
if ($settingsRes) {
$settingsRow = $settingsRes->fetch_assoc();
$configuredOver = (float)($settingsRow['over_threshold_kg'] ?? 0);
if ($configuredOver > 0) {
$OVERSTOCK_LIMIT_KG = $configuredOver;
}
}
}

/*
|--------------------------------------------------------------------------
| Handle submit
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$posted_token = (string)($_POST['csrf_token'] ?? '');
if ($posted_token === '' || !hash_equals($csrf_token, $posted_token)) {
    $error = "Invalid request. Please refresh the page and try again.";
} else {
$product_id = (int)($_POST['product_id'] ?? 0);
$batch_id = (int)($_POST['batch_id'] ?? 0);
$action = strtolower(trim($_POST['action'] ?? 'add'));
$qty_units = (int)($_POST['qty_value'] ?? 0);
$reason_code = trim($_POST['reason_code'] ?? '');
$note = trim($_POST['note'] ?? '');
$discount_price_per_kg = (float)($_POST['discount_price_per_kg'] ?? 0);

$validActions = ['add', 'damaged', 'unsellable', 'discounted'];
if (!in_array($action, $validActions, true)) {
$action = 'add';
}

if ($product_id <= 0 || $qty_units <= 0) {
$error = "Invalid product or quantity.";
} elseif ($action !== 'add' && $batch_id <= 0) {
$error = "Please select the stock batch to adjust.";
} elseif (in_array($action, ['damaged', 'unsellable'], true) && $reason_code === '') {
$error = "Please select a reason.";
} elseif ($action === 'discounted' && $discount_price_per_kg <= 0) {
$error = "Please enter a valid discounted price per kg.";
} else {
$stmtProduct = $conn->prepare("
SELECT product_id, variety, grade, unit_weight_kg, price_per_kg
FROM products
WHERE product_id = ?
LIMIT 1
");

if (!$stmtProduct) {
$error = "Prepare failed: " . $conn->error;
} else {
$stmtProduct->bind_param("i", $product_id);
$stmtProduct->execute();
$productRow = $stmtProduct->get_result()->fetch_assoc();
$stmtProduct->close();

$unit_weight = (float)($productRow['unit_weight_kg'] ?? 0);

if (!$productRow || $unit_weight <= 0) {
$error = "Product has no valid sack size.";
} else {
$qty_kg = $qty_units * $unit_weight;

$reasonMap = [
'torn_sack' => 'Torn sack',
'wet_stock' => 'Wet stock',
'pest_contamination' => 'Pest contamination',
'broken_seal' => 'Broken seal',
'quality_downgrade' => 'Quality downgrade',
'manual_recount' => 'Manual recount correction',
'other' => 'Other'
];

$conn->begin_transaction();

try {
$stmtStock = $conn->prepare("
SELECT IFNULL(SUM(remaining_qty_kg), 0) AS stock_kg
FROM stock_batches
WHERE product_id = ?
");

if (!$stmtStock) {
throw new Exception("Prepare failed (stock check): " . $conn->error);
}

$stmtStock->bind_param("i", $product_id);
$stmtStock->execute();
$current = $stmtStock->get_result()->fetch_assoc();
$stmtStock->close();

$current_stock = (float)($current['stock_kg'] ?? 0);

$selectedBatch = null;
if ($action !== 'add') {
$stmtBatch = $conn->prepare("
SELECT batch_id, batch_code, product_id, unit_weight_kg, remaining_qty_kg, regular_qty_kg,
       discounted_qty_kg, regular_price_per_kg, discounted_price_per_kg, arrived_at
FROM stock_batches
WHERE batch_id = ? AND product_id = ?
FOR UPDATE
");
if (!$stmtBatch) {
throw new Exception("Prepare failed (batch check): " . $conn->error);
}
$stmtBatch->bind_param("ii", $batch_id, $product_id);
$stmtBatch->execute();
$selectedBatch = $stmtBatch->get_result()->fetch_assoc();
$stmtBatch->close();
if (!$selectedBatch) {
throw new Exception("Selected batch was not found for this product.");
}
}

$discounted_now = 0.0;
$stmtDisc = $conn->prepare("
SELECT qty_kg
FROM product_discount_stock
WHERE product_id = ?
FOR UPDATE
");
if ($stmtDisc) {
$stmtDisc->bind_param("i", $product_id);
$stmtDisc->execute();
$drow = $stmtDisc->get_result()->fetch_assoc();
$discounted_now = (float)($drow['qty_kg'] ?? 0);
$stmtDisc->close();
}

$rice_name = (string)($productRow['variety'] ?? '');
$variety = (string)($productRow['grade'] ?? '');

if ($rice_name === '' || $variety === '') {
throw new Exception("Product name/variety missing; cannot log stock condition.");
}

$reasonLabel = $reasonMap[$reason_code] ?? 'Manual adjustment';
$fullReason = $reasonLabel . ($note !== '' ? ' - ' . $note : '');

if ($action === 'add') {
$projected = $current_stock + $qty_kg;

if ($projected > $OVERSTOCK_LIMIT_KG) {
throw new Exception(
"Cannot add stock. This will exceed the overstock threshold.\n" .
"Current stock: " . number_format($current_stock, 2) . " kg\n" .
"Incoming: " . number_format($qty_kg, 2) . " kg\n" .
"Projected: " . number_format($projected, 2) . " kg\n" .
"Limit: " . number_format($OVERSTOCK_LIMIT_KG, 2) . " kg"
);
}

$reference_type = "adjust";
$tx_type = "adjust";
$tx_qty_kg = $qty_kg;
$addNote = $note !== '' ? $note : 'Manual stock addition';

$currentPrice = (float)($productRow['price_per_kg'] ?? 0);
$stmtNewBatch = $conn->prepare("
INSERT INTO stock_batches
  (product_id, batch_code, source_reference_id, source_reference_type, arrived_at, unit_weight_kg,
   initial_qty_kg, remaining_qty_kg, regular_qty_kg, discounted_qty_kg,
   cost_per_kg, regular_price_per_kg, discounted_price_per_kg, note, created_by, created_at, updated_at)
VALUES (?, NULL, NULL, 'adjust', CURDATE(), ?, ?, ?, ?, 0.00, ?, ?, NULL, ?, ?, NOW(), NOW())
");
if (!$stmtNewBatch) {
throw new Exception("Prepare failed (manual batch): " . $conn->error);
}
$stmtNewBatch->bind_param(
"iddddddsi",
$product_id,
$unit_weight,
$qty_kg,
$qty_kg,
$qty_kg,
$currentPrice,
$currentPrice,
$addNote,
$user_id
);
$stmtNewBatch->execute();
$batch_id = (int)$conn->insert_id;
$stmtNewBatch->close();

$batchCode = 'B' . str_pad((string)$batch_id, 6, '0', STR_PAD_LEFT);
$stmtBatchCode = $conn->prepare("UPDATE stock_batches SET batch_code=? WHERE batch_id=?");
if ($stmtBatchCode) {
$stmtBatchCode->bind_param("si", $batchCode, $batch_id);
$stmtBatchCode->execute();
$stmtBatchCode->close();
}
$addNote .= " | batch={$batchCode}";

$stmtTx = $conn->prepare("
INSERT INTO inventory_transactions
(product_id, batch_id, qty_kg, reference_id, reference_type, type, note, created_at)
VALUES (?, ?, ?, NULL, ?, ?, ?, NOW())
");

if (!$stmtTx) {
throw new Exception("Prepare failed (inventory add): " . $conn->error);
}

$stmtTx->bind_param("iidsss", $product_id, $batch_id, $tx_qty_kg, $reference_type, $tx_type, $addNote);
$stmtTx->execute();
$stmtTx->close();

$before_stock_kg = $current_stock;
$after_stock_kg = $current_stock + $qty_kg;

$stmtAdj = $conn->prepare("
INSERT INTO adjust_logs
(product_id, batch_id, adjust_type, qty_sacks, qty_kg, before_stock_kg, after_stock_kg, note, adjusted_by, created_at)
VALUES (?, ?, 'add', ?, ?, ?, ?, ?, ?, NOW())
");

if (!$stmtAdj) {
throw new Exception("Prepare failed (adjust log add): " . $conn->error);
}

$qty_sacks_for_log = (float)$qty_units;
$stmtAdj->bind_param(
"iiddddsi",
$product_id,
$batch_id,
$qty_sacks_for_log,
$qty_kg,
$before_stock_kg,
$after_stock_kg,
$addNote,
$user_id
);
$stmtAdj->execute();
$stmtAdj->close();

} elseif ($action === 'damaged' || $action === 'unsellable') {
$regular_available = (float)($selectedBatch['regular_qty_kg'] ?? 0);

if ($regular_available < $qty_kg) {
throw new Exception("Not enough regular stock in selected batch. Batch regular available: " . number_format($regular_available, 2) . " kg");
}

$condition_type = ($action === 'damaged') ? 'Damaged' : 'Unsellable';

$stmtBatchReduce = $conn->prepare("
UPDATE stock_batches
SET regular_qty_kg = regular_qty_kg - ?,
    remaining_qty_kg = remaining_qty_kg - ?,
    updated_at = NOW()
WHERE batch_id = ? AND product_id = ? AND regular_qty_kg >= ?
");
if (!$stmtBatchReduce) {
throw new Exception("Prepare failed (batch reduce): " . $conn->error);
}
$stmtBatchReduce->bind_param("ddiid", $qty_kg, $qty_kg, $batch_id, $product_id, $qty_kg);
$stmtBatchReduce->execute();
if ($stmtBatchReduce->affected_rows !== 1) {
$stmtBatchReduce->close();
throw new Exception("Selected batch stock changed. Please refresh and try again.");
}
$stmtBatchReduce->close();

$stmtCond = $conn->prepare("
INSERT INTO stock_condition
(product_id, batch_id, rice_name, variety, condition_type, reason, quantity, adjusted_by, date_arrived)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
");

if (!$stmtCond) {
throw new Exception("Prepare failed (stock_condition writeoff): " . $conn->error);
}

$qty_for_condition = (float)$qty_kg;
$stmtCond->bind_param(
"iissssdi",
$product_id,
$batch_id,
$rice_name,
$variety,
$condition_type,
$fullReason,
$qty_for_condition,
$user_id
);
$stmtCond->execute();
$stmtCond->close();

$reference_type = "adjust";
$tx_type = "adjust";
$tx_qty_kg = (-1 * $qty_kg);

$stmtTx = $conn->prepare("
INSERT INTO inventory_transactions
(product_id, batch_id, qty_kg, reference_id, reference_type, type, note, created_at)
VALUES (?, ?, ?, NULL, ?, ?, ?, NOW())
");

if (!$stmtTx) {
throw new Exception("Prepare failed (inventory reduce): " . $conn->error);
}

$stmtTx->bind_param("iidsss", $product_id, $batch_id, $tx_qty_kg, $reference_type, $tx_type, $fullReason);
$stmtTx->execute();
$stmtTx->close();

$before_stock_kg = $current_stock;
$after_stock_kg = $current_stock - $qty_kg;

$stmtAdj = $conn->prepare("
INSERT INTO adjust_logs
(product_id, batch_id, adjust_type, qty_sacks, qty_kg, before_stock_kg, after_stock_kg, note, adjusted_by, created_at)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
");

if (!$stmtAdj) {
throw new Exception("Prepare failed (adjust log reduce): " . $conn->error);
}

$qty_sacks_for_log = (float)$qty_units;
$adjustType = $action;
$stmtAdj->bind_param(
"iisddddsi",
$product_id,
$batch_id,
$adjustType,
$qty_sacks_for_log,
$qty_kg,
$before_stock_kg,
$after_stock_kg,
$fullReason,
$user_id
);
$stmtAdj->execute();
$stmtAdj->close();

} else { // discounted
$regular_available = (float)($selectedBatch['regular_qty_kg'] ?? 0);

if ($regular_available < $qty_kg) {
throw new Exception("Not enough regular stock in selected batch to discount. Batch regular available: " . number_format($regular_available, 2) . " kg");
}

$stmtBatchDiscount = $conn->prepare("
UPDATE stock_batches
SET regular_qty_kg = regular_qty_kg - ?,
    discounted_qty_kg = discounted_qty_kg + ?,
    discounted_price_per_kg = ?,
    updated_at = NOW()
WHERE batch_id = ? AND product_id = ? AND regular_qty_kg >= ?
");
if (!$stmtBatchDiscount) {
throw new Exception("Prepare failed (batch discount): " . $conn->error);
}
$stmtBatchDiscount->bind_param("dddiid", $qty_kg, $qty_kg, $discount_price_per_kg, $batch_id, $product_id, $qty_kg);
$stmtBatchDiscount->execute();
if ($stmtBatchDiscount->affected_rows !== 1) {
$stmtBatchDiscount->close();
throw new Exception("Selected batch stock changed. Please refresh and try again.");
}
$stmtBatchDiscount->close();

$stmtUp = $conn->prepare("
INSERT INTO product_discount_stock (product_id, qty_kg, price_per_kg, updated_at)
VALUES (?, ?, ?, NOW())
ON DUPLICATE KEY UPDATE
qty_kg = qty_kg + VALUES(qty_kg),
price_per_kg = VALUES(price_per_kg),
updated_at = NOW()
");

if (!$stmtUp) {
throw new Exception("Prepare failed (product_discount_stock): " . $conn->error);
}

$stmtUp->bind_param("idd", $product_id, $qty_kg, $discount_price_per_kg);
$stmtUp->execute();
$stmtUp->close();

$discountReason = "Discounted @ ₱" . number_format($discount_price_per_kg, 2) . "/kg";
if ($note !== '') {
$discountReason .= " - " . $note;
}

$stmtCond = $conn->prepare("
INSERT INTO stock_condition
(product_id, batch_id, rice_name, variety, condition_type, reason, quantity, discount_price_per_kg, adjusted_by, date_arrived)
VALUES (?, ?, ?, ?, 'Discounted', ?, ?, ?, ?, NOW())
");

if (!$stmtCond) {
throw new Exception("Prepare failed (stock_condition discounted): " . $conn->error);
}

$qty_for_condition = (float)$qty_kg;
$stmtCond->bind_param(
"iisssddi",
$product_id,
$batch_id,
$rice_name,
$variety,
$discountReason,
$qty_for_condition,
$discount_price_per_kg,
$user_id
);
$stmtCond->execute();
$stmtCond->close();

$before_stock_kg = $current_stock;
$after_stock_kg = $current_stock;

$stmtAdj = $conn->prepare("
INSERT INTO adjust_logs
(product_id, batch_id, adjust_type, qty_sacks, qty_kg, before_stock_kg, after_stock_kg, note, adjusted_by, created_at)
VALUES (?, ?, 'discounted', ?, ?, ?, ?, ?, ?, NOW())
");

if (!$stmtAdj) {
throw new Exception("Prepare failed (adjust log discounted): " . $conn->error);
}

$qty_sacks_for_log = (float)$qty_units;
$stmtAdj->bind_param(
"iiddddsi",
$product_id,
$batch_id,
$qty_sacks_for_log,
$qty_kg,
$before_stock_kg,
$after_stock_kg,
$discountReason,
$user_id
);
$stmtAdj->execute();
$stmtAdj->close();
}

$conn->commit();
header("Location: adjust_stock.php?success=1");
exit;

} catch (Exception $e) {
$conn->rollback();
$error = $e->getMessage();
}
}
}
}
}
}

/*
|--------------------------------------------------------------------------
| Load products
|--------------------------------------------------------------------------
*/
$products = $conn->query("
SELECT
p.product_id,
p.variety,
p.grade,
p.unit_weight_kg,
p.price_per_kg,
IFNULL(SUM(sb.remaining_qty_kg), 0) AS stock_kg,
IFNULL(SUM(sb.discounted_qty_kg), 0) AS discounted_kg
FROM products p
LEFT JOIN stock_batches sb
ON sb.product_id = p.product_id
WHERE p.archived = 0
GROUP BY p.product_id
ORDER BY p.variety ASC
");

$batchData = [];
$batchRes = $conn->query("
SELECT
  sb.batch_id,
  sb.product_id,
  sb.batch_code,
  sb.arrived_at,
  sb.unit_weight_kg,
  sb.remaining_qty_kg,
  sb.regular_qty_kg,
  sb.discounted_qty_kg,
  sb.regular_price_per_kg,
  sb.discounted_price_per_kg
FROM stock_batches sb
JOIN products p ON p.product_id = sb.product_id
WHERE p.archived = 0 AND sb.remaining_qty_kg > 0.00001
ORDER BY p.variety ASC, p.grade ASC, sb.arrived_at ASC, sb.batch_id ASC
");
if ($batchRes) {
    $batchCounters = [];
while ($b = $batchRes->fetch_assoc()) {
$pid = (int)$b['product_id'];
if (!isset($batchCounters[$pid])) {
    $batchCounters[$pid] = 0;
}
$batchCounters[$pid]++;
$batchData[] = [
'batch_id' => (int)$b['batch_id'],
'product_id' => (int)$b['product_id'],
'batch_code' => (string)($b['batch_code'] ?: ('B' . str_pad((string)$b['batch_id'], 6, '0', STR_PAD_LEFT))),
'batch_label' => 'Batch ' . $batchCounters[$pid],
'arrived_at' => (string)($b['arrived_at'] ?? ''),
'unit_weight_kg' => (float)$b['unit_weight_kg'],
'remaining_qty_kg' => (float)$b['remaining_qty_kg'],
'regular_qty_kg' => (float)$b['regular_qty_kg'],
'discounted_qty_kg' => (float)$b['discounted_qty_kg'],
'regular_price_per_kg' => (float)$b['regular_price_per_kg'],
'discounted_price_per_kg' => (float)($b['discounted_price_per_kg'] ?? 0),
];
}
}

$productHistoryMap = [];
$historyRes = $conn->query("
    SELECT
        al.product_id,
        p.variety,
        p.grade,
        al.adjust_type,
        al.qty_sacks,
        al.qty_kg,
        al.before_stock_kg,
        al.after_stock_kg,
        al.note,
        al.created_at,
        al.batch_id,
        sb.batch_code,
        sc.condition_type,
        sc.reason AS condition_reason,
        sc.discount_price_per_kg
    FROM adjust_logs al
    JOIN products p ON p.product_id = al.product_id
    LEFT JOIN stock_batches sb ON sb.batch_id = al.batch_id
    LEFT JOIN stock_condition sc
        ON sc.product_id = al.product_id
       AND sc.batch_id = al.batch_id
       AND sc.date_arrived = al.created_at
    WHERE p.archived = 0
    ORDER BY al.created_at DESC, al.adjust_log_id DESC
");
if ($historyRes) {
    while ($h = $historyRes->fetch_assoc()) {
        $pid = (int)$h['product_id'];
        if (!isset($productHistoryMap[$pid])) {
            $productHistoryMap[$pid] = [
                'product_label' => (string)($h['variety'] . ' - ' . $h['grade']),
                'items' => [],
            ];
        }
        $productHistoryMap[$pid]['items'][] = [
            'batch_id' => (int)$h['batch_id'],
            'adjust_type' => (string)$h['adjust_type'],
            'qty_sacks' => (float)$h['qty_sacks'],
            'qty_kg' => (float)$h['qty_kg'],
            'before_stock_kg' => (float)$h['before_stock_kg'],
            'after_stock_kg' => (float)$h['after_stock_kg'],
            'note' => (string)($h['note'] ?? ''),
            'created_at' => (string)$h['created_at'],
            'batch_code' => (string)($h['batch_code'] ?? ''),
            'condition_type' => (string)($h['condition_type'] ?? ''),
            'condition_reason' => (string)($h['condition_reason'] ?? ''),
            'discount_price_per_kg' => $h['discount_price_per_kg'] !== null ? (float)$h['discount_price_per_kg'] : null,
        ];
    }
}

$condSearch = trim((string)($_GET['search'] ?? ''));
$condFilter = trim((string)($_GET['condition'] ?? ''));

$discountedConditionResult = $conn->query("
    SELECT
        rice_name,
        variety,
        discount_price_per_kg,
        SUM(quantity) AS total_kg,
        MAX(date_arrived) AS last_update
    FROM stock_condition
    WHERE condition_type = 'Discounted'
    GROUP BY rice_name, variety, discount_price_per_kg
    ORDER BY last_update DESC, rice_name ASC, variety ASC
");

$conditionSql = "
    SELECT
        rice_name,
        variety,
        condition_type,
        reason,
        discount_price_per_kg,
        SUM(quantity) AS total_kg,
        MAX(date_arrived) AS last_update
    FROM stock_condition
    WHERE 1=1
";
$conditionParams = [];
$conditionTypes = '';

if ($condSearch !== '') {
    $conditionSql .= " AND (
        rice_name LIKE ? OR
        variety LIKE ? OR
        reason LIKE ?
    )";
    $like = "%{$condSearch}%";
    $conditionParams[] = $like;
    $conditionParams[] = $like;
    $conditionParams[] = $like;
    $conditionTypes .= 'sss';
}

if ($condFilter !== '' && in_array($condFilter, ['Sellable', 'Discounted', 'Unsellable', 'Damaged'], true)) {
    $conditionSql .= " AND condition_type = ?";
    $conditionParams[] = $condFilter;
    $conditionTypes .= 's';
}

$conditionSql .= "
    GROUP BY rice_name, variety, condition_type, reason, discount_price_per_kg
    ORDER BY last_update DESC, rice_name ASC, variety ASC
";

$conditionStmt = $conn->prepare($conditionSql);
if (!$conditionStmt) {
    die("Query Prepare Failed: " . $conn->error);
}
if (!empty($conditionParams)) {
    $conditionStmt->bind_param($conditionTypes, ...$conditionParams);
}
if (!$conditionStmt->execute()) {
    die("Query Execute Failed: " . $conditionStmt->error);
}
$conditionResult = $conditionStmt->get_result();

$discountedConditionCount = ($discountedConditionResult instanceof mysqli_result) ? (int)$discountedConditionResult->num_rows : 0;
$conditionRecordsCount = ($conditionResult instanceof mysqli_result) ? (int)$conditionResult->num_rows : 0;
$tab = strtolower((string)($_GET['tab'] ?? 'adjust'));
if (!in_array($tab, ['adjust', 'condition'], true)) {
$tab = 'adjust';
}
$embedded = (strtolower((string)($_GET['embedded'] ?? '')) === '1' || strtolower((string)($_GET['embedded'] ?? '')) === 'true');
$activePage = ($tab === 'condition') ? 'stock_condition' : 'adjust_stock';

if ($embedded && $tab === 'adjust') {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>New Adjustment | DE ORO HIYS</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
        <link href="../css/inventory-adjust-stock.css" rel="stylesheet">
        <link href="../css/inventory-mobile.css" rel="stylesheet">
        <style>
            body{
                background:
                    radial-gradient(circle at top left, rgba(44,62,80,.12), transparent 28%),
                    linear-gradient(180deg, #edf1f5 0%, #e6edf4 100%);
            }
            .embedded-shell{
                padding:0;
            }
            .form-control,
            .form-select{
                border-color:#cbd5e1;
                background:#fff;
                color:#1f2c39;
            }
            .form-control:focus,
            .form-select:focus{
                border-color:#5f7c99;
                box-shadow:0 0 0 .2rem rgba(95,124,153,.18);
            }
        </style>
    </head>
    <body>
    <div class="embedded-shell">
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="modal-header px-4 py-3">
            <div>
                <h5 class="mb-1 fw-bold">New Adjustment</h5>
                <div class="text-muted">Adjust stock without leaving the Products page.</div>
            </div>
        </div>

        <div class="modal-body px-4 py-3">
            <form method="POST" id="adjustForm">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
                <div class="mb-3">
                    <label class="form-label fw-semibold">Product</label>
                    <select name="product_id" id="productSelect" class="form-select" required>
                        <option value="">Select product</option>
                        <?php foreach ($products as $row): ?>
                            <?php $regular_available = max(0, (float)$row['stock_kg'] - (float)$row['discounted_kg']); ?>
                            <option
                                value="<?= (int)$row['product_id'] ?>"
                                data-stock="<?= (float)$row['stock_kg'] ?>"
                                data-weight="<?= (float)$row['unit_weight_kg'] ?>"
                                data-discounted="<?= (float)$row['discounted_kg'] ?>"
                                data-regular="<?= $regular_available ?>"
                                data-price="<?= (float)$row['price_per_kg'] ?>"
                            >
                                <?= htmlspecialchars($row['variety'] . ' - ' . $row['grade'] . ' (' . (float)$row['unit_weight_kg'] . ' kg/sack)') ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Action</label>
                    <select class="form-select" id="actionSelect" name="action" required>
                        <option value="add">Stock Correction</option>
                        <option value="damaged">Damaged</option>
                        <option value="unsellable">Unsellable</option>
                        <option value="discounted">Discounted</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Quantity (sacks)</label>
                    <input type="number" id="qtyInput" name="qty_value" class="form-control" value="1" min="1" step="1" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Stock Batch</label>
                    <select name="batch_id" id="batchSelect" class="form-select">
                        <option value="">Select batch</option>
                    </select>
                    <small class="text-muted">Required for damaged, unsellable, and discounted adjustments.</small>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Reason</label>
                    <select name="reason_code" id="reasonCode" class="form-select">
                        <option value="">Select reason</option>
                        <option value="torn_sack">Torn sack</option>
                        <option value="wet_stock">Wet stock</option>
                        <option value="pest_contamination">Pest contamination</option>
                        <option value="broken_seal">Broken seal</option>
                        <option value="quality_downgrade">Quality downgrade</option>
                        <option value="manual_recount">Manual recount correction</option>
                        <option value="other">Other</option>
                    </select>
                </div>

                <div class="mb-3" id="discountWrap">
                    <label class="form-label fw-semibold">Discount Price (₱ per kg)</label>
                    <input type="number" name="discount_price_per_kg" id="discountPrice" class="form-control" min="0" step="0.01" placeholder="0.00">
                </div>

                <div class="mb-0">
                    <label class="form-label fw-semibold">Remarks / Notes</label>
                    <textarea name="note" id="noteField" class="form-control" rows="2" placeholder="Optional remarks"></textarea>
                </div>
            </form>
        </div>

        <div class="modal-footer px-4 py-3">
            <button type="button" class="btn btn-secondary" onclick="window.parent.postMessage({type:'close-adjustment-modal'}, '*')">Cancel</button>
            <button type="submit" form="adjustForm" class="btn btn-primary px-4">Save Adjustment</button>
        </div>
    </div>

    <script>
        const batchData = <?= json_encode($batchData, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
        const productSelect = document.getElementById('productSelect');
        const actionSelect = document.getElementById('actionSelect');
        const batchSelect = document.getElementById('batchSelect');
        const reasonCode = document.getElementById('reasonCode');
        const discountWrap = document.getElementById('discountWrap');
        const discountPrice = document.getElementById('discountPrice');
        const qtyInput = document.getElementById('qtyInput');

        function refreshBatches() {
            const selectedProduct = parseInt(productSelect.value || '0', 10);
            batchSelect.innerHTML = '<option value="">Select batch</option>';
            batchData.filter(b => Number(b.product_id) === selectedProduct).forEach(batch => {
                const opt = document.createElement('option');
                opt.value = batch.batch_id;
                opt.textContent = `${batch.batch_label} (${batch.batch_code}) - ${Number(batch.remaining_qty_kg).toFixed(2)} kg`;
                batchSelect.appendChild(opt);
            });
        }

        function refreshActionState() {
            const action = actionSelect.value;
            const needsBatch = action !== 'add';
            const needsReason = action === 'damaged' || action === 'unsellable';
            const needsDiscount = action === 'discounted';

            batchSelect.required = needsBatch;
            reasonCode.required = needsReason;
            discountPrice.required = needsDiscount;
            discountWrap.style.display = needsDiscount ? '' : 'none';
        }

        productSelect.addEventListener('change', refreshBatches);
        actionSelect.addEventListener('change', refreshActionState);
        refreshBatches();
        refreshActionState();
    </script>
    </body>
    </html>
    <?php
    return;
}

if ($embedded && $tab === 'condition') {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Stock Condition | DE ORO HIYS</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
        <link href="../css/inventory-adjust-stock.css" rel="stylesheet">
        <link href="../css/inventory-mobile.css" rel="stylesheet">
        <style>
            body{ background:#f4f7fb; }
            .embedded-shell{ padding:1rem; }
        </style>
    </head>
    <body>
        <div class="embedded-shell">
            <div class="card modern-card mb-4">
                <div class="card-body p-4">
                    <form method="GET" action="adjust_stock.php" class="row g-3 align-items-end">
                        <input type="hidden" name="tab" value="condition">
                        <input type="hidden" name="embedded" value="1">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Search</label>
                            <input type="text" name="search" class="form-control" value="<?= htmlspecialchars($condSearch) ?>" placeholder="Rice name, variety, or reason">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Condition</label>
                            <select name="condition" class="form-select">
                                <option value="">All conditions</option>
                                <?php foreach (['Sellable','Discounted','Unsellable','Damaged'] as $condOption): ?>
                                    <option value="<?= htmlspecialchars($condOption) ?>" <?= $condFilter === $condOption ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($condOption) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2 d-grid">
                            <button type="submit" class="btn btn-primary">Filter</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card modern-card" id="conditionRecordsPanel">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                        <div>
                            <h5 class="fw-bold mb-0">Stock Condition Records</h5>
                            <small class="text-muted">Latest records first</small>
                        </div>
                        <span class="badge bg-secondary"><?= $conditionRecordsCount ?> records</span>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-striped align-middle mb-0">
                            <thead class="table-dark">
                                <tr>
                                    <th>Item</th>
                                    <th>Condition</th>
                                    <th class="text-end">Qty</th>
                                    <th>Reason</th>
                                    <th>Discount Price</th>
                                    <th>Last Updated</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($conditionResult && $conditionResult->num_rows > 0): ?>
                                    <?php while ($row = $conditionResult->fetch_assoc()): ?>
                                        <?php
                                        $badgeClass = 'secondary';
                                        if ($row['condition_type'] === 'Sellable') $badgeClass = 'success';
                                        if ($row['condition_type'] === 'Discounted') $badgeClass = 'primary';
                                        if ($row['condition_type'] === 'Unsellable') $badgeClass = 'warning';
                                        if ($row['condition_type'] === 'Damaged') $badgeClass = 'danger';
                                        ?>
                                        <tr>
                                            <td>
                                                <div class="fw-semibold"><?= htmlspecialchars($row['rice_name'] . ' - ' . $row['variety']) ?></div>
                                            </td>
                                            <td><span class="badge bg-<?= $badgeClass ?>"><?= htmlspecialchars($row['condition_type']) ?></span></td>
                                            <td class="text-end"><?= number_format((float)$row['total_kg'], 2) ?> kg</td>
                                            <td><?= htmlspecialchars((string)($row['reason'] ?? '-')) ?></td>
                                            <td>
                                                <?php if ($row['condition_type'] === 'Discounted' && $row['discount_price_per_kg'] !== null): ?>
                                                    ₱<?= number_format((float)$row['discount_price_per_kg'], 2) ?>/kg
                                                <?php else: ?>
                                                    —
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?= $row['last_update']
                                                    ? htmlspecialchars(date('M d, Y • g:i A', strtotime($row['last_update'])))
                                                    : '—' ?>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="6" class="text-center text-muted py-4">No records matched the current filters.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    <?php
    return;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Stock Adjustment | DE ORO HIYS</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="../css/inventory-adjust-stock.css" rel="stylesheet">
<link href="../css/inventory-mobile.css" rel="stylesheet">
</head>
<body>

<?php
$profileLink = '../admin/profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>

<div class="container-fluid">
<div class="row">

<?php
$adminBase = '../admin/';
$inventoryBase = '../admin/';
$ownerBase = '../owner/';
include '../includes/admin_sidebar.php';
?>

<main class="col-lg-10 ms-sm-auto px-4 main-content">

<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
    <div>
        <h2 class="mb-0">Stock Adjustment & Condition</h2>
        <p class="text-muted mb-0">Adjust inventory on the left and track product condition on the right.</p>
    </div>
</div>

<?php if (isset($_GET['success'])): ?>
<div class="alert alert-success">Stock adjusted successfully!</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="row g-4 align-items-start">
    <div class="col-xl-5">
        <div class="card modern-card legacy-form-shell adjust-panel mb-4">
            <div class="card-body p-4">

<form method="POST" id="adjustForm">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">

<div class="mb-4">
<label class="form-label fw-semibold">Product</label>
<select name="product_id" id="productSelect" class="form-select" required>
<option value="">Select product</option>
<?php while ($row = $products->fetch_assoc()): ?>
<?php $regular_available = max(0, (float)$row['stock_kg'] - (float)$row['discounted_kg']); ?>
<option
value="<?= (int)$row['product_id'] ?>"
data-stock="<?= (float)$row['stock_kg'] ?>"
data-weight="<?= (float)$row['unit_weight_kg'] ?>"
data-discounted="<?= (float)$row['discounted_kg'] ?>"
data-regular="<?= $regular_available ?>"
data-price="<?= (float)$row['price_per_kg'] ?>"
>
<?= htmlspecialchars($row['variety'] . " - " . $row['grade'] . " (" . (float)$row['unit_weight_kg'] . " kg/sack)") ?>
</option>
<?php endwhile; ?>
</select>
</div>

<div class="mb-4">
<div class="d-flex justify-content-between align-items-center mb-2">
    <label class="form-label fw-semibold mb-0">Product History</label>
    <small class="text-muted" id="historyCountText">No product selected</small>
</div>
<div class="border rounded-4 p-3 bg-light-subtle product-history-panel" id="productHistoryPanel">
    <div class="text-muted small" id="productHistoryEmpty">
        Select a product to see whether it was adjusted, discounted, damaged, or marked unsellable before.
    </div>
    <div id="productHistoryList" class="d-grid gap-2" style="display:none;"></div>
</div>
</div>

<div class="mb-4" id="batchSelectWrap" style="display:none;">
<label class="form-label fw-semibold">Stock Batch</label>
<select name="batch_id" id="batchSelect" class="form-select">
<option value="">Select batch</option>
</select>
<small class="compact-note">
Choose the exact arrival batch for damaged, unsellable, or discounted stock so old stock and new arrivals stay separated.
</small>
</div>

<input type="hidden" name="action" id="actionType" value="add">

<div class="mb-4">
<label class="form-label fw-semibold">Action</label>
<select class="form-select" id="actionSelect" name="action_ui">
    <option value="add" selected>Stock Correction</option>
    <option value="damaged">Damaged</option>
    <option value="unsellable">Unsellable</option>
    <option value="discounted">Discounted</option>
</select>
<small class="compact-note">
Only the needed action types are kept here so the page stays focused and easy to scan.
</small>
</div>

<div class="summary-mini mb-4">
<div class="box">
<div class="label">Total Stock</div>
<div class="value"><span id="stockValue">0.00</span> kg</div>
</div>
<div class="box">
<div class="label">Regular Avail.</div>
<div class="value"><span id="regularValue">0.00</span> kg</div>
</div>
<div class="box">
<div class="label">Discounted</div>
<div class="value"><span id="discountedValue">0.00</span> kg</div>
</div>
<div class="box">
<div class="label">Unit Size</div>
<div class="value"><span id="weightValue">0.00</span> kg/sack</div>
</div>
<div class="box">
<div class="label">Price</div>
<div class="value">₱<span id="priceValue">0.00</span>/kg</div>
</div>
</div>

<div class="mb-3">
<label class="form-label fw-semibold">Quantity (number of sacks)</label>
<div class="input-group" style="max-width:340px;">
<button type="button" class="btn btn-outline-danger" onclick="changeQty(-1)">−</button>
<input
type="number"
id="qtyInput"
name="qty_value"
class="form-control text-center"
value="1"
min="1"
step="1"
required
>
<button type="button" class="btn btn-outline-success" onclick="changeQty(1)">+</button>
</div>
<small class="compact-note">Equivalent quantity: <span id="totalKgValue">0.00</span> kg</small>
</div>

<div class="mb-3 reason-wrap" id="reasonWrap">
<label class="form-label fw-semibold">Reason</label>
<select name="reason_code" id="reasonCode" class="form-select">
<option value="">Select reason</option>
<option value="torn_sack">Torn sack</option>
<option value="wet_stock">Wet stock</option>
<option value="pest_contamination">Pest contamination</option>
<option value="broken_seal">Broken seal</option>
<option value="quality_downgrade">Quality downgrade</option>
<option value="manual_recount">Manual recount correction</option>
<option value="other">Other</option>
</select>
</div>

<div class="mb-3 discount-wrap" id="discountWrap">
<label class="form-label fw-semibold">Discount Price (₱ per kg)</label>
<input
type="number"
name="discount_price_per_kg"
id="discountPrice"
class="form-control"
min="0"
step="0.01"
placeholder="0.00"
>

<small class="compact-note d-block mt-2">
Current regular price: <strong>₱<span id="currentPriceText">0.00</span>/kg</strong>
<br>
Suggested discounted price: <span class="fw-semibold text-primary" id="suggestedPrice">₱0.00</span>
<br>
Estimated profit/loss: <span id="profitLossText" class="fw-semibold">₱0.00</span>
</small>
</div>

<div class="mb-4">
<label class="form-label fw-semibold">Remarks / Notes</label>
<textarea name="note" id="noteField" class="form-control" rows="3" placeholder="Optional remarks"></textarea>
</div>

<div class="d-flex gap-2 align-items-center flex-wrap">
<button type="button" class="btn btn-primary px-4" id="openConfirmModal">
Review Adjustment
</button>
<small class="text-muted">Review the adjustment details before final confirmation.</small>
</div>

</form>

            </div>
        </div>
    </div>

    <div class="col-xl-7">
        <div class="card modern-card mb-4">
            <div class="card-body p-4">
                <form method="GET" action="adjust_stock.php" class="row g-3 align-items-end">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Search</label>
                        <input type="text" name="search" class="form-control" value="<?= htmlspecialchars($condSearch) ?>" placeholder="Rice name, variety, or reason">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Condition</label>
                        <select name="condition" class="form-select">
                            <option value="">All conditions</option>
                            <?php foreach (['Sellable','Discounted','Unsellable','Damaged'] as $condOption): ?>
                                <option value="<?= htmlspecialchars($condOption) ?>" <?= $condFilter === $condOption ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($condOption) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2 d-grid">
                        <button type="submit" class="btn btn-primary">Filter</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="card modern-card" id="conditionRecordsPanel">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                    <div>
                        <h5 class="fw-bold mb-0">Stock Condition Records</h5>
                        <small class="text-muted">Latest records first</small>
                    </div>
                    <span class="badge bg-secondary"><?= $conditionRecordsCount ?> records</span>
                </div>

                <div class="table-responsive">
                    <table class="table table-striped align-middle mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th>Item</th>
                                <th>Condition</th>
                                <th class="text-end">Qty</th>
                                <th>Reason</th>
                                <th>Discount Price</th>
                                <th>Last Updated</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($conditionResult && $conditionResult->num_rows > 0): ?>
                                <?php while ($row = $conditionResult->fetch_assoc()): ?>
                                    <?php
                                    $badgeClass = 'secondary';
                                    if ($row['condition_type'] === 'Sellable') $badgeClass = 'success';
                                    if ($row['condition_type'] === 'Discounted') $badgeClass = 'primary';
                                    if ($row['condition_type'] === 'Unsellable') $badgeClass = 'warning';
                                    if ($row['condition_type'] === 'Damaged') $badgeClass = 'danger';
                                    ?>
                                    <tr>
                                        <td>
                                            <div class="fw-semibold"><?= htmlspecialchars($row['rice_name'] . ' - ' . $row['variety']) ?></div>
                                        </td>
                                        <td><span class="badge bg-<?= $badgeClass ?>"><?= htmlspecialchars($row['condition_type']) ?></span></td>
                                        <td class="text-end"><?= number_format((float)$row['total_kg'], 2) ?> kg</td>
                                        <td><?= htmlspecialchars((string)($row['reason'] ?? '-')) ?></td>
                                        <td>
                                            <?php if ($row['condition_type'] === 'Discounted' && $row['discount_price_per_kg'] !== null): ?>
                                                ₱<?= number_format((float)$row['discount_price_per_kg'], 2) ?>/kg
                                            <?php else: ?>
                                                —
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?= $row['last_update']
                                                ? htmlspecialchars(date('M d, Y • g:i A', strtotime($row['last_update'])))
                                                : '—' ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="6" class="text-center text-muted py-4">No records matched the current filters.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="confirmAdjustModal" tabindex="-1" aria-labelledby="confirmAdjustModalLabel" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content border-0 shadow rounded-4">
<div class="modal-header">
<h5 class="modal-title fw-bold" id="confirmAdjustModalLabel">Confirm Stock Adjustment</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>

<div class="modal-body">
<div class="mb-3">
<span class="badge bg-primary" id="modalActionBadge">Stock Correction</span>
</div>

<div class="row g-3">
<div class="col-12">
<div class="modal-info-box">
<div class="small-label">Product</div>
<div class="big-value" id="modalProduct">—</div>
</div>
</div>

<div class="col-12 col-sm-6">
<div class="modal-info-box">
<div class="small-label">Quantity</div>
<div class="big-value"><span id="modalQty">0</span> sack(s)</div>
</div>
</div>

<div class="col-12 col-sm-6">
<div class="modal-info-box">
<div class="small-label">Equivalent</div>
<div class="big-value"><span id="modalKg">0.00</span> kg</div>
</div>
</div>

<div class="col-12 col-sm-6">
<div class="modal-info-box">
<div class="small-label">Current Total Stock</div>
<div class="big-value"><span id="modalCurrentStock">0.00</span> kg</div>
</div>
</div>

<div class="col-12 col-sm-6">
<div class="modal-info-box">
<div class="small-label">Remaining Regular Stock</div>
<div class="big-value"><span id="modalRemaining">0.00</span> kg</div>
</div>
</div>

<div class="col-12 col-sm-6">
<div class="modal-info-box">
<div class="small-label">Current Regular Price</div>
<div class="big-value">₱<span id="modalRegularPrice">0.00</span>/kg</div>
</div>
</div>

<div class="col-12 col-sm-6" id="modalDiscountWrap" style="display:none;">
<div class="modal-info-box">
<div class="small-label">Discount Price</div>
<div class="big-value">₱<span id="modalDiscountPrice">0.00</span>/kg</div>
</div>
</div>

<div class="col-12" id="modalProfitWrap" style="display:none;">
<div class="modal-info-box">
<div class="small-label">Estimated Profit/Loss</div>
<div class="big-value" id="modalProfitLoss">₱0.00</div>
</div>
</div>

<div class="col-12" id="modalReasonWrap" style="display:none;">
<div class="modal-info-box">
<div class="small-label">Reason</div>
<div class="big-value" id="modalReason">—</div>
</div>
</div>

<div class="col-12">
<div class="modal-info-box">
<div class="small-label">Remarks</div>
<div class="big-value" id="modalNote">—</div>
</div>
</div>

<div class="col-12">
<div class="alert alert-warning mb-0 d-none" id="modalWarning">
Please review carefully. This action will affect inventory records.
</div>
</div>
</div>
</div>

<div class="modal-footer">
<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Back</button>
<button type="submit" form="adjustForm" class="btn btn-primary">Confirm Adjustment</button>
</div>
</div>
</div>
</div>

</main>
</div>
</div>

<script>
const batchData = <?= json_encode($batchData, JSON_UNESCAPED_SLASHES) ?>;
const productHistoryMap = <?= json_encode($productHistoryMap, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
const batchLabelMap = Object.fromEntries(batchData.map(batch => [String(batch.batch_id), batch.batch_label || `Batch ${batch.batch_id}`]));

function escapeHtml(value) {
const str = String(value ?? '');
return str
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function getSelectedProduct() {
return document.getElementById('productSelect').selectedOptions[0] || null;
}

function getSelectedBatch() {
const select = document.getElementById('batchSelect');
const id = parseInt(select?.value || '0', 10);
return batchData.find(b => Number(b.batch_id) === id) || null;
}

function getSelectedAction() {
const select = document.getElementById('actionSelect');
return select ? (select.value || 'add') : 'add';
}

function formatActionLabel(action) {
if (action === 'damaged') return 'Mark Damaged';
if (action === 'unsellable') return 'Mark Unsellable';
if (action === 'discounted') return 'Mark Discounted';
return 'Stock Correction';
}

function renderProductHistory(productId) {
const historyList = document.getElementById('productHistoryList');
const historyEmpty = document.getElementById('productHistoryEmpty');
const historyCountText = document.getElementById('historyCountText');
if (!historyList || !historyEmpty || !historyCountText) return;

const record = productHistoryMap[String(productId)] || productHistoryMap[productId] || null;
if (!record || !Array.isArray(record.items) || record.items.length === 0) {
    historyList.style.display = 'none';
    historyList.innerHTML = '';
    historyEmpty.style.display = 'block';
    historyCountText.textContent = productId ? 'No history found' : 'No product selected';
    return;
}

historyEmpty.style.display = 'none';
historyList.style.display = 'grid';
historyCountText.textContent = `${record.items.length} recent record(s)`;

historyList.innerHTML = record.items.slice(0, 8).map(item => {
    const type = item.adjust_type || 'adjusted';
    const badgeText = formatActionLabel(type);
    const timeText = item.created_at ? new Date(String(item.created_at).replace(' ', 'T')).toLocaleString() : 'Unknown time';
    const batchText = item.batch_id ? escapeHtml(batchLabelMap[String(item.batch_id)] || `Batch ${item.batch_id}`) : 'Batch n/a';
    const extraText = type === 'discounted'
        ? `Discounted price: ₱${Number(item.discount_price_per_kg || 0).toFixed(2)}/kg`
        : escapeHtml(item.condition_reason || item.note || '-');

    return `
        <div class="border rounded-3 bg-white p-3">
            <div class="d-flex justify-content-between align-items-start gap-2">
                <div>
                    <div class="fw-semibold">${escapeHtml(badgeText)}</div>
                    <div class="small text-muted">${batchText} • ${escapeHtml(timeText)}</div>
                </div>
                <span class="badge bg-secondary">${Number(item.qty_kg || 0).toFixed(2)} kg</span>
            </div>
            <div class="small mt-2">
                Before: ${Number(item.before_stock_kg || 0).toFixed(2)} kg | After: ${Number(item.after_stock_kg || 0).toFixed(2)} kg
            </div>
            <div class="small text-muted mt-1">${extraText}</div>
        </div>
    `;
}).join('');
}

function kgToSacks(kg, weight) {
const qtyKg = parseFloat(kg || 0);
const unitWeight = parseFloat(weight || 0);
if (unitWeight <= 0) return `${qtyKg.toFixed(2)} kg`;
const sacks = Math.floor(qtyKg / unitWeight);
const loose = qtyKg - (sacks * unitWeight);
return `${sacks} sack(s)` + (loose > 0.004 ? ` + ${loose.toFixed(2)} kg loose` : '');
}

function updateBatchOptions() {
const product = getSelectedProduct();
const action = getSelectedAction();
const batchWrap = document.getElementById('batchSelectWrap');
const batchSelect = document.getElementById('batchSelect');
if (!batchWrap || !batchSelect) return;

const needsBatch = action !== 'add';
batchWrap.style.display = needsBatch ? 'block' : 'none';
batchSelect.required = needsBatch;

const productId = product ? parseInt(product.value || '0', 10) : 0;
const previous = batchSelect.value;
batchSelect.innerHTML = '<option value="">Select batch</option>';

if (!productId || !needsBatch) {
batchSelect.value = '';
return;
}

batchData
.filter(b => Number(b.product_id) === productId)
.filter(b => action === 'discounted' ? Number(b.regular_qty_kg || 0) > 0 : Number(b.regular_qty_kg || 0) > 0)
.forEach(b => {
const regularKg = Number(b.regular_qty_kg || 0);
const discountedKg = Number(b.discounted_qty_kg || 0);
const arrived = b.arrived_at ? `Arrived ${b.arrived_at}` : 'No date';
const label = `${b.batch_label || `Batch ${b.batch_id}`} - ${arrived} - Regular ${kgToSacks(regularKg, b.unit_weight_kg)}${discountedKg > 0 ? `, Discounted ${kgToSacks(discountedKg, b.unit_weight_kg)}` : ''}`;
const opt = document.createElement('option');
opt.value = b.batch_id;
opt.textContent = label;
batchSelect.appendChild(opt);
});

if (previous && Array.from(batchSelect.options).some(o => o.value === previous)) {
batchSelect.value = previous;
}
}

function changeQty(delta) {
const qtyInput = document.getElementById('qtyInput');
let val = parseInt(qtyInput.value || '1', 10);
val = isNaN(val) ? 1 : (val + delta);
if (val < 1) val = 1;
qtyInput.value = val;
updateUI();
}

function formatPeso(value) {
const num = parseFloat(value || 0);
return '₱' + num.toFixed(2);
}

function updateProfitLossDisplay(amount) {
const el = document.getElementById('profitLossText');
el.textContent = formatPeso(amount);
el.classList.remove('profit-positive', 'profit-negative');

if (amount > 0) {
el.classList.add('profit-positive');
} else if (amount < 0) {
el.classList.add('profit-negative');
}
}

function updateUI() {
updateBatchOptions();
const product = getSelectedProduct();
const batch = getSelectedBatch();
const action = getSelectedAction();
const qty = parseInt(document.getElementById('qtyInput').value || '1', 10);

const stock = product ? parseFloat(product.dataset.stock || '0') : 0;
const weight = product ? parseFloat(product.dataset.weight || '0') : 0;
const discounted = product ? parseFloat(product.dataset.discounted || '0') : 0;
const regular = action !== 'add' && batch ? parseFloat(batch.regular_qty_kg || '0') : (product ? parseFloat(product.dataset.regular || '0') : 0);
const price = action !== 'add' && batch ? parseFloat(batch.regular_price_per_kg || '0') : (product ? parseFloat(product.dataset.price || '0') : 0);
const totalKg = qty * weight;

document.getElementById('actionType').value = action;
document.getElementById('stockValue').textContent = stock.toFixed(2);
document.getElementById('regularValue').textContent = regular.toFixed(2);
document.getElementById('discountedValue').textContent = discounted.toFixed(2);
document.getElementById('weightValue').textContent = weight.toFixed(2);
document.getElementById('priceValue').textContent = price.toFixed(2);
document.getElementById('currentPriceText').textContent = price.toFixed(2);
document.getElementById('totalKgValue').textContent = totalKg.toFixed(2);

const suggestedPrice = price > 0 ? (price * 0.80) : 0;
document.getElementById('suggestedPrice').textContent = formatPeso(suggestedPrice);
renderProductHistory(product ? parseInt(product.value || '0', 10) : 0);

const reasonWrap = document.getElementById('reasonWrap');
const reasonCode = document.getElementById('reasonCode');
const discountWrap = document.getElementById('discountWrap');
const discountPrice = document.getElementById('discountPrice');

reasonWrap.style.display = (action === 'damaged' || action === 'unsellable') ? 'block' : 'none';
reasonCode.required = (action === 'damaged' || action === 'unsellable');

discountWrap.style.display = (action === 'discounted') ? 'block' : 'none';
discountPrice.required = (action === 'discounted');

if (action === 'discounted' && (!discountPrice.value || parseFloat(discountPrice.value) <= 0) && suggestedPrice > 0) {
discountPrice.placeholder = suggestedPrice.toFixed(2);
}

let estimatedProfitLoss = 0;
if (action === 'discounted') {
const enteredDiscount = parseFloat(discountPrice.value || 0);
if (enteredDiscount > 0 && totalKg > 0) {
estimatedProfitLoss = (enteredDiscount - price) * totalKg;
}
}
updateProfitLossDisplay(estimatedProfitLoss);
}

function openConfirmModal() {
const product = getSelectedProduct();
const batch = getSelectedBatch();
const action = getSelectedAction();
const qty = parseInt(document.getElementById('qtyInput').value || '1', 10);

if (!product) {
alert('Please select a product.');
return;
}

if (isNaN(qty) || qty <= 0) {
alert('Please enter a valid quantity.');
return;
}

if (action !== 'add' && !batch) {
alert('Please select the stock batch to adjust.');
return;
}

const stock = parseFloat(product.dataset.stock || '0');
const weight = parseFloat(product.dataset.weight || '0');
const regular = action !== 'add' && batch ? parseFloat(batch.regular_qty_kg || '0') : parseFloat(product.dataset.regular || '0');
const price = action !== 'add' && batch ? parseFloat(batch.regular_price_per_kg || '0') : parseFloat(product.dataset.price || '0');
const totalKg = qty * weight;

if (action !== 'add' && totalKg > regular) {
alert('Selected batch does not have enough regular stock for this adjustment.');
return;
}

const reasonSelect = document.getElementById('reasonCode');
const reasonNeeded = (action === 'damaged' || action === 'unsellable');

if (reasonNeeded && !reasonSelect.value) {
alert('Please select a reason.');
return;
}

const discountNeeded = (action === 'discounted');
const discountPriceValue = document.getElementById('discountPrice').value.trim();

if (discountNeeded && (!discountPriceValue || parseFloat(discountPriceValue) <= 0)) {
alert('Please enter a valid discount price.');
return;
}

let remaining = regular + totalKg;
if (action === 'damaged' || action === 'unsellable' || action === 'discounted') {
remaining = regular - totalKg;
}

document.getElementById('modalActionBadge').textContent = formatActionLabel(action);
document.getElementById('modalProduct').textContent = product.textContent.trim();
document.getElementById('modalQty').textContent = qty;
document.getElementById('modalKg').textContent = totalKg.toFixed(2);
document.getElementById('modalCurrentStock').textContent = stock.toFixed(2);
document.getElementById('modalRemaining').textContent = remaining.toFixed(2);
document.getElementById('modalRegularPrice').textContent = price.toFixed(2);

const noteValue = document.getElementById('noteField').value.trim();
document.getElementById('modalNote').textContent = noteValue !== '' ? noteValue : '—';

const modalReasonWrap = document.getElementById('modalReasonWrap');
const modalDiscountWrap = document.getElementById('modalDiscountWrap');
const modalProfitWrap = document.getElementById('modalProfitWrap');
const modalWarning = document.getElementById('modalWarning');

if (reasonNeeded) {
modalReasonWrap.style.display = 'block';
document.getElementById('modalReason').textContent =
reasonSelect.options[reasonSelect.selectedIndex].text;
} else {
modalReasonWrap.style.display = 'none';
document.getElementById('modalReason').textContent = '—';
}

if (discountNeeded) {
modalDiscountWrap.style.display = 'block';
modalProfitWrap.style.display = 'block';

const discountVal = parseFloat(discountPriceValue);
document.getElementById('modalDiscountPrice').textContent = discountVal.toFixed(2);

const profitLoss = (discountVal - price) * totalKg;
const modalProfit = document.getElementById('modalProfitLoss');
modalProfit.textContent = formatPeso(profitLoss);

modalProfit.classList.remove('profit-positive', 'profit-negative');
if (profitLoss > 0) {
modalProfit.classList.add('profit-positive');
} else if (profitLoss < 0) {
modalProfit.classList.add('profit-negative');
}
} else {
modalDiscountWrap.style.display = 'none';
modalProfitWrap.style.display = 'none';
document.getElementById('modalDiscountPrice').textContent = '0.00';
document.getElementById('modalProfitLoss').textContent = '₱0.00';
}

if (action !== 'add') {
modalWarning.classList.remove('d-none');
} else {
modalWarning.classList.add('d-none');
}

const modalEl = document.getElementById('confirmAdjustModal');
const modal = new bootstrap.Modal(modalEl);
modal.show();
}

document.getElementById('productSelect').addEventListener('change', updateUI);
document.getElementById('batchSelect').addEventListener('change', updateUI);
document.getElementById('actionSelect').addEventListener('change', updateUI);
document.getElementById('qtyInput').addEventListener('input', updateUI);
document.getElementById('discountPrice').addEventListener('input', updateUI);
document.getElementById('openConfirmModal').addEventListener('click', openConfirmModal);

updateUI();
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function () {
  const pollIntervalMs = 5000;
  let pollingInFlight = false;
  async function pollLiveMain() {
    if (pollingInFlight) return;
    pollingInFlight = true;
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('_live', Date.now().toString());
      const response = await fetch(url.toString(), { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const sourcePanel = doc.querySelector('#conditionRecordsPanel');
      const targetPanel = document.querySelector('#conditionRecordsPanel');
      if (sourcePanel && targetPanel) targetPanel.innerHTML = sourcePanel.innerHTML;
    } catch (error) {
      console.error('Adjust stock live poll failed:', error);
    } finally {
      pollingInFlight = false;
    }
  }
  pollLiveMain();
  window.setInterval(pollLiveMain, pollIntervalMs);
})();
</script>
</body>
</html>
