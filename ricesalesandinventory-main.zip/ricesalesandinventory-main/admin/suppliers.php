<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$role = $_SESSION['role'] ?? '';
if ($role !== 'admin') {
    header("Location: dashboard.php");
    exit;
}

$username = $_SESSION['username'] ?? 'User';
$user_id  = (int)($_SESSION['user_id'] ?? 0);

include '../config/db.php';

$activePage  = 'suppliers';
$profileLink = 'profile.php';
$logoutLink  = '../logout.php';

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}
$csrf_token = (string)$_SESSION['csrf_token'];

$tabParam = strtolower((string)($_GET['tab'] ?? 'suppliers'));
if (!in_array($tabParam, ['suppliers', 'po'], true)) {
    $tabParam = 'suppliers';
}

function logActivity($conn, $user_id, $type, $desc) {
    $stmt = $conn->prepare("
        INSERT INTO activity_logs (user_id, activity_type, description, created_at)
        VALUES (?, ?, ?, NOW())
    ");
    if ($stmt) {
        $stmt->bind_param("iss", $user_id, $type, $desc);
        $stmt->execute();
        $stmt->close();
    }
}

function validDateYmd($date) {
    if (!is_string($date) || trim($date) === '') {
        return false;
    }
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return $d && $d->format('Y-m-d') === $date;
}

function redirectWithMessage($type, $message) {
    $tab = strtolower((string)($_GET['tab'] ?? 'suppliers'));
    if (!in_array($tab, ['suppliers', 'po'], true)) {
        $tab = 'suppliers';
    }
    header("Location: suppliers.php?tab=" . urlencode($tab) . "&{$type}=" . urlencode($message));
    exit;
}

function requireCsrf() {
    $sessionToken = (string)($_SESSION['csrf_token'] ?? '');
    $postedToken = (string)($_POST['csrf_token'] ?? '');
    if ($sessionToken === '' || $postedToken === '' || !hash_equals($sessionToken, $postedToken)) {
        redirectWithMessage('error', 'Invalid request. Please refresh the page and try again.');
    }
}

function normalizeSupplierStatus($status) {
    $allowed = ['active', 'inactive'];
    return in_array($status, $allowed, true) ? $status : 'active';
}

function normalizePhoneNumber($phone) {
    return preg_replace('/\D+/', '', (string)$phone);
}

function normalizePoStatus($status) {
    $allowed = ['ordered', 'pending', 'received', 'completed', 'cancelled'];
    return in_array($status, $allowed, true) ? $status : 'ordered';
}

function poDisplayStatusLabel(array $po) {
    $approved = (int)($po['po_approved'] ?? 0) === 1;
    $status = strtolower((string)($po['status'] ?? 'pending'));

    if (!$approved) return 'Pending Approval';
    if ($status === 'cancelled') return 'Cancelled';
    return 'Completed';
}

function poDisplayStatusClass(array $po) {
    $approved = (int)($po['po_approved'] ?? 0) === 1;
    $status = strtolower((string)($po['status'] ?? 'pending'));
    if (!$approved) return 'bg-warning text-dark';
    if ($status === 'cancelled') return 'bg-danger';
    return 'bg-success';
}

$dbNameRes = $conn->query("SELECT DATABASE() AS dbname");
$dbName = $dbNameRes ? (string)($dbNameRes->fetch_assoc()['dbname'] ?? '') : '';
$dbNameEsc = $conn->real_escape_string($dbName);
$purchaseCols = [
    'delivery_receipt_no' => "ALTER TABLE purchases ADD COLUMN delivery_receipt_no VARCHAR(100) NULL AFTER request_reason",
    'invoice_no' => "ALTER TABLE purchases ADD COLUMN invoice_no VARCHAR(100) NULL AFTER delivery_receipt_no",
    'delivery_date' => "ALTER TABLE purchases ADD COLUMN delivery_date DATE NULL AFTER invoice_no",
    'received_by' => "ALTER TABLE purchases ADD COLUMN received_by VARCHAR(120) NULL AFTER delivery_date",
    'receiving_notes' => "ALTER TABLE purchases ADD COLUMN receiving_notes TEXT NULL AFTER received_by",
    'received_at' => "ALTER TABLE purchases ADD COLUMN received_at DATETIME NULL AFTER receiving_notes",
];

foreach ($purchaseCols as $col => $alterSql) {
    $colEsc = $conn->real_escape_string($col);
    $colRes = $conn->query("
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = '{$dbNameEsc}' AND TABLE_NAME = 'purchases' AND COLUMN_NAME = '{$colEsc}' LIMIT 1
    ");
    if (!$colRes || $colRes->num_rows === 0) {
        $conn->query($alterSql);
    }
}

if (isset($_POST['add_supplier'])) {
    requireCsrf();
    $name    = trim((string)$_POST['name'] ?? '');
    $phone   = normalizePhoneNumber($_POST['phone'] ?? '');
    $address = trim((string)$_POST['address'] ?? '');
    if ($name === '') redirectWithMessage('error', 'Supplier name is required.');
    if ($phone === '') redirectWithMessage('error', 'Supplier phone number is required.');

    $stmt = $conn->prepare("INSERT INTO suppliers (name, phone, address, status, created_at) VALUES (?, ?, ?, 'active', NOW())");
    if (!$stmt) redirectWithMessage('error', 'DB error: ' . $conn->error);
    $stmt->bind_param("sss", $name, $phone, $address);
    $stmt->execute();
    $newId = (int)$conn->insert_id;
    $stmt->close();
    logActivity($conn, $user_id, "SUPPLIER", "Added supplier #{$newId}: {$name}");
    redirectWithMessage('success', 'Supplier added successfully.');
}

if (isset($_POST['edit_supplier'])) {
    requireCsrf();
    $supplier_id = (int)($_POST['supplier_id'] ?? 0);
    $name = trim((string)$_POST['name'] ?? '');
    $phone = normalizePhoneNumber($_POST['phone'] ?? '');
    $address = trim((string)$_POST['address'] ?? '');
    $status = normalizeSupplierStatus(trim((string)$_POST['status'] ?? 'active'));
    if ($supplier_id <= 0 || $name === '' || $phone === '') redirectWithMessage('error', 'Invalid supplier update request.');

    $stmt = $conn->prepare("UPDATE suppliers SET name = ?, phone = ?, address = ?, status = ? WHERE supplier_id = ?");
    if (!$stmt) redirectWithMessage('error', 'DB error: ' . $conn->error);
    $stmt->bind_param("ssssi", $name, $phone, $address, $status, $supplier_id);
    $stmt->execute();
    $stmt->close();
    logActivity($conn, $user_id, "SUPPLIER", "Updated supplier #{$supplier_id}: {$name} ({$status})");
    redirectWithMessage('success', 'Supplier updated successfully.');
}

if (isset($_POST['create_po'])) {
    requireCsrf();
    $supplier_id = (int)($_POST['supplier_id'] ?? 0);
    $purchase_date = trim((string)$_POST['purchase_date'] ?? date('Y-m-d'));
    $request_reason = trim((string)$_POST['request_reason'] ?? '');
    $productIds = $_POST['product_id'] ?? [];
    $quantities = $_POST['quantity'] ?? [];
    if ($supplier_id <= 0) redirectWithMessage('error', 'Please select a supplier for the purchase order.');
    if (!validDateYmd($purchase_date)) $purchase_date = date('Y-m-d');

    $check = $conn->prepare("SELECT supplier_id, name FROM suppliers WHERE supplier_id = ? LIMIT 1");
    $check->bind_param("i", $supplier_id);
    $check->execute();
    $supplierRow = $check->get_result()->fetch_assoc();
    $check->close();
    if (!$supplierRow) redirectWithMessage('error', 'Selected supplier does not exist.');

    $items = []; $total_amount = 0.0;
    foreach ($productIds as $i => $rawProductId) {
        $productId = (int)$rawProductId;
        $qty = (int)($quantities[$i] ?? 0);
        if ($productId <= 0 || $qty <= 0) continue;
        $prodStmt = $conn->prepare("SELECT product_id, variety, grade, unit_weight_kg, COALESCE(price_per_sack,0) AS price_per_sack FROM products WHERE product_id = ? AND archived = 0 LIMIT 1");
        $prodStmt->bind_param("i", $productId);
        $prodStmt->execute();
        $productRow = $prodStmt->get_result()->fetch_assoc();
        $prodStmt->close();
        if (!$productRow) continue;
        $unitPrice = (float)$productRow['price_per_sack'];
        $total_amount += round($unitPrice * $qty, 2);
        $items[] = ['product_id' => $productId, 'quantity_sacks' => $qty, 'estimated_price' => $unitPrice];
    }
    if (!$items) redirectWithMessage('error', 'Please add at least one valid item.');

       $conn->begin_transaction();
    try {
        $status = 'pending'; // ✅ Explicitly set default status
        $stmt = $conn->prepare("INSERT INTO purchases (supplier_id, purchase_date, total_amount, request_reason, status, po_approved, created_by, created_at) VALUES (?, ?, ?, ?, ?, 0, ?, NOW())");
        // ✅ 7 placeholders = 7 values: i s d s s i
        $stmt->bind_param("isdssi", $supplier_id, $purchase_date, $total_amount, $request_reason, $status, $user_id);
        $stmt->execute();
        $poId = (int)$conn->insert_id;
        $stmt->close();

        $itemStmt = $conn->prepare("INSERT INTO purchase_items (purchases_id, product_id, quantity_sacks, estimated_price, supplier_price, line_total) VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($items as $item) {
            $lineTotal = round($item['estimated_price'] * $item['quantity_sacks'], 2);
            $itemStmt->bind_param("iiiddd", $poId, $item['product_id'], $item['quantity_sacks'], $item['estimated_price'], $item['estimated_price'], $lineTotal);
            $itemStmt->execute();
        }
        $itemStmt->close();
        $conn->commit();
        logActivity($conn, $user_id, "PO", "Submitted PO #{$poId} for supplier #{$supplier_id} ({$supplierRow['name']}), amount=" . number_format($total_amount, 2));
        redirectWithMessage('success', 'Purchase request submitted for approval.');
    } catch (Throwable $ex) {
        $conn->rollback();
        redirectWithMessage('error', 'Unable to submit: ' . $ex->getMessage());
    }
}

if (isset($_POST['update_po_status'])) {
    requireCsrf();
    $po_id = (int)($_POST['po_id'] ?? 0);
    $status = normalizePoStatus(trim((string)$_POST['status'] ?? 'ordered'));
    if ($po_id <= 0) redirectWithMessage('error', 'Invalid P.O. status update.');

    $check = $conn->prepare("SELECT po_approved, status FROM purchases WHERE purchases_id = ? LIMIT 1");
    $check->bind_param("i", $po_id);
    $check->execute();
    $poRow = $check->get_result()->fetch_assoc();
    $check->close();
    if (!$poRow) redirectWithMessage('error', 'Purchase request not found.');
    if ((int)$poRow['po_approved'] !== 1) redirectWithMessage('error', 'Owner approval required first.');

    $currentStatus = strtolower((string)$poRow['status']);
    if ($currentStatus === 'received' && $status === 'received') redirectWithMessage('error', 'Already received.');

    $stmt = $conn->prepare("UPDATE purchases SET status = ? WHERE purchases_id = ?");
    $stmt->bind_param("si", $status, $po_id);
    $stmt->execute();
    $stmt->close();
    logActivity($conn, $user_id, "PO", "Updated PO #{$po_id} to {$status}");
    redirectWithMessage('success', 'Purchase Order status updated.');
}

$suppliers = [];
$sqlSup = "SELECT s.supplier_id, s.name, s.phone, s.address, s.status, s.created_at,
    IFNULL(COUNT(p.purchases_id),0) AS po_count, IFNULL(SUM(p.total_amount),0) AS po_total, MAX(p.purchase_date) AS last_po_date
    FROM suppliers s LEFT JOIN purchases p ON p.supplier_id = s.supplier_id
    GROUP BY s.supplier_id ORDER BY s.created_at DESC, s.supplier_id DESC";

if (isset($_POST['save_supplier_prices'])) redirectWithMessage('error', 'Step replaced by stock-in.');

$DEFAULT_LOW = 10;
$DEFAULT_OVERSTOCK_LIMIT_KG = 2000;
$settingsRes = $conn->query("SELECT low_threshold_kg, over_threshold_kg FROM stock_settings WHERE id=1 LIMIT 1");
if ($settingsRes && $settingsRes->num_rows > 0) {
    $s = $settingsRes->fetch_assoc();
    $dbLow = (float)($s['low_threshold_kg'] ?? $DEFAULT_LOW);
    $OVERSTOCK_LIMIT_KG = (float)($s['over_threshold_kg'] ?? $DEFAULT_OVERSTOCK_LIMIT_KG);
} else { $dbLow = $DEFAULT_LOW; $OVERSTOCK_LIMIT_KG = $DEFAULT_OVERSTOCK_LIMIT_KG; }

$products = [];
$resProd = $conn->query("SELECT p.product_id, p.variety, p.grade, p.unit_weight_kg, IFNULL(SUM(sb.remaining_qty_kg),0) AS stock_kg
    FROM products p LEFT JOIN stock_batches sb ON sb.product_id = p.product_id WHERE p.archived=0
    GROUP BY p.product_id ORDER BY stock_kg ASC, p.variety ASC");
if ($resProd) while ($r = $resProd->fetch_assoc()) $products[] = $r;

$lowStockProducts = [];
foreach ($products as $p) {
    $stockKg = (float)($p['stock_kg'] ?? 0);
    if ($stockKg <= $dbLow) $lowStockProducts[] = $p;
}

$resSup = $conn->query($sqlSup);
if ($resSup) while ($r = $resSup->fetch_assoc()) $suppliers[] = $r;

$poRows = [];
$sqlPo = "SELECT p.purchases_id, p.supplier_id, p.purchase_date, p.total_amount, p.status, p.received_at,
    p.po_approved, p.po_approved_at, p.created_at, s.name AS supplier_name,
    u.username AS created_by_name, approver.username AS approved_by_name
    FROM purchases p LEFT JOIN suppliers s ON s.supplier_id = p.supplier_id
    LEFT JOIN users u ON u.user_id = p.created_by
    LEFT JOIN users approver ON approver.user_id = p.po_approved_by
    ORDER BY p.created_at DESC LIMIT 150";
$resPo = $conn->query($sqlPo);
if ($resPo) while ($r = $resPo->fetch_assoc()) $poRows[] = $r;

$totalSuppliers = count($suppliers);
$totalPoLoaded = count($poRows);
$totalPoAmount = array_sum(array_column($poRows, 'total_amount'));

function badgeClassForSupplier($s) { return $s==='active'?'bg-success':'bg-secondary'; }
function badgeClassForPo($s) { return match($s){'ordered'=>'bg-primary','pending'=>'bg-warning text-dark','received'=>'bg-success','cancelled'=>'bg-danger',default=>'bg-secondary'}; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Suppliers & P.O. | DE ORO HIYS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <link href="../css/layout.css" rel="stylesheet">
    <link href="../css/admin-mobile.css" rel="stylesheet">
    <link href="../css/admin-suppliers.css" rel="stylesheet">
    <style>
        /* Entire row is clickable */
        .supplier-row { cursor: pointer; transition: background-color 0.15s ease; }
        .supplier-row:hover { background-color: #e3f2fd !important; }
        /* Buttons inside row should not trigger row click */
        .supplier-row .action-btns { pointer-events: auto; }
    </style>
</head>
<body>
<?php include '../includes/topnav.php'; ?>
<div class="container-fluid">
    <div class="row">
        <?php include '../includes/admin_sidebar.php'; ?>
        <main class="col-lg-10 ms-sm-auto px-4 py-3">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div>
                    <h2 class="mb-1">Suppliers & Purchase Orders</h2>
                    <div class="text-muted small">Click any supplier row to view purchase history.</div>
                </div>
                <div class="page-actions">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addSupplierModal"><i class="fas fa-plus me-1"></i> Add Supplier</button>
                    <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createPoModal"><i class="fas fa-file-circle-plus me-1"></i> New Purchase Request</button>
                </div>
            </div>

            <?php if (isset($_GET['error'])): ?><div class="alert alert-danger mt-3"><?= e($_GET['error']) ?></div><?php endif; ?>
            <?php if (isset($_GET['success'])): ?><div class="alert alert-success mt-3"><?= e($_GET['success']) ?></div><?php endif; ?>

            <div class="row g-3 mt-1">
                <div class="col-md-3"><div class="card card-kpi h-100"><div class="card-body"><div class="kpi-label">Total Suppliers</div><div class="kpi-value"><?= $totalSuppliers ?></div></div></div></div>
                <div class="col-md-3"><div class="card card-kpi h-100"><div class="card-body"><div class="kpi-label">P.O. Loaded</div><div class="kpi-value"><?= $totalPoLoaded ?></div></div></div></div>
                <div class="col-md-3"><div class="card card-kpi h-100"><div class="card-body"><div class="kpi-label">Total Amount</div><div class="kpi-value">₱<?= number_format($totalPoAmount,2) ?></div></div></div></div>
                <div class="col-md-3"><div class="card card-kpi h-100"><div class="card-body"><div class="kpi-label">Current User</div><div class="kpi-value"><?= e($username) ?></div></div></div></div>
            </div>

            <div id="supTabRoot" class="row g-3 mt-3" data-active-tab="<?= e($tabParam) ?>">
                <div class="col-md-6 col-xl-3"><div class="sup-tab-card p-3 h-100 <?= $tabParam==='suppliers'?'active':'' ?>" data-tab="suppliers" role="button" tabindex="0"><div class="d-flex justify-content-between"><div class="fw-bold text-uppercase">Suppliers</div><i class="fa-solid fa-truck-field text-muted"></i></div><div class="mt-2 text-muted"><?= $totalSuppliers ?> record(s)</div></div></div>
                <div class="col-md-6 col-xl-3"><div class="sup-tab-card p-3 h-100 <?= $tabParam==='po'?'active':'' ?>" data-tab="po" role="button" tabindex="0"><div class="d-flex justify-content-between"><div class="fw-bold text-uppercase">Purchase Requests</div><i class="fa-solid fa-file-invoice text-muted"></i></div><div class="mt-2 text-muted"><?= $totalPoLoaded ?> record(s)</div></div></div>
            </div>

            <!-- SUPPLIERS TAB -->
            <div id="supPaneSuppliers" class="<?= $tabParam==='suppliers'?'':'d-none' ?>">
                <div class="card mt-3">
                    <div class="card-header fw-bold d-flex justify-content-between"><span>Supplier List</span><span class="text-muted small"><?= $totalSuppliers ?> supplier(s)</span></div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered mb-0 align-middle">
                                <thead class="table-dark">
                                    <tr>
                                        <th>ID</th>
                                        <th>Supplier Name</th>
                                        <th>Phone</th>
                                        <th>Address</th>
                                        <th class="text-end">PO Count</th>
                                        <th>Status</th>
                                        <th class="text-end">PO Total (₱)</th>
                                        <th>Last PO Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($totalSuppliers > 0): ?>
                                        <?php foreach ($suppliers as $s): ?>
                                            <!-- ✅ CLICKABLE ROW with data attributes -->
                                            <tr class="supplier-row"
                                                data-supplier-id="<?= (int)$s['supplier_id'] ?>"
                                                data-supplier-name="<?= e($s['name']) ?>"
                                                data-supplier-phone="<?= e($s['phone'] ?? '') ?>"
                                                data-supplier-address="<?= e($s['address'] ?? '') ?>">
                                                <td><?= (int)$s['supplier_id'] ?></td>
                                                <td class="fw-semibold"><?= e($s['name']) ?></td>
                                                <td><?= e($s['phone'] ?? '') ?></td>
                                                <td><?= e($s['address'] ?? '') ?></td>
                                                <td class="text-end"><?= (int)($s['po_count'] ?? 0) ?></td>
                                                <td><span class="badge <?= badgeClassForSupplier($s['status']) ?>"><?= strtoupper($s['status']) ?></span></td>
                                                <td class="text-end">₱<?= number_format($s['po_total'] ?? 0, 2) ?></td>
                                                <td><?= !empty($s['last_po_date']) ? e($s['last_po_date']) : '<span class="text-muted">—</span>' ?></td>
                                                <td>
                                                    <div class="action-btns">
                                                        <button type="button" class="btn btn-sm btn-info"
                                                            data-bs-toggle="modal" data-bs-target="#editSupplierModal"
                                                            data-supplier-id="<?= (int)$s['supplier_id'] ?>"
                                                            data-supplier-name="<?= e($s['name']) ?>"
                                                            data-supplier-phone="<?= e($s['phone'] ?? '') ?>"
                                                            data-supplier-address="<?= e($s['address'] ?? '') ?>"
                                                            data-supplier-status="<?= e($s['status'] ?? 'active') ?>">
                                                            <i class="fas fa-edit"></i>
                                                        </button>
                                                        <button type="button" class="btn btn-sm btn-success"
                                                            data-bs-toggle="modal" data-bs-target="#createPoModal"
                                                            data-supplier-id="<?= (int)$s['supplier_id'] ?>">
                                                            <i class="fas fa-file-circle-plus"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr><td colspan="9" class="text-center text-muted py-4">No suppliers found.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- PURCHASE ORDERS TAB -->
            <div id="supPanePo" class="<?= $tabParam==='po'?'':'d-none' ?>">
                <div class="card mt-3">
                    <div class="card-header fw-bold d-flex justify-content-between"><span>Purchase Request / P.O. List</span><span class="text-muted small">Latest 150 records</span></div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered mb-0">
                                <thead class="table-dark">
                                    <tr>
                                        <th>PO #</th><th>Supplier</th><th>Date</th><th class="text-end">Amount (₱)</th><th>Status</th><th>Created By</th><th>Created At</th><th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($totalPoLoaded > 0): ?>
                                        <?php foreach ($poRows as $po): ?>
                                            <?php
                                            $isApproved = (int)($po['po_approved'] ?? 0) === 1;
                                            $status = strtolower($po['status'] ?? 'pending');
                                            ?>
                                            <tr>
                                                <td class="fw-semibold">#<?= (int)$po['purchases_id'] ?></td>
                                                <td><?= e($po['supplier_name'] ?? 'N/A') ?></td>
                                                <td><?= e($po['purchase_date'] ?? '') ?></td>
                                                <td class="text-end"><?= $po['total_amount']>0?'₱'.number_format($po['total_amount'],2):'<span class="text-muted">—</span>' ?></td>
                                                <td><span class="badge <?= poDisplayStatusClass($po) ?>"><?= e(poDisplayStatusLabel($po)) ?></span></td>
                                                <td><?= e($po['created_by_name'] ?? 'N/A') ?></td>
                                                <td><?= e($po['created_at'] ?? '') ?></td>
                                                <td>
                                                    <?php if ($po['total_amount'] > 0): ?>
                                                        <a href="print_po.php?id=<?= (int)$po['purchases_id'] ?>" class="btn btn-outline-dark btn-sm" target="_blank"><i class="fas fa-print"></i> Print</a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr><td colspan="8" class="text-center text-muted py-4">No purchase orders found.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- 📋 SUPPLIER PURCHASE HISTORY MODAL -->
<div class="modal fade" id="supplierHistoryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-history me-2"></i>Purchase History — <span id="histSupplierName"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Phone:</strong> <span id="histSupplierPhone"></span></div>
                    <div class="col-md-5"><strong>Address:</strong> <span id="histSupplierAddress"></span></div>
                    <div class="col-md-3 text-end"><strong>Total POs:</strong> <span id="histPoCount" class="badge bg-primary"></span> &nbsp; <strong>Total:</strong> <span id="histTotalAmount" class="badge bg-success"></span></div>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-sm">
                        <thead class="table-dark">
                            <tr>
                                <th>PO #</th><th>Date</th><th>Status</th><th class="text-end">Amount</th><th>Approved</th><th>Received</th>
                            </tr>
                        </thead>
                        <tbody id="supplierHistoryBody">
                            <tr><td colspan="6" class="text-center text-muted">Loading...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- ADD SUPPLIER MODAL -->
<div class="modal fade" id="addSupplierModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" class="modal-content">
            <div class="modal-header"><h5 class="modal-title">Add Supplier</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <input type="hidden" name="csrf_token" value="<?= e($csrf_token) ?>">
                <div class="mb-3"><label class="form-label">Name *</label><input type="text" name="name" class="form-control" required></div>
                <div class="mb-3"><label class="form-label">Phone *</label><input type="tel" name="phone" class="form-control js-phone-only" required></div>
                <div class="mb-3"><label class="form-label">Address</label><textarea name="address" class="form-control" rows="3"></textarea></div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" name="add_supplier" class="btn btn-primary">Save</button></div>
        </form>
    </div>
</div>

<!-- EDIT SUPPLIER MODAL -->
<div class="modal fade" id="editSupplierModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="editSupplierModalTitle">Edit Supplier</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <input type="hidden" name="csrf_token" value="<?= e($csrf_token) ?>">
                <input type="hidden" name="supplier_id" id="editSupplierId">
                <div class="mb-3"><label class="form-label">Name *</label><input type="text" name="name" id="editSupplierName" class="form-control" required></div>
                <div class="mb-3"><label class="form-label">Phone *</label><input type="tel" name="phone" id="editSupplierPhone" class="form-control js-phone-only" required></div>
                <div class="mb-3"><label class="form-label">Address</label><textarea name="address" id="editSupplierAddress" class="form-control" rows="3"></textarea></div>
                <div class="mb-3"><label class="form-label">Status</label><select name="status" id="editSupplierStatus" class="form-select"><option value="active">ACTIVE</option><option value="inactive">INACTIVE</option></select></div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" name="edit_supplier" class="btn btn-primary">Save Changes</button></div>
        </form>
    </div>
</div>

<!-- CREATE PO MODAL -->
<div class="modal fade" id="createPoModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" class="modal-content">
            <div class="modal-header"><h5 class="modal-title"><i class="fa-solid fa-file-signature me-2"></i>New Purchase Request</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <input type="hidden" name="csrf_token" value="<?= e($csrf_token) ?>">
                <div class="mb-3"><label class="form-label">Supplier *</label>
                    <select name="supplier_id" id="createPoSupplierSelect" class="form-select" required>
                        <option value="">-- Select Supplier --</option>
                        <?php foreach ($suppliers as $s): ?>
                            <option value="<?= (int)$s['supplier_id'] ?>"><?= e($s['name']) ?><?= $s['status']==='inactive'?' (INACTIVE)':'' ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3"><label class="form-label">Purchase Date *</label><input type="date" name="purchase_date" value="<?= date('Y-m-d') ?>" class="form-control" required></div>
                <div class="mb-3">
                    <label class="form-label">Items</label>
                    <div id="itemsContainer">
                        <div class="row g-2 item-row mb-2">
                            <div class="col-md-7">
                                <select name="product_id[]" class="form-select" required>
                                    <option value="">-- Select Product --</option>
                                    <?php foreach ($products as $p): ?>
                                        <?php $isLow = (float)($p['stock_kg'] ?? 0) <= $dbLow; ?>
                                        <option value="<?= (int)$p['product_id'] ?>"><?= e($p['variety']) ?> | <?= e($p['grade']) ?><?= $isLow ? ' — LOW STOCK' : '' ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4"><input type="number" name="quantity[]" min="1" class="form-control" placeholder="Sacks" required></div>
                            <div class="col-md-1"><button type="button" class="btn btn-danger remove-item">×</button></div>
                        </div>
                    </div>
                    <button type="button" id="addItemBtn" class="btn btn-outline-primary btn-sm mt-2">+ Add Item</button>
                </div>
                <div class="mb-3"><label class="form-label">Reason</label><textarea name="request_reason" class="form-control" rows="3" required placeholder="Why is this purchase needed?"></textarea></div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" name="create_po" class="btn btn-success"><i class="fa-solid fa-paper-plane me-1"></i>Submit</button></div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const historyModal = new bootstrap.Modal(document.getElementById('supplierHistoryModal'));
    const allPOs = <?= json_encode($poRows) ?>;

    // ✅ ENTIRE ROW CLICK HANDLER
    document.querySelectorAll('.supplier-row').forEach(row => {
        row.addEventListener('click', function (e) {
            // Skip if clicking Edit or New PO buttons
            if (e.target.closest('.action-btns')) return;

            const supplierId = this.dataset.supplierId;
            const supplierName = this.dataset.supplierName;
            const supplierPhone = this.dataset.supplierPhone;
            const supplierAddress = this.dataset.supplierAddress;

            // Fill supplier info
            document.getElementById('histSupplierName').textContent = supplierName;
            document.getElementById('histSupplierPhone').textContent = supplierPhone || '—';
            document.getElementById('histSupplierAddress').textContent = supplierAddress || '—';

            // Filter POs for this supplier
            const supplierPOs = allPOs.filter(po => String(po.supplier_id) === String(supplierId));
            const totalPOs = supplierPOs.length;
            const totalAmt = supplierPOs.reduce((sum, po) => sum + (parseFloat(po.total_amount) || 0), 0);

            document.getElementById('histPoCount').textContent = totalPOs;
            document.getElementById('histTotalAmount').textContent = '₱' + totalAmt.toFixed(2);

            // Render history table
            const tbody = document.getElementById('supplierHistoryBody');
            tbody.innerHTML = '';

            if (supplierPOs.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted py-3">No purchase orders found for this supplier.</td></tr>';
            } else {
                supplierPOs.forEach(po => {
                    const isApproved = parseInt(po.po_approved || 0) === 1;
                    const status = (po.status || 'pending').toLowerCase();
                    let statusBadge = status, statusClass = 'bg-secondary';
                    if (!isApproved) { statusBadge = 'Pending Approval'; statusClass = 'bg-warning text-dark'; }
                    else if (status === 'cancelled') { statusBadge = 'Cancelled'; statusClass = 'bg-danger'; }
                    else if (status === 'received') { statusBadge = 'Received'; statusClass = 'bg-success'; }
                    else if (status === 'ordered') { statusBadge = 'Ordered'; statusClass = 'bg-primary'; }

                    const approvedText = isApproved
                        ? '<span class="text-success"><i class="fas fa-check-circle"></i> Yes</span>'
                        : '<span class="text-warning"><i class="fas fa-clock"></i> Pending</span>';
                    const amount = parseFloat(po.total_amount) > 0 ? '₱' + parseFloat(po.total_amount).toFixed(2) : '<span class="text-muted">—</span>';
                    const received = po.received_at || '—';

                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td class="fw-semibold">#${po.purchases_id}</td>
                        <td>${po.purchase_date || '—'}</td>
                        <td><span class="badge ${statusClass}">${statusBadge}</span></td>
                        <td class="text-end">${amount}</td>
                        <td>${approvedText}</td>
                        <td>${received}</td>
                    `;
                    tbody.appendChild(tr);
                });
            }

            historyModal.show();
        });
    });

    // === REST OF YOUR EXISTING SCRIPT ===
    const root = document.getElementById('supTabRoot');
    const paneSuppliers = document.getElementById('supPaneSuppliers');
    const panePo = document.getElementById('supPanePo');
    if (root && paneSuppliers && panePo) {
        const cards = Array.from(root.querySelectorAll('.sup-tab-card'));
        function setTab(tab, updateUrl) {
            const active = tab==='po'?'po':'suppliers';
            paneSuppliers.classList.toggle('d-none', active!=='suppliers');
            panePo.classList.toggle('d-none', active!=='po');
            cards.forEach(c => c.classList.toggle('active', c.dataset.tab === active));
            if (updateUrl) history.replaceState({}, '', `?tab=${active}`);
        }
        cards.forEach(card => {
            card.onclick = () => setTab(card.dataset.tab, true);
            card.onkeydown = e => { if (e.key==='Enter'||e.key===' ') { e.preventDefault(); setTab(card.dataset.tab, true); } };
        });
        setTab(root.dataset.activeTab || 'suppliers', false);
    }

    // Edit Supplier Modal Fill
    document.getElementById('editSupplierModal').addEventListener('show.bs.modal', e => {
        const btn = e.relatedTarget;
        document.getElementById('editSupplierId').value = btn.dataset.supplierId;
        document.getElementById('editSupplierName').value = btn.dataset.supplierName;
        document.getElementById('editSupplierPhone').value = (btn.dataset.supplierPhone||'').replace(/\D/g,'');
        document.getElementById('editSupplierAddress').value = btn.dataset.supplierAddress;
        document.getElementById('editSupplierStatus').value = btn.dataset.supplierStatus;
        document.getElementById('editSupplierModalTitle').textContent = `Edit Supplier — ${btn.dataset.supplierName}`;
    });

    // Pre-select supplier in Create PO
    document.querySelectorAll('[data-bs-target="#createPoModal"]').forEach(btn => {
        btn.onclick = () => {
            const sel = document.getElementById('createPoSupplierSelect');
            if (sel) sel.value = btn.dataset.supplierId || '';
        };
    });

    // Add Item button
    document.getElementById('addItemBtn').onclick = () => {
        const row = document.querySelector('.item-row');
        if (!row) return;
        const clone = row.cloneNode(true);
        clone.querySelectorAll('select, input').forEach(el => el.value = '');
        document.getElementById('itemsContainer').appendChild(clone);
    };
    document.addEventListener('click', e => {
        if (e.target.classList.contains('remove-item') && document.querySelectorAll('.item-row').length > 1) {
            e.target.closest('.item-row').remove();
        }
    });

    // Phone input filter
    document.querySelectorAll('.js-phone-only').forEach(input => {
        input.oninput = () => input.value = input.value.replace(/\D/g,'').slice(0,15);
    });
});
</script>
</body>
</html>