<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}
if (strtolower($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: ../login.php");
    exit;
}

header("Location: adjust_stock.php");
exit;

$username   = $_SESSION['username'] ?? 'User';
$role       = $_SESSION['role'] ?? '';
$user_id    = (int)($_SESSION['user_id'] ?? 0);
$activePage = 'stock_condition';

include '../config/db.php';

$create = "
CREATE TABLE IF NOT EXISTS stock_condition (
    stock_condition_id INT(11) NOT NULL AUTO_INCREMENT,
    product_id INT NOT NULL,
    rice_name VARCHAR(150) NOT NULL,
    variety VARCHAR(150) NOT NULL,
    condition_type ENUM('Sellable','Discounted','Unsellable','Damaged') NOT NULL DEFAULT 'Sellable',
    reason VARCHAR(255) DEFAULT NULL,
    quantity DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    discount_price_per_kg DECIMAL(12,2) DEFAULT NULL,
    adjusted_by INT NULL,
    date_arrived DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (stock_condition_id),
    KEY idx_product_condition (product_id, condition_type),
    KEY idx_rice_variety (rice_name, variety),
    KEY idx_condition_date (condition_type, date_arrived)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
";
if (!$conn->query($create)) {
    die("Setup Failed: " . $conn->error);
}

$columns = [];
$colRes = $conn->query("SHOW COLUMNS FROM stock_condition");
if ($colRes) {
    while ($col = $colRes->fetch_assoc()) {
        $columns[$col['Field']] = true;
    }
}

if (!isset($columns['product_id'])) {
    $conn->query("ALTER TABLE stock_condition ADD COLUMN product_id INT NOT NULL DEFAULT 0 AFTER stock_condition_id");
}
if (!isset($columns['discount_price_per_kg'])) {
    $conn->query("ALTER TABLE stock_condition ADD COLUMN discount_price_per_kg DECIMAL(12,2) DEFAULT NULL AFTER quantity");
}
if (!isset($columns['adjusted_by'])) {
    $conn->query("ALTER TABLE stock_condition ADD COLUMN adjusted_by INT NULL AFTER discount_price_per_kg");
}

$conn->query("
    ALTER TABLE stock_condition
    MODIFY COLUMN condition_type ENUM('Sellable','Discounted','Unsellable','Damaged') NOT NULL DEFAULT 'Sellable'
");

$summary_sql = "
    SELECT
        COALESCE(SUM(CASE WHEN condition_type = 'Sellable' THEN quantity ELSE 0 END), 0) AS sellable_total,
        COALESCE(SUM(CASE WHEN condition_type = 'Discounted' THEN quantity ELSE 0 END), 0) AS discounted_total,
        COALESCE(SUM(CASE WHEN condition_type = 'Unsellable' THEN quantity ELSE 0 END), 0) AS unsellable_total,
        COALESCE(SUM(CASE WHEN condition_type = 'Damaged' THEN quantity ELSE 0 END), 0) AS damaged_total,
        COALESCE(SUM(quantity), 0) AS overall_total,
        COUNT(*) AS total_entries
    FROM stock_condition
";
$summary_result = $conn->query($summary_sql);
$summary = $summary_result ? $summary_result->fetch_assoc() : [
    'sellable_total'   => 0,
    'discounted_total' => 0,
    'unsellable_total' => 0,
    'damaged_total'    => 0,
    'overall_total'    => 0,
    'total_entries'    => 0
];

$search = trim($_GET['search'] ?? '');
$condition = trim($_GET['condition'] ?? '');

$discounted_sql = "
    SELECT
        rice_name,
        variety,
        discount_price_per_kg,
        SUM(quantity) AS total_kg,
        MAX(date_arrived) AS last_update
    FROM stock_condition
    WHERE condition_type = 'Discounted'
    GROUP BY rice_name, variety, discount_price_per_kg
    ORDER BY last_update DESC, rice_name ASC, variety ASC
";
$discounted_result = $conn->query($discounted_sql);

$sql = "
    SELECT
        rice_name,
        variety,
        condition_type,
        reason,
        discount_price_per_kg,
        SUM(quantity) AS total_kg,
        MAX(date_arrived) AS last_update
    FROM stock_condition
    WHERE 1=1
";

$params = [];
$types = '';

if ($search !== '') {
    $sql .= " AND (
        rice_name LIKE ? OR
        variety LIKE ? OR
        reason LIKE ?
    )";
    $like = "%{$search}%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $types .= 'sss';
}

if ($condition !== '' && in_array($condition, ['Sellable', 'Discounted', 'Unsellable', 'Damaged'], true)) {
    $sql .= " AND condition_type = ?";
    $params[] = $condition;
    $types .= 's';
}

$sql .= "
    GROUP BY rice_name, variety, condition_type, reason, discount_price_per_kg
    ORDER BY last_update DESC, rice_name ASC, variety ASC
";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Query Prepare Failed: " . $conn->error);
}

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

if (!$stmt->execute()) {
    die("Query Execute Failed: " . $stmt->error);
}

$result = $stmt->get_result();

$discounted_count = ($discounted_result instanceof mysqli_result) ? (int)$discounted_result->num_rows : 0;
$records_count = ($result instanceof mysqli_result) ? (int)$result->num_rows : 0;
$tab = strtolower((string)($_GET['tab'] ?? ''));
if (!in_array($tab, ['discounted', 'records'], true)) {
    $tab = '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Stock Condition</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="../css/inventory-adjust-stock.css" rel="stylesheet">
<link href="../css/inventory-stock-condition.css" rel="stylesheet">
<link href="../css/inventory-mobile.css" rel="stylesheet">
</head>
<body>

<?php
$profileLink = '../admin/profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>

<div class="container-fluid">
<div class="row">

<?php
$adminBase = '../admin/';
$inventoryBase = '../admin/';
$ownerBase = '../owner/';
include '../includes/admin_sidebar.php';
?>

<main class="col-lg-10 ms-sm-auto px-4 main-content">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-1">
        <h2 class="mb-0">Stock Condition</h2>
        <small class="text-muted">Last refresh: <?= date('M d, Y • g:i A') ?></small>
    </div>
    <p class="text-muted mb-3">Monitor stock quality, discounted items, damaged/unsellable records, and summaries.</p>

    <div class="row g-3 mb-3">
        <div class="col-md-6 col-xl-3">
            <div class="stat-tile h-100 d-flex gap-3 align-items-start">
                <div class="cond-icon cond-sellable"><i class="fas fa-check-circle"></i></div>
                <div>
                    <div class="stat-label">Sellable</div>
                    <div class="stat-value"><?php echo number_format((float)$summary['sellable_total'], 2); ?> kg</div>
                    <small class="text-muted">Ready for sale</small>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-xl-3">
            <div class="stat-tile h-100 d-flex gap-3 align-items-start">
                <div class="cond-icon cond-discounted"><i class="fas fa-tags"></i></div>
                <div>
                    <div class="stat-label">Discounted</div>
                    <div class="stat-value"><?php echo number_format((float)$summary['discounted_total'], 2); ?> kg</div>
                    <small class="text-muted">Lower price</small>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-xl-3">
            <div class="stat-tile h-100 d-flex gap-3 align-items-start">
                <div class="cond-icon cond-unsellable"><i class="fas fa-exclamation-triangle"></i></div>
                <div>
                    <div class="stat-label">Unsellable</div>
                    <div class="stat-value"><?php echo number_format((float)$summary['unsellable_total'], 2); ?> kg</div>
                    <small class="text-muted">Needs review</small>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-xl-3">
            <div class="stat-tile h-100 d-flex gap-3 align-items-start">
                <div class="cond-icon cond-damaged"><i class="fas fa-times-circle"></i></div>
                <div>
                    <div class="stat-label">Damaged</div>
                    <div class="stat-value"><?php echo number_format((float)$summary['damaged_total'], 2); ?> kg</div>
                    <small class="text-muted">Recorded damage</small>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-xl-3">
            <div class="stat-tile h-100 d-flex gap-3 align-items-start">
                <div class="cond-icon cond-total"><i class="fas fa-boxes-stacked"></i></div>
                <div>
                    <div class="stat-label">Overall Recorded</div>
                    <div class="stat-value"><?php echo number_format((float)$summary['overall_total'], 2); ?> kg</div>
                    <small class="text-muted"><?php echo (int)$summary['total_entries']; ?> entries</small>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-3">
        <div class="col-md-6 col-xl-3">
            <div class="modern-card cond-tab-card p-3 h-100 <?= $tab === 'discounted' ? 'active' : '' ?>" data-tab="discounted" role="button" tabindex="0">
                <div class="d-flex align-items-center justify-content-between">
                    <div class="fw-bold text-uppercase" style="letter-spacing:.3px;">Discounted Stocks</div>
                    <i class="fas fa-tags text-muted"></i>
                </div>
                <div class="mt-2 text-muted"><?= (int)$discounted_count ?> record(s)</div>
            </div>
        </div>

        <div class="col-md-6 col-xl-3">
            <div class="modern-card cond-tab-card p-3 h-100 <?= $tab === 'records' ? 'active' : '' ?>" data-tab="records" role="button" tabindex="0">
                <div class="d-flex align-items-center justify-content-between">
                    <div class="fw-bold text-uppercase" style="letter-spacing:.3px;">Condition Records</div>
                    <i class="fas fa-clipboard-list text-muted"></i>
                </div>
                <div class="mt-2 text-muted"><?= (int)$records_count ?> record(s)</div>
            </div>
        </div>
    </div>

    <div id="condPlaceholder" class="p-4 text-center <?= $tab !== '' ? 'd-none' : '' ?>">
        Select a card above to view details.
    </div>

    <div id="condPaneDiscounted" class="<?= $tab === 'discounted' ? '' : 'd-none' ?>">
        <div class="card modern-card legacy-form-shell adjust-panel mb-4">
            <div class="legacy-header"><i class="fas fa-tags"></i> Discounted Stocks</div>
            <div class="card-body p-3">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                <small class="text-muted">Latest discounted entries first</small>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>Rice Name</th>
                            <th>Variety</th>
                            <th>Discount Price</th>
                            <th class="text-end">Total Quantity (kg)</th>
                            <th>Last Updated</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($discounted_result && $discounted_result->num_rows > 0): ?>
                        <?php while ($d = $discounted_result->fetch_assoc()): ?>
                            <tr>
                                <td class="fw-semibold"><?php echo htmlspecialchars($d['rice_name']); ?></td>
                                <td><?php echo htmlspecialchars($d['variety']); ?></td>
                                <td>
                                    <?php if ($d['discount_price_per_kg'] !== null): ?>
                                        <span class="discount-note">₱<?php echo number_format((float)$d['discount_price_per_kg'], 2); ?>/kg</span>
                                    <?php else: ?>
                                        —
                                    <?php endif; ?>
                                </td>
                                <td class="text-end fw-semibold"><?php echo number_format((float)$d['total_kg'], 2); ?></td>
                                <td>
                                    <?php
                                    echo $d['last_update']
                                        ? date('M d, Y • g:i A', strtotime($d['last_update']))
                                        : '—';
                                    ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5">
                                <div class="empty-state">
                                    <i class="fas fa-tags"></i>
                                    <div class="fw-semibold">No discounted stocks yet</div>
                                    <div>Discounted stock entries will appear here first.</div>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            </div>
        </div>
    </div>

    <div id="condPaneRecords" class="<?= $tab === 'records' ? '' : 'd-none' ?>">
        <div class="card modern-card legacy-form-shell adjust-panel mb-4">
            <div class="legacy-header"><i class="fas fa-filter"></i> Filters</div>
            <div class="card-body p-3">
            <form method="GET" class="row g-3 mb-0">
                <input type="hidden" name="tab" value="records">
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Search</label>
                    <input
                        type="text"
                        name="search"
                        class="form-control"
                        placeholder="Search rice name, variety, or reason"
                        value="<?php echo htmlspecialchars($search); ?>"
                    >
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">Condition</label>
                    <select name="condition" class="form-select">
                        <option value="">All Conditions</option>
                        <option value="Sellable" <?php echo ($condition === 'Sellable' ? 'selected' : ''); ?>>Sellable</option>
                        <option value="Discounted" <?php echo ($condition === 'Discounted' ? 'selected' : ''); ?>>Discounted</option>
                        <option value="Unsellable" <?php echo ($condition === 'Unsellable' ? 'selected' : ''); ?>>Unsellable</option>
                        <option value="Damaged" <?php echo ($condition === 'Damaged' ? 'selected' : ''); ?>>Damaged</option>
                    </select>
                </div>

                <div class="col-md-2 d-flex align-items-end">
                    <div class="w-100 d-grid">
                        <button type="submit" class="btn btn-primary">Apply</button>
                    </div>
                </div>
            </form>
            </div>
        </div>

        <div class="card modern-card legacy-form-shell adjust-panel">
            <div class="legacy-header"><i class="fas fa-clipboard-list"></i> Stock Condition Records</div>
            <div class="card-body p-3">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                <small class="text-muted">Latest records first</small>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>Rice Name</th>
                        <th>Variety</th>
                        <th>Condition</th>
                        <th>Reason</th>
                        <th>Discount Price</th>
                        <th class="text-end">Total Quantity (kg)</th>
                        <th>Last Updated</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <?php
                        $badgeClass = "bg-success";
                        if ($row['condition_type'] === "Discounted") $badgeClass = "bg-warning text-dark";
                        if ($row['condition_type'] === "Unsellable") $badgeClass = "bg-secondary";
                        if ($row['condition_type'] === "Damaged") $badgeClass = "bg-danger";
                        ?>
                        <tr>
                            <td class="fw-semibold"><?php echo htmlspecialchars($row['rice_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['variety']); ?></td>
                            <td>
                                <span class="badge rounded-pill <?php echo $badgeClass; ?>">
                                    <?php echo htmlspecialchars($row['condition_type']); ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($row['reason'] ?: '—'); ?></td>
                            <td>
                                <?php if ($row['condition_type'] === 'Discounted' && $row['discount_price_per_kg'] !== null): ?>
                                    <span class="discount-note">₱<?php echo number_format((float)$row['discount_price_per_kg'], 2); ?>/kg</span>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                            <td class="text-end fw-semibold"><?php echo number_format((float)$row['total_kg'], 2); ?></td>
                            <td>
                                <?php
                                echo $row['last_update']
                                    ? date('M d, Y • g:i A', strtotime($row['last_update']))
                                    : '—';
                                ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7">
                            <div class="empty-state">
                                <i class="fas fa-box-open"></i>
                                <div class="fw-semibold">No records found</div>
                                <div>Adjusted, discounted, damaged, or unsellable stocks will appear here.</div>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        </div>
    </div>
</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(() => {
  const cards = Array.from(document.querySelectorAll('.cond-tab-card'));
  const placeholder = document.getElementById('condPlaceholder');
  const paneDiscounted = document.getElementById('condPaneDiscounted');
  const paneRecords = document.getElementById('condPaneRecords');

  if(cards.length === 0 || !placeholder || !paneDiscounted || !paneRecords){
    return;
  }

  function setTab(tab, updateUrl){
    const active = (tab === 'discounted' || tab === 'records') ? tab : '';

    paneDiscounted.classList.toggle('d-none', active !== 'discounted');
    paneRecords.classList.toggle('d-none', active !== 'records');
    placeholder.classList.toggle('d-none', active !== '');

    cards.forEach((c) => c.classList.toggle('active', (c.dataset.tab || '') === active));

    if(updateUrl){
      const url = new URL(window.location.href);
      if(active){
        url.searchParams.set('tab', active);
      } else {
        url.searchParams.delete('tab');
      }
      history.replaceState({}, '', url.toString());
    }
  }

  function handleActivate(card){
    const tab = (card.dataset.tab || '').toLowerCase();
    setTab(tab, true);
  }

  cards.forEach((card) => {
    card.addEventListener('click', () => handleActivate(card));
    card.addEventListener('keydown', (e) => {
      if(e.key === 'Enter' || e.key === ' '){
        e.preventDefault();
        handleActivate(card);
      }
    });
  });
})();
</script>
<script>
(function () {
  const pollIntervalMs = 5000;
  let pollingInFlight = false;
  async function pollLiveMain() {
    if (pollingInFlight) return;
    pollingInFlight = true;
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('_live', Date.now().toString());
      const response = await fetch(url.toString(), { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const sourceMain = doc.querySelector('main');
      const targetMain = document.querySelector('main');
      if (sourceMain && targetMain) targetMain.innerHTML = sourceMain.innerHTML;
    } catch (error) {
      console.error('Stock condition live poll failed:', error);
    } finally {
      pollingInFlight = false;
    }
  }
  pollLiveMain();
  window.setInterval(pollLiveMain, pollIntervalMs);
})();
</script>
</body>
</html>
