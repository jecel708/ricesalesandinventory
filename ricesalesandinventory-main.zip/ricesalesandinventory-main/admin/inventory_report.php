<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}
if (strtolower($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: ../login.php");
    exit;
}
include '../config/db.php';
/* =========================================================
   HELPERS
========================================================= */
function normalizeBatchCode(string $code): string
{
    $code = trim($code);
    if ($code === '') {
        return '';
    }
    if (preg_match('/^LEGACY-(\d+)$/i', $code, $matches)) {
        return 'Batch ' . $matches[1];
    }
    return $code;
}
function inventoryTypeBadge(array $row): array
{
    $type = strtolower(trim((string)($row['type'] ?? '')));
    $reference = strtoupper(trim((string)($row['reference_type'] ?? '')));
    if ($reference === 'RETURN') {
        return ['RETURN', 'badge badge-return'];
    }
    if ($reference === 'PURCHASE') {
        return ['PURCHASE', 'badge badge-in'];
    }
    if ($reference === 'SALE') {
        return ['SALE', 'badge badge-out'];
    }
    if ($type === 'in') {
        return ['IN', 'badge badge-in'];
    }
    if ($type === 'out') {
        return ['OUT', 'badge badge-out'];
    }
    if ($type === 'adjust' || $reference === 'ADJUST') {
        return ['ADJUST', 'badge badge-adjust'];
    }
    return [$reference !== '' ? $reference : 'N/A', 'badge badge-neutral'];
}
/* =========================================================
   USER / PAGE
========================================================= */
$username   = $_SESSION['username'] ?? 'User';
$user_id    = (int)($_SESSION['user_id'] ?? 0);
$activePage = 'inventory_report';
$profileLink = 'profile.php';
$logoutLink  = '../logout.php';
/* =========================================================
   STOCK THRESHOLD SETTINGS
========================================================= */
$settingsRow = [];
$settingsRes = $conn->query("SELECT low_threshold_kg, over_threshold_kg FROM stock_settings WHERE id = 1 LIMIT 1");
if ($settingsRes) {
    $settingsRow = $settingsRes->fetch_assoc() ?: [];
}
$DEFAULT_LOW_STOCK_THRESHOLD = 10.0;
$DEFAULT_OVERSTOCK_THRESHOLD  = 1000.0;
$lowThreshold = (float)($settingsRow['low_threshold_kg'] ?? $DEFAULT_LOW_STOCK_THRESHOLD);
$overThreshold = (float)($settingsRow['over_threshold_kg'] ?? $DEFAULT_OVERSTOCK_THRESHOLD);
/* =========================================================
   DATE RANGE
========================================================= */
$fromRaw = (string)($_GET['from'] ?? date('Y-m-d', strtotime('-29 days')));
$toRaw = (string)($_GET['to'] ?? date('Y-m-d'));
$fromObj = DateTime::createFromFormat('Y-m-d', $fromRaw) ?: new DateTime('-29 days');
$toObj = DateTime::createFromFormat('Y-m-d', $toRaw) ?: new DateTime('today');
if ($fromObj > $toObj) {
    $tmp = clone $fromObj;
    $fromObj = clone $toObj;
    $toObj = $tmp;
}
$fromDate = $fromObj->format('Y-m-d');
$toDate   = $toObj->format('Y-m-d');
$rangeStart = $fromDate . ' 00:00:00';
$rangeEnd = (clone $toObj)->modify('+1 day')->format('Y-m-d 00:00:00');
/* =========================================================
   TABS — FIXED VALIDATION
========================================================= */
$tab = strtolower(trim((string)($_GET['tab'] ?? 'overview')));
if (!in_array($tab, ['overview', 'suppliers', 'purchasereport'], true)) {
    $tab = 'overview';
}
/* =========================================================
   TREND
========================================================= */
$trend = strtolower((string)($_GET['trend'] ?? 'daily'));
if (!in_array($trend, ['daily', 'weekly', 'monthly', 'yearly'], true)) {
    $trend = 'daily';
}
/* =========================================================
   CURRENT STOCK SUMMARY
========================================================= */
$currentStockSql = "
    SELECT
        COUNT(*) AS active_products,
        IFNULL(SUM(COALESCE(COALESCE(sb.stock_kg, p.stock_kg), 0)), 0) AS total_stock_kg,
        SUM(CASE WHEN COALESCE(COALESCE(sb.stock_kg, p.stock_kg), 0) <= ? THEN 1 ELSE 0 END) AS low_stock_count,
        SUM(CASE WHEN COALESCE(COALESCE(sb.stock_kg, p.stock_kg), 0) <= 0 THEN 1 ELSE 0 END) AS out_of_stock_count,
        SUM(CASE WHEN COALESCE(COALESCE(sb.stock_kg, p.stock_kg), 0) >= ? THEN 1 ELSE 0 END) AS overstock_count
    FROM products p
    LEFT JOIN (SELECT product_id, IFNULL(SUM(remaining_qty_kg), 0) AS stock_kg FROM stock_batches GROUP BY product_id) sb
        ON sb.product_id = p.product_id
    WHERE COALESCE(p.archived, 0) = 0
";
$stmt = $conn->prepare($currentStockSql);
$stockSummary = [
    'active_products'    => 0,
    'total_stock_kg'     => 0,
    'low_stock_count'    => 0,
    'out_of_stock_count' => 0,
    'overstock_count'    => 0,
];
if ($stmt) {
    $stmt->bind_param("dd", $lowThreshold, $overThreshold);
    $stmt->execute();
    $stockSummary = $stmt->get_result()->fetch_assoc() ?: $stockSummary;
    $stmt->close();
}
/* =========================================================
   INVENTORY MOVEMENT SUMMARY
========================================================= */
$movementSql = "
    SELECT
        COUNT(*) AS transaction_count,
        IFNULL(SUM(CASE WHEN LOWER(IFNULL(type,'')) = 'in' THEN ABS(COALESCE(qty_kg,0)) ELSE 0 END), 0) AS inbound_kg,
        IFNULL(SUM(CASE WHEN LOWER(IFNULL(type,'')) = 'out' THEN ABS(COALESCE(qty_kg,0)) ELSE 0 END), 0) AS outbound_kg,
        IFNULL(SUM(CASE WHEN LOWER(IFNULL(type,'')) = 'adjust' OR LOWER(IFNULL(reference_type,'')) = 'adjust' THEN ABS(COALESCE(qty_kg,0)) ELSE 0 END), 0) AS adjusted_kg,
        IFNULL(SUM(CASE WHEN LOWER(IFNULL(type,'')) = 'in' THEN ABS(COALESCE(qty_kg,0)) WHEN LOWER(IFNULL(type,'')) = 'out' THEN ABS(COALESCE(qty_kg,0)) WHEN LOWER(IFNULL(type,'')) = 'adjust' OR LOWER(IFNULL(reference_type,'')) = 'adjust' THEN ABS(COALESCE(qty_kg,0)) ELSE 0 END), 0) AS moved_kg
    FROM inventory_transactions
    WHERE created_at >= ? AND created_at < ?
";
$stmt = $conn->prepare($movementSql);
$movementSummary = [
    'transaction_count' => 0,
    'inbound_kg'        => 0,
    'outbound_kg'       => 0,
    'adjusted_kg'       => 0,
    'moved_kg'          => 0,
];
if ($stmt) {
    $stmt->bind_param("ss", $rangeStart, $rangeEnd);
    $stmt->execute();
    $movementSummary = $stmt->get_result()->fetch_assoc() ?: $movementSummary;
    $stmt->close();
}
/* =========================================================
   FAST MOVERS
========================================================= */
$fastMovingItems = [];
$moversSql = "
    SELECT
        p.product_id, p.variety, p.grade, p.unit_weight_kg,
        COALESCE(SUM(CASE WHEN LOWER(IFNULL(s.status,'')) <> 'cancelled' THEN ABS(COALESCE(si.qty_kg,0)) ELSE 0 END), 0) AS sold_kg,
        COALESCE((SELECT SUM(sb2.remaining_qty_kg) FROM stock_batches sb2 WHERE sb2.product_id = p.product_id), p.stock_kg, 0) AS stock_kg
    FROM products p
    LEFT JOIN sales_items si ON si.product_id = p.product_id
    LEFT JOIN sales s ON s.sale_id = si.sale_id AND s.sale_date >= ? AND s.sale_date < ?
    WHERE COALESCE(p.archived, 0) = 0
    GROUP BY p.product_id, p.variety, p.grade, p.unit_weight_kg, p.stock_kg
    ORDER BY sold_kg DESC, p.variety ASC, p.grade ASC LIMIT 5
";
$stmt = $conn->prepare($moversSql);
if ($stmt) {
    $stmt->bind_param("ss", $rangeStart, $rangeEnd);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) { $fastMovingItems[] = $row; }
    $stmt->close();
}
/* =========================================================
   SLOW MOVERS
========================================================= */
$slowMovingItems = [];
$slowMovingSql = "
    SELECT
        p.product_id, p.variety, p.grade, p.unit_weight_kg,
        COALESCE(SUM(CASE WHEN LOWER(IFNULL(s.status,'')) <> 'cancelled' THEN ABS(COALESCE(si.qty_kg,0)) ELSE 0 END), 0) AS sold_kg,
        COALESCE((SELECT SUM(sb2.remaining_qty_kg) FROM stock_batches sb2 WHERE sb2.product_id = p.product_id), p.stock_kg, 0) AS stock_kg
    FROM products p
    LEFT JOIN sales_items si ON si.product_id = p.product_id
    LEFT JOIN sales s ON s.sale_id = si.sale_id AND s.sale_date >= ? AND s.sale_date < ?
    WHERE COALESCE(p.archived, 0) = 0
    GROUP BY p.product_id, p.variety, p.grade, p.unit_weight_kg, p.stock_kg
    ORDER BY sold_kg ASC, stock_kg DESC, p.variety ASC, p.grade ASC LIMIT 5
";
$stmt = $conn->prepare($slowMovingSql);
if ($stmt) {
    $stmt->bind_param("ss", $rangeStart, $rangeEnd);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) { $slowMovingItems[] = $row; }
    $stmt->close();
}
/* =========================================================
   SUPPLIER PURCHASE SUMMARY
========================================================= */
$supplierPurchaseSummary = ['purchase_count' => 0, 'total_amount' => 0, 'total_qty_sacks' => 0, 'supplier_count' => 0];
$supplierPurchaseHistory = [];
$supplierTopList = [];
$supplierSummaryStmt = $conn->prepare("
    SELECT
        COUNT(DISTINCT p.purchases_id) AS purchase_count,
        IFNULL(SUM(COALESCE(p.total_amount,0)), 0) AS total_amount,
        IFNULL(SUM(COALESCE(pi.quantity_sacks,0)), 0) AS total_qty_sacks,
        COUNT(DISTINCT p.supplier_id) AS supplier_count
    FROM purchases p
    LEFT JOIN purchase_items pi ON pi.purchases_id = p.purchases_id
    WHERE p.po_approved = 1
      AND COALESCE(p.purchase_date, p.created_at) >= ?
      AND COALESCE(p.purchase_date, p.created_at) < ?
");
if ($supplierSummaryStmt) {
    $supplierSummaryStmt->bind_param("ss", $rangeStart, $rangeEnd);
    $supplierSummaryStmt->execute();
    $supplierPurchaseSummary = $supplierSummaryStmt->get_result()->fetch_assoc() ?: $supplierPurchaseSummary;
    $supplierSummaryStmt->close();
}
/* =========================================================
   SUPPLIER PURCHASE HISTORY
========================================================= */
$supplierHistoryStmt = $conn->prepare("
    SELECT
        p.purchases_id, p.purchase_date, p.total_amount, p.status, p.po_approved_at, p.received_at,
        s.name AS supplier_name, s.phone AS supplier_phone, s.address AS supplier_address,
        COALESCE(SUM(pi.quantity_sacks), 0) AS total_sacks, COUNT(pi.purchase_item_id) AS line_count
    FROM purchases p
    LEFT JOIN suppliers s ON s.supplier_id = p.supplier_id
    LEFT JOIN purchase_items pi ON pi.purchases_id = p.purchases_id
    WHERE p.po_approved = 1
      AND COALESCE(p.purchase_date, p.created_at) >= ?
      AND COALESCE(p.purchase_date, p.created_at) < ?
    GROUP BY p.purchases_id, p.purchase_date, p.total_amount, p.status, p.po_approved_at, p.received_at, s.name, s.phone, s.address
    ORDER BY COALESCE(p.purchase_date, p.created_at) DESC, p.purchases_id DESC LIMIT 50
");
if ($supplierHistoryStmt) {
    $supplierHistoryStmt->bind_param("ss", $rangeStart, $rangeEnd);
    $supplierHistoryStmt->execute();
    $res = $supplierHistoryStmt->get_result();
    while ($row = $res->fetch_assoc()) { $supplierPurchaseHistory[] = $row; }
    $supplierHistoryStmt->close();
}
/* =========================================================
   TOP SUPPLIERS
========================================================= */
$supplierTopStmt = $conn->prepare("
    SELECT
        s.supplier_id, s.name AS supplier_name,
        COUNT(DISTINCT p.purchases_id) AS purchase_count,
        IFNULL(SUM(COALESCE(p.total_amount,0)), 0) AS total_amount,
        MAX(COALESCE(p.purchase_date, p.created_at)) AS last_purchase
    FROM suppliers s
    LEFT JOIN purchases p ON p.supplier_id = s.supplier_id
        AND p.po_approved = 1
        AND COALESCE(p.purchase_date, p.created_at) >= ?
        AND COALESCE(p.purchase_date, p.created_at) < ?
    GROUP BY s.supplier_id, s.name
    HAVING purchase_count > 0
    ORDER BY total_amount DESC, purchase_count DESC, supplier_name ASC LIMIT 10
");
if ($supplierTopStmt) {
    $supplierTopStmt->bind_param("ss", $rangeStart, $rangeEnd);
    $supplierTopStmt->execute();
    $res = $supplierTopStmt->get_result();
    while ($row = $res->fetch_assoc()) { $supplierTopList[] = $row; }
    $supplierTopStmt->close();
}
/* =========================================================
   HIGHEST STOCK ITEMS
========================================================= */
$topStockItems = [];
$stmt = $conn->prepare("
    SELECT p.product_id, p.variety, p.grade, p.unit_weight_kg,
        COALESCE(COALESCE(sb.stock_kg, p.stock_kg), 0) AS stock_kg, p.delivery_date
    FROM products p
    LEFT JOIN (SELECT product_id, IFNULL(SUM(remaining_qty_kg),0) AS stock_kg FROM stock_batches GROUP BY product_id) sb
        ON sb.product_id = p.product_id
    WHERE COALESCE(p.archived, 0) = 0
    ORDER BY COALESCE(COALESCE(sb.stock_kg, p.stock_kg), 0) DESC, variety ASC, grade ASC LIMIT 10
");
if ($stmt) {
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) { $topStockItems[] = $row; }
    $stmt->close();
}
/* =========================================================
   LOW STOCK ITEMS
========================================================= */
$lowStockItems = [];
$stmt = $conn->prepare("
    SELECT p.product_id, p.variety, p.grade, p.unit_weight_kg,
        COALESCE(COALESCE(sb.stock_kg, p.stock_kg), 0) AS stock_kg, p.delivery_date
    FROM products p
    LEFT JOIN (SELECT product_id, IFNULL(SUM(remaining_qty_kg),0) AS stock_kg FROM stock_batches GROUP BY product_id) sb
        ON sb.product_id = p.product_id
    WHERE COALESCE(p.archived, 0) = 0
      AND COALESCE(COALESCE(sb.stock_kg, p.stock_kg), 0) <= ?
    ORDER BY COALESCE(COALESCE(sb.stock_kg, p.stock_kg), 0) ASC, variety ASC, grade ASC LIMIT 10
");
if ($stmt) {
    $stmt->bind_param("d", $lowThreshold);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) { $lowStockItems[] = $row; }
    $stmt->close();
}
/* =========================================================
   RECENT INVENTORY TRANSACTIONS
========================================================= */
$recentTransactions = [];
$stmt = $conn->prepare("
    SELECT it.*, p.variety, p.grade, sb.batch_code
    FROM inventory_transactions it
    LEFT JOIN products p ON p.product_id = it.product_id
    LEFT JOIN stock_batches sb ON sb.batch_id = it.batch_id
    WHERE it.created_at >= ? AND it.created_at < ?
    ORDER BY it.created_at DESC LIMIT 20
");
if ($stmt) {
    $stmt->bind_param("ss", $rangeStart, $rangeEnd);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) { $recentTransactions[] = $row; }
    $stmt->close();
}
$trendItems = [];
$trendLabel = 'Daily Sales';
$trendSubLabel = 'Sales totals grouped by day.';
$trendSql = '';
if ($trend === 'weekly') {
    $trendLabel = 'Weekly Sales';
    $trendSubLabel = 'Sales totals grouped by week.';
    $trendSql = "
        SELECT DATE_SUB(DATE(s.sale_date), INTERVAL WEEKDAY(s.sale_date) DAY) AS period_start,
               DATE_ADD(DATE(s.sale_date), INTERVAL 6 DAY) AS period_end,
               COALESCE(SUM(s.total_amount),0) AS sales_total, COUNT(*) AS sale_count
        FROM sales s
        WHERE LOWER(IFNULL(s.status,'')) <> 'cancelled' AND s.sale_date >= ? AND s.sale_date < ?
        GROUP BY YEARWEEK(s.sale_date,1) ORDER BY period_start DESC LIMIT 12
    ";
} elseif ($trend === 'monthly') {
    $trendLabel = 'Monthly Sales';
    $trendSubLabel = 'Sales totals grouped by month.';
    $trendSql = "
        SELECT DATE_FORMAT(s.sale_date,'%Y-%m-01') AS period_start, LAST_DAY(s.sale_date) AS period_end,
               COALESCE(SUM(s.total_amount),0) AS sales_total, COUNT(*) AS sale_count
        FROM sales s
        WHERE LOWER(IFNULL(s.status,'')) <> 'cancelled' AND s.sale_date >= ? AND s.sale_date < ?
        GROUP BY DATE_FORMAT(s.sale_date,'%Y-%m') ORDER BY period_start DESC LIMIT 12
    ";
} elseif ($trend === 'yearly') {
    $trendLabel = 'Yearly Sales';
    $trendSubLabel = 'Sales totals grouped by year.';
    $trendSql = "
        SELECT MAKEDATE(YEAR(s.sale_date),1) AS period_start, MAKEDATE(YEAR(s.sale_date),365) AS period_end,
               COALESCE(SUM(s.total_amount),0) AS sales_total, COUNT(*) AS sale_count
        FROM sales s
        WHERE LOWER(IFNULL(s.status,'')) <> 'cancelled' AND s.sale_date >= ? AND s.sale_date < ?
        GROUP BY YEAR(s.sale_date) ORDER BY period_start DESC LIMIT 12
    ";
} else {
    $trendSql = "
        SELECT DATE(s.sale_date) AS period_start, DATE(s.sale_date) AS period_end,
               COALESCE(SUM(s.total_amount),0) AS sales_total, COUNT(*) AS sale_count
        FROM sales s
        WHERE LOWER(IFNULL(s.status,'')) <> 'cancelled' AND s.sale_date >= ? AND s.sale_date < ?
        GROUP BY DATE(s.sale_date) ORDER BY period_start DESC LIMIT 12
    ";
}
$trendStmt = $conn->prepare($trendSql);
if ($trendStmt) {
    $trendStmt->bind_param("ss", $rangeStart, $rangeEnd);
    $trendStmt->execute();
    $res = $trendStmt->get_result();
    while ($row = $res->fetch_assoc()) { $trendItems[] = $row; }
    $trendStmt->close();
}
/* =========================================================
   PURCHASE REPORT
========================================================= */
$purchaseReportSummary = ['total_po' => 0, 'total_amount' => 0, 'total_sacks' => 0, 'avg_po_amount' => 0];
$purchaseReportItems = [];
$prSummaryStmt = $conn->prepare("
    SELECT COUNT(DISTINCT p.purchases_id) AS total_po,
           IFNULL(SUM(DISTINCT COALESCE(p.total_amount,0)),0) AS total_amount,
           IFNULL(SUM(COALESCE(pi.quantity_sacks,0)),0) AS total_sacks
    FROM purchases p LEFT JOIN purchase_items pi ON pi.purchases_id = p.purchases_id
    WHERE p.po_approved = 1
      AND COALESCE(p.purchase_date, p.created_at) >= ?
      AND COALESCE(p.purchase_date, p.created_at) < ?
");
if ($prSummaryStmt) {
    $prSummaryStmt->bind_param("ss", $rangeStart, $rangeEnd);
    $prSummaryStmt->execute();
    $res = $prSummaryStmt->get_result()->fetch_assoc();
    $purchaseReportSummary = $res ?: $purchaseReportSummary;
    $purchaseReportSummary['avg_po_amount'] = $purchaseReportSummary['total_po'] > 0
        ? $purchaseReportSummary['total_amount'] / $purchaseReportSummary['total_po'] : 0;
    $prSummaryStmt->close();
}
$prItemsStmt = $conn->prepare("
    SELECT p.purchases_id, p.purchase_date, p.total_amount, p.status, p.po_approved_at,
           s.name AS supplier_name, COALESCE(SUM(pi.quantity_sacks),0) AS total_sacks,
           COUNT(pi.purchase_item_id) AS item_count
    FROM purchases p LEFT JOIN suppliers s ON s.supplier_id = p.supplier_id
    LEFT JOIN purchase_items pi ON pi.purchases_id = p.purchases_id
    WHERE p.po_approved = 1
      AND COALESCE(p.purchase_date, p.created_at) >= ?
      AND COALESCE(p.purchase_date, p.created_at) < ?
    GROUP BY p.purchases_id, p.purchase_date, p.total_amount, p.status, p.po_approved_at, s.name
    ORDER BY COALESCE(p.purchase_date, p.created_at) DESC LIMIT 100
");
if ($prItemsStmt) {
    $prItemsStmt->bind_param("ss", $rangeStart, $rangeEnd);
    $prItemsStmt->execute();
    $res = $prItemsStmt->get_result();
    while ($row = $res->fetch_assoc()) { $purchaseReportItems[] = $row; }
    $prItemsStmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Inventory Reports | DE ORO HIYS</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="../css/layout.css" rel="stylesheet">
<link href="../css/admin-mobile.css" rel="stylesheet">
<link href="../css/admin-dashboard.css" rel="stylesheet">
<link href="../css/report-print.css" rel="stylesheet">
<style>
:root {
    --system-navy: #2D4056;
    --system-navy-dark: #24364A;
    --system-navy-light: #3B526B;
    --system-bg: #EDF1F5;
    --system-card: #F6F8FA;
    --system-border: #D5DDE6;
    --system-text: #2C3E50;
    --system-muted: #6C757D;
    --system-success: #198754;
    --system-danger: #DC3545;
    --system-warning: #D89E00;
}
body { background: var(--system-bg); color: var(--system-text); }
.main-content { background: var(--system-bg); }
h3,h4,h5,h6 { color: var(--system-text); }
.modern-card { border: 1px solid var(--system-border); background: var(--system-card); border-radius: 10px; box-shadow: 0 2px 8px rgba(45,64,86,0.06); overflow: hidden; }
.modern-card .card-header { background: var(--system-navy); color: #fff; border-bottom: 1px solid var(--system-navy-dark); font-weight: 700; }
.modern-card .card-body { background: var(--system-card); }
.nav-pills { gap: 6px; }
.nav-pills .nav-link { color: var(--system-text); background: #E2E7ED; border: 1px solid var(--system-border); border-radius: 7px; font-weight: 600; padding: 9px 18px; position: relative; z-index: 10; pointer-events: auto; cursor: pointer; }
.nav-pills .nav-link:hover { background: #D7DEE6; color: var(--system-navy-dark); }
.nav-pills .nav-link.active { background: var(--system-navy); color: #fff; border-color: var(--system-navy); }
.form-control,.form-select { border: 1px solid #C8D1DB; color: var(--system-text); background: #fff; border-radius: 6px; }
.form-control:focus,.form-select:focus { border-color: var(--system-navy); box-shadow: 0 0 0 0.15rem rgba(45,64,86,0.15); }
.btn-success { background: var(--system-navy); border-color: var(--system-navy); }
.btn-success:hover,.btn-success:focus { background: var(--system-navy-dark); border-color: var(--system-navy-dark); }
.btn-outline-dark { color: var(--system-navy); border-color: var(--system-navy); }
.btn-outline-dark:hover { background: var(--system-navy); border-color: var(--system-navy); color: #fff; }
.card-header .fw-bold { color: #fff; }
.card-header .small,.card-header .text-muted { color: rgba(255,255,255,.72) !important; }
.table-wrap { overflow-x: auto; }
.table { color: var(--system-text); }
.table thead.table-dark { background: var(--system-navy) !important; }
.table thead.table-dark th { background: var(--system-navy) !important; color: #fff !important; border-color: #40556C !important; font-weight: 700; }
.table-bordered { border-color: var(--system-border); }
.table-bordered > :not(caption) > * > * { border-color: var(--system-border); }
.table-striped > tbody > tr:nth-of-type(odd) > * { background-color: #F0F3F6; }
.table tbody tr:hover > * { background-color: #E7ECF1; }
.table-sm th,.table-sm td { padding: 11px 12px; }
.table tbody td { vertical-align: middle; }
.movers-card { border: 1px solid var(--system-border); border-radius: 10px; overflow: hidden; background: var(--system-card); box-shadow: 0 2px 8px rgba(45,64,86,0.06); }
.movers-header { background: var(--system-navy); color: #fff; padding: 20px 22px; }
.movers-title { font-size: 1.25rem; font-weight: 700; color: #fff; }
.movers-subtitle { color: rgba(255,255,255,.70); font-size: .88rem; }
.mover-panel { background: var(--system-card); border: 1px solid var(--system-border); border-radius: 10px; overflow: hidden; height: 100%; }
.mover-panel.fast { border-left: 5px solid var(--system-success); }
.mover-panel.slow { border-left: 5px solid var(--system-danger); }
.mover-panel-header { padding: 18px 20px 10px; }
.mover-panel-title { font-size: 1.05rem; font-weight: 700; color: var(--system-text); }
.mover-panel-subtitle { color: var(--system-muted); font-size: .85rem; }
.mover-table { margin-bottom: 0; }
.mover-table thead th { background: var(--system-navy); color: #fff; border: 0; font-size: .78rem; text-transform: uppercase; letter-spacing: .03em; padding: 12px; }
.mover-table tbody td { padding: 13px 12px; vertical-align: middle; }
.mover-product { font-weight: 600; color: var(--system-text); }
.mover-rank { width: 40px; font-weight: 700; color: var(--system-muted); }
.mover-progress { height: 7px; border-radius: 20px; background: #E2E7ED; margin-top: 7px; overflow: hidden; }
.mover-progress-bar { height: 100%; border-radius: 20px; }
.fast .mover-progress-bar { background: var(--system-success); }
.slow .mover-progress-bar { background: var(--system-danger); }
.mover-summary-badge { background: rgba(255,255,255,.10); border: 1px solid rgba(255,255,255,.20); color: #fff; border-radius: 30px; padding: 8px 14px; font-size: .82rem; }
.mover-empty { padding: 35px 15px; text-align: center; color: var(--system-muted); }
.report-kpi { border: 1px solid var(--system-border); background: var(--system-card); border-radius: 10px; box-shadow: 0 2px 8px rgba(45,64,86,0.05); transition: transform .15s ease, box-shadow .15s ease; }
.report-kpi:hover { transform: translateY(-2px); box-shadow: 0 5px 14px rgba(45,64,86,0.09); }
.badge-in { background: #DFF3E7; color: #146C43; border: 1px solid #B9E2C8; }
.badge-out { background: #FBE3E5; color: #B02A37; border: 1px solid #F3BEC4; }
.badge-return { background: #E0EAF4; color: var(--system-navy); border: 1px solid #C3D2E2; }
.badge-adjust { background: #FFF1CC; color: #8A6500; border: 1px solid #F1D88A; }
.badge-neutral { background: #E9ECEF; color: #495057; border: 1px solid #D6DADF; }
.status-received { background: #DFF3E7; color: #146C43; }
.status-pending { background: #FFF1CC; color: #8A6500; }
.status-default { background: #E9ECEF; color: #495057; }
.text-success { color: #198754 !important; }
.text-danger { color: #DC3545 !important; }
.text-warning { color: #B17A00 !important; }
.text-muted { color: var(--system-muted) !important; }
@media print {
    body { background: #fff !important; }
    .no-print { display: none !important; }
    .modern-card,.movers-card { box-shadow: none !important; border: 1px solid #aaa !important; }
    .movers-header { background: #eee !important; color: #000 !important; }
    .movers-title { color: #000 !important; }
    .movers-subtitle { color: #555 !important; }
    .mover-summary-badge { color: #000 !important; border-color: #aaa !important; background: #fff !important; }
    .table thead.table-dark th,.mover-table thead th { background: #2D4056 !important; color: #fff !important; }
}
@media (max-width: 768px) {
    .main-content { padding-left: 15px !important; padding-right: 15px !important; }
    .movers-header { padding: 17px; }
    .movers-title { font-size: 1.1rem; }
    .mover-summary-badge { font-size: .76rem; padding: 7px 10px; }
    .table { font-size: .88rem; }
}
</style>
</head>
<body>
<?php include '../includes/topnav.php'; ?>
<div class="container-fluid">
    <div class="row">
        <?php include '../includes/admin_sidebar.php'; ?>
        <main class="col-lg-10 ms-sm-auto px-4 py-4 main-content">
            <!-- PAGE HEADER -->
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Inventory Reports</h3>
                    <div class="text-muted small">Monitor inventory movement, stock levels, suppliers, and purchasing activity.</div>
                </div>
                <button class="btn btn-outline-dark no-print" onclick="window.print()">
                    <i class="fa-solid fa-print me-1"></i> Print
                </button>
            </div>

            <!-- =====================================================
                 TABS — FIXED CLICKABLE LINKS
            ====================================================== -->
            <ul class="nav nav-pills mb-4 no-print">
                <li class="nav-item">
                    <a class="nav-link <?= $tab === 'overview' ? 'active' : '' ?>"
                       href="inventory_report.php?tab=overview&from=<?= urlencode($fromDate) ?>&to=<?= urlencode($toDate) ?>">
                        <i class="fa-solid fa-chart-column me-1"></i> Overview
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $tab === 'suppliers' ? 'active' : '' ?>"
                       href="inventory_report.php?tab=suppliers&from=<?= urlencode($fromDate) ?>&to=<?= urlencode($toDate) ?>">
                        <i class="fa-solid fa-truck-field me-1"></i> Supplier Reports
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $tab === 'purchasereport' ? 'active' : '' ?>"
                       href="inventory_report.php?tab=purchasereport&from=<?= urlencode($fromDate) ?>&to=<?= urlencode($toDate) ?>">
                        <i class="fa-solid fa-file-invoice me-1"></i> Purchase Report
                    </a>
                </li>
            </ul>

            <!-- DATE FILTER -->
            <form class="card modern-card mb-4 no-print">
                <div class="card-body">
                    <div class="row g-3 align-items-end">
                        <div class="col-md-4 col-lg-3">
                            <label class="form-label fw-semibold">From</label>
                            <input type="date" class="form-control" name="from" value="<?= htmlspecialchars($fromDate) ?>">
                        </div>
                        <div class="col-md-4 col-lg-3">
                            <label class="form-label fw-semibold">To</label>
                            <input type="date" class="form-control" name="to" value="<?= htmlspecialchars($toDate) ?>">
                        </div>
                        <div class="col-md-4 col-lg-3">
                            <button type="submit" class="btn btn-success w-100">
                                <i class="fa-solid fa-filter me-1"></i> Apply Range
                            </button>
                        </div>
                        <div class="col-12 col-lg-3 text-lg-end">
                            <div class="small text-muted">Low-stock threshold: <strong><?= number_format($lowThreshold, 2) ?> kg</strong></div>
                            <div class="small text-muted">Overstock threshold: <strong><?= number_format($overThreshold, 2) ?> kg</strong></div>
                        </div>
                    </div>
                </div>
            </form>

            <?php if ($tab === 'overview'): ?>
            <!-- FAST / SLOW MOVERS -->
            <div class="movers-card mb-4">
                <div class="movers-header">
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                        <div>
                            <div class="movers-title"><i class="fa-solid fa-chart-line me-2"></i> Fast & Slow Movers</div>
                            <div class="movers-subtitle">Sales performance from <?= htmlspecialchars(date('M d, Y', strtotime($fromDate))) ?> to <?= htmlspecialchars(date('M d, Y', strtotime($toDate))) ?></div>
                        </div>
                        <div class="d-flex gap-2 flex-wrap">
                            <?php if (!empty($fastMovingItems)):
                                $fastTop = $fastMovingItems[0];
                                $fastTopName = trim(($fastTop['variety'] ?? '') . ' - ' . ($fastTop['grade'] ?? ''));
                            ?>
                            <span class="mover-summary-badge">
                                <i class="fa-solid fa-arrow-trend-up me-1"></i> Fastest: <?= htmlspecialchars($fastTopName) ?>
                            </span>
                            <?php endif; ?>
                            <?php if (!empty($slowMovingItems)):
                                $slowTop = $slowMovingItems[0];
                                $slowTopName = trim(($slowTop['variety'] ?? '') . ' - ' . ($slowTop['grade'] ?? ''));
                            ?>
                            <span class="mover-summary-badge">
                                <i class="fa-solid fa-arrow-trend-down me-1"></i> Slowest: <?= htmlspecialchars($slowTopName) ?>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="p-3 p-lg-4">
                    <div class="row g-4">
                        <!-- FAST -->
                        <div class="col-lg-6">
                            <div class="mover-panel fast">
                                <div class="mover-panel-header">
                                    <div class="mover-panel-title">Fast Moving Products</div>
                                    <div class="mover-panel-subtitle">Products with the highest sales volume</div>
                                </div>
                                <div class="table-responsive">
                                    <table class="table mover-table">
                                        <thead>
                                            <tr><th>Rank</th><th>Product</th><th class="text-end">Sold</th><th class="text-end">Stock</th></tr>
                                        </thead>
                                        <tbody>
                                        <?php if (empty($fastMovingItems)): ?>
                                            <tr><td colspan="4" class="mover-empty"><i class="fa-solid fa-chart-line fa-2x mb-2"></i><div>No sales data found for this period.</div></td></tr>
                                        <?php else:
                                            $maxFastSold = 0;
                                            foreach ($fastMovingItems as $item) {
                                                $maxFastSold = max($maxFastSold, (float)($item['sold_kg'] ?? 0));
                                            }
                                            foreach ($fastMovingItems as $index => $row):
                                                $productName = trim(($row['variety'] ?? '') . ' - ' . ($row['grade'] ?? ''));
                                                if ($productName === '-') $productName = 'N/A';
                                                $soldKg = (float)($row['sold_kg'] ?? 0);
                                                $stockKg = (float)($row['stock_kg'] ?? 0);
                                                $percentage = $maxFastSold > 0 ? ($soldKg / $maxFastSold) * 100 : 0;
                                        ?>
                                            <tr>
                                                <td class="mover-rank">#<?= $index + 1 ?></td>
                                                <td><div class="mover-product"><?= htmlspecialchars($productName) ?></div><div class="mover-progress"><div class="mover-progress-bar" style="width:<?= min(100, $percentage) ?>%"></div></div></td>
                                                <td class="text-end fw-semibold"><?= number_format($soldKg, 2) ?> kg</td>
                                                <td class="text-end"><?= number_format($stockKg, 2) ?> kg</td>
                                            </tr>
                                            <?php endforeach;
                                        endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- SLOW -->
                        <div class="col-lg-6">
                            <div class="mover-panel slow">
                                <div class="mover-panel-header">
                                    <div class="mover-panel-title">Slow Moving Products</div>
                                    <div class="mover-panel-subtitle">Products that may require attention</div>
                                </div>
                                <div class="table-responsive">
                                    <table class="table mover-table">
                                        <thead>
                                            <tr><th>Rank</th><th>Product</th><th class="text-end">Sold</th><th class="text-end">Stock</th></tr>
                                        </thead>
                                        <tbody>
                                        <?php if (empty($slowMovingItems)): ?>
                                            <tr><td colspan="4" class="mover-empty"><i class="fa-solid fa-box-open fa-2x mb-2"></i><div>No product data found for this period.</div></td></tr>
                                        <?php else:
                                            $maxSlowStock = 0;
                                            foreach ($slowMovingItems as $item) {
                                                $maxSlowStock = max($maxSlowStock, (float)($item['stock_kg'] ?? 0));
                                            }
                                            foreach ($slowMovingItems as $index => $row):
                                                $productName = trim(($row['variety'] ?? '') . ' - ' . ($row['grade'] ?? ''));
                                                if ($productName === '-') $productName = 'N/A';
                                                $soldKg = (float)($row['sold_kg'] ?? 0);
                                                $stockKg = (float)($row['stock_kg'] ?? 0);
                                                $percentage = $maxSlowStock > 0 ? ($stockKg / $maxSlowStock) * 100 : 0;
                                        ?>
                                            <tr>
                                                <td class="mover-rank">#<?= $index + 1 ?></td>
                                                <td><div class="mover-product"><?= htmlspecialchars($productName) ?></div><div class="mover-progress"><div class="mover-progress-bar" style="width:<?= min(100, $percentage) ?>%"></div></div></td>
                                                <td class="text-end fw-semibold"><?= number_format($soldKg, 2) ?> kg</td>
                                                <td class="text-end"><?= number_format($stockKg, 2) ?> kg</td>
                                            </tr>
                                            <?php endforeach;
                                        endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TREND BREAKDOWN -->
            <div class="card modern-card mb-4 no-print">
                <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <div><div class="fw-bold">Trend Breakdown</div><div class="small"><?= htmlspecialchars($trendSubLabel) ?></div></div>
                    <form method="GET" class="d-flex align-items-center gap-2">
                        <input type="hidden" name="tab" value="overview">
                        <input type="hidden" name="from" value="<?= htmlspecialchars($fromDate) ?>">
                        <input type="hidden" name="to" value="<?= htmlspecialchars($toDate) ?>">
                        <select name="trend" class="form-select form-select-sm" onchange="this.form.submit()">
                            <option value="daily" <?= $trend === 'daily' ? 'selected' : '' ?>>Daily</option>
                            <option value="weekly" <?= $trend === 'weekly' ? 'selected' : '' ?>>Weekly</option>
                            <option value="monthly" <?= $trend === 'monthly' ? 'selected' : '' ?>>Monthly</option>
                            <option value="yearly" <?= $trend === 'yearly' ? 'selected' : '' ?>>Yearly</option>
                        </select>
                    </form>
                </div>
                <div class="card-body">
                    <div class="table-wrap">
                        <table class="table table-sm table-striped table-bordered align-middle mb-0">
                            <thead class="table-dark">
                                <tr>
                                    <th><?= htmlspecialchars($trend === 'weekly' ? 'Weekly' : ($trend === 'monthly' ? 'Month' : ($trend === 'yearly' ? 'Year' : 'Date'))) ?></th>
                                    <th class="text-end">Sales</th>
                                    <th class="text-end">Count</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if (empty($trendItems)): ?>
                                <tr><td colspan="3" class="text-center text-muted py-3">No sales data found for the selected range.</td></tr>
                            <?php else:
                                foreach ($trendItems as $row):
                                    $start = !empty($row['period_start']) ? date('M d, Y', strtotime((string)$row['period_start'])) : '-';
                                    $end = !empty($row['period_end']) ? date('M d, Y', strtotime((string)$row['period_end'])) : '-';
                                    $period = $trend === 'daily' ? $start : ($trend === 'monthly' ? date('M Y', strtotime((string)$row['period_start'])) : ($trend === 'yearly' ? date('Y', strtotime((string)$row['period_start'])) : "$start - $end"));
                            ?>
                                <tr>
                                    <td class="fw-semibold"><?= htmlspecialchars($period) ?></td>
                                    <td class="text-end fw-semibold">₱<?= number_format((float)($row['sales_total'] ?? 0), 2) ?></td>
                                    <td class="text-end"><?= number_format((int)($row['sale_count'] ?? 0)) ?></td>
                                </tr>
                                <?php endforeach;
                            endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- STOCK LEVELS -->
            <div class="row g-3 mb-4">
                <div class="col-lg-6">
                    <div class="card modern-card h-100">
                        <div class="card-header fw-bold"><i class="fa-solid fa-boxes-stacked me-2"></i> Highest Stock Levels</div>
                        <div class="card-body">
                            <div class="table-wrap">
                                <table class="table table-sm align-middle mb-0">
                                    <thead class="table-light"><tr><th>Product</th><th class="text-end">Stock(kg)</th><th>Grade / Weight</th></tr>
</thead>
<tbody>
<?php if (empty($topStockItems)): ?>
<tr><td colspan="3" class="text-center text-muted py-3">No stock data available.</td></tr>
<?php else: ?>
<?php foreach ($topStockItems as $row):
    $productName = trim(($row['variety'] ?? '') . ($row['delivery_date'] ? ' (' . date('M d, Y', strtotime($row['delivery_date'])) . ')' : '')) ?: 'Unnamed Product';
    $stockKg = (float)($row['stock_kg'] ?? 0);
    $gradeInfo = trim(($row['grade'] ?? '-') . ' / ' . number_format((float)($row['unit_weight_kg'] ?? 0), 2) . 'kg');
?>
<tr>
    <td class="fw-semibold"><?= htmlspecialchars($productName) ?></td>
    <td class="text-end fw-bold"><?= number_format($stockKg, 2) ?></td>
    <td class="text-muted small"><?= htmlspecialchars($gradeInfo) ?></td>
</tr>
<?php endforeach; ?>
<?php endif; ?>
</tbody>
</table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="card modern-card h-100">
                        <div class="card-header fw-bold"><i class="fa-solid fa-triangle-exclamation me-2"></i> Low Stock Items</div>
                        <div class="card-body">
                            <div class="table-wrap">
                                <table class="table table-sm align-middle mb-0">
                                    <thead class="table-light"><tr><th>Product</th><th class="text-end">Stock (kg)</th><th>Status</th></tr></thead>
                                    <tbody>
<?php if (empty($lowStockItems)): ?>
<tr><td colspan="3" class="text-center text-success py-3"><i class="fa-solid fa-circle-check me-1"></i> All stock levels are sufficient.</td></tr>
<?php else: ?>
<?php foreach ($lowStockItems as $row):
    $productName = trim(($row['variety'] ?? '') . ' - ' . ($row['grade'] ?? '')) ?: 'Unnamed Product';
    $stockKg = (float)($row['stock_kg'] ?? 0);
    $status = $stockKg <= 0
        ? '<span class="badge bg-danger">Out of Stock</span>'
        : '<span class="badge bg-warning text-dark">Low Stock</span>';
?>
<tr>
    <td class="fw-semibold"><?= htmlspecialchars($productName) ?></td>
    <td class="text-end fw-bold"><?= number_format($stockKg, 2) ?></td>
    <td><?= $status ?></td>
</tr>
<?php endforeach; ?>
<?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- CURRENT STOCK SUMMARY -->
            <div class="row g-3 mb-4">
                <div class="col-xl-2 col-md-4 col-6">
                    <div class="report-kpi p-3 text-center">
                        <div class="small text-muted">Active Products</div>
                        <div class="fw-bold display-6 mt-1"><?= number_format((int)$stockSummary['active_products']) ?></div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-4 col-6">
                    <div class="report-kpi p-3 text-center">
                        <div class="small text-muted">Total Stock</div>
                        <div class="fw-bold display-6 mt-1"><?= number_format((float)$stockSummary['total_stock_kg'], 0) ?><div class="small fw-normal">kg</div></div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-4 col-6">
                    <div class="report-kpi p-3 text-center">
                        <div class="small text-muted">Low Stock</div>
                        <div class="fw-bold display-6 mt-1 text-warning"><?= number_format((int)$stockSummary['low_stock_count']) ?></div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-4 col-6">
                    <div class="report-kpi p-3 text-center">
                        <div class="small text-muted">Out of Stock</div>
                        <div class="fw-bold display-6 mt-1 text-danger"><?= number_format((int)$stockSummary['out_of_stock_count']) ?></div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-4 col-6">
                    <div class="report-kpi p-3 text-center">
                        <div class="small text-muted">Overstock</div>
                        <div class="fw-bold display-6 mt-1 text-success"><?= number_format((int)$stockSummary['overstock_count']) ?></div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-4 col-6">
                    <div class="report-kpi p-3 text-center">
                        <div class="small text-muted">Transactions</div>
                        <div class="fw-bold display-6 mt-1"><?= number_format((int)$movementSummary['transaction_count']) ?></div>
                    </div>
                </div>
            </div>

            <!-- INVENTORY MOVEMENT -->
            <div class="card modern-card mb-4">
                <div class="card-header fw-bold"><i class="fa-solid fa-right-left me-2"></i> Inventory Movement</div>
                <div class="card-body">
                    <div class="row g-3 text-center">
                        <div class="col-md-3 col-6">
                            <div class="fw-bold text-success fs-4"><?= number_format((float)$movementSummary['inbound_kg'], 2) ?> kg</div>
                            <div class="small text-muted">Inbound</div>
                        </div>
                        <div class="col-md-3 col-6">
                            <div class="fw-bold text-danger fs-4"><?= number_format((float)$movementSummary['outbound_kg'], 2) ?> kg</div>
                            <div class="small text-muted">Outbound</div>
                        </div>
                        <div class="col-md-3 col-6">
                            <div class="fw-bold text-warning fs-4"><?= number_format((float)$movementSummary['adjusted_kg'], 2) ?> kg</div>
                            <div class="small text-muted">Adjusted</div>
                        </div>
                        <div class="col-md-3 col-6">
                            <div class="fw-bold fs-4"><?= number_format((float)$movementSummary['moved_kg'], 2) ?> kg</div>
                            <div class="small text-muted">Total Moved</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- RECENT TRANSACTIONS -->
            <div class="card modern-card mb-4">
                <div class="card-header fw-bold"><i class="fa-solid fa-clock-rotate-left me-2"></i> Recent Transactions</div>
                <div class="card-body">
                    <div class="table-wrap">
                        <table class="table table-sm table-striped table-bordered align-middle mb-0">
                            <thead class="table-dark">
                                <tr>
                                    <th>Date</th>
                                    <th>Product</th>
                                    <th>Batch</th>
                                    <th>Type</th>
                                    <th class="text-end">Qty (kg)</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
<?php if (empty($recentTransactions)): ?>
                                <tr><td colspan="6" class="text-center text-muted py-3">No transactions found for this period.</td></tr>
<?php else: ?>
<?php foreach ($recentTransactions as $row):
    [$badgeText, $badgeClass] = inventoryTypeBadge($row);
    $productName = trim(($row['variety'] ?? 'N/A') . ' - ' . ($row['grade'] ?? '')) ?: 'N/A';
    $batchCode = normalizeBatchCode($row['batch_code'] ?? '');
    $qty = (float)($row['qty_kg'] ?? 0);
    $notes = trim((string)($row['notes'] ?? '')) ?: '-';
    $created = !empty($row['created_at']) ? date('M d, Y H:i', strtotime((string)$row['created_at'])) : '-';
?>
                                <tr>
                                    <td class="small"><?= htmlspecialchars($created) ?></td>
                                    <td class="fw-semibold"><?= htmlspecialchars($productName) ?></td>
                                    <td class="small"><?= htmlspecialchars($batchCode) ?></td>
                                    <td><span class="badge <?= $badgeClass ?>"><?= htmlspecialchars($badgeText) ?></span></td>
                                    <td class="text-end"><?= number_format($qty, 2) ?></td>
                                    <td class="small text-muted text-truncate" style="max-width:180px;"><?= htmlspecialchars($notes) ?></td>
                                </tr>
<?php endforeach; ?>
<?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <?php elseif ($tab === 'suppliers'): ?>
            <!-- SUPPLIER REPORTS TAB CONTENT -->
            <div class="row g-3 mb-4">
                <div class="col-md-3 col-6">
                    <div class="report-kpi p-3 text-center">
                        <div class="small text-muted">Purchases</div>
                        <div class="fw-bold display-6 mt-1"><?= number_format((int)$supplierPurchaseSummary['purchase_count']) ?></div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="report-kpi p-3 text-center">
                        <div class="small text-muted">Total Amount</div>
                        <div class="fw-bold display-6 mt-1">₱<?= number_format((float)$supplierPurchaseSummary['total_amount'], 0) ?></div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="report-kpi p-3 text-center">
                        <div class="small text-muted">Total Sacks</div>
                        <div class="fw-bold display-6 mt-1"><?= number_format((int)$supplierPurchaseSummary['total_qty_sacks']) ?></div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="report-kpi p-3 text-center">
                        <div class="small text-muted">Suppliers</div>
                        <div class="fw-bold display-6 mt-1"><?= number_format((int)$supplierPurchaseSummary['supplier_count']) ?></div>
                    </div>
                </div>
            </div>

            <!-- TOP SUPPLIERS -->
            <div class="card modern-card mb-4">
                <div class="card-header fw-bold"><i class="fa-solid fa-ranking-star me-2"></i> Top Suppliers by Purchase Value</div>
                <div class="card-body">
                    <div class="table-wrap">
                        <table class="table table-sm table-striped table-bordered align-middle mb-0">
                            <thead class="table-dark">
                                <tr>
                                    <th>Supplier</th>
                                    <th class="text-end">Purchases</th>
                                    <th class="text-end">Total Value</th>
                                    <th>Last Purchase</th>
                                </tr>
                            </thead>
                            <tbody>
<?php if (empty($supplierTopList)): ?>
                                <tr><td colspan="4" class="text-center text-muted py-3">No supplier purchase records found.</td></tr>
<?php else: ?>
<?php foreach ($supplierTopList as $row):
    $supplierName = htmlspecialchars($row['supplier_name'] ?? 'N/A');
    $lastDate = !empty($row['last_purchase']) ? date('M d, Y', strtotime((string)$row['last_purchase'])) : '-';
?>
                                <tr>
                                    <td class="fw-semibold"><?= $supplierName ?></td>
                                    <td class="text-end"><?= number_format((int)$row['purchase_count']) ?></td>
                                    <td class="text-end fw-bold">₱<?= number_format((float)$row['total_amount'], 2) ?></td>
                                    <td class="small"><?= $lastDate ?></td>
                                </tr>
<?php endforeach; ?>
<?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- PURCHASE HISTORY -->
            <div class="card modern-card">
                <div class="card-header fw-bold"><i class="fa-solid fa-clock-rotate-left me-2"></i> Purchase History</div>
                <div class="card-body">
                    <div class="table-wrap">
                        <table class="table table-sm table-striped table-bordered align-middle mb-0">
                            <thead class="table-dark">
                                <tr>
                                    <th>Date</th>
                                    <th>Supplier</th>
                                    <th class="text-end">Sacks</th>
                                    <th class="text-end">Amount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
<?php if (empty($supplierPurchaseHistory)): ?>
                                <tr><td colspan="5" class="text-center text-muted py-3">No approved purchases in this date range.</td></tr>
<?php else: ?>
<?php foreach ($supplierPurchaseHistory as $row):
    $pDate = !empty($row['purchase_date']) ? date('M d, Y', strtotime((string)$row['purchase_date'])) : '-';
    $supplierName = htmlspecialchars($row['supplier_name'] ?? 'N/A');
    $status = strtolower($row['status'] ?? '');
    $statusClass = match(true) {
        $status==='received' => 'status-received',
        $status==='pending' || $status==='approved' => 'status-pending',
        default => 'status-default'
    };
?>
                                <tr>
                                    <td class="small"><?= $pDate ?></td>
                                    <td class="fw-semibold"><?= $supplierName ?></td>
                                    <td class="text-end"><?= number_format((int)$row['total_sacks']) ?></td>
                                    <td class="text-end fw-bold">₱<?= number_format((float)$row['total_amount'], 2) ?></td>
                                    <td><span class="badge <?= $statusClass ?>"><?= htmlspecialchars(ucwords($status)) ?></span></td>
                                </tr>
<?php endforeach; ?>
<?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <?php elseif ($tab === 'purchasereport'): ?>
            <!-- PURCHASE REPORT TAB CONTENT -->
            <div class="row g-3 mb-4">
                <div class="col-md-3 col-6">
                    <div class="report-kpi p-3 text-center">
                        <div class="small text-muted">Total POs</div>
                        <div class="fw-bold display-6 mt-1"><?= number_format((int)$purchaseReportSummary['total_po']) ?></div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="report-kpi p-3 text-center">
                        <div class="small text-muted">Total Amount</div>
                        <div class="fw-bold display-6 mt-1">₱<?= number_format((float)$purchaseReportSummary['total_amount'], 0) ?></div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="report-kpi p-3 text-center">
                        <div class="small text-muted">Total Sacks</div>
                        <div class="fw-bold display-6 mt-1"><?= number_format((int)$purchaseReportSummary['total_sacks']) ?></div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="report-kpi p-3 text-center">
                        <div class="small text-muted">Avg PO Amount</div>
                        <div class="fw-bold display-6 mt-1">₱<?= number_format((float)$purchaseReportSummary['avg_po_amount'], 0) ?></div>
                    </div>
                </div>
            </div>

            <div class="card modern-card">
                <div class="card-header fw-bold"><i class="fa-solid fa-file-invoice me-2"></i> Purchase Report Detail</div>
                <div class="card-body">
                    <div class="table-wrap">
                        <table class="table table-sm table-striped table-bordered align-middle mb-0">
                            <thead class="table-dark">
                                <tr>
                                    <th>PO #</th>
                                    <th>Date</th>
                                    <th>Supplier</th>
                                    <th class="text-end">Items</th>
                                    <th class="text-end">Sacks</th>
                                    <th class="text-end">Amount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
<?php if (empty($purchaseReportItems)): ?>
                                <tr><td colspan="7" class="text-center text-muted py-3">No purchase orders found in selected range.</td></tr>
<?php else: ?>
<?php foreach ($purchaseReportItems as $row):
    $poDate = !empty($row['purchase_date']) ? date('M d, Y', strtotime((string)$row['purchase_date'])) : '-';
    $supplierName = htmlspecialchars($row['supplier_name'] ?? 'N/A');
    $status = strtolower($row['status'] ?? '');
    $statusClass = match(true) {
        $status==='received' => 'status-received',
        $status==='pending' || $status==='approved' => 'status-pending',
        default => 'status-default'
    };
?>
                                <tr>
                                    <td class="fw-semibold">#<?= $row['purchases_id'] ?></td>
                                    <td class="small"><?= $poDate ?></td>
                                    <td><?= $supplierName ?></td>
                                    <td class="text-end"><?= number_format((int)$row['item_count']) ?></td>
                                    <td class="text-end"><?= number_format((int)$row['total_sacks']) ?></td>
                                    <td class="text-end fw-bold">₱<?= number_format((float)$row['total_amount'], 2) ?></td>
                                    <td><span class="badge <?= $statusClass ?>"><?= htmlspecialchars(ucwords($status)) ?></span></td>
                                </tr>
<?php endforeach; ?>
<?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <?php endif; ?>

        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>