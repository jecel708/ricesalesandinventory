<?php
declare(strict_types=1);

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

if (strtolower($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: ../login.php");
    exit;
}

include "../config/db.php";
require_once __DIR__ . '/../includes/receivable_penalty.php';
ensurePenaltyPaymentColumn($conn);

$username = $_SESSION['username'] ?? 'Admin';
$admin_id = (int)($_SESSION['user_id'] ?? 0);

$success = "";
$error   = "";

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}
$csrf_token = (string)$_SESSION['csrf_token'];

function h($v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function f($v): float {
    return (float)($v ?? 0);
}

function qs(array $params): string {
    return http_build_query($params);
}

/*
|--------------------------------------------------------------------------
| Handle Waiver Request
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['waive_penalty'])) {
    $posted_token = (string)($_POST['csrf_token'] ?? '');
    if ($posted_token === '' || !hash_equals($csrf_token, $posted_token)) {
        $error = "Invalid request. Please refresh the page and try again.";
    } else {
        $ar_id  = (int)($_POST['id'] ?? 0);
        $reason = trim((string)($_POST['reason'] ?? ''));

        if ($ar_id <= 0) {
            $error = "Invalid reference ID.";
        } elseif ($reason === '') {
            $error = "Reason is required.";
        } else {
            $conn->begin_transaction();

            try {
                // Confirm that the submitted reference still has a penalty due.
                $arCheck = $conn->prepare("
                    SELECT ar.ar_id, ar.sales_id, ar.balance,
                        (" . receivablePenaltyOutstandingSql() . ") AS penalty_due
                    FROM account_receivable ar
                    LEFT JOIN penalties p
                      ON p.reference_id = ar.ar_id AND p.reference_type = 'receivable'
                    WHERE ar.ar_id = ?
                      AND (" . receivablePenaltyOutstandingSql() . ") > 0
                    LIMIT 1
                    FOR UPDATE
                ");
                if (!$arCheck) {
                    throw new Exception("Unable to validate the receivable: " . $conn->error);
                }
                $arCheck->bind_param("i", $ar_id);
                if (!$arCheck->execute()) {
                    throw new Exception("Unable to validate the receivable: " . $arCheck->error);
                }
                $arResult = $arCheck->get_result();
                $arRecord = $arResult ? $arResult->fetch_assoc() : null;
                $arCheck->close();
                if (!$arRecord) {
                    throw new Exception("The selected receivable is no longer available for waiver.");
                }

                // Check if penalty row already exists.
            $check = $conn->prepare("
                SELECT penalty_id
                FROM penalties
                WHERE reference_id = ?
                  AND reference_type = 'receivable'
                LIMIT 1
            ");
            if (!$check) {
                throw new Exception($conn->error);
            }
                $check->bind_param("i", $ar_id);
                if (!$check->execute()) {
                    throw new Exception("Unable to check the existing penalty: " . $check->error);
                }
                $res = $check->get_result();
                $existing = $res ? $res->fetch_assoc() : null;
                $check->close();

                if ($existing) {
                $penaltyId = (int)$existing['penalty_id'];

                $upd = $conn->prepare("
                    UPDATE penalties
                    SET waived_amount = IFNULL(waived_amount,0)
                            + GREATEST(penalty_amount - IFNULL(amount_paid,0) - IFNULL(waived_amount,0),0),
                        days_late = 0,
                        last_calculated = NOW()
                    WHERE penalty_id = ?
                ");
                if (!$upd) {
                    throw new Exception($conn->error);
                }

                    $upd->bind_param("i", $penaltyId);
                    if (!$upd->execute()) {
                        throw new Exception("Unable to waive the existing penalty: " . $upd->error);
                    }
                    $upd->close();
                } else {
                    // Insert a waived penalty record if none exists yet.
                    $ins = $conn->prepare("
                    INSERT INTO penalties (
                        reference_id,
                        reference_type,
                        penalty_amount,
                        waived_amount,
                        days_late,
                        last_calculated
                    ) VALUES (?, 'receivable', ?, ?, 0, NOW())
                    ");
                    if (!$ins) {
                        throw new Exception("Unable to create the waiver penalty record: " . $conn->error);
                    }

                    $penaltyDue = (float)$arRecord['penalty_due'];
                    $waivedAmount = $penaltyDue;
                    $ins->bind_param("idd", $ar_id, $penaltyDue, $waivedAmount);
                    if (!$ins->execute()) {
                        throw new Exception("Unable to create the waiver penalty record: " . $ins->error);
                    }
                    $ins->close();
                }

                if ((float)$arRecord['balance'] <= 0.00001) {
                    $paidAr = $conn->prepare("UPDATE account_receivable SET status='paid' WHERE ar_id=?");
                    if (!$paidAr) {
                        throw new Exception("Unable to clear the receivable status: " . $conn->error);
                    }
                    $paidAr->bind_param("i", $ar_id);
                    if (!$paidAr->execute()) {
                        throw new Exception("Unable to clear the receivable status: " . $paidAr->error);
                    }
                    $paidAr->close();

                    $saleId = (int)($arRecord['sales_id'] ?? 0);
                    if ($saleId > 0) {
                        $paidSale = $conn->prepare("UPDATE sales SET status='paid' WHERE sale_id=?");
                        if (!$paidSale) {
                            throw new Exception("Unable to clear the sale status: " . $conn->error);
                        }
                        $paidSale->bind_param("i", $saleId);
                        if (!$paidSale->execute()) {
                            throw new Exception("Unable to clear the sale status: " . $paidSale->error);
                        }
                        $paidSale->close();
                    }
                }

            // Insert waiver history
            $waive = $conn->prepare("
                INSERT INTO penalty_waivers (
                    reference_id,
                    reference_type,
                    waived_by,
                    reason,
                    waived_date
                ) VALUES (?, 'receivable', ?, ?, NOW())
            ");
                if (!$waive) {
                    throw new Exception("Unable to prepare waiver history: " . $conn->error);
                }

                $waive->bind_param("iis", $ar_id, $admin_id, $reason);
                if (!$waive->execute()) {
                    throw new Exception("Unable to save waiver history: " . $waive->error);
                }
                $waive->close();

            $conn->commit();
            $success = "Penalty waived successfully.";

            // Keep audit logging separate so it cannot undo a completed waiver.
            $activityType = 'Penalty Waiver';
            $description  = "Waived penalty for AR #{$ar_id}. Reason: {$reason}";
            $logStmt = $conn->prepare("
                INSERT INTO activity_logs (user_id, activity_type, description, created_at)
                VALUES (?, ?, ?, NOW())
            ");
            if ($logStmt) {
                $logStmt->bind_param("iss", $admin_id, $activityType, $description);
                if (!$logStmt->execute()) {
                    error_log("Penalty waiver activity log failed: " . $logStmt->error);
                }
                $logStmt->close();
            } else {
                error_log("Penalty waiver activity log prepare failed: " . $conn->error);
            }
            } catch (Throwable $e) {
                $conn->rollback();
                $error = "Failed to waive penalty: " . $e->getMessage();
            }
        }
    }
}

/*
|--------------------------------------------------------------------------
| Filters / Search / Pagination
|--------------------------------------------------------------------------
*/
$filter = strtolower(trim($_GET['filter'] ?? 'all'));
$search = trim($_GET['q'] ?? '');
$page   = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset  = ($page - 1) * $perPage;

if (!in_array($filter, ['all', 'active', 'waived'], true)) {
    $filter = 'all';
}

/*
|--------------------------------------------------------------------------
| Search SQL (prepared)
|--------------------------------------------------------------------------
*/
$searchSql = '';
$searchParams = [];
$searchTypes = '';
if ($search !== '') {
    $searchSql = " AND (
        c.first_name LIKE ?
        OR c.last_name LIKE ?
        OR CONCAT(IFNULL(c.first_name,''), ' ', IFNULL(c.last_name,'')) LIKE ?
        OR c.phone LIKE ?
        OR c.address LIKE ?
    )";
    $like = "%{$search}%";
    $searchParams = [$like, $like, $like, $like, $like];
    $searchTypes = 'sssss';
}

/*
|--------------------------------------------------------------------------
| Penalty Expressions
|--------------------------------------------------------------------------
*/
$effectivePenaltyExpr = receivablePenaltyOutstandingSql();

$daysLateExpr = "
    CASE
        WHEN p.penalty_id IS NOT NULL THEN p.days_late
        WHEN ar.status <> 'paid' AND ar.due_date < CURDATE()
            THEN 1
        ELSE 0
    END
";

/*
|--------------------------------------------------------------------------
| WHERE SQL
|--------------------------------------------------------------------------
*/
$whereSql = $filter === 'waived'
    ? " WHERE 1=1 {$searchSql} "
    : " WHERE (ar.balance > 0 OR ({$effectivePenaltyExpr}) > 0) {$searchSql} ";

if ($filter === 'active') {
    $whereSql .= " AND ({$effectivePenaltyExpr}) > 0 ";
} elseif ($filter === 'waived') {
    $whereSql .= " AND p.penalty_id IS NOT NULL AND (p.penalty_amount = 0 OR (IFNULL(p.waived_amount,0) > 0 AND p.penalty_amount <= IFNULL(p.amount_paid,0) + IFNULL(p.waived_amount,0))) ";
}

/*
|--------------------------------------------------------------------------
| Count Query
|--------------------------------------------------------------------------
*/
$countSql = "
    SELECT COUNT(*) AS cnt
    FROM account_receivable ar
    LEFT JOIN customers c
        ON ar.customer_id = c.customer_id
    LEFT JOIN penalties p
        ON p.reference_id = ar.ar_id
       AND p.reference_type = 'receivable'
    {$whereSql}
";

$countStmt = $conn->prepare($countSql);
if (!$countStmt) {
    die("COUNT QUERY PREP ERROR: " . $conn->error);
}
if (!empty($searchParams)) {
    $countStmt->bind_param($searchTypes, ...$searchParams);
}
if (!$countStmt->execute()) {
    die("COUNT QUERY EXEC ERROR: " . $countStmt->error);
}
$countRes = $countStmt->get_result();
$totalRows = (int)(($countRes ? $countRes->fetch_assoc()['cnt'] : 0) ?? 0);
$countStmt->close();
$totalPages = max(1, (int)ceil($totalRows / $perPage));

if ($page > $totalPages) {
    $page = $totalPages;
    $offset = ($page - 1) * $perPage;
}

/*
|--------------------------------------------------------------------------
| List Query
|--------------------------------------------------------------------------
*/
$listSql = "
    SELECT
        ar.ar_id,
        ar.balance AS ar_balance,
        ar.due_date AS ar_due,
        ar.status AS ar_status,
        c.customer_id,
        CONCAT(IFNULL(c.first_name,''), ' ', IFNULL(c.last_name,'')) AS customer_name,
        c.first_name,
        c.last_name,
        p.penalty_id,
        p.penalty_amount AS stored_penalty_amount,
        p.amount_paid AS penalty_paid,
        p.waived_amount,
        p.days_late AS stored_days_late,
        p.last_calculated,
        {$daysLateExpr} AS effective_days_late,
        {$effectivePenaltyExpr} AS effective_penalty_amount
    FROM account_receivable ar
    LEFT JOIN customers c
        ON ar.customer_id = c.customer_id
    LEFT JOIN penalties p
        ON p.reference_id = ar.ar_id
       AND p.reference_type = 'receivable'
    {$whereSql}
    ORDER BY effective_penalty_amount DESC, ar.due_date ASC, ar.ar_id DESC
    LIMIT {$perPage} OFFSET {$offset}
";

$listRows = [];
$listStmt = $conn->prepare($listSql);
if (!$listStmt) {
    die("LIST QUERY PREP ERROR: " . $conn->error);
}
if (!empty($searchParams)) {
    $listStmt->bind_param($searchTypes, ...$searchParams);
}
if (!$listStmt->execute()) {
    die("LIST QUERY EXEC ERROR: " . $listStmt->error);
}
$listRes = $listStmt->get_result();
if ($listRes) {
    while ($row = $listRes->fetch_assoc()) {
        $listRows[] = $row;
    }
}
$listStmt->close();

/*
|--------------------------------------------------------------------------
| Stats Query
|--------------------------------------------------------------------------
*/
$statsSql = "
    SELECT
        COUNT(*) AS total_penalized,
        SUM(CASE WHEN ({$effectivePenaltyExpr}) > 0 THEN 1 ELSE 0 END) AS active,
        SUM(CASE WHEN p.penalty_id IS NOT NULL AND (p.penalty_amount = 0 OR (IFNULL(p.waived_amount,0) > 0 AND p.penalty_amount <= IFNULL(p.amount_paid,0) + IFNULL(p.waived_amount,0))) THEN 1 ELSE 0 END) AS waived,
        SUM(CASE WHEN ({$effectivePenaltyExpr}) > 0 THEN ({$effectivePenaltyExpr}) ELSE 0 END) AS total_active_amount,
        AVG(CASE WHEN ({$effectivePenaltyExpr}) > 0 THEN ({$effectivePenaltyExpr}) ELSE NULL END) AS avg_penalty
    FROM account_receivable ar
    LEFT JOIN penalties p
        ON p.reference_id = ar.ar_id
       AND p.reference_type = 'receivable'
    WHERE (
        ar.balance > 0
        OR ({$effectivePenaltyExpr}) > 0
        OR (p.penalty_id IS NOT NULL AND (p.penalty_amount = 0 OR IFNULL(p.waived_amount,0) > 0))
    )
";

$statsRes = $conn->query($statsSql);
if (!$statsRes) {
    die("STATS QUERY ERROR: " . $conn->error . "<br><pre>{$statsSql}</pre>");
}

$stats = $statsRes->fetch_assoc() ?: [
    'total_penalized' => 0,
    'active' => 0,
    'waived' => 0,
    'total_active_amount' => 0,
    'avg_penalty' => 0
];

/*
|--------------------------------------------------------------------------
| Waiver History
|--------------------------------------------------------------------------
*/
$waiverRows = [];

$waiverSql = "
    SELECT
        pw.reference_id,
        pw.reason,
        pw.waived_date,
        u.username,
        TRIM(CONCAT(IFNULL(u.first_name, ''), ' ', IFNULL(u.last_name, ''))) AS name
    FROM penalty_waivers pw
    LEFT JOIN users u
        ON pw.waived_by = u.user_id
    WHERE pw.reference_type = 'receivable'
    ORDER BY pw.waived_date DESC
    LIMIT 20
";

$waiverRes = $conn->query($waiverSql);
if ($waiverRes) {
    while ($row = $waiverRes->fetch_assoc()) {
        $waiverRows[] = $row;
    }
}

$baseParams = [
    'filter' => $filter,
    'q'      => $search,
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penalty Management | DE ORO HIYS</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <link href="../css/layout.css" rel="stylesheet">
    <link href="../css/admin-mobile.css" rel="stylesheet">
    <link href="../css/admin-penalties.css" rel="stylesheet">
</head>
<body>

<?php
$profileLink = 'profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>

<div class="container-fluid">
<div class="row">

<?php include '../includes/admin_sidebar.php'; ?>

<main class="col-lg-10 ms-sm-auto px-4 main-content">
<div class="py-4"></div>

<?php if ($success): ?>
    <div class="alert alert-success"><?= h($success) ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
    <div>
        <h3 class="fw-bold mb-1">Penalty Management</h3>
        <div class="text-muted">Monitor and waive penalties for overdue accounts</div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-12 col-md-6 col-xl-3">
        <div class="card modern-card card-kpi p-3">
            <div class="d-flex align-items-start justify-content-between gap-3">
                <div>
                    <div class="kpi-label">Total Penalized</div>
                    <div class="kpi-value"><?= (int)($stats['total_penalized'] ?? 0) ?></div>
                    <div class="kpi-sub">AR records with balances</div>
                </div>
                <span class="kpi-icon"><i class="fa-solid fa-file-invoice"></i></span>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-6 col-xl-3">
        <div class="card modern-card card-kpi p-3">
            <div class="d-flex align-items-start justify-content-between gap-3">
                <div>
                    <div class="kpi-label">Active Penalties</div>
                    <div class="kpi-value"><?= (int)($stats['active'] ?? 0) ?></div>
                    <div class="kpi-sub">Outstanding penalties</div>
                </div>
                <span class="kpi-icon"><i class="fa-solid fa-triangle-exclamation"></i></span>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-6 col-xl-3">
        <div class="card modern-card card-kpi p-3">
            <div class="d-flex align-items-start justify-content-between gap-3">
                <div>
                    <div class="kpi-label">Total Penalty Amount</div>
                    <div class="kpi-value">₱<?= number_format(f($stats['total_active_amount'] ?? 0), 2) ?></div>
                    <div class="kpi-sub">All active penalties</div>
                </div>
                <span class="kpi-icon"><i class="fa-solid fa-peso-sign"></i></span>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-6 col-xl-3">
        <div class="card modern-card card-kpi p-3">
            <div class="d-flex align-items-start justify-content-between gap-3">
                <div>
                    <div class="kpi-label">Average Penalty</div>
                    <div class="kpi-value">₱<?= number_format(f($stats['avg_penalty'] ?? 0), 2) ?></div>
                    <div class="kpi-sub">Per account</div>
                </div>
                <span class="kpi-icon"><i class="fa-solid fa-chart-line"></i></span>
            </div>
        </div>
    </div>
</div>

<div class="card modern-card mb-3">
    <div class="card-body">
        <form class="row g-2 align-items-end" method="GET">
            <div class="col-12 col-md-6">
                <label class="form-label">Status</label>
                <select class="form-select" name="filter" onchange="this.form.submit()">
                    <option value="all" <?= $filter === 'all' ? 'selected' : '' ?>>All</option>
                    <option value="active" <?= $filter === 'active' ? 'selected' : '' ?>>Active Only</option>
                    <option value="waived" <?= $filter === 'waived' ? 'selected' : '' ?>>Waived Only</option>
                </select>
            </div>
            <div class="col-12 col-md-6">
                <label class="form-label">Search Customer</label>
                <input type="text" class="form-control" name="q" value="<?= h($search) ?>" placeholder="Customer name...">
            </div>
            <div class="col-12 d-flex gap-2">
                <button class="btn btn-primary" type="submit"><i class="fa-solid fa-magnifying-glass me-2"></i>Search</button>
                <a class="btn btn-outline-dark" href="penalties.php"><i class="fa-solid fa-rotate-left me-2"></i>Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="card modern-card mb-4">
    <div class="card-body table-responsive">
        <table class="table table-striped table-bordered mb-0 align-middle penalties-table">
            <thead class="table-dark">
                <tr>
                    <th>AR Ref</th>
                    <th>Customer Name</th>
                    <th class="text-end">
                        <div class="th-wrap">
                            <span class="th-title">Balance</span>
                            <span class="th-sub">(₱)</span>
                        </div>
                    </th>
                    <th class="text-center">
                        <div class="th-wrap">
                            <span class="th-title">Days Late</span>
                            <span class="th-sub">(days)</span>
                        </div>
                    </th>
                    <th class="text-end">
                        <div class="th-wrap">
                            <span class="th-title">Penalty</span>
                            <span class="th-sub">(₱)</span>
                        </div>
                    </th>
                    <th>Due Date</th>
                    <th>Last Calc</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($listRows) > 0): ?>
                    <?php foreach ($listRows as $row): ?>
                        <?php
                            $arId = (int)($row['ar_id'] ?? 0);
                            $name = trim((string)($row['customer_name'] ?? ''));
                            if ($name === '') {
                                $name = 'N/A';
                            }

                            $balance = f($row['ar_balance'] ?? 0);
                            $daysLate = (int)($row['effective_days_late'] ?? 0);
                            $penalty = f($row['effective_penalty_amount'] ?? 0);
                            $dueDate = $row['ar_due'] ?? null;
                            $lastCalc = $row['last_calculated'] ?? null;
                            $isWaived = ((int)($row['penalty_id'] ?? 0) > 0)
                                && (f($row['stored_penalty_amount'] ?? 0) == 0.0
                                    || (f($row['waived_amount'] ?? 0) > 0
                                        && f($row['stored_penalty_amount'] ?? 0)
                                            <= f($row['penalty_paid'] ?? 0) + f($row['waived_amount'] ?? 0)));
                        ?>
                        <tr>
                            <td class="fw-bold">#<?= $arId ?></td>
                            <td><?= h($name) ?></td>
                            <td class="text-end">₱<?= number_format($balance, 2) ?></td>
                            <td class="text-center">
                                <?php if ($daysLate > 0): ?>
                                    <span class="badge bg-warning text-dark"><?= $daysLate ?> days</span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <?php if ($penalty > 0): ?>
                                    <span class="badge bg-danger">₱<?= number_format($penalty, 2) ?></span>
                                <?php elseif ($isWaived): ?>
                                    <span class="badge bg-success">Waived</span>
                                <?php else: ?>
                                    <span class="text-muted">₱0.00</span>
                                <?php endif; ?>
                            </td>
                            <td><?= !empty($dueDate) ? date('M d, Y', strtotime((string)$dueDate)) : '-' ?></td>
                            <td><?= !empty($lastCalc) ? date('M d, Y', strtotime((string)$lastCalc)) : '-' ?></td>
                            <td>
                                <?php if ($penalty > 0): ?>
                                    <button
                                        type="button"
                                        class="btn btn-sm btn-warning btn-waive"
                                        data-bs-toggle="modal"
                                        data-bs-target="#waiverModal"
                                        data-id="<?= $arId ?>"
                                        data-name="<?= h($name) ?>"
                                        data-penalty="<?= number_format($penalty, 2) ?>"
                                    >
                                        <i class="fa-solid fa-ban me-1"></i>Waive
                                    </button>
                                <?php else: ?>
                                    <span class="text-muted small">No action</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted py-4">No penalties found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="card-footer bg-white d-flex flex-wrap justify-content-between align-items-center gap-2">
        <div class="small text-muted">
            <?php if ($totalRows > 0): ?>
                Showing <?= $offset + 1 ?>–<?= min($totalRows, $offset + $perPage) ?> of <?= $totalRows ?> results
            <?php else: ?>
                Showing 0 results
            <?php endif; ?>
        </div>

        <?php if ($totalPages > 1): ?>
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php $prev = $baseParams; $prev['page'] = max(1, $page - 1); ?>
                    <?php $next = $baseParams; $next['page'] = min($totalPages, $page + 1); ?>

                    <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                        <a class="page-link" href="?<?= h(qs($prev)) ?>">Prev</a>
                    </li>

                    <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                        <?php $p = $baseParams; $p['page'] = $i; ?>
                        <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                            <a class="page-link" href="?<?= h(qs($p)) ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>

                    <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                        <a class="page-link" href="?<?= h(qs($next)) ?>">Next</a>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>
    </div>
</div>

<div class="card modern-card">
    <div class="card-header">
        <h5 class="mb-0"><i class="fa-solid fa-history me-2"></i>Recent Waivers</h5>
    </div>
    <div class="card-body table-responsive">
        <table class="table table-sm table-striped mb-0">
            <thead class="table-light">
                <tr>
                    <th>AR Ref #</th>
                    <th>Waived By</th>
                    <th>Reason</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($waiverRows)): ?>
                    <?php foreach ($waiverRows as $w): ?>
                        <tr>
                            <td><strong>#<?= (int)($w['reference_id'] ?? 0) ?></strong></td>
                            <td><?= h($w['username'] ?? $w['name'] ?? 'System') ?></td>
                            <td><?= h($w['reason'] ?? '-') ?></td>
                            <td><?= !empty($w['waived_date']) ? date('M d, Y H:i', strtotime((string)$w['waived_date'])) : '-' ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" class="text-center text-muted py-2">No waivers recorded yet.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</main>
</div>
</div>

<div class="modal fade" id="waiverModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Waive Penalty</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
                <div class="modal-body">
                    <p class="mb-3">
                        <strong id="waiverCustomerName">Customer</strong><br>
                        Penalty: <strong>₱<span id="waiverPenaltyAmount">0.00</span></strong>
                    </p>

                    <input type="hidden" name="waive_penalty" value="1">
                    <input type="hidden" name="id" id="waiverReferenceId" value="">

                    <div class="mb-3">
                        <label class="form-label">Reason for Waiver</label>
                        <textarea class="form-control" name="reason" rows="3" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">
                        <i class="fa-solid fa-ban me-1"></i>Confirm Waiver
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('click', function (event) {
    const btn = event.target.closest('.btn-waive');
    if (!btn) return;

    const refInput = document.getElementById('waiverReferenceId');
    const nameEl = document.getElementById('waiverCustomerName');
    const penaltyEl = document.getElementById('waiverPenaltyAmount');

    if (refInput) refInput.value = btn.getAttribute('data-id') || '';
    if (nameEl) nameEl.textContent = btn.getAttribute('data-name') || 'Customer';
    if (penaltyEl) penaltyEl.textContent = btn.getAttribute('data-penalty') || '0.00';

    const textarea = document.querySelector('#waiverModal textarea[name="reason"]');
    if (textarea) textarea.value = '';
});
</script>
<script>
(function () {
  const pollIntervalMs = 5000;
  let pollingInFlight = false;
  async function pollLiveMain() {
    if (pollingInFlight) return;
    pollingInFlight = true;
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('_live', Date.now().toString());
      const response = await fetch(url.toString(), { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const sourceMain = doc.querySelector('main');
      const targetMain = document.querySelector('main');
      if (sourceMain && targetMain) targetMain.innerHTML = sourceMain.innerHTML;
    } catch (error) {
      console.error('Penalties live poll failed:', error);
    } finally {
      pollingInFlight = false;
    }
  }
  pollLiveMain();
  window.setInterval(pollLiveMain, pollIntervalMs);
})();
</script>

</body>
</html>
