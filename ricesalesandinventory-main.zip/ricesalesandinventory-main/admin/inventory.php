<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit;
}
if(strtolower($_SESSION['role'] ?? '') !== 'admin'){
    header("Location: ../login.php");
    exit;
}

$username = $_SESSION['username'] ?? 'User';
$user_id  = (int)($_SESSION['user_id'] ?? 0);
$activePage = 'inventory';

include '../config/db.php';

function normalizeBatchCode(string $code): string {
    $code = trim($code);
    if ($code === '') {
        return '';
    }
    if (preg_match('/^LEGACY-(\d+)$/i', $code, $matches)) {
        return 'Batch ' . $matches[1];
    }
    return $code;
}

// --- Handle Approve Return ---
if(isset($_POST['approve_return'])) {
    $return_id = (int)($_POST['return_id'] ?? 0);

    // Get return details
    $stmt = $conn->prepare("SELECT return_id, sale_id, product_id, qty_returned, status FROM returns WHERE return_id = ?");
    $stmt->bind_param("i", $return_id);
    $stmt->execute();
    $ret = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if(!$ret){
        $message = "Return not found.";
    } else {
        $product_id    = (int)$ret['product_id'];
        $sale_id       = (int)$ret['sale_id'];
        $qty_returned  = (float)$ret['qty_returned'];

        // Use transaction so stock update + log always match
        $conn->begin_transaction();
        try {
            // Update return status (pending/approved/rejected)
            $stmt = $conn->prepare("UPDATE returns SET status='approved' WHERE return_id=?");
            $stmt->bind_param("i", $return_id);
            $stmt->execute();
            $stmt->close();

            // Update stock
            $stmt = $conn->prepare("UPDATE products SET stock_kg = stock_kg + ? WHERE product_id = ?");
            $stmt->bind_param("di", $qty_returned, $product_id);
            $stmt->execute();
            $stmt->close();

            $returnBatch = null;
            $stmt = $conn->prepare("
                SELECT batch_id, regular_kg, discount_kg
                FROM sales_items
                WHERE sale_id = ? AND product_id = ? AND batch_id IS NOT NULL
                ORDER BY sales_item_id ASC
                LIMIT 1
            ");
            if($stmt){
                $stmt->bind_param("ii", $sale_id, $product_id);
                $stmt->execute();
                $returnBatch = $stmt->get_result()->fetch_assoc();
                $stmt->close();
            }

            $batch_id = (int)($returnBatch['batch_id'] ?? 0);
            if($batch_id > 0){
                $soldDiscount = (float)($returnBatch['discount_kg'] ?? 0);
                if($soldDiscount > 0){
                    $stmt = $conn->prepare("
                        UPDATE stock_batches
                        SET discounted_qty_kg = discounted_qty_kg + ?,
                            remaining_qty_kg = remaining_qty_kg + ?,
                            updated_at = NOW()
                        WHERE batch_id = ? AND product_id = ?
                    ");
                    if($stmt){
                        $stmt->bind_param("ddii", $qty_returned, $qty_returned, $batch_id, $product_id);
                        $stmt->execute();
                        $stmt->close();
                    }

                    $stmt = $conn->prepare("
                        INSERT INTO product_discount_stock (product_id, qty_kg, price_per_kg, updated_at)
                        SELECT product_id, ?, IFNULL(discounted_price_per_kg, 0), NOW()
                        FROM stock_batches
                        WHERE batch_id = ?
                        ON DUPLICATE KEY UPDATE qty_kg = qty_kg + VALUES(qty_kg), updated_at = NOW()
                    ");
                    if($stmt){
                        $stmt->bind_param("di", $qty_returned, $batch_id);
                        $stmt->execute();
                        $stmt->close();
                    }
                } else {
                    $stmt = $conn->prepare("
                        UPDATE stock_batches
                        SET regular_qty_kg = regular_qty_kg + ?,
                            remaining_qty_kg = remaining_qty_kg + ?,
                            updated_at = NOW()
                        WHERE batch_id = ? AND product_id = ?
                    ");
                    if($stmt){
                        $stmt->bind_param("ddii", $qty_returned, $qty_returned, $batch_id, $product_id);
                        $stmt->execute();
                        $stmt->close();
                    }
                }
            }

            // Log inventory transaction
            $reference_type = "return";
            $type = "in";
            $note = "Customer return approved";

            $stmt = $conn->prepare("
                INSERT INTO inventory_transactions
                    (product_id, batch_id, qty_kg, reference_id, reference_type, type, note, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->bind_param("iidisss", $product_id, $batch_id, $qty_returned, $return_id, $reference_type, $type, $note);
            $stmt->execute();
            $stmt->close();

            $conn->commit();
            $message = "Return approved and stock updated!";
        } catch (Exception $e) {
            $conn->rollback();
            $message = "Failed to approve return: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Stock Logs | DE ORO HIYS</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="../css/inventory-stock-logs.css" rel="stylesheet">
<link href="../css/inventory-mobile.css" rel="stylesheet">
</head>
<body>

<?php
$profileLink = '../admin/profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>

<div class="container-fluid">
<div class="row">

<?php
$adminBase = '../admin/';
$inventoryBase = '../admin/';
$ownerBase = '../owner/';
include '../includes/admin_sidebar.php';
?>

<main class="col-lg-10 ms-auto main-content">
<div class="container-fluid py-4">

<h3 class="mb-4 legacy-page-title">Inventory Reports Logs</h3>

<?php if(isset($message)): ?>
<div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<?php
$sql = "
SELECT 
    it.*,
    p.variety,
    p.grade,
    sb.batch_code,

    r.return_id,
    r.status AS return_status,

    sa.sale_id,
    c.first_name,
    c.last_name,

    sa_r.sale_id AS return_sale_id,
    c_r.first_name AS return_first_name,
    c_r.last_name  AS return_last_name,

    pu.purchases_id,
    sup.name AS supplier_name

FROM inventory_transactions it
LEFT JOIN products p ON it.product_id = p.product_id
LEFT JOIN stock_batches sb ON sb.batch_id = it.batch_id

LEFT JOIN returns r
    ON it.reference_type='return' AND it.reference_id = r.return_id

LEFT JOIN sales sa
    ON it.reference_type='sale' AND it.reference_id = sa.sale_id
LEFT JOIN customers c
    ON sa.customer_id = c.customer_id

LEFT JOIN sales sa_r
    ON r.sale_id = sa_r.sale_id
LEFT JOIN customers c_r
    ON sa_r.customer_id = c_r.customer_id

LEFT JOIN purchases pu
    ON it.reference_type='purchase' AND it.reference_id = pu.purchases_id
LEFT JOIN suppliers sup
    ON pu.supplier_id = sup.supplier_id

ORDER BY it.created_at DESC
";
$result = $conn->query($sql);
if(!$result){
    die("Query Error: " . $conn->error);
}

$inRows = [];
$outRows = [];
$adjustRows = [];
$returnRows = [];
while($row = $result->fetch_assoc()){
    $type = strtolower(trim((string)($row['type'] ?? '')));
    $refLower = strtolower(trim((string)($row['reference_type'] ?? '')));

    if($refLower === 'return'){
        $returnRows[] = $row;
    } elseif($refLower === 'adjust' || $type === 'adjust'){
        $adjustRows[] = $row;
    } elseif($type === 'in'){
        $inRows[] = $row;
    } else {
        $outRows[] = $row;
    }
}

function renderLogRows(array $rows, string $bucket): void {
    if(count($rows) === 0){
        echo "<tr><td colspan='9' class='text-center text-muted'>No records found.</td></tr>";
        return;
    }

    foreach($rows as $row){
        $date = date("M d, Y h:i A", strtotime((string)$row['created_at']));
        $product = trim(((string)($row['variety'] ?? ''))." - ".((string)($row['grade'] ?? '')));
        if($product === "-") $product = "N/A";
        $batchCode = trim((string)($row['batch_code'] ?? ''));
        if($batchCode !== ''){
            $product .= " (" . $batchCode . ")";
        }

        $customer = "N/A";
        if(!empty($row['first_name'])){
            $customer = $row['first_name']." ".$row['last_name'];
        } elseif(!empty($row['return_first_name'])){
            $customer = $row['return_first_name']." ".$row['return_last_name'];
        }

        $type = strtolower(trim((string)($row['type'] ?? '')));
        $ref = strtoupper(trim((string)($row['reference_type'] ?? '')));
        $qtyNum = (float)($row['qty_kg'] ?? 0);

        if($bucket === 'adjust'){
            $signedQty = ($qtyNum >= 0 ? '+' : '-') . number_format(abs($qtyNum), 2);
            $qtyClass = "type-adjust";
            $typeText = "ADJUST";
            $typeClass = "type-adjust";
            $showSupplier = "N/A";
            $refBadge = "<span class='badge badge-adjust'>ADJUST</span>";
        } else {
            $isIn = ($type === 'in');
            $signedQty = ($isIn ? '+' : '-') . number_format(abs($qtyNum), 2);
            $qtyClass = $isIn ? "qty-in" : "qty-out";
            $typeText = strtoupper($type);
            $typeClass = $isIn ? "type-in" : "type-out";
            $supplier = (!empty($row['supplier_name'])) ? $row['supplier_name'] : 'N/A';
            $showSupplier = ($isIn && $ref === "PURCHASE") ? $supplier : "N/A";
            if($ref === "RETURN") $refBadge = "<span class='badge badge-return'>RETURN #".(int)$row['reference_id']."</span>";
            elseif($ref === "SALE") $refBadge = "<span class='badge badge-sale'>SALE #".(int)$row['reference_id']."</span>";
            elseif($ref === "PURCHASE") $refBadge = "<span class='badge badge-purchase'>PURCHASE #".(int)$row['reference_id']."</span>";
            else $refBadge = "<span class='badge bg-secondary'>".$ref."</span>";
        }

        $note = htmlspecialchars((string)($row['note'] ?? ''));
        echo "<tr>
            <td>{$date}</td>
            <td>".htmlspecialchars($product)."</td>
            <td>".htmlspecialchars($customer)."</td>
            <td>".htmlspecialchars($showSupplier)."</td>
            <td class='{$qtyClass}'>{$signedQty}</td>
            <td class='{$typeClass}'>{$typeText}</td>
            <td>{$refBadge}</td>
            <td>{$note}</td>
            <td>";

        if(($bucket === 'in' || $bucket === 'return') && $ref === "RETURN" && isset($row['return_id']) && strtolower((string)($row['return_status'] ?? '')) === 'pending'){
            echo "<form method='POST' class='m-0'>
                    <input type='hidden' name='return_id' value='".(int)$row['return_id']."'>
                    <button type='submit' name='approve_return' class='btn btn-sm btn-success'>Approve</button>
                  </form>";
        } else {
            echo "-";
        }

        echo "</td></tr>";
    }
}
?>

<div class="row g-3 mb-4">
  <div class="col-md-3">
    <div class="toolbar log-card" data-target="panel-in">
      <div class="fw-bold text-success">IN Logs</div>
      <div class="table-note"><?= count($inRows) ?> record(s)</div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="toolbar log-card" data-target="panel-out">
      <div class="fw-bold text-danger">OUT Logs</div>
      <div class="table-note"><?= count($outRows) ?> record(s)</div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="toolbar log-card" data-target="panel-return">
      <div class="fw-bold text-primary">RETURN Logs</div>
      <div class="table-note"><?= count($returnRows) ?> record(s)</div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="toolbar log-card" data-target="panel-adjust">
      <div class="fw-bold text-warning">ADJUST Logs</div>
      <div class="table-note"><?= count($adjustRows) ?> record(s)</div>
    </div>
  </div>
</div>

<div id="logsPlaceholder" class="alert alert-secondary">
  Select a card above to view logs.
</div>

<div id="panel-in" class="card modern-card shadow-sm mb-3 d-none">
  <div class="card-header bg-white fw-bold text-success">IN Logs</div>
  <div class="card-body">
    <div class="table-wrap">
      <table class="table table-striped table-bordered align-middle mb-0">
        <thead class="table-dark">
          <tr>
            <th>Date</th><th>Product</th><th>Customer</th><th>Supplier</th><th>Qty (kg)</th><th>Type</th><th>Reference</th><th>Note</th><th>Action</th>
          </tr>
        </thead>
        <tbody><?php renderLogRows($inRows, 'in'); ?></tbody>
      </table>
    </div>
  </div>
</div>

<div id="panel-out" class="card modern-card shadow-sm mb-3 d-none">
  <div class="card-header bg-white fw-bold text-danger">OUT Logs</div>
  <div class="card-body">
    <div class="table-wrap">
      <table class="table table-striped table-bordered align-middle mb-0">
        <thead class="table-dark">
          <tr>
            <th>Date</th><th>Product</th><th>Customer</th><th>Supplier</th><th>Qty (kg)</th><th>Type</th><th>Reference</th><th>Note</th><th>Action</th>
          </tr>
        </thead>
        <tbody><?php renderLogRows($outRows, 'out'); ?></tbody>
      </table>
    </div>
  </div>
</div>

<div id="panel-return" class="card modern-card shadow-sm mb-3 d-none">
  <div class="card-header bg-white fw-bold text-primary">RETURN Logs</div>
  <div class="card-body">
    <div class="table-wrap">
      <table class="table table-striped table-bordered align-middle mb-0">
        <thead class="table-dark">
          <tr>
            <th>Date</th><th>Product</th><th>Customer</th><th>Supplier</th><th>Qty (kg)</th><th>Type</th><th>Reference</th><th>Note</th><th>Action</th>
          </tr>
        </thead>
        <tbody><?php renderLogRows($returnRows, 'return'); ?></tbody>
      </table>
    </div>
  </div>
</div>

<div id="panel-adjust" class="card modern-card shadow-sm d-none">
  <div class="card-header bg-white fw-bold text-warning">ADJUST Logs</div>
  <div class="card-body">
    <div class="table-wrap">
      <table class="table table-striped table-bordered align-middle mb-0">
        <thead class="table-dark">
          <tr>
            <th>Date</th><th>Product</th><th>Customer</th><th>Supplier</th><th>Qty (kg)</th><th>Type</th><th>Reference</th><th>Note</th><th>Action</th>
          </tr>
        </thead>
        <tbody><?php renderLogRows($adjustRows, 'adjust'); ?></tbody>
      </table>
    </div>
  </div>
</div>

</div>
</main>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="../js/inventory-stock-logs.js"></script>
<script>
(function () {
  const pollIntervalMs = 3600000;
  const idleDelayMs = 2500;
  let pollingInFlight = false;
  let lastInteraction = Date.now();
  let pollTimer = null;
  let controller = null;

  function pageIsSafeToRefresh() {
    const main = document.querySelector('main');
    return !document.hidden
      && !!main
      && !main.contains(document.activeElement)
      && !document.querySelector('.modal.show')
      && !document.querySelector('.table-wrap:hover')
      && Date.now() - lastInteraction >= idleDelayMs;
  }

  function noteInteraction() {
    lastInteraction = Date.now();
    if (controller) {
      controller.abort();
      controller = null;
    }
    schedulePoll();
  }

  function schedulePoll() {
    clearTimeout(pollTimer);
    pollTimer = window.setTimeout(pollLiveMain, pollIntervalMs);
  }

  async function pollLiveMain() {
    if (pollingInFlight) return;
    if (!pageIsSafeToRefresh()) {
      schedulePoll();
      return;
    }

    pollingInFlight = true;
    controller = new AbortController();
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('_live', Date.now().toString());
      const response = await fetch(url.toString(), {
        credentials: 'same-origin',
        cache: 'no-store',
        signal: controller.signal,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      });
      if (!response.ok || !pageIsSafeToRefresh()) return;

      const html = await response.text();
      if (!pageIsSafeToRefresh()) return;

      const doc = new DOMParser().parseFromString(html, 'text/html');
      const sourceMain = doc.querySelector('main');
      const targetMain = document.querySelector('main');
      if (!sourceMain || !targetMain) return;

      sourceMain.querySelectorAll('.log-card').forEach((sourceCard) => {
        const targetCard = targetMain.querySelector(`.log-card[data-target="${sourceCard.dataset.target}"]`);
        const sourceCount = sourceCard.querySelector('.table-note');
        const targetCount = targetCard?.querySelector('.table-note');
        if (sourceCount && targetCount && sourceCount.textContent !== targetCount.textContent) {
          targetCount.textContent = sourceCount.textContent;
        }
      });

      ['panel-in', 'panel-out', 'panel-return', 'panel-adjust'].forEach((panelId) => {
        if (!pageIsSafeToRefresh()) return;

        const sourceBody = sourceMain.querySelector(`#${panelId} tbody`);
        const targetBody = targetMain.querySelector(`#${panelId} tbody`);
        if (!sourceBody || !targetBody || sourceBody.innerHTML === targetBody.innerHTML) return;

        const wrapper = targetBody.closest('.table-wrap');
        const scrollTop = wrapper?.scrollTop ?? 0;
        targetBody.replaceChildren(...Array.from(sourceBody.children, (row) => row.cloneNode(true)));
        if (wrapper) wrapper.scrollTop = scrollTop;
      }
    } catch (error) {
      if (error.name !== 'AbortError') {
        console.error('Inventory live poll failed:', error);
      }
    } finally {
      pollingInFlight = false;
      controller = null;
      schedulePoll();
    }
  }

  ['pointerdown', 'keydown', 'input', 'scroll'].forEach((eventName) => {
    document.addEventListener(eventName, noteInteraction, true);
  });

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      if (controller) controller.abort();
      clearTimeout(pollTimer);
      return;
    }
    noteInteraction();
  });

  schedulePoll();
})();
</script>
</body>
</html>
