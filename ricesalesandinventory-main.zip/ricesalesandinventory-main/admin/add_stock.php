<?php
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit;
}

if(strtolower($_SESSION['role'] ?? '') !== 'admin'){
    header("Location: ../login.php");
    exit;
}

$username = $_SESSION['username'] ?? 'User';
$user_id  = (int)($_SESSION['user_id'] ?? 0);
$activePage = 'add_stock';

include '../config/db.php';

$error = "";

/*
|--------------------------------------------------------------------------
| AUTO MIGRATE PRODUCTS COLUMNS
|--------------------------------------------------------------------------
*/

// Add delivery_date if missing
$deliveryColCheck = $conn->query("
    SHOW COLUMNS FROM products LIKE 'delivery_date'
");

if($deliveryColCheck && $deliveryColCheck->num_rows === 0){
    $conn->query("
        ALTER TABLE products
        ADD COLUMN delivery_date DATE NULL
        AFTER price_per_kg
    ");
}

// Add sell_price_per_sack if missing
$sellSackColCheck = $conn->query("
    SHOW COLUMNS FROM products LIKE 'sell_price_per_sack'
");

if($sellSackColCheck && $sellSackColCheck->num_rows === 0){
    $conn->query("
        ALTER TABLE products
        ADD COLUMN sell_price_per_sack DECIMAL(10,2)
        NOT NULL DEFAULT 0
        AFTER price_per_sack
    ");
}


/*
|--------------------------------------------------------------------------
| AUTO MIGRATE PURCHASE RECEIVING AUDIT COLUMNS
|--------------------------------------------------------------------------
*/

$purchaseColChecks = [
    'received_by' => "
        ALTER TABLE purchases
        ADD COLUMN received_by VARCHAR(120) NULL
        AFTER delivery_date
    ",

    'receiving_notes' => "
        ALTER TABLE purchases
        ADD COLUMN receiving_notes TEXT NULL
        AFTER received_by
    ",

    'received_at' => "
        ALTER TABLE purchases
        ADD COLUMN received_at DATETIME NULL
        AFTER receiving_notes
    ",
];

foreach ($purchaseColChecks as $colName => $alterSql) {

    $escapedCol = $conn->real_escape_string($colName);

    $colCheck = $conn->query("
        SHOW COLUMNS FROM purchases LIKE '{$escapedCol}'
    ");

    if ($colCheck && $colCheck->num_rows === 0) {
        $conn->query($alterSql);
    }
}


/*
|--------------------------------------------------------------------------
| STOCK LIMIT SETTINGS
|--------------------------------------------------------------------------
*/

$DEFAULT_OVERSTOCK_LIMIT_KG = 1000;
$OVERSTOCK_LIMIT_KG = $DEFAULT_OVERSTOCK_LIMIT_KG;

$prefillPoId = (int)($_GET['po_id'] ?? $_GET['purchase_id'] ?? 0);

$settingsRes = $conn->query("
    SELECT over_threshold_kg
    FROM stock_settings
    WHERE id = 1
    LIMIT 1
");

if($settingsRes){

    $settingsRow = $settingsRes->fetch_assoc();

    $configuredOver = (float)(
        $settingsRow['over_threshold_kg'] ?? 0
    );

    if($configuredOver > 0){
        $OVERSTOCK_LIMIT_KG = $configuredOver;
    }
}


/*
|--------------------------------------------------------------------------
| AJAX: ADD SUPPLIER
|--------------------------------------------------------------------------
*/

if(isset($_POST['ajax']) && $_POST['ajax'] === 'add_supplier'){

    header('Content-Type: application/json; charset=utf-8');

    $name    = trim($_POST['supplier_name'] ?? '');
    $phone   = trim($_POST['supplier_phone'] ?? '');
    $address = trim($_POST['supplier_address'] ?? '');

    if($name === ''){

        echo json_encode([
            'ok' => false,
            'message' => 'Supplier name is required.'
        ]);

        exit;
    }


    $stmt = $conn->prepare("
        SELECT supplier_id, name
        FROM suppliers
        WHERE name = ?
        LIMIT 1
    ");

    if(!$stmt){

        echo json_encode([
            'ok' => false,
            'message' => 'DB error: ' . $conn->error
        ]);

        exit;
    }


    $stmt->bind_param("s", $name);
    $stmt->execute();

    $dup = $stmt->get_result()->fetch_assoc();

    $stmt->close();


    if($dup){

        echo json_encode([
            'ok' => true,
            'supplier_id' => (int)$dup['supplier_id'],
            'supplier_name' => $dup['name'],
            'message' => 'Supplier already exists. Selected.'
        ]);

        exit;
    }


    $stmt = $conn->prepare("
        INSERT INTO suppliers
        (
            name,
            phone,
            address,
            status,
            created_at
        )
        VALUES
        (
            ?,
            ?,
            ?,
            'active',
            NOW()
        )
    ");

    if(!$stmt){

        echo json_encode([
            'ok' => false,
            'message' => 'DB error: ' . $conn->error
        ]);

        exit;
    }


    $stmt->bind_param(
        "sss",
        $name,
        $phone,
        $address
    );

    $stmt->execute();

    $newId = (int)$conn->insert_id;

    $stmt->close();


    echo json_encode([
        'ok' => true,
        'supplier_id' => $newId,
        'supplier_name' => $name,
        'message' => 'Supplier added!'
    ]);

    exit;
}


/*
|--------------------------------------------------------------------------
| AJAX: GET LAST SUPPLIER PRICE
|--------------------------------------------------------------------------
*/

if(isset($_POST['ajax']) && $_POST['ajax'] === 'last_supplier_price'){

    header('Content-Type: application/json; charset=utf-8');

    $product_id  = (int)($_POST['product_id'] ?? 0);
    $supplier_id = (int)($_POST['supplier_id'] ?? 0);


    if($product_id <= 0 || $supplier_id <= 0){

        echo json_encode([
            'ok' => false,
            'message' => 'Product and supplier are required.'
        ]);

        exit;
    }


    $stmt = $conn->prepare("
        SELECT it.note
        FROM inventory_transactions it

        INNER JOIN purchases p
            ON p.purchases_id = it.reference_id

        WHERE it.product_id = ?
        AND it.reference_type = 'purchase'
        AND LOWER(it.type) = 'in'
        AND p.supplier_id = ?

        ORDER BY
            it.created_at DESC,
            it.transaction_id DESC

        LIMIT 1
    ");


    if(!$stmt){

        echo json_encode([
            'ok' => false,
            'message' => 'DB error: ' . $conn->error
        ]);

        exit;
    }


    $stmt->bind_param(
        "ii",
        $product_id,
        $supplier_id
    );

    $stmt->execute();

    $row = $stmt->get_result()->fetch_assoc();

    $stmt->close();


    if(!$row || !isset($row['note'])){

        echo json_encode([
            'ok' => true,
            'found' => false,
            'price' => null
        ]);

        exit;
    }


    $note = (string)$row['note'];

    $price = null;


    if(
        preg_match(
            '/supplier\/sack=₱\s*([0-9]+(?:\.[0-9]+)?)/u',
            $note,
            $m
        )
    ){

        $price = (float)$m[1];

    } elseif(
        preg_match(
            '/supplier\/sack=PHP\s*([0-9]+(?:\.[0-9]+)?)/i',
            $note,
            $m2
        )
    ){

        $price = (float)$m2[1];
    }


    if($price === null){

        echo json_encode([
            'ok' => true,
            'found' => false,
            'price' => null
        ]);

        exit;
    }


    echo json_encode([
        'ok' => true,
        'found' => true,
        'price' => $price
    ]);

    exit;
}


/*
|--------------------------------------------------------------------------
| SAVE STOCK IN / RECEIVING
|--------------------------------------------------------------------------
*/

if(
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && !isset($_POST['ajax'])
){

    $purchase_id = (int)($_POST['purchase_id'] ?? 0);
    $product_id  = (int)($_POST['product_id'] ?? 0);
    $supplier_id = (int)($_POST['supplier_id'] ?? 0);

    $purchase_date = $_POST['purchase_date'] ?? date('Y-m-d');

    $delivery_date = $_POST['delivery_date'] ?? null;

    $due_date = $_POST['due_date'] ?? null;

    /*
    |--------------------------------------------------------------------------
    | PAYMENT TYPE
    |--------------------------------------------------------------------------
    |
    | cash   = paid immediately, no AP
    | credit = Utang, automatically creates Accounts Payable
    |
    */

    $payment_type = $_POST['payment_type'] ?? 'cash';

    if(
        !in_array(
            $payment_type,
            ['cash', 'credit'],
            true
        )
    ){
        $payment_type = 'cash';
    }


    $qty_sacks = (float)(
        $_POST['qty_sacks'] ?? 0
    );

    $supplier_price_per_sack = (float)(
        $_POST['supplier_price_per_sack'] ?? 0
    );

    $transport_handling = (float)(
        $_POST['transport_handling'] ?? 0
    );

    $markup_per_kg = (float)(
        $_POST['markup_per_kg'] ?? 0
    );

    if($markup_per_kg < 0){
        $markup_per_kg = 0;
    }

    $note = trim($_POST['note'] ?? '');


    /*
    |--------------------------------------------------------------------------
    | VALIDATION
    |--------------------------------------------------------------------------
    */

    if($purchase_id <= 0){

        $error = "Please select an approved purchase order first.";

    } elseif($product_id <= 0 || $supplier_id <= 0){

        $error = "Please select a product and supplier.";

    } elseif($qty_sacks <= 0){

        $error = "Please enter a valid quantity (no. of sacks).";

    } elseif($supplier_price_per_sack < 0){

        $error = "Supplier price per sack must be 0 or higher.";

    } elseif($transport_handling < 0){

        $error = "Transport/Handling must be 0 or higher.";

    } else {


        /*
        |--------------------------------------------------------------------------
        | GET PRODUCT INFORMATION
        |--------------------------------------------------------------------------
        */

        $stmtW = $conn->prepare("
            SELECT
                variety,
                grade,
                unit_weight_kg
            FROM products
            WHERE product_id = ?
            AND archived = 0
            LIMIT 1
        ");


        if(!$stmtW){

            $error = "DB error: " . $conn->error;

        } else {


            $stmtW->bind_param(
                "i",
                $product_id
            );

            $stmtW->execute();

            $prodRow =
                $stmtW->get_result()->fetch_assoc();

            $stmtW->close();


            if(!$prodRow){

                $error =
                    "Selected product not found or archived.";

            } else {


                $unit_weight_kg = (float)(
                    $prodRow['unit_weight_kg'] ?? 0
                );


                if($unit_weight_kg <= 0){

                    $error =
                        "This product has no valid unit size "
                        . "(kg per sack). Please set it in Products first.";

                } else {


                    $qty_kg =
                        $qty_sacks * $unit_weight_kg;


                    /*
                    |--------------------------------------------------------------------------
                    | GET CURRENT STOCK
                    |--------------------------------------------------------------------------
                    */

                    $currentStockKg = 0.0;


                    $stmtS = $conn->prepare("
                        SELECT IFNULL(
                            SUM(
                                CASE
                                    WHEN LOWER(type) = 'in'
                                        THEN qty_kg

                                    WHEN LOWER(type) = 'out'
                                        THEN -qty_kg

                                    WHEN LOWER(type) = 'adjust'
                                        THEN qty_kg

                                    ELSE 0
                                END
                            ),
                            0
                        ) AS stock_kg

                        FROM inventory_transactions

                        WHERE product_id = ?
                    ");


                    if($stmtS){

                        $stmtS->bind_param(
                            "i",
                            $product_id
                        );

                        $stmtS->execute();

                        $rowS =
                            $stmtS->get_result()->fetch_assoc();

                        $stmtS->close();

                        $currentStockKg = (float)(
                            $rowS['stock_kg'] ?? 0
                        );
                    }


                    $projected =
                        $currentStockKg + $qty_kg;


                    /*
                    |--------------------------------------------------------------------------
                    | CHECK OVERSTOCK
                    |--------------------------------------------------------------------------
                    */

                    if($projected > $OVERSTOCK_LIMIT_KG){

                        $error =
                            "Cannot stock in this item. "
                            . "It would exceed the warehouse limit.\n"
                            . "Current stock: "
                            . number_format($currentStockKg, 2)
                            . " kg\n"
                            . "Incoming: "
                            . number_format($qty_kg, 2)
                            . " kg\n"
                            . "Projected: "
                            . number_format($projected, 2)
                            . " kg\n"
                            . "Limit: "
                            . number_format(
                                $OVERSTOCK_LIMIT_KG,
                                2
                            )
                            . " kg";

                    } else {


                        /*
                        |--------------------------------------------------------------------------
                        | COMPUTE TOTAL RECEIVING AMOUNT
                        |--------------------------------------------------------------------------
                        */

                        $total_amount =
                            ($qty_sacks * $supplier_price_per_sack)
                            + $transport_handling;


                        /*
                        |--------------------------------------------------------------------------
                        | DEFAULT DUE DATE
                        |--------------------------------------------------------------------------
                        */

                        if(
                            $payment_type === 'credit'
                            && empty($due_date)
                            && $total_amount > 0
                        ){

                            $due_date = date(
                                'Y-m-d',
                                strtotime(
                                    $purchase_date . ' +7 days'
                                )
                            );
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | COST COMPUTATION
                        |--------------------------------------------------------------------------
                        */

                        $per_sack_transport =
                            ($qty_sacks > 0)
                            ? (
                                $transport_handling
                                / $qty_sacks
                            )
                            : 0.0;


                        $landed_cost_per_sack =
                            $supplier_price_per_sack
                            + $per_sack_transport;


                        $cost_per_kg =
                            ($unit_weight_kg > 0)
                            ? (
                                $landed_cost_per_sack
                                / $unit_weight_kg
                            )
                            : 0.0;


                        $suggested_sell_per_kg =
                            $cost_per_kg
                            + $markup_per_kg;


                        $sell_price_per_sack =
                            $suggested_sell_per_kg
                            * $unit_weight_kg;


                        $cost_per_kg =
                            round($cost_per_kg, 2);

                        $suggested_sell_per_kg =
                            round(
                                $suggested_sell_per_kg,
                                2
                            );

                        $sell_price_per_sack =
                            round(
                                $sell_price_per_sack,
                                2
                            );


                        /*
                        |--------------------------------------------------------------------------
                        | VERIFY PURCHASE ORDER
                        |--------------------------------------------------------------------------
                        */

                        $purchaseCheck = $conn->prepare("
                            SELECT
                                purchases_id,
                                supplier_id,
                                po_approved
                            FROM purchases
                            WHERE purchases_id = ?
                            LIMIT 1
                        ");


                        if(!$purchaseCheck){

                            throw new Exception(
                                "Prepare failed "
                                . "(purchase lookup): "
                                . $conn->error
                            );
                        }


                        $purchaseCheck->bind_param(
                            "i",
                            $purchase_id
                        );

                        $purchaseCheck->execute();

                        $purchaseRow =
                            $purchaseCheck
                            ->get_result()
                            ->fetch_assoc();

                        $purchaseCheck->close();


                        if(!$purchaseRow){

                            throw new Exception(
                                "Selected purchase order was not found."
                            );
                        }


                        if(
                            (int)(
                                $purchaseRow['po_approved'] ?? 0
                            ) !== 1
                        ){

                            throw new Exception(
                                "Selected purchase order "
                                . "is not approved yet."
                            );
                        }


                        $purchaseSupplierId = (int)(
                            $purchaseRow['supplier_id'] ?? 0
                        );


                        if($purchaseSupplierId > 0){

                            // Always use supplier assigned to PO
                            $supplier_id = $purchaseSupplierId;
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | BEGIN DATABASE TRANSACTION
                        |--------------------------------------------------------------------------
                        */

                        $conn->begin_transaction();


                        try {


                            /*
                            |--------------------------------------------------------------------------
                            | 1. UPDATE PRODUCT PRICES
                            |--------------------------------------------------------------------------
                            */

                            $stmtU = $conn->prepare("
                                UPDATE products
                                SET
                                    price_per_sack = ?,
                                    sell_price_per_sack = ?,
                                    price_per_kg = ?,
                                    delivery_date = ?
                                WHERE product_id = ?
                            ");


                            if(!$stmtU){

                                throw new Exception(
                                    "Prepare failed "
                                    . "(products update): "
                                    . $conn->error
                                );
                            }


                            $actualDeliveryDate =
                                !empty($delivery_date)
                                ? $delivery_date
                                : $purchase_date;


                            $stmtU->bind_param(
                                "dddsi",
                                $supplier_price_per_sack,
                                $sell_price_per_sack,
                                $suggested_sell_per_kg,
                                $actualDeliveryDate,
                                $product_id
                            );

                            $stmtU->execute();
                            $stmtU->close();


                            /*
                            |--------------------------------------------------------------------------
                            | 2. MARK PURCHASE AS RECEIVED
                            |--------------------------------------------------------------------------
                            */

                            $purchase_status = 'received';

                            $received_by = $username;

                            $received_notes =
                                ($note !== '')
                                ? $note
                                : 'Stock in recorded';


                            $stmtP = $conn->prepare("
                                UPDATE purchases
                                SET
                                    supplier_id = ?,
                                    purchase_date = ?,
                                    total_amount = ?,
                                    status = ?,
                                    po_approved = 1,
                                    received_by = ?,
                                    receiving_notes = ?,
                                    received_at = NOW()
                                WHERE purchases_id = ?
                            ");


                            if(!$stmtP){

                                throw new Exception(
                                    "Prepare failed "
                                    . "(purchases): "
                                    . $conn->error
                                );
                            }


                            $stmtP->bind_param(
                                "isdsssi",
                                $supplier_id,
                                $purchase_date,
                                $total_amount,
                                $purchase_status,
                                $received_by,
                                $received_notes,
                                $purchase_id
                            );

                            $stmtP->execute();
                            $stmtP->close();


                            /*
                            |--------------------------------------------------------------------------
                            | 3. UPDATE OR INSERT PURCHASE ITEM
                            |--------------------------------------------------------------------------
                            */

                            $itemLookup = $conn->prepare("
                                SELECT purchase_item_id
                                FROM purchase_items
                                WHERE purchases_id = ?
                                AND product_id = ?
                                LIMIT 1
                            ");


                            if(!$itemLookup){

                                throw new Exception(
                                    "Prepare failed "
                                    . "(purchase_items lookup): "
                                    . $conn->error
                                );
                            }


                            $itemLookup->bind_param(
                                "ii",
                                $purchase_id,
                                $product_id
                            );

                            $itemLookup->execute();

                            $existingItem =
                                $itemLookup
                                ->get_result()
                                ->fetch_assoc();

                            $itemLookup->close();


                            $itemTotal = round(
                                $qty_sacks
                                * $supplier_price_per_sack,
                                2
                            );


                            if($existingItem){


                                $stmtItem = $conn->prepare("
                                    UPDATE purchase_items
                                    SET
                                        quantity_sacks = ?,
                                        estimated_price = ?,
                                        supplier_price = ?,
                                        line_total = ?
                                    WHERE purchase_item_id = ?
                                    AND purchases_id = ?
                                ");


                                if(!$stmtItem){

                                    throw new Exception(
                                        "Prepare failed "
                                        . "(purchase_items update): "
                                        . $conn->error
                                    );
                                }


                                $itemId = (int)(
                                    $existingItem['purchase_item_id']
                                );


                                $stmtItem->bind_param(
                                    "ddddii",
                                    $qty_sacks,
                                    $supplier_price_per_sack,
                                    $supplier_price_per_sack,
                                    $itemTotal,
                                    $itemId,
                                    $purchase_id
                                );

                                $stmtItem->execute();
                                $stmtItem->close();


                            } else {


                                $stmtItem = $conn->prepare("
                                    INSERT INTO purchase_items
                                    (
                                        purchases_id,
                                        product_id,
                                        quantity_sacks,
                                        estimated_price,
                                        supplier_price,
                                        line_total
                                    )
                                    VALUES (?, ?, ?, ?, ?, ?)
                                ");


                                if(!$stmtItem){

                                    throw new Exception(
                                        "Prepare failed "
                                        . "(purchase_items insert): "
                                        . $conn->error
                                    );
                                }


                                $stmtItem->bind_param(
                                    "iiiddd",
                                    $purchase_id,
                                    $product_id,
                                    $qty_sacks,
                                    $supplier_price_per_sack,
                                    $supplier_price_per_sack,
                                    $itemTotal
                                );

                                $stmtItem->execute();
                                $stmtItem->close();
                            }


                            /*
                            |--------------------------------------------------------------------------
                            | 4. COMPUTE PURCHASE TOTAL
                            |--------------------------------------------------------------------------
                            */

                            $sumStmt = $conn->prepare("
                                SELECT IFNULL(
                                    SUM(
                                        CASE
                                            WHEN line_total > 0
                                                THEN line_total

                                            WHEN supplier_price > 0
                                                THEN quantity_sacks
                                                * supplier_price

                                            ELSE quantity_sacks
                                                * estimated_price
                                        END
                                    ),
                                    0
                                ) AS grand_total
                                FROM purchase_items
                                WHERE purchases_id = ?
                            ");


                            if(!$sumStmt){

                                throw new Exception(
                                    "Prepare failed "
                                    . "(purchase_items sum): "
                                    . $conn->error
                                );
                            }


                            $sumStmt->bind_param(
                                "i",
                                $purchase_id
                            );

                            $sumStmt->execute();

                            $grandTotalRow =
                                $sumStmt
                                ->get_result()
                                ->fetch_assoc();

                            $sumStmt->close();


                            /*
                            | Purchase items total
                            */

                            $grandTotal = (float)(
                                $grandTotalRow['grand_total']
                                ?? 0
                            );


                            /*
                            | Add transport/handling to actual total
                            */

                            $grandTotal = round(
                                $grandTotal
                                + $transport_handling,
                                2
                            );


                            $stmtTotal = $conn->prepare("
                                UPDATE purchases
                                SET total_amount = ?
                                WHERE purchases_id = ?
                            ");


                            if(!$stmtTotal){

                                throw new Exception(
                                    "Prepare failed "
                                    . "(purchase total update): "
                                    . $conn->error
                                );
                            }


                            $stmtTotal->bind_param(
                                "di",
                                $grandTotal,
                                $purchase_id
                            );

                            $stmtTotal->execute();
                            $stmtTotal->close();


                            /*
                            |--------------------------------------------------------------------------
                            | 5. CREATE / UPDATE ACCOUNTS PAYABLE
                            |--------------------------------------------------------------------------
                            |
                            | ONLY FOR CREDIT / UTANG
                            |
                            */

                            if(
                                $payment_type === 'credit'
                                && $grandTotal > 0
                            ){


                                /*
                                |--------------------------------------------------------------------------
                                | CHECK EXISTING AP FOR THIS PURCHASE
                                |--------------------------------------------------------------------------
                                */

                                $apCheck = $conn->prepare("
                                    SELECT
                                        ap_id,
                                        amount_paid,
                                        approved
                                    FROM account_payable
                                    WHERE purchase_id = ?
                                    ORDER BY ap_id DESC
                                    LIMIT 1
                                ");


                                if(!$apCheck){

                                    throw new Exception(
                                        "Prepare failed "
                                        . "(AP lookup): "
                                        . $conn->error
                                    );
                                }


                                $apCheck->bind_param(
                                    "i",
                                    $purchase_id
                                );

                                $apCheck->execute();

                                $existingAP =
                                    $apCheck
                                    ->get_result()
                                    ->fetch_assoc();

                                $apCheck->close();


                                /*
                                |--------------------------------------------------------------------------
                                | UPDATE EXISTING AP
                                |--------------------------------------------------------------------------
                                */

                                if($existingAP){


                                    $existingAmountPaid = (float)(
                                        $existingAP['amount_paid'] ?? 0
                                    );


                                    $isApproved = (int)($existingAP['approved'] ?? 0) === 1;
                                    $newBalance = $isApproved
                                        ? max(0, round($grandTotal - $existingAmountPaid, 2))
                                        : 0.00;

                                    if (!$isApproved) {
                                        $newStatus = 'pending';
                                    } elseif ($newBalance <= 0) {
                                        $newStatus = 'paid';
                                    } elseif ($existingAmountPaid > 0) {
                                        $newStatus = 'partial';
                                    } else {
                                        $newStatus = 'unpaid';
                                    }


                                    $stmtAP = $conn->prepare("
                                        UPDATE account_payable
                                        SET
                                            supplier_id = ?,
                                            total_amount = ?,
                                            balance = ?,
                                            due_date = ?,
                                            status = ?
                                        WHERE ap_id = ?
                                    ");


                                    if(!$stmtAP){

                                        throw new Exception(
                                            "Prepare failed "
                                            . "(AP update): "
                                            . $conn->error
                                        );
                                    }


                                    $apId = (int)(
                                        $existingAP['ap_id']
                                    );


                                    $stmtAP->bind_param(
                                        "iddssi",
                                        $supplier_id,
                                        $grandTotal,
                                        $newBalance,
                                        $due_date,
                                        $newStatus,
                                        $apId
                                    );

                                    $stmtAP->execute();
                                    $stmtAP->close();


                                } else {


                                    /*
                                    |--------------------------------------------------------------------------
                                    | CREATE NEW AP
                                    |--------------------------------------------------------------------------
                                    */

                                    $apAmountPaid = 0.00;

                                    $apBalance = 0.00;

                                    $apStatus = 'pending';


                                    $stmtAP = $conn->prepare("
                                        INSERT INTO account_payable
                                        (
                                            purchase_id,
                                            supplier_id,
                                            total_amount,
                                            amount_paid,
                                            balance,
                                            due_date,
                                            status,
                                            approved,
                                            accrued_interest,
                                            accrued_penalty,
                                            last_charge_date,
                                            created_at
                                        )
                                        VALUES
                                        (
                                            ?,
                                            ?,
                                            ?,
                                            ?,
                                            ?,
                                            ?,
                                            ?,
                                            0,
                                            0.00,
                                            0.00,
                                            NULL,
                                            NOW()
                                        )
                                    ");


                                    if(!$stmtAP){

                                        throw new Exception(
                                            "Prepare failed "
                                            . "(AP insert): "
                                            . $conn->error
                                        );
                                    }


                                    $stmtAP->bind_param(
                                        "iidddss",
                                        $purchase_id,
                                        $supplier_id,
                                        $grandTotal,
                                        $apAmountPaid,
                                        $apBalance,
                                        $due_date,
                                        $apStatus
                                    );

                                    $stmtAP->execute();
                                    $stmtAP->close();
                                }
                            }


                            /*
                            |--------------------------------------------------------------------------
                            | 6. CREATE STOCK BATCH
                            |--------------------------------------------------------------------------
                            */

                            $reference_type = 'purchase';

                            $type = 'in';


                            if($note === ""){
                                $note = "Stock in recorded";
                            }


                            $noteFull =
                                $note

                                . " | sacks="
                                . rtrim(
                                    rtrim(
                                        number_format(
                                            $qty_sacks,
                                            2,
                                            '.',
                                            ''
                                        ),
                                        '0'
                                    ),
                                    '.'
                                )

                                . " | sack_size="
                                . rtrim(
                                    rtrim(
                                        number_format(
                                            $unit_weight_kg,
                                            2,
                                            '.',
                                            ''
                                        ),
                                        '0'
                                    ),
                                    '.'
                                )
                                . "kg"

                                . " | supplier/sack=₱"
                                . number_format(
                                    $supplier_price_per_sack,
                                    2
                                )

                                . " | transport=₱"
                                . number_format(
                                    $transport_handling,
                                    2
                                )

                                . " | cost/kg=₱"
                                . number_format(
                                    $cost_per_kg,
                                    2
                                )

                                . " | markup/kg=₱"
                                . number_format(
                                    $markup_per_kg,
                                    2
                                )

                                . " | sell/kg=₱"
                                . number_format(
                                    $suggested_sell_per_kg,
                                    2
                                )

                                . " | sell/sack=₱"
                                . number_format(
                                    $sell_price_per_sack,
                                    2
                                )

                                . " | payment="
                                . $payment_type;


                            $stmtBatch = $conn->prepare("
                                INSERT INTO stock_batches
                                (
                                    product_id,
                                    batch_code,
                                    source_reference_id,
                                    source_reference_type,
                                    arrived_at,
                                    unit_weight_kg,
                                    initial_qty_kg,
                                    remaining_qty_kg,
                                    regular_qty_kg,
                                    discounted_qty_kg,
                                    cost_per_kg,
                                    regular_price_per_kg,
                                    discounted_price_per_kg,
                                    note,
                                    created_by,
                                    created_at,
                                    updated_at
                                )
                                VALUES
                                (
                                    ?,
                                    NULL,
                                    ?,
                                    'purchase',
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    0.00,
                                    ?,
                                    ?,
                                    NULL,
                                    ?,
                                    ?,
                                    NOW(),
                                    NOW()
                                )
                            ");


                            if(!$stmtBatch){

                                throw new Exception(
                                    "Prepare failed "
                                    . "(stock_batches): "
                                    . $conn->error
                                );
                            }


                            $stmtBatch->bind_param(
                                "iisddddddsi",
                                $product_id,
                                $purchase_id,
                                $purchase_date,
                                $unit_weight_kg,
                                $qty_kg,
                                $qty_kg,
                                $qty_kg,
                                $cost_per_kg,
                                $suggested_sell_per_kg,
                                $noteFull,
                                $user_id
                            );

                            $stmtBatch->execute();

                            $batch_id = (int)$conn->insert_id;

                            $stmtBatch->close();


                            /*
                            |--------------------------------------------------------------------------
                            | GENERATE BATCH CODE
                            |--------------------------------------------------------------------------
                            */

                            $batchCode =
                                'B'
                                . str_pad(
                                    (string)$batch_id,
                                    6,
                                    '0',
                                    STR_PAD_LEFT
                                );


                            $stmtBatchCode = $conn->prepare("
                                UPDATE stock_batches
                                SET batch_code = ?
                                WHERE batch_id = ?
                            ");


                            if($stmtBatchCode){

                                $stmtBatchCode->bind_param(
                                    "si",
                                    $batchCode,
                                    $batch_id
                                );

                                $stmtBatchCode->execute();
                                $stmtBatchCode->close();
                            }


                            $noteFull .=
                                " | batch={$batchCode}";


                            /*
                            |--------------------------------------------------------------------------
                            | 7. CREATE INVENTORY TRANSACTION
                            |--------------------------------------------------------------------------
                            */

                            $stmt2 = $conn->prepare("
                                INSERT INTO inventory_transactions
                                (
                                    product_id,
                                    batch_id,
                                    qty_kg,
                                    reference_id,
                                    reference_type,
                                    type,
                                    note,
                                    created_at
                                )
                                VALUES
                                (
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    NOW()
                                )
                            ");


                            if(!$stmt2){

                                throw new Exception(
                                    "Prepare failed "
                                    . "(inventory_transactions): "
                                    . $conn->error
                                );
                            }


                            $stmt2->bind_param(
                                "iidisss",
                                $product_id,
                                $batch_id,
                                $qty_kg,
                                $purchase_id,
                                $reference_type,
                                $type,
                                $noteFull
                            );

                            $stmt2->execute();
                            $stmt2->close();


                            /*
                            |--------------------------------------------------------------------------
                            | COMMIT EVERYTHING
                            |--------------------------------------------------------------------------
                            */

                            $conn->commit();


                            header(
                                "Location: add_stock.php"
                                . "?success=received"
                                . "&purchase_id="
                                . $purchase_id
                                . "&product_id="
                                . $product_id
                                . "&received_sacks="
                                . rawurlencode(
                                    (string)$qty_sacks
                                )
                            );

                            exit;


                        } catch (Exception $e) {

                            $conn->rollback();

                            $error =
                                "Failed to record stock in: "
                                . $e->getMessage();
                        }
                    }
                }
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| LOAD PRODUCTS
|--------------------------------------------------------------------------
*/

$products = $conn->query("
    SELECT
        product_id,
        variety,
        grade,
        unit_weight_kg
    FROM products
    WHERE archived = 0
    ORDER BY variety ASC, grade ASC
");


/*
|--------------------------------------------------------------------------
| LOAD SUPPLIERS
|--------------------------------------------------------------------------
*/

$suppliers = $conn->query("
    SELECT
        supplier_id,
        name,
        phone,
        address
    FROM suppliers
    WHERE status = 'active'
    ORDER BY name ASC
");


/*
|--------------------------------------------------------------------------
| LOAD APPROVED / RECEIVED PURCHASE ORDERS
|--------------------------------------------------------------------------
*/

$donePoRows = $conn->query("
    SELECT
        p.purchases_id,
        p.purchase_date,
        p.total_amount,
        p.status,
        p.po_approved_at,
        p.received_at,
        s.name AS supplier_name

    FROM purchases p

    LEFT JOIN suppliers s
        ON s.supplier_id = p.supplier_id

    WHERE p.po_approved = 1

    ORDER BY
        COALESCE(
            p.po_approved_at,
            p.created_at
        ) DESC,
        p.purchases_id DESC

    LIMIT 100
");


$donePoList = [];
$donePoItemMap = [];


if($donePoRows){

    while($row = $donePoRows->fetch_assoc()){
        $donePoList[] = $row;
    }
}


$donePoIds = array_map(
    static fn(array $row): int =>
        (int)($row['purchases_id'] ?? 0),
    $donePoList
);


$donePoIds = array_values(
    array_filter(
        $donePoIds,
        static fn(int $id): bool => $id > 0
    )
);


if($donePoIds){

    $idList = implode(
        ',',
        array_map(
            'intval',
            $donePoIds
        )
    );


    $donePoItemRes = $conn->query("
        SELECT
            pi.purchases_id,
            pi.product_id,
            pi.quantity_sacks,
            pi.supplier_price,
            pi.line_total,
            pr.variety,
            pr.grade,
            pr.unit_weight_kg

        FROM purchase_items pi

        LEFT JOIN products pr
            ON pr.product_id = pi.product_id

        WHERE pi.purchases_id IN ({$idList})

        ORDER BY
            pi.purchases_id ASC,
            pi.purchase_item_id ASC
    ");


    if($donePoItemRes){

        while(
            $itemRow =
            $donePoItemRes->fetch_assoc()
        ){

            $poId = (int)(
                $itemRow['purchases_id'] ?? 0
            );

            if($poId <= 0){
                continue;
            }

            if(!isset($donePoItemMap[$poId])){
                $donePoItemMap[$poId] = [];
            }

            $donePoItemMap[$poId][] = $itemRow;
        }
    }
}


/*
|--------------------------------------------------------------------------
| SUCCESS RECEIVING SUMMARY
|--------------------------------------------------------------------------
*/

$receivedSummary = null;


if(
    isset($_GET['success'])
    && $_GET['success'] === 'received'
    && $prefillPoId > 0
){

    $receivedProductId =
        (int)($_GET['product_id'] ?? 0);


    if($receivedProductId > 0){

        $summaryStmt = $conn->prepare("
            SELECT
                p.variety,
                p.grade,
                p.unit_weight_kg,

                IFNULL(
                    SUM(sb.remaining_qty_kg),
                    0
                ) AS stock_kg

            FROM products p

            LEFT JOIN stock_batches sb
                ON sb.product_id = p.product_id

            WHERE p.product_id = ?

            GROUP BY p.product_id

            LIMIT 1
        ");


        if($summaryStmt){

            $summaryStmt->bind_param(
                "i",
                $receivedProductId
            );

            $summaryStmt->execute();

            $receivedSummary =
                $summaryStmt
                ->get_result()
                ->fetch_assoc();

            $summaryStmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1"
>

<title>Stock In | DE ORO HIYS</title>

<link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
    rel="stylesheet"
>

<link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    rel="stylesheet"
>

<link
    href="../css/inventory-add-stock.css"
    rel="stylesheet"
>

<link
    href="../css/inventory-mobile.css"
    rel="stylesheet"
>

</head>

<body>

<?php

$profileLink = '../admin/profile.php';
$logoutLink = '../logout.php';

include '../includes/topnav.php';

?>

<div class="container-fluid">
<div class="row">

<?php

$adminBase = '../admin/';
$inventoryBase = '../admin/';
$ownerBase = '../owner/';

include '../includes/admin_sidebar.php';

?>

<main class="col-lg-10 ms-sm-auto px-4 main-content">

<h2 class="mb-3">Stock In</h2>


<ul
    class="nav nav-tabs stock-tabs mb-3"
    id="stockInTabs"
    role="tablist"
>

    <li
        class="nav-item"
        role="presentation"
    >

        <button
            class="nav-link active"
            id="stock-form-tab"
            data-bs-toggle="tab"
            data-bs-target="#stock-form-pane"
            type="button"
            role="tab"
        >
            Stock In Form
        </button>

    </li>


    <li
        class="nav-item"
        role="presentation"
    >

        <button
            class="nav-link"
            id="done-po-tab"
            data-bs-toggle="tab"
            data-bs-target="#done-po-pane"
            type="button"
            role="tab"
        >
            Purchase Order Records
        </button>

    </li>

</ul>


<div
    class="tab-content"
    id="stockInTabsContent"
>


<div
    class="tab-pane fade show active"
    id="stock-form-pane"
    role="tabpanel"
>


<div class="card p-3 mb-3">

<label class="fw-bold">
    Purchase Order
</label>


<select
    id="poSelect"
    class="form-select"
>

<option value="">
    -- Select Approved PO --
</option>

<?php

$poList = $conn->query("
    SELECT
        p.purchases_id,
        s.name

    FROM purchases p

    JOIN suppliers s
        ON s.supplier_id = p.supplier_id

    WHERE p.po_approved = 1
    AND p.status != 'received'

    ORDER BY p.purchases_id DESC
");

while($po = $poList->fetch_assoc()):

?>

<option
    value="<?= $po['purchases_id'] ?>"
    <?= ((int)$po['purchases_id'] === $prefillPoId) ? 'selected' : '' ?>
>

    PO #<?= $po['purchases_id'] ?>
    -
    <?= htmlspecialchars($po['name']) ?>

</option>

<?php endwhile; ?>

</select>

</div>


<?php if($error): ?>

<div
    class="alert alert-danger"
    style="white-space: pre-line;"
>
    <?= htmlspecialchars($error) ?>
</div>

<?php endif; ?>


<?php
if(
    isset($_GET['success'])
    && $_GET['success'] === 'received'
):
?>

<div class="alert alert-success">

    Stock in recorded successfully!
    Purchase order marked as received.

    <br>

    <small class="text-muted">
        This receiving adds a new batch on top of
        the old stock, it does not replace it.
    </small>


    <?php if($receivedSummary): ?>

    <div class="mt-2 small">

        <strong>
            <?= htmlspecialchars(
                $receivedSummary['variety']
                . ' - '
                . $receivedSummary['grade']
            ) ?>
        </strong>

        now has a total of

        <strong>
            <?= number_format(
                (float)(
                    $receivedSummary['stock_kg'] ?? 0
                ),
                2
            ) ?>
            kg
        </strong>

        in stock

        <?php
        if(
            (float)(
                $receivedSummary['unit_weight_kg'] ?? 0
            ) > 0
        ):
        ?>

        (
        about
        <?= number_format(
            (float)(
                $receivedSummary['stock_kg'] ?? 0
            )
            /
            (float)$receivedSummary['unit_weight_kg'],
            0
        ) ?>
        sacks
        )

        <?php endif; ?>

        .

    </div>

    <?php endif; ?>

</div>

<?php endif; ?>


<div class="card legacy-form-shell mt-3 mb-4">

<div class="legacy-header">
    <i class="fas fa-coins"></i>
    Stock In Form
</div>


<form method="POST">

<input
    type="hidden"
    name="purchase_id"
    id="purchase_id"
    value="<?= $prefillPoId > 0 ? (int)$prefillPoId : '' ?>"
>


<div class="legacy-topline">


<div class="legacy-field small">

<label>Stock In No</label>

<input
    type="text"
    class="form-control form-control-sm"
    value="RS-<?= htmlspecialchars(date('Ymd')) ?>"
    readonly
>

</div>


<div class="legacy-field small">

<label>Date Received</label>

<input
    type="date"
    name="purchase_date"
    class="form-control form-control-sm"
    value="<?= htmlspecialchars(date('Y-m-d')) ?>"
    required
>

</div>


<div class="legacy-field small">

<label>Date Delivery</label>

<input
    type="date"
    name="delivery_date"
    class="form-control form-control-sm"
    value=""
>

</div>


<!-- NEW: PAYMENT TYPE -->

<div class="legacy-field small">

<label>Payment Type</label>

<select
    name="payment_type"
    id="paymentType"
    class="form-select form-select-sm"
    required
>

<option value="cash">
    Cash / Paid
</option>

<option value="credit">
    Credit / Utang
</option>

</select>

</div>


<!-- DUE DATE: ONLY SHOWN FOR CREDIT -->

<div
    class="legacy-field small"
    id="dueDateWrapper"
    style="display:none;"
>

<label>Due Date</label>

<input
    type="date"
    name="due_date"
    id="dueDate"
    class="form-control form-control-sm"
    value=""
>

</div>


<div
    class="legacy-field"
    style="flex:1 1 260px;"
>

<label>Note</label>

<input
    type="text"
    name="note"
    class="form-control form-control-sm"
    placeholder="Delivered by supplier / received by staff"
>

</div>

</div>


<div class="legacy-section">

<h3 class="legacy-section-title">
    Rice Information
</h3>


<div class="legacy-box">

<div class="row g-2">


<div class="col-md-6">

<label class="form-label fw-semibold mb-1">
    Product
</label>

<select
    name="product_id"
    id="productSelect"
    class="form-select form-select-sm"
    required
>

<option value="">
    Select product
</option>

<?php while($row = $products->fetch_assoc()): ?>

<option
    value="<?= (int)$row['product_id'] ?>"
    data-weight="<?= (float)$row['unit_weight_kg'] ?>"
    data-variety="<?= htmlspecialchars(
        (string)$row['variety'],
        ENT_QUOTES
    ) ?>"
    data-grade="<?= htmlspecialchars(
        (string)$row['grade'],
        ENT_QUOTES
    ) ?>"
>

<?= htmlspecialchars(
    $row['variety']
    . " - "
    . $row['grade']
    . " ("
    . (float)$row['unit_weight_kg']
    . " kg/sack)"
) ?>

</option>

<?php endwhile; ?>

</select>

</div>


<div class="col-md-2">

<label class="form-label fw-semibold mb-1">
    Sacks In
</label>

<input
    type="number"
    step="1"
    min="1"
    name="qty_sacks"
    id="qtySacks"
    class="form-control form-control-sm"
    required
>

</div>


<div class="col-md-2">

<label class="form-label fw-semibold mb-1">
    Palit / Sack
</label>

<input
    type="number"
    step="0.01"
    min="0"
    name="supplier_price_per_sack"
    id="supplierPrice"
    class="form-control form-control-sm"
    required
>

</div>


<div class="col-md-2">

<label class="form-label fw-semibold mb-1">
    Markup / Kg
</label>

<input
    type="number"
    step="0.01"
    min="0"
    name="markup_per_kg"
    id="markupKg"
    class="form-control form-control-sm"
    value="0.00"
    required
>

</div>

</div>


<input
    type="hidden"
    name="transport_handling"
    id="transportCost"
    value="0"
>

</div>


<div class="table-responsive mt-2">

<table class="table stock-grid mb-0">

<thead>

<tr>
    <th style="width:56px;">No.</th>
    <th>Variety Name</th>
    <th style="width:120px;">Sacks</th>
    <th style="width:140px;">Price</th>
    <th style="width:170px;">Subtotal</th>
</tr>

</thead>

<tbody>

<tr>
    <td>1</td>
    <td id="gridVariety">-</td>
    <td id="gridSacks">0</td>
    <td id="gridPrice">0.00</td>
    <td id="gridSubtotal">0.00</td>
</tr>

</tbody>

</table>

</div>


<div class="total-panel">

    Total (php)

    <span
        class="amount"
        id="previewAmount"
    >
        0.00
    </span>

</div>


<div class="price-panels">


<div class="price-panel">

<div class="label">
    Palit Price (Per Sack)
</div>

<div class="value">
    PHP
    <span id="previewBuyPrice">
        0.00
    </span>
</div>

</div>


<div class="price-panel">

<div class="label">
    Markup Price (Per Kg)
</div>

<div class="value">
    PHP
    <span id="previewMarkupKg">
        0.00
    </span>
</div>

</div>


<div class="price-panel">

<div class="label">
    Baligya Price (Suggested / Kg)
</div>

<div class="value">
    PHP
    <span id="previewSellPrice">
        0.00
    </span>
</div>

</div>


<div class="price-panel">

<div class="label">
    Baligya Price (Per Sack)
</div>

<div class="value">
    PHP
    <span id="previewSellPriceSack">
        0.00
    </span>
</div>

</div>

</div>


<div class="legacy-hint text-end mt-1">

    Unit size:
    <span id="previewUnitWeight">0.00</span>
    kg/sack |

    Total weight:
    <span id="previewTotalKg">0.00</span>
    kg |

    Markup:
    <span id="previewMarkupHint">0.00</span>/kg |

    Suggested sell:
    <span id="previewSellKg">0.00</span>/kg |

    Sell per sack:
    <span id="previewSellSackText">0.00</span>

</div>

</div>


<div class="legacy-section">

<h3 class="legacy-section-title">
    Suppliers Information
</h3>


<div class="legacy-box">

<div class="row g-2">


<div class="col-md-8">

<label class="form-label fw-semibold mb-1">
    Supplier Name
</label>


<div class="d-flex gap-2">

<select
    id="supplierSelect"
    name="supplier_id"
    class="form-select form-select-sm"
    required
>

<option value="">
    Select supplier
</option>

<?php while($s = $suppliers->fetch_assoc()): ?>

<option
    value="<?= (int)$s['supplier_id'] ?>"
    data-phone="<?= htmlspecialchars(
        (string)($s['phone'] ?? ''),
        ENT_QUOTES
    ) ?>"
    data-address="<?= htmlspecialchars(
        (string)($s['address'] ?? ''),
        ENT_QUOTES
    ) ?>"
>

<?= htmlspecialchars($s['name']) ?>

</option>

<?php endwhile; ?>

</select>


<button
    type="button"
    class="btn btn-sm btn-outline-primary"
    data-bs-toggle="modal"
    data-bs-target="#addSupplierModal"
>
    + Add
</button>

</div>

</div>


<div class="col-md-8">

<label class="form-label fw-semibold mb-1">
    Supplier Address
</label>

<input
    type="text"
    id="supplierAddressPreview"
    class="form-control form-control-sm"
    value=""
    readonly
>

</div>


<div class="col-md-4">

<label class="form-label fw-semibold mb-1">
    Contact No
</label>

<input
    type="text"
    id="supplierPhonePreview"
    class="form-control form-control-sm"
    value=""
    readonly
>

</div>

</div>

</div>


<div class="legacy-actions">

<button
    type="submit"
    class="btn btn-success btn-sm"
>

<i class="fas fa-save"></i>
Save

</button>


<a
    href="add_stock.php"
    class="btn btn-outline-secondary btn-sm"
>

<i class="fas fa-times"></i>
Cancel

</a>

</div>


<div class="legacy-hint mt-2">

    For Credit / Utang, if Due Date is blank,
    the system automatically uses +7 days.

</div>

</div>

</form>

</div>

</div>


<!-- PURCHASE ORDER RECORDS TAB -->

<div
    class="tab-pane fade"
    id="done-po-pane"
    role="tabpanel"
>


<div
    class="card done-po-shell mb-4"
    id="donePoSection"
>

<div class="done-po-header">

<i class="fas fa-clipboard-check"></i>
Purchase Order Lists

</div>


<div class="done-po-body">


<div
    class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3"
>

<div>

<h5 class="mb-1">
    Completed PO List
</h5>

<div class="text-muted small">
    Approved POs that are ready for stock-in
    or already recorded as received.
</div>

</div>


<span
    class="badge bg-success"
    id="donePoCountBadge"
>
    <?= count($donePoList) ?> records
</span>

</div>


<div class="table-responsive">

<table class="table done-po-table align-middle mb-0">

<thead>

<tr>
    <th>PO #</th>
    <th>Supplier</th>
    <th>Approved</th>
    <th>Status</th>
    <th class="text-end">Amount</th>
    <th>Received</th>
    <th class="text-end">Action</th>
</tr>

</thead>


<tbody>

<?php if($donePoList): ?>

<?php foreach($donePoList as $po): ?>

<?php

$poId = (int)(
    $po['purchases_id'] ?? 0
);

$status = strtolower(
    (string)($po['status'] ?? 'completed')
);

if(
    !in_array(
        $status,
        ['completed', 'received'],
        true
    )
){
    $status = 'completed';
}

$isReceived = $status === 'received';

$statusLabel =
    $isReceived
    ? 'Received'
    : 'Approved';

$statusClass =
    $isReceived
    ? 'bg-success'
    : 'bg-warning text-dark';

$receivedAt =
    (string)($po['received_at'] ?? '');

$canLoad = !$isReceived;

?>

<tr>

<td class="fw-semibold">
    #<?= $poId ?>
</td>


<td>
    <?= htmlspecialchars(
        (string)($po['supplier_name'] ?? '-')
    ) ?>
</td>


<td>
    <?= !empty($po['po_approved_at'])
        ? htmlspecialchars(
            (string)$po['po_approved_at']
        )
        : '-'
    ?>
</td>


<td>

<span class="badge <?= $statusClass ?>">
    <?= htmlspecialchars($statusLabel) ?>
</span>

</td>


<td class="text-end">

₱<?= number_format(
    (float)($po['total_amount'] ?? 0),
    2
) ?>

</td>


<td>

<?= $receivedAt !== ''
    ? htmlspecialchars($receivedAt)
    : '<span class="text-muted">Not yet</span>'
?>

</td>


<td class="text-end">

<div
    class="d-flex justify-content-end flex-wrap gap-2"
>

<?php if($poId > 0): ?>

<button
    type="button"
    class="btn btn-sm btn-outline-dark"
    data-bs-toggle="modal"
    data-bs-target="#poItemsModal<?= $poId ?>"
>
    View Items
</button>

<?php endif; ?>


<?php if($canLoad): ?>

<a
    class="btn btn-sm btn-outline-primary"
    href="add_stock.php?po_id=<?= $poId ?>"
>
    Load in form
</a>

<?php else: ?>

<span class="badge bg-success align-self-center">
    Received
</span>

<?php endif; ?>

</div>

</td>

</tr>

<?php endforeach; ?>


<?php else: ?>

<tr>

<td
    colspan="7"
    class="text-center text-muted py-4"
>
    No completed purchase orders yet.
</td>

</tr>

<?php endif; ?>

</tbody>

</table>

</div>


<?php foreach($donePoList as $po): ?>

<?php

$poId = (int)(
    $po['purchases_id'] ?? 0
);

if($poId <= 0){
    continue;
}

$poItems =
    $donePoItemMap[$poId] ?? [];

?>


<div
    class="modal fade"
    id="poItemsModal<?= $poId ?>"
    tabindex="-1"
    aria-hidden="true"
>

<div
    class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable"
>

<div class="modal-content">


<div class="modal-header bg-dark text-white">

<div>

<h5 class="modal-title mb-0">
    PO #<?= $poId ?> Items
</h5>

<div class="small text-white-50">

<?= htmlspecialchars(
    (string)($po['supplier_name'] ?? '-')
) ?>

</div>

</div>


<button
    type="button"
    class="btn-close btn-close-white"
    data-bs-dismiss="modal"
    aria-label="Close"
></button>

</div>


<div class="modal-body">

<?php if($poItems): ?>

<div class="table-responsive">

<table class="table done-po-table align-middle mb-0">

<thead>

<tr>
    <th>Product</th>
    <th class="text-end">Qty (sacks)</th>
    <th class="text-end">Price / Sack</th>
    <th class="text-end">Line Total</th>
</tr>

</thead>


<tbody>

<?php foreach($poItems as $item): ?>

<?php

$variety =
    trim(
        (string)($item['variety'] ?? '')
    );

$grade =
    trim(
        (string)($item['grade'] ?? '')
    );

$productName =
    trim(
        $variety
        .
        (
            $variety !== ''
            && $grade !== ''
            ? ' - '
            : ''
        )
        .
        $grade
    );

if($productName === ''){
    $productName = 'Unknown product';
}

?>

<tr>

<td>
    <?= htmlspecialchars($productName) ?>
</td>

<td class="text-end">

<?= number_format(
    (float)($item['quantity_sacks'] ?? 0),
    2
) ?>

</td>

<td class="text-end">

₱<?= number_format(
    (float)($item['supplier_price'] ?? 0),
    2
) ?>

</td>

<td class="text-end">

₱<?= number_format(
    (float)($item['line_total'] ?? 0),
    2
) ?>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>


<?php else: ?>

<div class="alert alert-light border mb-0">
    No line items were found for this purchase order.
</div>

<?php endif; ?>

</div>


<div class="modal-footer">

<span class="text-muted small me-auto">

Approved:

<?= !empty($po['po_approved_at'])
    ? htmlspecialchars(
        (string)$po['po_approved_at']
    )
    : '-'
?>

</span>


<button
    type="button"
    class="btn btn-secondary"
    data-bs-dismiss="modal"
>
    Close
</button>

</div>

</div>
</div>
</div>

<?php endforeach; ?>

</div>
</div>
</div>

</div>

</main>

</div>
</div>


<!-- ADD SUPPLIER MODAL -->

<div
    class="modal fade"
    id="addSupplierModal"
    tabindex="-1"
    aria-hidden="true"
>

<div class="modal-dialog">

<div class="modal-content">


<div class="modal-header">

<h5 class="modal-title">
    Add Supplier
</h5>

<button
    type="button"
    class="btn-close"
    data-bs-dismiss="modal"
></button>

</div>


<div class="modal-body">

<div
    id="supplierModalAlert"
    class="alert d-none"
></div>


<div class="mb-3">

<label class="form-label">
    Supplier Name *
</label>

<input
    type="text"
    id="modalSupplierName"
    class="form-control"
    placeholder="e.g. ABC Rice Trading"
>

</div>


<div class="mb-3">

<label class="form-label">
    Phone (optional)
</label>

<input
    type="text"
    id="modalSupplierPhone"
    class="form-control"
    placeholder="e.g. 09123456789"
>

</div>


<div class="mb-3">

<label class="form-label">
    Address (optional)
</label>

<textarea
    id="modalSupplierAddress"
    class="form-control"
    rows="2"
    placeholder="e.g. CDO"
></textarea>

</div>

</div>


<div class="modal-footer">

<button
    type="button"
    class="btn btn-secondary"
    data-bs-dismiss="modal"
>
    Cancel
</button>


<button
    type="button"
    id="saveSupplierBtn"
    class="btn btn-primary"
>
    Save Supplier
</button>

</div>

</div>
</div>
</div>


<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
></script>

<script
    src="../js/inventory-add-stock.js?v=markup-1"
></script>


<script>

/*
|--------------------------------------------------------------------------
| STOCK IN PREVIEW
|--------------------------------------------------------------------------
*/

(function () {

function updateStockInPreviewFallback() {

    const markupInput =
        document.getElementById('markupKg');

    const value =
        parseFloat(markupInput?.value || '0');

    const markup =
        Number.isFinite(value) && value > 0
        ? value
        : 0;


    const productSelect =
        document.getElementById('productSelect');


    const selected =
        productSelect
        ? productSelect.options[
            productSelect.selectedIndex
        ]
        : null;


    const unitWeight =
        parseFloat(
            selected?.getAttribute('data-weight')
            || '0'
        )
        || 0;


    const variety =
        (
            selected?.getAttribute('data-variety')
            || ''
        ).trim();


    const grade =
        (
            selected?.getAttribute('data-grade')
            || ''
        ).trim();


    const sacks =
        parseFloat(
            document
            .getElementById('qtySacks')
            ?.value
            || '0'
        )
        || 0;


    const pricePerSack =
        parseFloat(
            document
            .getElementById('supplierPrice')
            ?.value
            || '0'
        )
        || 0;


    const transport =
        parseFloat(
            document
            .getElementById('transportCost')
            ?.value
            || '0'
        )
        || 0;


    const subtotal =
        sacks * pricePerSack;


    const totalAmount =
        subtotal + transport;


    const totalKg =
        sacks * unitWeight;


    const landedPerSack =
        pricePerSack
        +
        (
            sacks > 0
            ? transport / sacks
            : 0
        );


    const costPerKg =
        unitWeight > 0
        ? landedPerSack / unitWeight
        : 0;


    const sellKg =
        costPerKg + markup;


    const sellSack =
        sellKg * unitWeight;


    const updates = {

        previewMarkupKg: markup,

        previewMarkupHint: markup,

        previewSellKg: sellKg,

        previewSellPrice: sellKg,

        previewSellPriceSack: sellSack,

        previewSellSackText: sellSack,

        previewUnitWeight: unitWeight,

        previewTotalKg: totalKg,

        previewAmount: totalAmount,

        previewBuyPrice: pricePerSack,

        gridSacks: sacks,

        gridPrice: pricePerSack,

        gridSubtotal: subtotal

    };


    Object.keys(updates).forEach(function(id){

        const el =
            document.getElementById(id);

        if(el){
            el.textContent =
                updates[id].toFixed(2);
        }

    });


    const gridVariety =
        document.getElementById('gridVariety');


    if(gridVariety){

        gridVariety.textContent =
            [variety, grade]
            .filter(Boolean)
            .join(' - ')
            || '-';
    }
}


[
    'productSelect',
    'qtySacks',
    'supplierPrice',
    'markupKg',
    'transportCost'
].forEach(function(id){

    const el =
        document.getElementById(id);

    if(!el){
        return;
    }

    el.addEventListener(
        'input',
        updateStockInPreviewFallback
    );

    el.addEventListener(
        'change',
        updateStockInPreviewFallback
    );

});


updateStockInPreviewFallback();

})();


/*
|--------------------------------------------------------------------------
| SHOW / HIDE DUE DATE
|--------------------------------------------------------------------------
*/

(function(){

    const paymentType =
        document.getElementById('paymentType');

    const dueDateWrapper =
        document.getElementById('dueDateWrapper');

    const dueDate =
        document.getElementById('dueDate');


    function updatePaymentType(){

        if(!paymentType || !dueDateWrapper){
            return;
        }


        if(paymentType.value === 'credit'){

            dueDateWrapper.style.display = '';


            /*
            | Automatically set +7 days if empty
            */

            if(dueDate && !dueDate.value){

                const receivedDateInput =
                    document.querySelector(
                        'input[name="purchase_date"]'
                    );


                let baseDate =
                    receivedDateInput?.value
                    ? new Date(
                        receivedDateInput.value
                        + 'T00:00:00'
                    )
                    : new Date();


                baseDate.setDate(
                    baseDate.getDate() + 7
                );


                const yyyy =
                    baseDate.getFullYear();


                const mm =
                    String(
                        baseDate.getMonth() + 1
                    ).padStart(2, '0');


                const dd =
                    String(
                        baseDate.getDate()
                    ).padStart(2, '0');


                dueDate.value =
                    yyyy
                    + '-'
                    + mm
                    + '-'
                    + dd;
            }

        } else {

            dueDateWrapper.style.display = 'none';

            if(dueDate){
                dueDate.value = '';
            }
        }
    }


    if(paymentType){

        paymentType.addEventListener(
            'change',
            updatePaymentType
        );

        updatePaymentType();
    }

})();


/*
|--------------------------------------------------------------------------
| LIVE PO DATA POLLING
|--------------------------------------------------------------------------
*/

(function(){

    const pollIntervalMs = 3000;

    let pollingInFlight = false;


    function isPoItemsModalOpen(){

        return Boolean(
            document.querySelector(
                '[id^="poItemsModal"].show'
            )
        );
    }


    function syncSelectOptions(
        sourceSelect,
        targetSelect
    ){

        if(!sourceSelect || !targetSelect){
            return;
        }


        const currentValue =
            targetSelect.value;


        targetSelect.innerHTML =
            sourceSelect.innerHTML;


        if(
            currentValue
            &&
            Array
            .from(targetSelect.options)
            .some(
                (opt) =>
                    opt.value === currentValue
            )
        ){

            targetSelect.value =
                currentValue;
        }
    }


    async function pollAddStockLiveData(){

        if(pollingInFlight){
            return;
        }

        // Replacing the PO section also removes its Bootstrap modals. Do not
        // refresh it while a "View Items" modal owns the page backdrop.
        if(isPoItemsModalOpen()){
            return;
        }

        pollingInFlight = true;


        try {

            const url =
                new URL(window.location.href);

            url.searchParams.set(
                'ajax',
                'live'
            );


            const response =
                await fetch(
                    url.toString(),
                    {
                        credentials: 'same-origin',
                        headers: {
                            'X-Requested-With':
                                'XMLHttpRequest'
                        }
                    }
                );


            const html =
                await response.text();


            const doc =
                new DOMParser()
                .parseFromString(
                    html,
                    'text/html'
                );

            // A modal may have opened while this request was in flight.
            // Keeping the existing markup avoids a stranded gray backdrop.
            if(isPoItemsModalOpen()){
                return;
            }


            syncSelectOptions(
                doc.getElementById('poSelect'),
                document.getElementById('poSelect')
            );


            const sourceSection =
                doc.getElementById('donePoSection');

            const targetSection =
                document.getElementById('donePoSection');


            if(sourceSection && targetSection){

                targetSection.innerHTML =
                    sourceSection.innerHTML;
            }


            const sourceBadge =
                doc.getElementById('donePoCountBadge');

            const targetBadge =
                document.getElementById('donePoCountBadge');


            if(sourceBadge && targetBadge){

                targetBadge.textContent =
                    sourceBadge.textContent;
            }


        } catch(error){

            console.error(
                'Stock-in live poll failed:',
                error
            );

        } finally {

            pollingInFlight = false;
        }
    }


    pollAddStockLiveData();


    window.setInterval(
        pollAddStockLiveData,
        pollIntervalMs
    );

})();


/*
|--------------------------------------------------------------------------
| LOAD SELECTED PO DETAILS INTO FORM
|--------------------------------------------------------------------------
*/

function applyPoDetails(data){

    if(!data || data.error){
        return;
    }


    const supplierSelect =
        document.getElementById('supplierSelect');

    const productSelect =
        document.getElementById('productSelect');

    const qtySacks =
        document.getElementById('qtySacks');

    const supplierPrice =
        document.getElementById('supplierPrice');

    const purchaseId =
        document.getElementById('purchase_id');


    if(supplierSelect){
        supplierSelect.value =
            data.supplier_id || '';
    }


    if(productSelect){
        productSelect.value =
            data.product_id || '';
    }


    if(qtySacks){
        qtySacks.value =
            data.qty_sacks || '';
    }


    if(supplierPrice){
        supplierPrice.value =
            data.price_per_sack || '';
    }


    if(purchaseId){

        purchaseId.value =
            data.purchase_id
            || data.purchases_id
            || '';
    }


    supplierSelect?.dispatchEvent(
        new Event(
            'change',
            { bubbles: true }
        )
    );


    productSelect?.dispatchEvent(
        new Event(
            'change',
            { bubbles: true }
        )
    );


    qtySacks?.dispatchEvent(
        new Event(
            'input',
            { bubbles: true }
        )
    );


    supplierPrice?.dispatchEvent(
        new Event(
            'input',
            { bubbles: true }
        )
    );
}


const poSelect =
    document.getElementById('poSelect');


if(poSelect){

    poSelect.addEventListener(
        'change',
        function(){

            const id = this.value;

            if(!id){
                return;
            }


            fetch(
                'get_po_details.php?id='
                + encodeURIComponent(id)
            )

            .then(
                response => response.json()
            )

            .then(
                applyPoDetails
            )

            .catch(
                error => {
                    console.error(error);
                }
            );

        }
    );


    if(poSelect.value){

        poSelect.dispatchEvent(
            new Event('change')
        );
    }
}

</script>

</body>
</html>
