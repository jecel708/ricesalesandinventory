<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit;
}
if(strtolower($_SESSION['role'] ?? '') !== 'admin'){
    header("Location: ../login.php");
    exit;
}

$username = $_SESSION['username'] ?? 'Admin';
include '../config/db.php';

$LEAD_TIME_DAYS = 2;
$SAFETY_STOCK_KG = 10;
$TARGET_DAYS_COVER = 7;
$RESTOCK_LOOKBACK_DAYS = 30;

/* Tunable controls from query params */
$LEAD_TIME_DAYS    = (int)($_GET['lead'] ?? $LEAD_TIME_DAYS);
$SAFETY_STOCK_KG   = (float)($_GET['safety'] ?? $SAFETY_STOCK_KG);
$TARGET_DAYS_COVER = (int)($_GET['cover'] ?? $TARGET_DAYS_COVER);
$RESTOCK_LOOKBACK_DAYS = (int)($_GET['lookback'] ?? $RESTOCK_LOOKBACK_DAYS);

if($LEAD_TIME_DAYS < 1) $LEAD_TIME_DAYS = 1;
if($LEAD_TIME_DAYS > 30) $LEAD_TIME_DAYS = 30;
if($SAFETY_STOCK_KG < 0) $SAFETY_STOCK_KG = 0;
if($SAFETY_STOCK_KG > 10000) $SAFETY_STOCK_KG = 10000;
if($TARGET_DAYS_COVER < 1) $TARGET_DAYS_COVER = 1;
if($TARGET_DAYS_COVER > 60) $TARGET_DAYS_COVER = 60;
if($RESTOCK_LOOKBACK_DAYS < 7) $RESTOCK_LOOKBACK_DAYS = 7;
if($RESTOCK_LOOKBACK_DAYS > 180) $RESTOCK_LOOKBACK_DAYS = 180;

$VALID_SALE_STATUSES = "('paid','unpaid','partial')";

function forecast_sma($series, $periods = 3, $window = 3) {
    $result = [];
    $data = $series;
    for($i = 0; $i < $periods; $i++){
        $slice = array_slice($data, -$window);
        $avg = array_sum($slice) / max(1, count($slice));
        $result[] = round($avg, 2);
        $data[] = $avg;
    }
    return $result;
}

function forecast_linear($series, $periods = 3) {
    $n = count($series);
    if($n < 2) return forecast_sma($series, $periods, 3);
    $x_sum = array_sum(range(1, $n));
    $y_sum = array_sum($series);
    $xy_sum = $x2_sum = 0;
    for($i = 0; $i < $n; $i++){
        $x = $i + 1;
        $xy_sum += $x * $series[$i];
        $x2_sum += $x * $x;
    }
    $slope = ($n * $xy_sum - $x_sum * $y_sum) / ($n * $x2_sum - $x_sum * $x_sum);
    $intercept = ($y_sum - $slope * $x_sum) / $n;
    $result = [];
    for($i = 1; $i <= $periods; $i++){
        $result[] = round(max(0, $intercept + $slope * ($n + $i)), 2);
    }
    return $result;
}

function forecast_exponential($series, $periods = 3, $alpha = 0.3) {
    $n = count($series);
    if($n < 2) return forecast_sma($series, $periods, 3);
    $ses = $series[0];
    for($i = 1; $i < $n; $i++){
        $ses = $alpha * $series[$i] + (1 - $alpha) * $ses;
    }
    $result = [];
    for($i = 0; $i < $periods; $i++){
        $result[] = round(max(0, $ses), 2);
    }
    return $result;
}

function mean_absolute_error($actual, $predicted) {
    $sum = 0;
    $count = 0;
    foreach($actual as $i => $val){
        if(isset($predicted[$i]) && $val !== null && $predicted[$i] !== null){
            $sum += abs($val - $predicted[$i]);
            $count++;
        }
    }
    return $count > 0 ? $sum / $count : 9999;
}

function pick_best_algorithm($series, $periods = 3) {
    $n = count($series);
    if($n < 3) return ['name' => 'Moving Average (SMA)', 'key' => 'sma', 'forecast' => forecast_sma($series, $periods, 3)];

    $testActual = array_slice($series, 0, $n - 1);
    $holdout = array_slice($series, $n - 1, 1);

    $smaF = forecast_sma($testActual, 1, 3);
    $linF = forecast_linear($testActual, 1);
    $expF = forecast_exponential($testActual, 1, 0.3);

    $errSma = mean_absolute_error($holdout, $smaF);
    $errLin = mean_absolute_error($holdout, $linF);
    $errExp = mean_absolute_error($holdout, $expF);

    $errors = [
        ['key' => 'sma',    'name' => 'Moving Average (SMA)',      'err' => $errSma],
        ['key' => 'linear', 'name' => 'Linear Regression',          'err' => $errLin],
        ['key' => 'exp',    'name' => 'Exponential Smoothing',      'err' => $errExp],
    ];

    usort($errors, fn($a,$b) => $a['err'] <=> $b['err']);
    $best = $errors[0];
    $best['forecast'] = match($best['key']) {
        'sma'    => forecast_sma($series, $periods, 3),
        'linear' => forecast_linear($series, $periods),
        'exp'    => forecast_exponential($series, $periods, 0.3),
    };
    return $best;
}

/* -----------------------------
   SALES PER PRODUCT
------------------------------ */
$salesPerProduct = [];
$sql = "
SELECT
    p.product_id,
    CONCAT(p.variety,' - ',p.grade) AS product_label,
    SUM(si.qty_kg) AS total_sold_kg
FROM sales_items si
JOIN sales s ON si.sale_id = s.sale_id
JOIN products p ON si.product_id = p.product_id
WHERE LOWER(s.status) IN $VALID_SALE_STATUSES
GROUP BY p.product_id
ORDER BY total_sold_kg DESC
";
$result = $conn->query($sql);
if($result){
    while($row = $result->fetch_assoc()){
        $row['total_sold_kg'] = (float)($row['total_sold_kg'] ?? 0);
        $salesPerProduct[] = $row;
    }
}

/* -----------------------------
   SALES OVER TIME
------------------------------ */
$months = [];
$salesKgData = [];

$sql = "
SELECT
    DATE_FORMAT(s.sale_date,'%b %Y') AS month_label,
    YEAR(s.sale_date) AS y,
    MONTH(s.sale_date) AS m,
    COALESCE(SUM(si.qty_kg),0) AS total_kg
FROM sales_items si
JOIN sales s ON si.sale_id = s.sale_id
WHERE LOWER(s.status) IN $VALID_SALE_STATUSES
GROUP BY y, m, month_label
ORDER BY y, m
";
$result = $conn->query($sql);
if($result){
    while($row = $result->fetch_assoc()){
        $months[] = $row['month_label'];
        $salesKgData[] = (float)$row['total_kg'];
    }
}

// Calendar filters for the sales trend chart. Keep the existing all-time monthly
// series above for the forecast and dashboard KPIs.
$trendInterval = strtolower(trim((string)($_GET['trend_interval'] ?? 'month')));
if(!in_array($trendInterval, ['day', 'week', 'month'], true)) $trendInterval = 'month';
$trendStart = trim((string)($_GET['trend_start'] ?? ''));
$trendEnd = trim((string)($_GET['trend_end'] ?? ''));
$validDate = static function(string $value): bool {
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    return $date instanceof DateTimeImmutable && $date->format('Y-m-d') === $value;
};
$dateBounds = $conn->query("SELECT MIN(DATE(sale_date)) AS first_sale, MAX(DATE(sale_date)) AS last_sale FROM sales");
$dateBoundRow = $dateBounds ? $dateBounds->fetch_assoc() : [];
$defaultTrendStart = (string)($dateBoundRow['first_sale'] ?? '');
$defaultTrendEnd = (string)($dateBoundRow['last_sale'] ?? '');
if(!$validDate($defaultTrendStart)) $defaultTrendStart = date('Y-m-d', strtotime('-1 year'));
if(!$validDate($defaultTrendEnd)) $defaultTrendEnd = date('Y-m-d');
if(!$validDate($trendStart)) $trendStart = $defaultTrendStart;
if(!$validDate($trendEnd)) $trendEnd = $defaultTrendEnd;
if($trendStart > $trendEnd){
    [$trendStart, $trendEnd] = [$trendEnd, $trendStart];
}

$trendPeriodExpr = match($trendInterval) {
    'day' => 'DATE(s.sale_date)',
    'week' => 'DATE_SUB(DATE(s.sale_date), INTERVAL WEEKDAY(s.sale_date) DAY)',
    default => "DATE_FORMAT(s.sale_date, '%Y-%m-01')",
};
$trendTotals = [];
$trendStmt = $conn->prepare("SELECT {$trendPeriodExpr} AS period_start, COALESCE(SUM(si.qty_kg),0) AS total_kg
    FROM sales_items si JOIN sales s ON s.sale_id = si.sale_id
    WHERE LOWER(s.status) IN $VALID_SALE_STATUSES AND DATE(s.sale_date) BETWEEN ? AND ?
    GROUP BY period_start ORDER BY period_start");
if($trendStmt){
    $trendStmt->bind_param('ss', $trendStart, $trendEnd);
    if($trendStmt->execute()){
        $trendResult = $trendStmt->get_result();
        while($trendRow = $trendResult->fetch_assoc()){
            $trendTotals[(string)$trendRow['period_start']] = (float)$trendRow['total_kg'];
        }
    }
    $trendStmt->close();
}
$trendLabels = [];
$trendSalesData = [];
$rangeStart = new DateTimeImmutable($trendStart);
$rangeEnd = new DateTimeImmutable($trendEnd);
if($trendInterval === 'week'){
    $rangeStart = $rangeStart->modify('monday this week');
    $rangeEnd = $rangeEnd->modify('monday this week');
    $step = new DateInterval('P7D');
} elseif($trendInterval === 'month'){
    $rangeStart = $rangeStart->modify('first day of this month');
    $rangeEnd = $rangeEnd->modify('first day of this month');
    $step = new DateInterval('P1M');
} else {
    $step = new DateInterval('P1D');
}
$periods = new DatePeriod($rangeStart, $step, $rangeEnd->modify('+1 day'));
foreach($periods as $periodDate){
    $key = $periodDate->format('Y-m-d');
    $trendLabels[] = match($trendInterval) {
        'day' => $periodDate->format('M j, Y'),
        'week' => 'Week of ' . $periodDate->format('M j, Y'),
        default => $periodDate->format('M Y'),
    };
    $trendSalesData[] = (float)($trendTotals[$key] ?? 0);
}

// Product-by-product sales for the same selected calendar range.
$allProductSalesLabels = [];
$allProductSalesKg = [];
$productSalesStmt = $conn->prepare("SELECT p.product_id, CONCAT(p.variety, ' - ', p.grade) AS product_label,
        COALESCE(SUM(CASE WHEN s.sale_id IS NOT NULL THEN si.qty_kg ELSE 0 END), 0) AS sold_kg
    FROM products p
    LEFT JOIN sales_items si ON si.product_id = p.product_id
    LEFT JOIN sales s ON s.sale_id = si.sale_id
        AND LOWER(s.status) IN $VALID_SALE_STATUSES
        AND DATE(s.sale_date) BETWEEN ? AND ?
    GROUP BY p.product_id, p.variety, p.grade
    ORDER BY sold_kg DESC, product_label ASC");
if($productSalesStmt){
    $productSalesStmt->bind_param('ss', $trendStart, $trendEnd);
    if($productSalesStmt->execute()){
        $productSalesResult = $productSalesStmt->get_result();
        while($productSalesRow = $productSalesResult->fetch_assoc()){
            $allProductSalesLabels[] = (string)$productSalesRow['product_label'];
            $allProductSalesKg[] = (float)$productSalesRow['sold_kg'];
        }
    }
    $productSalesStmt->close();
}

$topProduct = $salesPerProduct[0]['product_label'] ?? 'N/A';
$totalSoldKg = array_sum($salesKgData);

$totalMonths = count($salesKgData);
$growth = 0;
if($totalMonths >= 2 && (float)$salesKgData[$totalMonths - 2] > 0){
    $growth = (($salesKgData[$totalMonths - 1] - $salesKgData[$totalMonths - 2]) / $salesKgData[$totalMonths - 2]) * 100;
}

/* -----------------------------
   FORECAST — AUTO BEST ALGORITHM
------------------------------ */
function nextMonthsLabels($n = 3){
    $labels = [];
    $dt = new DateTime('first day of this month');
    for($i = 1; $i <= $n; $i++){
        $dt->modify('+1 month');
        $labels[] = $dt->format('M Y');
    }
    return $labels;
}

$forecastLabels = nextMonthsLabels(3);
$bestAlgo = ['name' => 'Moving Average (SMA)', 'key' => 'sma', 'forecast' => [0,0,0]];
if(count($salesKgData) >= 2){
    $bestAlgo = pick_best_algorithm($salesKgData);
}
$forecastData = $bestAlgo['forecast'];
$algoName = $bestAlgo['name'];

$combinedLabels = array_merge($months, $forecastLabels);
$actualPadded = array_merge($salesKgData, array_fill(0, count($forecastLabels), null));
$forecastPadded = array_merge(array_fill(0, count($months), null), $forecastData);

$forecastTable = [];
for($i = 0; $i < count($forecastLabels); $i++){
    $forecastTable[] = [
        'month' => $forecastLabels[$i],
        'pred'  => $forecastData[$i]
    ];
}

// Build zero-filled daily and weekly sales series so quiet periods remain part of the forecast.
$dailyStart = new DateTimeImmutable('today -29 days');
$today = new DateTimeImmutable('today');
$dailyByDate = [];
$dailyRes = $conn->query("
    SELECT DATE(s.sale_date) AS sale_day, COALESCE(SUM(si.qty_kg), 0) AS total_kg
    FROM sales_items si
    JOIN sales s ON s.sale_id = si.sale_id
    WHERE LOWER(s.status) IN $VALID_SALE_STATUSES
      AND DATE(s.sale_date) BETWEEN '{$dailyStart->format('Y-m-d')}' AND '{$today->format('Y-m-d')}'
    GROUP BY DATE(s.sale_date)
    ORDER BY sale_day
");
if($dailyRes){
    while($row = $dailyRes->fetch_assoc()) $dailyByDate[(string)$row['sale_day']] = (float)$row['total_kg'];
}
$dailySeries = [];
for($offset = 0; $offset < 30; $offset++){
    $day = $dailyStart->modify("+{$offset} days");
    $dailySeries[] = (float)($dailyByDate[$day->format('Y-m-d')] ?? 0);
}
$dailyBest = pick_best_algorithm($dailySeries, 7);
$dailyForecast = [];
for($offset = 1; $offset <= 7; $offset++){
    $dailyForecast[] = [
        'label' => $today->modify("+{$offset} days")->format('D, M j'),
        'value' => (float)($dailyBest['forecast'][$offset - 1] ?? 0),
    ];
}

$weekStart = $today->modify('monday this week')->modify('-11 weeks');
$weekEnd = $today;
$weeklyByDate = [];
$weeklyDailyRes = $conn->query("
    SELECT DATE(s.sale_date) AS sale_day, COALESCE(SUM(si.qty_kg), 0) AS total_kg
    FROM sales_items si
    JOIN sales s ON s.sale_id = si.sale_id
    WHERE LOWER(s.status) IN $VALID_SALE_STATUSES
      AND DATE(s.sale_date) BETWEEN '{$weekStart->format('Y-m-d')}' AND '{$weekEnd->format('Y-m-d')}'
    GROUP BY DATE(s.sale_date)
    ORDER BY sale_day
");
if($weeklyDailyRes){
    while($row = $weeklyDailyRes->fetch_assoc()) $weeklyByDate[(string)$row['sale_day']] = (float)$row['total_kg'];
}
$weeklySeries = [];
for($weekOffset = 0; $weekOffset < 12; $weekOffset++){
    $week = $weekStart->modify("+{$weekOffset} weeks");
    $weekTotal = 0.0;
    for($dayOffset = 0; $dayOffset < 7; $dayOffset++){
        $day = $week->modify("+{$dayOffset} days");
        if($day > $today) break;
        $weekTotal += (float)($weeklyByDate[$day->format('Y-m-d')] ?? 0);
    }
    $weeklySeries[] = $weekTotal;
}
$weeklyBest = pick_best_algorithm($weeklySeries, 4);
$weeklyForecast = [];
$nextWeekStart = $today->modify('monday this week')->modify('+1 week');
for($offset = 0; $offset < 4; $offset++){
    $periodStart = $nextWeekStart->modify("+{$offset} weeks");
    $weeklyForecast[] = [
        'label' => $periodStart->format('M j') . ' – ' . $periodStart->modify('+6 days')->format('M j'),
        'value' => (float)($weeklyBest['forecast'][$offset] ?? 0),
    ];
}

/* -----------------------------
   SALES BY DAY OF WEEK
------------------------------ */
$daysOrder = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
$daySalesMap = array_fill_keys($daysOrder, 0.0);

$sql = "
SELECT
    DAYOFWEEK(s.sale_date) AS dow,
    SUM(si.qty_kg) AS total_kg
FROM sales_items si
JOIN sales s ON si.sale_id = s.sale_id
WHERE LOWER(s.status) IN $VALID_SALE_STATUSES
  AND s.sale_date >= (CURDATE() - INTERVAL 90 DAY)
GROUP BY dow
";
$res = $conn->query($sql);
if($res){
    while($r = $res->fetch_assoc()){
        $dow = (int)$r['dow'];
        $kg = (float)$r['total_kg'];
        $labelMap = [1=>'Sun',2=>'Mon',3=>'Tue',4=>'Wed',5=>'Thu',6=>'Fri',7=>'Sat'];
        $daySalesMap[$labelMap[$dow]] = $kg;
    }
}
$daySalesLabels = array_keys($daySalesMap);
$daySalesData = array_values($daySalesMap);

$peakDay = 'N/A';
$peakKg = 0;
foreach($daySalesMap as $d => $kg){
    if($kg > $peakKg){
        $peakKg = $kg;
        $peakDay = $d;
    }
}

/* -----------------------------
   RESTOCK / STOCK
------------------------------ */
$restockRows = [];
$fastMovers = [];
$slowMovers = [];
$deadStock = [];

$sql = "
SELECT
    p.product_id,
    CONCAT(p.variety,' - ',p.grade) AS product_label,

    IFNULL(SUM(
        CASE
            WHEN LOWER(it.type)='in' THEN it.qty_kg
            WHEN LOWER(it.type)='out' THEN -it.qty_kg
            WHEN LOWER(it.type)='adjust' THEN it.qty_kg
            ELSE 0
        END
    ), 0) AS current_stock,

    (
        SELECT IFNULL(SUM(si.qty_kg),0)
        FROM sales_items si
        JOIN sales s ON s.sale_id = si.sale_id
        WHERE si.product_id = p.product_id
          AND LOWER(s.status) IN $VALID_SALE_STATUSES
          AND s.sale_date >= (CURDATE() - INTERVAL {$RESTOCK_LOOKBACK_DAYS} DAY)
    ) AS sold_last_n

FROM products p
LEFT JOIN inventory_transactions it ON it.product_id = p.product_id
WHERE p.archived = 0
GROUP BY p.product_id
ORDER BY sold_last_n DESC
";
$res = $conn->query($sql);
$allProdForRestock = [];
if($res){
    while($r = $res->fetch_assoc()){
        $r['current_stock'] = (float)($r['current_stock'] ?? 0);
        $r['sold_last_n'] = (float)($r['sold_last_n'] ?? 0);
        $allProdForRestock[] = $r;
    }
}

foreach($allProdForRestock as &$r){
    $current = (float)$r['current_stock'];
    $soldN = (float)$r['sold_last_n'];

    $avgDaily = $soldN / max(1, $RESTOCK_LOOKBACK_DAYS);
    $reorderPoint = ($avgDaily * $LEAD_TIME_DAYS) + $SAFETY_STOCK_KG;
    $targetStock = ($avgDaily * $TARGET_DAYS_COVER) + $SAFETY_STOCK_KG;

    $suggested = $targetStock - $current;
    if($suggested < 0) $suggested = 0;

    $status = 'OK';
    if($current <= 0) $status = 'OUT';
    else if($current <= $reorderPoint) $status = 'REORDER';

    $r['_avgDaily'] = $avgDaily;
    $r['_reorderPoint'] = $reorderPoint;
    $r['_targetStock'] = $targetStock;
    $r['_suggested'] = $suggested;
    $r['_status'] = $status;
    $r['_daysCover'] = $avgDaily > 0 ? round($current / $avgDaily, 1) : 999;
}
unset($r);

$restockCandidates = array_filter($allProdForRestock, fn($r) => $r['_status'] !== 'OK');
usort($restockCandidates, function($a, $b) {
    $prio = ['OUT'=>0,'REORDER'=>1,'OK'=>2];
    $pa = $prio[$a['_status']] ?? 9;
    $pb = $prio[$b['_status']] ?? 9;
    if($pa !== $pb) return $pa <=> $pb;
    return (float)$a['_daysCover'] <=> (float)$b['_daysCover'];
});
$restockRows = array_slice($restockCandidates, 0, 8);
$suggestedRestockTotalKg = array_sum(array_map(fn($r) => (float)$r['_suggested'], $restockCandidates));
$suggestedRestockProductCount = count($restockCandidates);

$fastMovers = array_slice($allProdForRestock, 0, 5);

$slowMovers = $allProdForRestock;
usort($slowMovers, fn($a, $b) => (float)$a['sold_last_n'] <=> (float)$b['sold_last_n']);
$slowMovers = array_slice($slowMovers, 0, 5);

foreach($allProdForRestock as $r){
    if((float)$r['current_stock'] > 0 && (float)$r['sold_last_n'] <= 0){
        $deadStock[] = $r;
    }
}
$deadStock = array_slice($deadStock, 0, 5);

$fastTop = $fastMovers[0] ?? null;
$slowTop = $slowMovers[0] ?? null;

$maxFastSold = 0.0;
$maxSlowSold = 0.0;

foreach($fastMovers as $r){
    if((float)$r['sold_last_n'] > $maxFastSold) $maxFastSold = (float)$r['sold_last_n'];
}
foreach($slowMovers as $r){
    if((float)$r['sold_last_n'] > $maxSlowSold) $maxSlowSold = (float)$r['sold_last_n'];
}

$restockAlertCount = count($restockCandidates);
$fastRestockCandidates = array_values(array_filter($restockCandidates, fn($r) => (float)$r['sold_last_n'] > 0));
usort($fastRestockCandidates, fn($a, $b) => (float)$b['sold_last_n'] <=> (float)$a['sold_last_n']);
$fastRestockLabels = array_map(fn($r) => (string)$r['product_label'], $fastRestockCandidates);
$fastRestockSoldKg = array_map(fn($r) => (float)$r['sold_last_n'], $fastRestockCandidates);
$fastRestockSuggestedKg = array_map(fn($r) => (float)$r['_suggested'], $fastRestockCandidates);
$outOfStockCount = count(array_filter($allProdForRestock, fn($r) => $r['_status']==='OUT'));
$slowMovingCount = count(array_filter($allProdForRestock, fn($r) => (float)$r['sold_last_n'] <= 5));
$totalSoldLastN = array_sum(array_column($allProdForRestock, 'sold_last_n'));

$growthClass = ($growth >= 0) ? 'text-success' : 'text-danger';
$growthIcon = ($growth >= 0) ? 'fa-arrow-trend-up' : 'fa-arrow-trend-down';

/* -----------------------------
   CHART DATA
------------------------------ */
$topProdLabels = [];
$topProdKg = [];
foreach(array_slice($salesPerProduct, 0, 10) as $r){
    $topProdLabels[] = (string)$r['product_label'];
    $topProdKg[] = (float)$r['total_sold_kg'];
}

$stockLabels = [];
$stockData = [];
$stockSorted = $allProdForRestock;
usort($stockSorted, fn($a, $b) => (float)$b['current_stock'] <=> (float)$a['current_stock']);
foreach(array_slice($stockSorted, 0, 10) as $r){
    $stockLabels[] = (string)$r['product_label'];
    $stockData[] = (float)$r['current_stock'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Analytics & Forecasting | DE ORO HIYS</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <link href="../css/layout.css" rel="stylesheet">
    <link href="../css/admin-mobile.css" rel="stylesheet">
    <link href="../css/admin-analytics.css" rel="stylesheet">
    <link href="../css/report-print.css" rel="stylesheet">
    <style>
        /* Custom Dark Navy Blue Header - Matches your table header */
        .card-header-dark-navy {
            background-color: #2c3e50;
            color: white;
        }
        .border-navy {
            border-color: #2c3e50 !important;
        }
        .analytics-row > .analytics-box { min-width: 0; }
        .analytics-row > .analytics-box:only-child { grid-column: 1 / -1; }
        .analytics-box .box-head { flex-wrap: wrap; align-items: center; }
        .trend-filter-form { flex: 1 1 560px; justify-content: flex-end; }
        .trend-filter-form label { display: grid; gap: .25rem; color: rgba(255,255,255,.82); }
        .trend-filter-form input,
        .trend-filter-form select { min-width: 135px; }
        .chart-product-wrap { min-height: 420px; }
        .sales-forecast-feature .chartWrap { height: 430px; }
        .suggested-restock-names {
            margin-top: .35rem;
            color: #2c3e50;
            font-size: .95rem;
            font-weight: 800;
            line-height: 1.2;
        }
        @media (max-width: 767.98px) {
            .trend-filter-form { flex-basis: 100%; justify-content: flex-start; }
            .trend-filter-form label { flex: 1 1 130px; }
            .trend-filter-form input,
            .trend-filter-form select { width: 100%; }
        }
    </style>
</head>
<body>

<?php
$profileLink = 'profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>

<div class="container-fluid">
    <div class="row">

        <?php include '../includes/admin_sidebar.php'; ?>

        <main class="col-lg-10 ms-sm-auto px-4 main-content">
            <div class="py-4">

                <div id="adminPageHeader" class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
                    <div>
                        <div class="section-subtitle mb-1">Admin Dashboard</div>
                        <h3 class="fw-bold mb-1">Analytics & Forecasting</h3>
                        <div class="text-muted">Sales trend, stock movement, restock priorities</div>
                    </div>
                    <button class="btn btn-outline-dark" onclick="window.print()">
                        <i class="fa-solid fa-print me-1"></i> Print Report
                    </button>
                </div>


                <div class="row g-3 mb-4">
                    <div class="col-12 col-md-4 col-xl">
                        <div class="card modern-card card-kpi h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center gap-3">
                                    <div>
                                        <div class="kpi-label">Sold (Last <?= (int)$RESTOCK_LOOKBACK_DAYS ?> days)</div>
                                        <div class="kpi-value"><?= number_format((float)$totalSoldLastN, 2) ?> <span>kg</span></div>
                                        <div class="kpi-sub">Movement window</div>
                                    </div>
                                    <div class="kpi-icon"><i class="fa-solid fa-boxes-stacked"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-md-4 col-xl">
                        <div class="card modern-card card-kpi h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center gap-3">
                                    <div>
                                        <div class="kpi-label">Restock Alerts</div>
                                        <div class="kpi-value"><?= (int)$restockAlertCount ?></div>
                                        <div class="kpi-sub">Needs attention</div>
                                    </div>
                                    <div class="kpi-icon"><i class="fa-solid fa-triangle-exclamation"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-md-4 col-xl">
                        <div class="card modern-card card-kpi h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center gap-3">
                                    <div>
                                        <div class="kpi-label">Out of Stock</div>
                                        <div class="kpi-value"><?= (int)$outOfStockCount ?></div>
                                        <div class="kpi-sub">Critical items</div>
                                    </div>
                                    <div class="kpi-icon"><i class="fa-solid fa-ban"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-md-4 col-xl">
                        <div class="card modern-card card-kpi h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center gap-3">
                                    <div>
                                        <div class="kpi-label">Slow Movers</div>
                                        <div class="kpi-value"><?= (int)$slowMovingCount ?></div>
                                        <div class="kpi-sub">Low movement</div>
                                    </div>
                                    <div class="kpi-icon"><i class="fa-solid fa-hourglass-half"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-md-4 col-xl">
                        <div class="card modern-card card-kpi h-100 border-success">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center gap-3">
                                    <div>
                                        <div class="kpi-label">Suggested Restocking</div>
                                        <div class="kpi-value text-success"><?= number_format($suggestedRestockTotalKg, 2) ?> <span>kg</span></div>
                                        <div class="suggested-restock-names">
                                            <?php if($suggestedRestockProductCount > 0): ?>
                                                <?= htmlspecialchars(implode(', ', array_map(fn($r) => (string)$r['product_label'], $restockCandidates)), ENT_QUOTES, 'UTF-8') ?>
                                            <?php else: ?>
                                                No products need restocking
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="kpi-icon"><i class="fa-solid fa-cart-plus"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-md-4 col-xl">
                        <div class="card modern-card card-kpi h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start gap-3">
                                    <div class="flex-grow-1 min-w-0">
                                        <div class="kpi-label">Top Product</div>
                                        <div class="kpi-title text-truncate"><?= htmlspecialchars($topProduct) ?></div>
                                        <div class="kpi-sub">Best seller</div>
                                    </div>
                                    <div class="kpi-icon"><i class="fa-solid fa-crown"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <section class="analytics-box sales-forecast-feature mb-4">
                    <div class="box-head">
                        <div>
                            <h4 class="fw-bold mb-1">Sales Forecast</h4>
                            <div class="small-note">Monthly sales history and the next three months forecast · Method: <?= htmlspecialchars($algoName) ?></div>
                        </div>
                    </div>
                    <div class="chartWrap"><canvas id="salesChart"></canvas></div>
                </section>

                <div class="analytics-row mb-4">
                    <div class="analytics-box">
                        <div class="box-head">
                            <div>
                                <h5 class="fw-bold mb-1">Fast Movers to Restock</h5>
                                <div class="small-note">Products with recent sales that are at or below their reorder point · last <?= (int)$RESTOCK_LOOKBACK_DAYS ?> days</div>
                            </div>
                        </div>
                        <?php if(empty($fastRestockLabels)): ?>
                            <div class="alert alert-success m-3 mb-0">No fast-moving products currently need restocking.</div>
                        <?php else: ?>
                            <div class="chartWrap"><canvas id="fastRestockChart"></canvas></div>
                        <?php endif; ?>
                    </div>

                    <div class="analytics-box">
                        <div class="box-head">
                            <div>
                                <h5 class="fw-bold mb-1">Sales by Product</h5>
                                <div class="small-note">All active products · kilograms sold from <?= htmlspecialchars($trendStart, ENT_QUOTES, 'UTF-8') ?> to <?= htmlspecialchars($trendEnd, ENT_QUOTES, 'UTF-8') ?></div>
                            </div>
                        </div>
                        <div class="chartWrap chart-product-wrap" style="height: <?= max(420, min(900, count($allProductSalesLabels) * 26)) ?>px"><canvas id="allProductSalesChart"></canvas></div>
                    </div>
                </div>

                <div class="analytics-row mb-4">
                    <div class="analytics-box">
                        <div class="box-head">
                            <div>
                                <h5 class="fw-bold mb-1"><?= ucfirst($trendInterval) ?> Sales Trend</h5>
                                <div class="small-note"><?= ucfirst($trendInterval) ?> sales in kilograms · choose a calendar range</div>
                            </div>
                            <form method="get" class="d-flex flex-wrap align-items-end gap-2 trend-filter-form">
                                <input type="hidden" name="lead" value="<?= (int)$LEAD_TIME_DAYS ?>">
                                <input type="hidden" name="safety" value="<?= htmlspecialchars((string)$SAFETY_STOCK_KG, ENT_QUOTES, 'UTF-8') ?>">
                                <input type="hidden" name="cover" value="<?= (int)$TARGET_DAYS_COVER ?>">
                                <input type="hidden" name="lookback" value="<?= (int)$RESTOCK_LOOKBACK_DAYS ?>">
                                <label class="small">From
                                    <input class="form-control form-control-sm" type="date" name="trend_start" value="<?= htmlspecialchars($trendStart, ENT_QUOTES, 'UTF-8') ?>" required>
                                </label>
                                <label class="small">To
                                    <input class="form-control form-control-sm" type="date" name="trend_end" value="<?= htmlspecialchars($trendEnd, ENT_QUOTES, 'UTF-8') ?>" required>
                                </label>
                                <label class="small">View
                                    <select class="form-select form-select-sm" name="trend_interval">
                                        <option value="day" <?= $trendInterval === 'day' ? 'selected' : '' ?>>Daily</option>
                                        <option value="week" <?= $trendInterval === 'week' ? 'selected' : '' ?>>Weekly</option>
                                        <option value="month" <?= $trendInterval === 'month' ? 'selected' : '' ?>>Monthly</option>
                                    </select>
                                </label>
                                <button class="btn btn-sm btn-light" type="submit">Apply</button>
                            </form>
                        </div>
                        <div class="chartWrap"><canvas id="monthlyKgChart"></canvas></div>
                    </div>


                </div>

                <div class="analytics-row mb-4">
                    <div class="analytics-box">
                        <div class="box-head">
                            <div>
                                <h5 class="fw-bold mb-1">Top Products</h5>
                                <div class="small-note">Top 10 by kilograms sold</div>
                            </div>
                        </div>
                        <div class="chartWrap"><canvas id="topProductsChart"></canvas></div>
                    </div>

                    <div class="analytics-box">
                        <div class="box-head">
                            <div>
                                <h5 class="fw-bold mb-1">Current Stock Levels</h5>
                                <div class="small-note">Top 10 products by stock on hand</div>
                            </div>
                        </div>
                        <div class="chartWrap"><canvas id="stockChart"></canvas></div>
                    </div>
                </div>

                <div class="analytics-row mb-4">
                    <div class="analytics-box">
                        <div class="box-head">
                            <div>
                                <h5 class="fw-bold mb-1">Sales by Day of Week</h5>
                                <div class="small-note">Last 90 days • Peak day: <b><?= htmlspecialchars($peakDay) ?></b> (<?= number_format((float)$peakKg, 2) ?> kg)</div>
                            </div>
                        </div>
                        <div class="chartWrap"><canvas id="dowChart"></canvas></div>
                    </div>

                    <div class="analytics-box">
    <div class="box-head">
        <div>
            <h5 class="fw-bold mb-1">Sales Forecast</h5>
            <div class="small-note">Daily, weekly, and monthly predicted sales in kilograms</div>
        </div>
    </div>
    <div class="row g-3 p-3">
        <div class="col-12 col-xl-4">
            <div class="fw-semibold mb-2">Daily · next 7 days <span class="small text-muted">(<?= htmlspecialchars($dailyBest['name']) ?>)</span></div>
            <div class="table-responsive modern-table"><table class="table table-sm align-middle mb-0"><thead><tr><th>Day</th><th class="text-end">Forecast (kg)</th></tr></thead><tbody>
                <?php foreach($dailyForecast as $f): ?><tr><td class="fw-semibold"><?= htmlspecialchars($f['label']) ?></td><td class="text-end"><?= number_format($f['value'], 2) ?></td></tr><?php endforeach; ?>
            </tbody></table></div>
        </div>
        <div class="col-12 col-xl-4">
            <div class="fw-semibold mb-2">Weekly · next 4 weeks <span class="small text-muted">(<?= htmlspecialchars($weeklyBest['name']) ?>)</span></div>
            <div class="table-responsive modern-table"><table class="table table-sm align-middle mb-0"><thead><tr><th>Week</th><th class="text-end">Forecast (kg)</th></tr></thead><tbody>
                <?php foreach($weeklyForecast as $f): ?><tr><td class="fw-semibold"><?= htmlspecialchars($f['label']) ?></td><td class="text-end"><?= number_format($f['value'], 2) ?></td></tr><?php endforeach; ?>
            </tbody></table></div>
        </div>
        <div class="col-12 col-xl-4">
            <div class="fw-semibold mb-2">Monthly · next 3 months <span class="small text-muted">(<?= htmlspecialchars($algoName) ?>)</span></div>
            <div class="table-responsive modern-table"><table class="table table-sm align-middle mb-0"><thead><tr><th>Month</th><th class="text-end">Forecast (kg)</th></tr></thead><tbody>
                <?php foreach($forecastTable as $f): ?><tr><td class="fw-semibold"><?= htmlspecialchars($f['month']) ?></td><td class="text-end"><?= number_format((float)$f['pred'], 2) ?></td></tr><?php endforeach; ?>
            </tbody></table></div>
        </div>
    </div>
</div>
</div>
<div class="analytics-box mb-4">
                    <div class="box-head">
                        <div>
                            <h5 class="fw-bold mb-1">Dead Stock / No Sales</h5>
                            <div class="small-note">Products with stock on hand but no sales in the last <?= (int)$RESTOCK_LOOKBACK_DAYS ?> days</div>
                        </div>
                    </div>
                    <?php if(empty($deadStock)): ?>
                        <div class="alert alert-success m-3 mb-0">No dead stock detected in this period.</div>
                    <?php else: ?>
                        <div class="table-responsive modern-table m-3">
                            <table class="table table-sm align-middle mb-0">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th class="text-end">Current Stock</th>
                                        <th class="text-end">Sold Last <?= (int)$RESTOCK_LOOKBACK_DAYS ?> Days</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($deadStock as $r): ?>
                                        <tr>
                                            <td class="fw-semibold"><?= htmlspecialchars($r['product_label']) ?></td>
                                            <td class="text-end"><?= number_format((float)$r['current_stock'], 2) ?> kg</td>
                                            <td class="text-end"><?= number_format((float)$r['sold_last_n'], 2) ?> kg</td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="mover-feature mt-2">
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                        <div>
                            <h5 class="fw-bold mb-1"><i class="fa-solid fa-bolt me-1 text-primary"></i>Fast & Slow Movers Spotlight</h5>
                            <div class="small text-muted">Based on sales in the last <?= (int)$RESTOCK_LOOKBACK_DAYS ?> days</div>
                        </div>
                        <div class="d-flex flex-wrap gap-2">
                            <span class="mover-kpi">
                                <i class="fa-solid fa-fire text-success"></i>
                                Fastest: <?= htmlspecialchars((string)($fastTop['product_label'] ?? 'N/A')) ?>
                            </span>
                            <span class="mover-kpi">
                                <i class="fa-solid fa-snowflake text-danger"></i>
                                Slowest: <?= htmlspecialchars((string)($slowTop['product_label'] ?? 'N/A')) ?>
                            </span>
                        </div>
                    </div>

                    <div class="analytics-row">
                        <div class="analytics-box mover-card fast">
                            <div class="box-head">
                                <div>
                                    <h6 class="fw-bold mb-1 text-success">Fast Moving Products</h6>
                                    <div class="small-note">Best recent movers</div>
                                </div>
                            </div>
                            <?php if(empty($fastMovers)): ?>
                                <div class="alert alert-light border mb-0">No sales movement yet in this window.</div>
                            <?php else: ?>
                                <div class="table-responsive modern-table">
                                    <table class="table table-sm align-middle mb-0">
                                        <thead>
                                            <tr>
                                                <th style="width:56px">Rank</th>
                                                <th>Product</th>
                                                <th class="text-end">Sold</th>
                                                <th class="text-end">Stock</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($fastMovers as $idx => $r): ?>
                                                <?php $pct = $maxFastSold > 0 ? (((float)$r['sold_last_n'] / $maxFastSold) * 100) : 0; ?>
                                                <tr>
                                                    <td><span class="mover-rank"><?= (int)($idx + 1) ?></span></td>
                                                    <td>
                                                        <div class="fw-semibold"><?= htmlspecialchars($r['product_label']) ?></div>
                                                        <div class="mover-bar mt-1">
                                                            <span class="mover-fill fast" style="width: <?= number_format($pct,1,'.','') ?>%"></span>
                                                        </div>
                                                    </td>
                                                    <td class="text-end fw-semibold"><?= number_format((float)$r['sold_last_n'], 2) ?> kg</td>
                                                    <td class="text-end"><?= number_format((float)$r['current_stock'], 2) ?> kg</td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="analytics-box mover-card slow">
                            <div class="box-head">
                                <div>
                                    <h6 class="fw-bold mb-1 text-danger">Slow Moving Products</h6>
                                    <div class="small-note">Useful to avoid overstock or spoilage</div>
                                </div>
                            </div>
                            <?php if(empty($slowMovers)): ?>
                                <div class="alert alert-light border mb-0">No products available for movement ranking.</div>
                            <?php else: ?>
                                <div class="table-responsive modern-table">
                                    <table class="table table-sm align-middle mb-0">
                                        <thead>
                                            <tr>
                                                <th style="width:56px">Rank</th>
                                                <th>Product</th>
                                                <th class="text-end">Sold</th>
                                                <th class="text-end">Stock</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($slowMovers as $idx => $r): ?>
                                                <?php
                                                $ratio = $maxSlowSold > 0 ? (((float)$r['sold_last_n'] / $maxSlowSold) * 100) : 0;
                                                $stagnantPct = 100 - $ratio;
                                                if($stagnantPct < 8) $stagnantPct = 8;
                                                ?>
                                                <tr>
                                                    <td><span class="mover-rank"><?= (int)($idx + 1) ?></span></td>
                                                    <td>
                                                        <div class="fw-semibold"><?= htmlspecialchars($r['product_label']) ?></div>
                                                        <div class="mover-bar mt-1">
                                                            <span class="mover-fill slow" style="width: <?= number_format($stagnantPct,1,'.','') ?>%"></span>
                                                        </div>
                                                    </td>
                                                    <td class="text-end fw-semibold"><?= number_format((float)$r['sold_last_n'], 2) ?> kg</td>
                                                    <td class="text-end"><?= number_format((float)$r['current_stock'], 2) ?> kg</td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>

    </div>
</div>

<script id="adminAnalyticsData" type="application/json"><?= json_encode([
    'months' => $months,
    'salesKgData' => $salesKgData,
    'trendLabels' => $trendLabels,
    'trendSalesData' => $trendSalesData,
    'allProductSalesLabels' => $allProductSalesLabels,
    'allProductSalesKg' => $allProductSalesKg,
    'fastRestockLabels' => $fastRestockLabels,
    'fastRestockSoldKg' => $fastRestockSoldKg,
    'fastRestockSuggestedKg' => $fastRestockSuggestedKg,
    'combinedLabels' => $combinedLabels,
    'actualPadded' => $actualPadded,
    'forecastPadded' => $forecastPadded,
    'daySalesLabels' => $daySalesLabels,
    'daySalesData' => $daySalesData,
    'topProdLabels' => $topProdLabels,
    'topProdKg' => $topProdKg,
    'stockLabels' => $stockLabels,
    'stockData' => $stockData,
], JSON_UNESCAPED_SLASHES) ?></script>

<script src="../js/admin_analytics.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
