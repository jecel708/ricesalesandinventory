


<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

if (strtolower($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: ../login.php");
    exit;
}

include '../config/db.php';

$username = $_SESSION['username'] ?? 'Admin';

$success = $_GET['success'] ?? '';
$error   = $_GET['error'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_status'])) {
    $targetUserId = (int)($_POST['user_id'] ?? 0);
    $newStatus = strtolower(trim((string)($_POST['new_status'] ?? '')));
    $allowedStatus = ['active', 'inactive'];

    if ($targetUserId <= 0 || !in_array($newStatus, $allowedStatus, true)) {
        header('Location: users.php?error=' . urlencode('Invalid status update request.'));
        exit;
    }

    $stmt = $conn->prepare("SELECT user_id, username, role, status FROM users WHERE user_id=? LIMIT 1");
    if (!$stmt) {
        header('Location: users.php?error=' . urlencode('Unable to prepare user lookup.'));
        exit;
    }
    $stmt->bind_param('i', $targetUserId);
    $stmt->execute();
    $targetUser = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$targetUser) {
        header('Location: users.php?error=' . urlencode('User not found.'));
        exit;
    }

    if (strtolower((string)$targetUser['role']) === 'admin') {
        header('Location: users.php?error=' . urlencode('Admin status cannot be changed here.'));
        exit;
    }

    if ($targetUserId === (int)($_SESSION['user_id'] ?? 0) && $newStatus === 'inactive') {
        header('Location: users.php?error=' . urlencode('You cannot deactivate your own account.'));
        exit;
    }

    if (strtolower((string)$targetUser['status']) === $newStatus) {
        header('Location: users.php?success=' . urlencode('No status change was needed.'));
        exit;
    }

    $update = $conn->prepare("UPDATE users SET status=? WHERE user_id=?");
    if (!$update) {
        header('Location: users.php?error=' . urlencode('Unable to prepare status update.'));
        exit;
    }
    $update->bind_param('si', $newStatus, $targetUserId);
    if (!$update->execute()) {
        $update->close();
        header('Location: users.php?error=' . urlencode('Failed to update user status.'));
        exit;
    }
    $update->close();

    $adminId = (int)($_SESSION['user_id'] ?? 0);
    $usernameTarget = (string)$targetUser['username'];
    $description = sprintf(
        'Changed user status for %s (#%d) to %s',
        $usernameTarget,
        $targetUserId,
        $newStatus
    );
    $log = $conn->prepare("
        INSERT INTO activity_logs
        (user_id, activity_type, description, created_at)
        VALUES (?, 'USER_STATUS_CHANGE', ?, NOW())
    ");
    if ($log) {
        $log->bind_param('is', $adminId, $description);
        $log->execute();
        $log->close();
    }

    header('Location: users.php?success=' . urlencode('User status updated successfully.'));
    exit;
}

$users = $conn->query("
    SELECT user_id, username, first_name, last_name, phone, role, status, created_at
    FROM users
    ORDER BY created_at DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>User Management | DE ORO HIYS</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

<link href="../css/layout.css" rel="stylesheet">
<link href="../css/admin-users.css" rel="stylesheet">
<link href="../css/admin-mobile.css" rel="stylesheet">

<style>
/* Gmail-only email validation */
#email.is-valid {
    border-color: #198754;
}
#email.is-invalid {
    border-color: #dc3545;
}
</style>
</head>

<body>

<?php
include '../includes/topnav.php';
?>

<div class="container-fluid">
<div class="row">

<?php include '../includes/admin_sidebar.php'; ?>

<main class="col-lg-10 ms-sm-auto px-4">

<!-- HEADER -->
<div class="d-flex justify-content-between align-items-center my-3">
  <div>
    <h3 class="fw-bold mb-0">User Management</h3>
    <small class="text-muted">Manage cashier and owner accounts</small>
  </div>

  <button class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#addUserModal">
    <i class="fas fa-user-plus me-1"></i> Add User
  </button>
</div>

<!-- ALERTS -->
<?php if($success): ?>
<div class="alert alert-success alert-dismissible fade show">
  <?= htmlspecialchars($success) ?>
  <button class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if($error): ?>
<div class="alert alert-danger alert-dismissible fade show">
  <?= htmlspecialchars($error) ?>
  <button class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- TABLE -->
<div class="card">
<div class="card-body table-responsive">

<table class="table table-hover align-middle">
<thead class="table-dark">
<tr>
  <th>ID</th>
  <th>Username</th>
  <th>Name</th>
  <th>Phone</th>
  <th>Role</th>
  <th>Status</th>
  <th>Created</th>
  <th class="text-end">Actions</th>
</tr>
</thead>

<tbody>
<?php if($users && $users->num_rows > 0): ?>
<?php while($u = $users->fetch_assoc()): ?>
<tr>
  <td><?= (int)$u['user_id'] ?></td>
  <td><?= htmlspecialchars($u['username']) ?></td>
  <td><?= htmlspecialchars($u['first_name'].' '.$u['last_name']) ?></td>
  <td><?= htmlspecialchars($u['phone']) ?></td>
  <td><span class="badge bg-primary"><?= htmlspecialchars($u['role']) ?></span></td>
  <td>
    <span class="badge <?= strtolower($u['status']) === 'active' ? 'bg-success' : 'bg-secondary' ?>">
      <?= htmlspecialchars($u['status']) ?>
    </span>
  </td>
  <td><?= htmlspecialchars($u['created_at']) ?></td>
  <td class="text-end">
    <?php if (strtolower((string)$u['role']) === 'admin'): ?>
      <span class="text-muted small">System</span>
    <?php else: ?>
      <form method="POST" action="users.php" class="d-inline">
        <input type="hidden" name="toggle_status" value="1">
        <input type="hidden" name="user_id" value="<?= (int)$u['user_id'] ?>">
        <?php if (strtolower((string)$u['status']) === 'active'): ?>
          <input type="hidden" name="new_status" value="inactive">
          <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Deactivate this user?');">
            <i class="fa-solid fa-user-slash me-1"></i>Deactivate
          </button>
        <?php else: ?>
          <input type="hidden" name="new_status" value="active">
          <button type="submit" class="btn btn-sm btn-outline-success" onclick="return confirm('Activate this user?');">
            <i class="fa-solid fa-user-check me-1"></i>Activate
          </button>
        <?php endif; ?>
      </form>
    <?php endif; ?>
  </td>
</tr>
<?php endwhile; ?>
<?php else: ?>
<tr>
  <td colspan="8" class="text-center text-muted">No users found</td>
</tr>
<?php endif; ?>
</tbody>

</table>

</div>
</div>

</main>
</div>
</div>

<!-- ================= ADD USER MODAL ================= -->
<div class="modal fade" id="addUserModal">
<div class="modal-dialog modal-md modal-dialog-centered">
<div class="modal-content">

<form method="POST" action="add_user.php" id="addUserForm" novalidate>

<!-- HEADER -->
<div class="modal-header">
<h5 class="modal-title">Add User</h5>
<button class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">

<!-- ACCOUNT -->
<h6 class="text-muted">Account Information</h6>
<hr>

<!-- USERNAME -->
<div class="mb-3">
<label class="form-label">Username <span class="text-danger">*</span></label>
<input type="text" class="form-control" name="username" id="username" required>
</div>

<!-- EMAIL -->
<div class="mb-3">
<label class="form-label" for="email">Email <span class="text-danger">*</span></label>
<input
    type="email"
    class="form-control"
    name="email"
    id="email"
    placeholder="example@gmail.com"
    autocomplete="email"
    required
    pattern="[A-Za-z0-9._%+-]+@gmail\\.com"
    title="Please enter a valid Gmail address ending with @gmail.com">
<small id="emailCheck" class="d-block mt-1 text-muted">
    Only Gmail addresses ending in @gmail.com are accepted.
</small>
</div>

<!-- PASSWORD -->
<div class="mb-3">
<label class="form-label">Password <span class="text-danger">*</span></label>

<div class="input-group">
<input type="password" class="form-control" name="password" id="password" required>
<button type="button" class="btn btn-outline-secondary" onclick="togglePassword()">
<i class="fas fa-eye"></i>
</button>
</div>

<!-- PASSWORD POLICY -->
<small class="text-muted d-block mt-2">
<b>Password Policy:</b><br>
• Minimum 8 characters<br>
• 1 uppercase letter<br>
• 1 lowercase letter<br>
• 1 number<br>
• 1 special character (@$!%*?&)
</small>

<div class="progress mt-2" style="height:6px;">
<div id="strengthBar" class="progress-bar"></div>
</div>
<small id="strengthText"></small>
</div>

<!-- CONFIRM PASSWORD -->
<div class="mb-3">
<label class="form-label">Confirm Password <span class="text-danger">*</span></label>

<div class="input-group">
    <input type="password" class="form-control" name="confirm_password" id="confirm_password" required>

    <button type="button" class="btn btn-outline-secondary" onclick="toggleConfirmPassword()">
        <i class="fas fa-eye"></i>
    </button>
</div>

<small id="matchText"></small>
</div>

<!-- PERSONAL -->
<h6 class="text-muted mt-3">Personal Information</h6>
<hr>

<div class="row">
<div class="col-12 mb-3">
<label class="form-label">First Name</label>
<input type="text" class="form-control" name="first_name" id="first_name">
</div>

<div class="col-12 mb-3">
<label class="form-label">Last Name</label>
<input type="text" class="form-control" name="last_name" id="last_name">
</div>
</div>

<!-- PHONE -->
<div class="mb-3">
<label class="form-label">Phone <span class="text-danger">*</span></label>
<input type="tel" class="form-control" name="phone" id="phone"
maxlength="11" placeholder="09XXXXXXXXX" required>
<small id="phoneCheck"></small>
</div>

<!-- PERMISSIONS -->
<h6 class="text-muted mt-3">Permissions</h6>
<hr>

<!-- ROLE -->
<div class="mb-3">
<label class="form-label">Role <span class="text-danger">*</span></label>
<select class="form-select" name="role" id="role" required>
<option value="cashier">Cashier</option>
<option value="owner">Owner</option>
</select>
<small id="roleDesc" class="text-muted"></small>
</div>

<!-- STATUS -->
<div class="mb-3">
<label class="form-label">Status <span class="text-danger">*</span></label>
<select class="form-select" name="status" required>
<option value="active">Active</option>
<option value="inactive">Inactive</option>
</select>
</div>

</div>

<!-- FOOTER -->
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
<button class="btn btn-dark">Create User</button>
</div>

</form>

</div>
</div>
</div>

<!-- ================= JS ================= -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>

// TOGGLE PASSWORD
function togglePassword() {
    const pw = document.getElementById("password");
    pw.type = pw.type === "password" ? "text" : "password";
}

// GMAIL-ONLY EMAIL VALIDATION
const addUserForm = document.getElementById("addUserForm");
const emailInput = document.getElementById("email");
const emailCheck = document.getElementById("emailCheck");

function isValidGmail(email) {
    return /^[A-Za-z0-9._%+-]+@gmail\.com$/i.test(String(email).trim());
}

function updateEmailValidation() {
    if (!emailInput || !emailCheck) return;

    const value = emailInput.value.trim();

    if (value === "") {
        emailInput.classList.remove("is-valid", "is-invalid");
        emailCheck.className = "d-block mt-1 text-muted";
        emailCheck.innerText = "Only Gmail addresses ending in @gmail.com are accepted.";
        return false;
    }

    if (isValidGmail(value)) {
        emailInput.classList.remove("is-invalid");
        emailInput.classList.add("is-valid");
        emailCheck.className = "d-block mt-1 text-success";
        emailCheck.innerText = "✓ Valid Gmail address";
        return true;
    }

    emailInput.classList.remove("is-valid");
    emailInput.classList.add("is-invalid");
    emailCheck.className = "d-block mt-1 text-danger";
    emailCheck.innerText = "✗ Please enter a valid Gmail address ending in @gmail.com.";
    return false;
}

emailInput?.addEventListener("input", updateEmailValidation);
emailInput?.addEventListener("blur", updateEmailValidation);

addUserForm?.addEventListener("submit", function (event) {
    if (!updateEmailValidation()) {
        event.preventDefault();
        emailInput?.focus();
        return false;
    }

    return true;
});

// PASSWORD STRENGTH
document.getElementById("password").addEventListener("input", function () {
    const val = this.value;
    let strength = 0;

    if (val.length >= 8) strength++;
    if (/[A-Z]/.test(val)) strength++;
    if (/[a-z]/.test(val)) strength++;
    if (/[0-9]/.test(val)) strength++;
    if (/[\W_]/.test(val)) strength++;

    const bar = document.getElementById("strengthBar");
    const text = document.getElementById("strengthText");

    const levels = ["Weak", "Fair", "Good", "Strong", "Very Strong"];
    const colors = ["bg-danger", "bg-warning", "bg-info", "bg-primary", "bg-success"];

    bar.className = "progress-bar " + (colors[strength - 1] || "");
    bar.style.width = (strength * 20) + "%";

    text.innerText = levels[strength - 1] || "";
});

// CONFIRM PASSWORD
document.getElementById("confirm_password").addEventListener("input", function () {
    const pw = document.getElementById("password").value;
    const cp = this.value;

    document.getElementById("matchText").innerText =
        pw === cp ? "✓ Password match" : "✗ Password not match";
});

function toggleConfirmPassword() {
    const cp = document.getElementById("confirm_password");
    cp.type = cp.type === "password" ? "text" : "password";
}
// ROLE DESCRIPTION
document.getElementById("role").addEventListener("change", function () {
    document.getElementById("roleDesc").innerText =
        this.value === "cashier"
        ? "Can process sales only."
        : "Can view reports & manage system.";
});

// PHONE VALIDATION
document.getElementById("phone").addEventListener("input", function () {
    const ok = /^09\d{9}$/.test(this.value);

    document.getElementById("phoneCheck").innerText =
        ok ? "✓ Valid format" : "✗ Invalid format";
});

</script>
<script>
(function () {
  const pollIntervalMs = 5000;
  let pollingInFlight = false;
  async function pollLiveMain() {
    if (pollingInFlight) return;
    pollingInFlight = true;
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('_live', Date.now().toString());
      const response = await fetch(url.toString(), { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const sourceMain = doc.querySelector('main');
      const targetMain = document.querySelector('main');
      if (sourceMain && targetMain) targetMain.innerHTML = sourceMain.innerHTML;
    } catch (error) {
      console.error('Users live poll failed:', error);
    } finally {
      pollingInFlight = false;
    }
  }
  pollLiveMain();
  window.setInterval(pollLiveMain, pollIntervalMs);
})();
</script>

</body>
</html>