<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit;
}
if(strtolower($_SESSION['role'] ?? '') !== 'admin'){
    header("Location: ../login.php");
    exit;
}

$username = $_SESSION['username'] ?? 'User';
$activePage = 'logs';
include '../config/db.php';

$tab = $_GET['tab'] ?? 'activity';
if(!in_array($tab, ['activity', 'login', 'inventory'], true)){
    $tab = 'activity';
}
$q = trim($_GET['q'] ?? '');
$date = trim($_GET['date'] ?? '');
$parsedDate = DateTime::createFromFormat('!Y-m-d', $date);
if(!$parsedDate || $parsedDate->format('Y-m-d') !== $date){
    $date = '';
}

function h($v){
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function logTabUrl(string $tab, string $q, string $date): string {
    $params = ['tab' => $tab];
    if($q !== '') $params['q'] = $q;
    if($date !== '') $params['date'] = $date;
    return '?' . http_build_query($params);
}

function normalizeBatchCode(string $code): string {
    $code = trim($code);
    if ($code === '') {
        return '';
    }
    if (preg_match('/^LEGACY-(\d+)$/i', $code, $matches)) {
        return 'Batch ' . $matches[1];
    }
    return $code;
}

// Fetch Activity Logs
$activityLogs = [];
if($tab === 'activity'){
    if($q !== '' || $date !== ''){
        $stmt = $conn->prepare("
            SELECT al.*, u.first_name, u.last_name, u.username
            FROM activity_logs al
            LEFT JOIN users u ON al.user_id = u.user_id
            WHERE (? = '' OR (
                al.activity_type LIKE CONCAT('%',?,'%')
                OR al.description LIKE CONCAT('%',?,'%')
                OR u.username LIKE CONCAT('%',?,'%')
                OR u.first_name LIKE CONCAT('%',?,'%')
                OR u.last_name LIKE CONCAT('%',?,'%')
            ))
            AND (? = '' OR DATE(al.created_at) = ?)
            ORDER BY al.created_at DESC
            LIMIT 200
        ");
        $stmt->bind_param("ssssssss", $q, $q, $q, $q, $q, $q, $date, $date);
        $stmt->execute();
        $activityLogs = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    } else {
        $res = $conn->query("
            SELECT al.*, u.first_name, u.last_name, u.username
            FROM activity_logs al
            LEFT JOIN users u ON al.user_id = u.user_id
            ORDER BY al.created_at DESC
            LIMIT 200
        ");
        if($res) $activityLogs = $res->fetch_all(MYSQLI_ASSOC);
    }
}

// Fetch Login Logs
$loginLogs = [];
if($tab === 'login'){
    if($q !== '' || $date !== ''){
        $stmt = $conn->prepare("
            SELECT ll.*, u.first_name, u.last_name, u.username
            FROM login_logs ll
            LEFT JOIN users u ON ll.user_id = u.user_id
            WHERE (? = '' OR (
                ll.device_info LIKE CONCAT('%',?,'%')
                OR ll.ip_address LIKE CONCAT('%',?,'%')
                OR u.username LIKE CONCAT('%',?,'%')
                OR u.first_name LIKE CONCAT('%',?,'%')
                OR u.last_name LIKE CONCAT('%',?,'%')
            ))
            AND (? = '' OR DATE(ll.login_time) = ?)
            ORDER BY ll.login_time DESC
            LIMIT 200
        ");
        $stmt->bind_param("ssssssss", $q, $q, $q, $q, $q, $q, $date, $date);
        $stmt->execute();
        $loginLogs = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    } else {
        $res = $conn->query("
            SELECT ll.*, u.first_name, u.last_name, u.username
            FROM login_logs ll
            LEFT JOIN users u ON ll.user_id = u.user_id
            ORDER BY ll.login_time DESC
            LIMIT 200
        ");
        if($res) $loginLogs = $res->fetch_all(MYSQLI_ASSOC);
    }
}

// Fetch Inventory Logs
$inventoryLogs = [];
if($tab === 'inventory'){
    if($q !== '' || $date !== ''){
        $stmt = $conn->prepare("
            SELECT it.*, p.variety, p.grade, sb.batch_code
            FROM inventory_transactions it
            LEFT JOIN products p ON it.product_id = p.product_id
            LEFT JOIN stock_batches sb ON it.batch_id = sb.batch_id
            WHERE (? = '' OR (
                p.variety LIKE CONCAT('%',?,'%')
                OR p.grade LIKE CONCAT('%',?,'%')
                OR sb.batch_code LIKE CONCAT('%',?,'%')
                OR it.reference_type LIKE CONCAT('%',?,'%')
                OR it.type LIKE CONCAT('%',?,'%')
                OR it.note LIKE CONCAT('%',?,'%')
            ))
            AND (? = '' OR DATE(it.created_at) = ?)
            ORDER BY it.created_at DESC
            LIMIT 200
        ");
        $stmt->bind_param("sssssssss", $q, $q, $q, $q, $q, $q, $q, $date, $date);
        $stmt->execute();
        $inventoryLogs = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    } else {
        $res = $conn->query("
            SELECT it.*, p.variety, p.grade, sb.batch_code
            FROM inventory_transactions it
            LEFT JOIN products p ON it.product_id = p.product_id
            LEFT JOIN stock_batches sb ON it.batch_id = sb.batch_id
            ORDER BY it.created_at DESC
            LIMIT 200
        ");
        if($res) $inventoryLogs = $res->fetch_all(MYSQLI_ASSOC);
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>System Logs | DE ORO HIYS</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

<link href="../css/layout.css" rel="stylesheet">
<link href="../css/admin-mobile.css" rel="stylesheet">
<link href="../css/admin-system-logs.css" rel="stylesheet">
</head>

<body>

<?php
$profileLink = 'profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>

<div class="container-fluid">
<div class="row">

<?php include '../includes/admin_sidebar.php'; ?>

<main class="col-lg-10 ms-sm-auto px-4 main-content">
  <h3 class="fw-bold mb-1">System Logs</h3>
  <p class="text-muted mb-4">Track user actions, logins, and notifications for accountability</p>

  <div class="card modern-card mb-3">
    <div class="card-body d-flex flex-wrap gap-2 justify-content-between align-items-center">
      <div class="btn-group">
        <a class="btn btn-outline-primary <?= $tab==='activity'?'active':'' ?>" href="<?= h(logTabUrl('activity', $q, $date)) ?>">Activity Logs</a>
        <a class="btn btn-outline-primary <?= $tab==='login'?'active':'' ?>" href="<?= h(logTabUrl('login', $q, $date)) ?>">Login Logs</a>
        <a class="btn btn-outline-primary <?= $tab==='inventory'?'active':'' ?>" href="<?= h(logTabUrl('inventory', $q, $date)) ?>">Inventory Logs</a>
      </div>

      <form method="GET" class="d-flex flex-wrap gap-2">
        <input type="hidden" name="tab" value="<?= h($tab) ?>">
        <input type="text" name="q" class="form-control" placeholder="Search logs..." value="<?= h($q) ?>">
        <input type="date" name="date" class="form-control" value="<?= h($date) ?>" aria-label="Filter logs by day" title="Filter logs by day">
        <button class="btn btn-dark" type="submit"><i class="fas fa-filter"></i><span class="visually-hidden">Apply filters</span></button>
      </form>
    </div>
  </div>

  <div class="card modern-card">
    <div class="card-body table-responsive">

      <?php if($tab==='activity'): ?>
        <table class="table table-bordered table-striped">
          <thead class="table-dark">
            <tr>
              <th>Date</th>
              <th>User</th>
              <th>Type</th>
              <th>Description</th>
            </tr>
          </thead>
          <tbody>
          <?php if(empty($activityLogs)): ?>
            <tr><td colspan="4" class="text-center text-muted">No activity logs found.</td></tr>
          <?php else: ?>
            <?php foreach($activityLogs as $l): ?>
              <?php
                $fullName = trim(($l['first_name'] ?? '') . ' ' . ($l['last_name'] ?? ''));
                $displayUser = $fullName !== '' ? $fullName : ($l['username'] ?? 'Unknown');
                if (!empty($l['username'])) {
                    $displayUser .= " ({$l['username']})";
                }

                $badgeClass = 'bg-info';
                if (($l['activity_type'] ?? '') === 'Penalty Waiver') {
                    $badgeClass = 'bg-warning text-dark';
                }
              ?>
              <tr>
                <td><?= !empty($l['created_at']) ? date("M d, Y h:i A", strtotime($l['created_at'])) : '-' ?></td>
                <td><?= h($displayUser) ?></td>
                <td><span class="badge <?= $badgeClass ?>"><?= h($l['activity_type'] ?? 'N/A') ?></span></td>
                <td><?= h($l['description'] ?? '') ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
          </tbody>
        </table>

      <?php elseif($tab==='login'): ?>
        <table class="table table-bordered table-striped">
          <thead class="table-dark">
            <tr>
              <th>Login Time</th>
              <th>User</th>
              <th>Device</th>
              <th>IP Address</th>
            </tr>
          </thead>
          <tbody>
          <?php if(empty($loginLogs)): ?>
            <tr><td colspan="4" class="text-center text-muted">No login logs found.</td></tr>
          <?php else: ?>
            <?php foreach($loginLogs as $l): ?>
              <?php
                $fullName = trim(($l['first_name'] ?? '') . ' ' . ($l['last_name'] ?? ''));
                $displayUser = $fullName !== '' ? $fullName : ($l['username'] ?? 'Unknown');
                if (!empty($l['username'])) {
                    $displayUser .= " ({$l['username']})";
                }
              ?>
              <tr>
                <td><?= !empty($l['login_time']) ? date("M d, Y h:i A", strtotime($l['login_time'])) : '-' ?></td>
                <td><?= h($displayUser) ?></td>
                <td><?= h($l['device_info'] ?? '') ?></td>
                <td><?= h($l['ip_address'] ?? '') ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
          </tbody>
        </table>

      <?php elseif($tab==='inventory'): ?>
        <table class="table table-bordered table-striped">
          <thead class="table-dark">
            <tr>
              <th>Date</th>
              <th>Product</th>
              <th>Batch</th>
              <th>Type</th>
              <th>Reference</th>
              <th class="text-end">Qty (kg)</th>
              <th>Note</th>
            </tr>
          </thead>
          <tbody>
          <?php if(empty($inventoryLogs)): ?>
            <tr><td colspan="7" class="text-center text-muted">No inventory logs found.</td></tr>
          <?php else: ?>
            <?php foreach($inventoryLogs as $l): ?>
              <?php
                $productLabel = trim(($l['variety'] ?? '') . ' - ' . ($l['grade'] ?? ''));
                if ($productLabel === '-') {
                    $productLabel = 'Unknown';
                }
              ?>
              <?php
                $transactionType = strtolower(trim((string)($l['type'] ?? '')));
                $referenceType = strtolower(trim((string)($l['reference_type'] ?? '')));
                $typeClass = 'bg-secondary text-white';
                if ($transactionType === 'in') {
                    $typeClass = 'bg-success';
                } elseif ($transactionType === 'out') {
                    $typeClass = 'bg-danger';
                } elseif ($transactionType === 'adjust') {
                    $typeClass = 'bg-warning text-dark';
                } elseif ($transactionType === 'return') {
                    $typeClass = 'bg-info text-dark';
                }

                $refClass = 'bg-secondary text-white';
                if ($referenceType === 'purchase') {
                    $refClass = 'bg-primary';
                } elseif ($referenceType === 'sale') {
                    $refClass = 'bg-danger';
                } elseif ($referenceType === 'return') {
                    $refClass = 'bg-success';
                } elseif ($referenceType === 'adjust') {
                    $refClass = 'bg-warning text-dark';
                }
              ?>
              <tr>
                <td><?= !empty($l['created_at']) ? date("M d, Y h:i A", strtotime($l['created_at'])) : '-' ?></td>
                <td><?= h($productLabel) ?></td>
                <td><?= h(normalizeBatchCode((string)($l['batch_code'] ?? '')) ?: '-') ?></td>
                <td><span class="badge <?= $typeClass ?>"><?= h(ucfirst($transactionType ?: 'N/A')) ?></span></td>
                <td><span class="badge <?= $refClass ?>"><?= h(ucfirst($referenceType ?: 'N/A')) ?></span></td>
                <td class="text-end"><?= number_format((float)($l['qty_kg'] ?? 0), 2) ?></td>
                <td><?= h($l['note'] ?? '') ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
          </tbody>
        </table>

      <?php endif; ?>

    </div>
  </div>

</main>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function () {
  const pollIntervalMs = 5000;
  let pollingInFlight = false;
  async function pollLiveMain() {
    if (pollingInFlight) return;
    const targetMain = document.querySelector('main');
    if (!targetMain || targetMain.contains(document.activeElement)) return;
    pollingInFlight = true;
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('_live', Date.now().toString());
      const response = await fetch(url.toString(), { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      if (!response.ok) return;
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const sourceMain = doc.querySelector('main');
      if (sourceMain && sourceMain.innerHTML !== targetMain.innerHTML) {
        targetMain.innerHTML = sourceMain.innerHTML;
      }
    } catch (error) {
      console.error('System logs live poll failed:', error);
    } finally {
      pollingInFlight = false;
    }
  }
  pollLiveMain();
  window.setInterval(pollLiveMain, pollIntervalMs);
})();
</script>
</body>
</html>