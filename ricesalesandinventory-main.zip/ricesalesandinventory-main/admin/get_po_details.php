<?php
include '../config/db.php';

$id = (int)($_GET['id'] ?? 0);

header('Content-Type: application/json');

$stmt = $conn->prepare("
    SELECT
        pr.purchases_id,
        pr.supplier_id,
        pr.purchase_date,
        pr.payment_terms,
        pr.request_reason,

        pi.product_id,
        pi.quantity_sacks,
        pi.supplier_price,

        s.name AS supplier_name

    FROM purchases pr

    JOIN purchase_items pi
        ON pi.purchases_id = pr.purchases_id

    JOIN suppliers s
        ON s.supplier_id = pr.supplier_id

    WHERE pr.purchases_id = ?

    LIMIT 1
");

$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();

if($row = $result->fetch_assoc()){

    echo json_encode([
        'purchase_id'   => (int)$row['purchases_id'],
        'purchases_id'  => (int)$row['purchases_id'],
        'supplier_id'   => (int)$row['supplier_id'],
        'supplier_name' => $row['supplier_name'],

        'product_id'    => (int)$row['product_id'],
        'qty_sacks'     => (float)$row['quantity_sacks'],

        'price_per_sack'=> (float)$row['supplier_price'],

        'purchase_date' => $row['purchase_date'],

        // your purchases table doesn't have these
        'delivery_date' => '',
        'due_date'      => '',

        'note'          => $row['request_reason'] ?? ''
    ]);

}else{

    echo json_encode([
        'error' => 'PO not found'
    ]);

}
