<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

// Allows BOTH admin and owner — cashier gets blocked
$role = strtolower($_SESSION['role'] ?? '');

if (!in_array($role, ['admin', 'owner'])) {
    header("Location: ../login.php");
    exit;
}

$username = $_SESSION['username'] ?? 'Owner';

include '../config/db.php';

$allowedStatuses = ['all', 'paid', 'unpaid', 'partial', 'cancelled'];

$saleIdQuery = trim((string)($_GET['sale_id'] ?? ''));
$cashierId = (int)($_GET['cashier_id'] ?? 0);

$statusFilter = strtolower(trim((string)($_GET['status'] ?? 'all')));

if (!in_array($statusFilter, $allowedStatuses, true)) {
    $statusFilter = 'all';
}

$hasFilters =
    array_key_exists('from', $_GET) ||
    array_key_exists('to', $_GET) ||
    array_key_exists('sale_id', $_GET) ||
    array_key_exists('cashier_id', $_GET) ||
    array_key_exists('status', $_GET);

$isExport = strtolower(trim((string)($_GET['export'] ?? ''))) === 'csv';

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;


/* =========================================================
   DATE FILTER
   ========================================================= */

$from = $_GET['from'] ?? date('Y-m-d', strtotime('-30 days'));
$to   = $_GET['to'] ?? date('Y-m-d');

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) {
    $from = date('Y-m-01');
}

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
    $to = date('Y-m-d');
}

// Ensure from <= to
if (strtotime($from) > strtotime($to)) {
    $tmp = $from;
    $from = $to;
    $to = $tmp;
}


/* =========================================================
   IF NO FILTERS, USE MOST RECENT SALES DATA
   ========================================================= */

if (!$hasFilters) {

    $mxRes = $conn->query("
        SELECT MIN(sale_date) AS min_date, MAX(sale_date) AS max_date
        FROM sales
        WHERE (status IS NULL OR LOWER(status) <> 'cancelled')
          AND sale_date IS NOT NULL
          AND sale_date <> '0000-00-00 00:00:00'
    ");

    if ($mxRes) {

        $mxRow = $mxRes->fetch_assoc();
        $minDate = $mxRow['min_date'] ?? null;
        $maxDate = $mxRow['max_date'] ?? null;

        if ($minDate && $maxDate) {
            $from = date('Y-m-d', strtotime($minDate));
            $to = date('Y-m-d', strtotime($maxDate));
        }
    }
}


/* =========================================================
   FILTER SQL
   ========================================================= */

$filterParts = [
    "DATE(s.sale_date) BETWEEN ? AND ?",
    "s.sale_date <> '0000-00-00 00:00:00'"
];

$filterParams = [$from, $to];
$filterTypes = 'ss';

if ($saleIdQuery !== '') {

    $filterParts[] = "CAST(s.sale_id AS CHAR) LIKE CONCAT('%', ?, '%')";
    $filterParams[] = $saleIdQuery;
    $filterTypes .= 's';
}

if ($cashierId > 0) {

    $filterParts[] = "s.user_id = ?";
    $filterParams[] = $cashierId;
    $filterTypes .= 'i';
}

if ($statusFilter !== 'all') {

    $filterParts[] = "LOWER(IFNULL(s.status,'')) = ?";
    $filterParams[] = $statusFilter;
    $filterTypes .= 's';
}

$filterSql = implode(' AND ', $filterParts);


/* =========================================================
   CASHIER LIST
   ========================================================= */

$cashiers = [];

$cashierRes = $conn->query("
    SELECT DISTINCT
        u.user_id,
        u.username
    FROM sales s
    JOIN users u ON u.user_id = s.user_id
    WHERE s.sale_date <> '0000-00-00 00:00:00'
    ORDER BY u.username ASC
");

if ($cashierRes) {
    $cashiers = $cashierRes->fetch_all(MYSQLI_ASSOC);
}


/* =========================================================
   SUMMARY
   ========================================================= */

$summary = [
    'total_kg' => 0,
    'total_rev' => 0,
    'sales_count' => 0,
    'cash_sales' => 0,
    'utang_sales' => 0
];

$stmt = $conn->prepare("
    SELECT
        COALESCE(SUM(s.total_amount),0) AS total_rev,
        COUNT(DISTINCT s.sale_id) AS sales_count,

        COUNT(
            DISTINCT CASE
                WHEN LOWER(IFNULL(s.status,'')) = 'paid'
                THEN s.sale_id
            END
        ) AS cash_sales,

        COUNT(
            DISTINCT CASE
                WHEN LOWER(IFNULL(s.status,'')) IN ('unpaid','partial')
                THEN s.sale_id
            END
        ) AS utang_sales

    FROM sales s

    WHERE {$filterSql}
");

if ($stmt) {

    $stmt->bind_param($filterTypes, ...$filterParams);
    $stmt->execute();

    $row = $stmt->get_result()->fetch_assoc();

    if ($row) {

        $summary['total_rev'] = $row['total_rev'] ?? 0;
        $summary['sales_count'] = $row['sales_count'] ?? 0;
        $summary['cash_sales'] = $row['cash_sales'] ?? 0;
        $summary['utang_sales'] = $row['utang_sales'] ?? 0;
    }

    $stmt->close();
}


/* =========================================================
   TOTAL KG
   ========================================================= */

$stmt = $conn->prepare("
    SELECT
        COALESCE(SUM(si.qty_kg),0) AS total_kg
    FROM sales s
    JOIN sales_items si
        ON si.sale_id = s.sale_id
    WHERE {$filterSql}
");

if ($stmt) {

    $stmt->bind_param($filterTypes, ...$filterParams);
    $stmt->execute();

    $row = $stmt->get_result()->fetch_assoc();

    if ($row) {
        $summary['total_kg'] = $row['total_kg'] ?? 0;
    }

    $stmt->close();
}

$summary['avg_ticket'] =
    $summary['sales_count'] > 0
        ? ($summary['total_rev'] / $summary['sales_count'])
        : 0;


/* =========================================================
   ALL-TIME SALES
   ========================================================= */

$allTimeSalesTotal = 0;

$allTimeRes = $conn->query("
    SELECT
        COALESCE(SUM(total_amount),0) AS total_sales
    FROM sales
    WHERE LOWER(IFNULL(status,'')) <> 'cancelled'
      AND sale_date <> '0000-00-00 00:00:00'
");

if ($allTimeRes) {

    $allTimeRow = $allTimeRes->fetch_assoc();

    $allTimeSalesTotal =
        (float)($allTimeRow['total_sales'] ?? 0);
}


/* =========================================================
   SALES METRIC FUNCTION
   ========================================================= */

function sales_metric_totals(
    mysqli $conn,
    string $dateExpr,
    string $start,
    string $end,
    ?int $cashierId = null
): array {

    $sql = "
        SELECT
            COALESCE(SUM(s.total_amount),0) AS total_rev,
            COUNT(DISTINCT s.sale_id) AS sales_count

        FROM sales s

        WHERE {$dateExpr} BETWEEN ? AND ?
          AND LOWER(IFNULL(s.status,'')) <> 'cancelled'
    ";

    $types = 'ss';
    $params = [$start, $end];

    if ($cashierId !== null && $cashierId > 0) {

        $sql .= " AND s.user_id = ? ";

        $types .= 'i';
        $params[] = $cashierId;
    }

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return [
            'total_rev' => 0,
            'sales_count' => 0
        ];
    }

    $stmt->bind_param($types, ...$params);
    $stmt->execute();

    $row = $stmt->get_result()->fetch_assoc() ?: [];

    $stmt->close();

    return [
        'total_rev' => (float)($row['total_rev'] ?? 0),
        'sales_count' => (int)($row['sales_count'] ?? 0)
    ];
}


/* =========================================================
   BIND HELPER
   ========================================================= */

function bind_exec_all(
    mysqli_stmt $stmt,
    string $types,
    array $params
): void {

    $bind = array_merge([$types], $params);

    $refs = [];

    foreach ($bind as $k => $v) {
        $refs[$k] = &$bind[$k];
    }

    call_user_func_array(
        [$stmt, 'bind_param'],
        $refs
    );

    $stmt->execute();
}


/* =========================================================
   REPORT DATE RANGE
   ========================================================= */

$reportDateStart = $from . ' 00:00:00';
$reportDateEnd   = $to . ' 23:59:59';

$rangeDays = max(
    1,
    (int)(
        floor(
            (strtotime($to) - strtotime($from)) / 86400
        ) + 1
    )
);


/* =========================================================
   PERIOD STATS
   ========================================================= */

$periodStats = [

    'daily' => sales_metric_totals(
        $conn,
        's.sale_date',
        date('Y-m-d 00:00:00'),
        date('Y-m-d 23:59:59'),
        null
    ),

    'weekly' => sales_metric_totals(
        $conn,
        's.sale_date',
        date(
            'Y-m-d 00:00:00',
            strtotime('monday this week')
        ),
        date(
            'Y-m-d 23:59:59',
            strtotime('sunday this week')
        ),
        null
    ),

    'monthly' => sales_metric_totals(
        $conn,
        's.sale_date',
        date('Y-m-01 00:00:00'),
        date('Y-m-t 23:59:59'),
        null
    ),

    'yearly' => sales_metric_totals(
        $conn,
        's.sale_date',
        date('Y-01-01 00:00:00'),
        date('Y-12-31 23:59:59'),
        null
    )
];


/* =========================================================
   DAILY SERIES
   ========================================================= */

$trendDateStart = date('Y-01-01 00:00:00');
$trendDateEnd = date('Y-m-d 23:59:59');
$dailySeries = [];

$stmt = $conn->prepare("
    SELECT
        DATE(s.sale_date) AS bucket_date,
        COALESCE(SUM(s.total_amount),0) AS total_rev,
        COUNT(DISTINCT s.sale_id) AS sales_count

    FROM sales s

    WHERE s.sale_date BETWEEN ? AND ?
      AND LOWER(IFNULL(s.status,'')) <> 'cancelled'

    GROUP BY DATE(s.sale_date)

    ORDER BY bucket_date ASC
");

if ($stmt) {

    $stmt->bind_param(
        'ss',
        $trendDateStart,
        $trendDateEnd
    );

    $stmt->execute();

    $dailySeries =
        $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $stmt->close();
}


/* =========================================================
   WEEKLY SERIES
   ========================================================= */

$weeklySeries = [];

$stmt = $conn->prepare("
    SELECT
        YEARWEEK(s.sale_date, 1) AS bucket_key,
        MIN(DATE(s.sale_date)) AS week_start,
        MAX(DATE(s.sale_date)) AS week_end,
        COALESCE(SUM(s.total_amount),0) AS total_rev,
        COUNT(DISTINCT s.sale_id) AS sales_count

    FROM sales s

    WHERE s.sale_date BETWEEN ? AND ?
      AND LOWER(IFNULL(s.status,'')) <> 'cancelled'

    GROUP BY YEARWEEK(s.sale_date, 1)

    ORDER BY bucket_key ASC
");

if ($stmt) {

    $stmt->bind_param(
        'ss',
        $trendDateStart,
        $trendDateEnd
    );

    $stmt->execute();

    $weeklySeries =
        $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $stmt->close();
}


/* =========================================================
   MONTHLY SERIES
   ========================================================= */

$monthlySeries = [];

$stmt = $conn->prepare("
    SELECT
        DATE_FORMAT(s.sale_date, '%Y-%m') AS bucket_key,
        MIN(DATE(s.sale_date)) AS period_start,
        MAX(DATE(s.sale_date)) AS period_end,
        COALESCE(SUM(s.total_amount),0) AS total_rev,
        COUNT(DISTINCT s.sale_id) AS sales_count

    FROM sales s

    WHERE s.sale_date BETWEEN ? AND ?
      AND LOWER(IFNULL(s.status,'')) <> 'cancelled'

    GROUP BY DATE_FORMAT(s.sale_date, '%Y-%m')

    ORDER BY bucket_key ASC
");

if ($stmt) {

    $stmt->bind_param(
        'ss',
        $reportDateStart,
        $reportDateEnd
    );

    $stmt->execute();

    $monthlySeries =
        $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $stmt->close();
}


/* =========================================================
   YEARLY SERIES
   ========================================================= */

$yearlySeries = [];

$stmt = $conn->prepare("
    SELECT
        YEAR(s.sale_date) AS bucket_key,
        COALESCE(SUM(s.total_amount),0) AS total_rev,
        COUNT(DISTINCT s.sale_id) AS sales_count

    FROM sales s

    WHERE s.sale_date BETWEEN ? AND ?
      AND LOWER(IFNULL(s.status,'')) <> 'cancelled'

    GROUP BY YEAR(s.sale_date)

    ORDER BY bucket_key ASC
");

if ($stmt) {

    $stmt->bind_param(
        'ss',
        $reportDateStart,
        $reportDateEnd
    );

    $stmt->execute();

    $yearlySeries =
        $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $stmt->close();
}


/* =========================================================
   PRODUCT SALES
   ========================================================= */

$productSales = [];

$stmt = $conn->prepare("
    SELECT
        p.product_id,

        CONCAT(
            p.variety,
            ' - ',
            p.grade
        ) AS product_name,

        COALESCE(SUM(si.qty_kg),0) AS total_kg,

        COALESCE(SUM(si.line_total),0) AS total_sales,

        COUNT(DISTINCT s.sale_id) AS sale_count

    FROM sales s

    JOIN sales_items si
        ON si.sale_id = s.sale_id

    JOIN products p
        ON p.product_id = si.product_id

    WHERE s.sale_date BETWEEN ? AND ?
      AND LOWER(IFNULL(s.status,'')) <> 'cancelled'

    GROUP BY
        p.product_id,
        product_name

    ORDER BY total_sales DESC

    LIMIT 10
");

if ($stmt) {

    $stmt->bind_param(
        'ss',
        $reportDateStart,
        $reportDateEnd
    );

    $stmt->execute();

    $productSales =
        $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $stmt->close();
}


/* =========================================================
   CASHIER SALES
   ========================================================= */

$cashierSales = [];

$stmt = $conn->prepare("
    SELECT
        u.user_id,
        u.username,

        COALESCE(SUM(s.total_amount),0)
            AS total_sales,

        COUNT(DISTINCT s.sale_id)
            AS sale_count,

        COALESCE(
            SUM(
                CASE
                    WHEN LOWER(IFNULL(s.status,'')) = 'paid'
                    THEN s.total_amount
                    ELSE 0
                END
            ),
            0
        ) AS cash_sales,

        COALESCE(
            SUM(
                CASE
                    WHEN LOWER(IFNULL(s.status,'')) IN ('unpaid','partial')
                    THEN s.total_amount
                    ELSE 0
                END
            ),
            0
        ) AS utang_sales

    FROM sales s

    JOIN users u
        ON u.user_id = s.user_id

    WHERE s.sale_date BETWEEN ? AND ?
      AND LOWER(IFNULL(s.status,'')) <> 'cancelled'

    GROUP BY
        u.user_id,
        u.username

    ORDER BY total_sales DESC
");

if ($stmt) {

    $stmt->bind_param(
        'ss',
        $reportDateStart,
        $reportDateEnd
    );

    $stmt->execute();

    $cashierSales =
        $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $stmt->close();
}


/* =========================================================
   SALES COMPARISON
   ========================================================= */

$comparison = [

    'current' => sales_metric_totals(
        $conn,
        's.sale_date',
        $reportDateStart,
        $reportDateEnd,
        $cashierId > 0 ? $cashierId : null
    ),

    'previous' => sales_metric_totals(
        $conn,
        's.sale_date',

        date(
            'Y-m-d 00:00:00',
            strtotime(
                $from . ' -' . $rangeDays . ' days'
            )
        ),

        date(
            'Y-m-d 23:59:59',
            strtotime($from . ' -1 day')
        ),

        $cashierId > 0 ? $cashierId : null
    )
];

$comparison['delta'] =
    $comparison['current']['total_rev']
    -
    $comparison['previous']['total_rev'];

$comparison['growth_pct'] =
    $comparison['previous']['total_rev'] > 0

        ? (
            (
                $comparison['delta']
                /
                $comparison['previous']['total_rev']
            ) * 100
        )

        : 0;


/* =========================================================
   KPI CARD FUNCTION
   ========================================================= */

function metric_card(
    string $label,
    $value,
    string $sub = '',
    string $icon = 'fa-chart-line'
): void {

?>
    <div class="col-12 col-md-6 col-xl-3">

        <div class="border rounded-4 bg-white h-100 p-3 shadow-sm kpi-card">

            <div class="d-flex gap-3 align-items-start">

                <div class="kpi-icon">

                    <i class="fa-solid <?= htmlspecialchars(
                        $icon,
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>"></i>

                </div>

                <div class="min-w-0">

                    <div class="kpi-label">
                        <?= htmlspecialchars(
                            $label,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>
                    </div>

                    <div class="kpi-value">

                        <?= is_string($value)

                            ? htmlspecialchars(
                                $value,
                                ENT_QUOTES,
                                'UTF-8'
                            )

                            : $value

                        ?>

                    </div>

                    <?php if ($sub !== ''): ?>

                        <div class="kpi-sub">

                            <?= htmlspecialchars(
                                $sub,
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>

                        </div>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    </div>
<?php
}


/* =========================================================
   SALES ROWS
   ========================================================= */

$rows = [];

$stmt = $conn->prepare("
    SELECT

        s.sale_id,
        s.sale_date,
        s.status,

        u.username AS cashier_name,

        CONCAT(
            IFNULL(c.first_name,''),
            ' ',
            IFNULL(c.last_name,'')
        ) AS customer,

        COALESCE(
            s.total_amount,
            0
        ) AS amount,

        IFNULL(
            ar.balance,
            0
        ) AS balance,

        COALESCE(
            (
                SELECT SUM(si2.qty_kg)
                FROM sales_items si2
                WHERE si2.sale_id = s.sale_id
            ),
            0
        ) AS kg

    FROM sales s

    LEFT JOIN users u
        ON u.user_id = s.user_id

    LEFT JOIN customers c
        ON c.customer_id = s.customer_id

    LEFT JOIN account_receivable ar
        ON ar.sales_id = s.sale_id

    WHERE {$filterSql}

    ORDER BY s.sale_date DESC

    LIMIT ? OFFSET ?
");

if ($stmt) {

    $bindTypes = $filterTypes . 'ii';

    $queryParams =
        array_merge(
            $filterParams,
            [$perPage, $offset]
        );

    $bindArgs =
        array_merge(
            [$bindTypes],
            $queryParams
        );

    $refs = [];

    foreach ($bindArgs as $key => $value) {
        $refs[$key] = &$bindArgs[$key];
    }

    call_user_func_array(
        [$stmt, 'bind_param'],
        $refs
    );

    $stmt->execute();

    $rows =
        $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $stmt->close();
}


/* =========================================================
   TOTAL ROW COUNT
   ========================================================= */

$countRes = $conn->prepare("
    SELECT COUNT(DISTINCT s.sale_id) AS cnt

    FROM sales s

    LEFT JOIN sales_items si
        ON si.sale_id = s.sale_id

    WHERE {$filterSql}
");

$totalRows = 0;

if ($countRes) {

    $countRes->bind_param(
        $filterTypes,
        ...$filterParams
    );

    $countRes->execute();

    $countRow =
        $countRes->get_result()->fetch_assoc();

    $totalRows =
        (int)($countRow['cnt'] ?? 0);

    $countRes->close();
}

$totalPages =
    (int)max(
        1,
        ceil($totalRows / $perPage)
    );


/* =========================================================
   CSV EXPORT
   ========================================================= */

if ($isExport) {

    $filename =
        'sales_logs_' .
        $from .
        '_to_' .
        $to .
        '.csv';

    header(
        'Content-Type: text/csv; charset=UTF-8'
    );

    header(
        'Content-Disposition: attachment; filename="' .
        $filename .
        '"'
    );

    $out = fopen(
        'php://output',
        'w'
    );

    fputcsv(
        $out,
        [
            'Date',
            'Sale ID',
            'Cashier',
            'Customer',
            'Total kg',
            'Amount',
            'Status'
        ]
    );

    foreach ($rows as $r) {

        $st =
            strtolower(
                trim(
                    (string)($r['status'] ?? '')
                )
            );

        $statusLabel =
            $st !== ''
                ? strtoupper($st)
                : 'COMPLETED';

        fputcsv(
            $out,
            [

                !empty($r['sale_date'])
                    ? date(
                        'M d, Y h:i A',
                        strtotime($r['sale_date'])
                    )
                    : '',

                (int)($r['sale_id'] ?? 0),

                trim(
                    (string)($r['cashier_name'] ?? '')
                ) ?: 'Cashier',

                trim(
                    (string)($r['customer'] ?? '')
                ) ?: 'Walk-in Customer',

                number_format(
                    (float)($r['kg'] ?? 0),
                    2,
                    '.',
                    ''
                ),

                number_format(
                    (float)($r['amount'] ?? 0),
                    2,
                    '.',
                    ''
                ),

                $statusLabel
            ]
        );
    }

    fclose($out);

    exit;
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1"
>

<title>
    Sales Reports & Logs | DE ORO HIYS
</title>

<link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
    rel="stylesheet"
>

<link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    rel="stylesheet"
>

<link
    href="../css/layout.css"
    rel="stylesheet"
>

<link
    href="../css/owner-sales-report.css"
    rel="stylesheet"
>

<link
    href="../css/owner-mobile.css"
    rel="stylesheet"
>

<link
    href="../css/admin-mobile.css"
    rel="stylesheet"
>

<link
    href="../css/report-print.css"
    rel="stylesheet"
>

<link
    href="../css/cashier-sales-history.css"
    rel="stylesheet"
>

</head>


<body>

<?php

$profileLink = 'profile.php';
$logoutLink = '../logout.php';

include '../includes/topnav.php';

?>


<div class="container-fluid">

<div class="row">


<?php include '../includes/admin_sidebar.php'; ?>


<main class="col-lg-10 ms-sm-auto px-4 main-content">

<div class="py-4">


<!-- =====================================================
     PAGE HEADER
====================================================== -->

<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">

    <div>

        <h3 class="fw-bold mb-1">
            Sales Report
        </h3>

        <div class="text-muted">
            Filter by date range, then print if needed.
        </div>

    </div>


    <button
        class="btn btn-outline-dark no-print"
        onclick="window.print()"
    >

        <i class="fa-solid fa-print me-1"></i>

        Print

    </button>

</div>


<!-- =====================================================
     REPORT FRAME
====================================================== -->

<div class="report-frame modern-card mb-4">


<!-- =====================================================
     FILTER TOOLBAR
====================================================== -->

<div class="report-toolbar no-print">

<form
    class="row g-3 align-items-end"
    method="get"
>


<div class="col-12 col-md-3">

    <label class="form-label fw-semibold">
        Date From
    </label>

    <input
        type="date"
        class="form-control"
        name="from"
        value="<?= htmlspecialchars($from) ?>"
    >

</div>


<div class="col-12 col-md-3">

    <label class="form-label fw-semibold">
        Date To
    </label>

    <input
        type="date"
        class="form-control"
        name="to"
        value="<?= htmlspecialchars($to) ?>"
    >

</div>


<div class="col-12 col-md-3">

    <label class="form-label fw-semibold">
        Search
    </label>

    <input
        type="text"
        class="form-control"
        name="sale_id"
        value="<?= htmlspecialchars($saleIdQuery) ?>"
        placeholder="Invoice / Sale ID"
    >

</div>


<div class="col-12 col-md-3">

    <label class="form-label fw-semibold">
        Cashier
    </label>

    <select
        class="form-select"
        name="cashier_id"
    >

        <option
            value="0"
            <?= $cashierId <= 0 ? 'selected' : '' ?>
        >
            All Cashiers
        </option>


        <?php foreach ($cashiers as $cashier): ?>

            <option
                value="<?= (int)$cashier['user_id'] ?>"
                <?= $cashierId === (int)$cashier['user_id']
                    ? 'selected'
                    : ''
                ?>
            >

                <?= htmlspecialchars(
                    $cashier['username'] ?? 'Cashier'
                ) ?>

            </option>

        <?php endforeach; ?>

    </select>

</div>


<div class="col-12 col-md-3">

    <label class="form-label fw-semibold">
        Status
    </label>

    <select
        class="form-select"
        name="status"
    >

        <option
            value="all"
            <?= $statusFilter === 'all'
                ? 'selected'
                : ''
            ?>
        >
            All
        </option>

        <option
            value="paid"
            <?= $statusFilter === 'paid'
                ? 'selected'
                : ''
            ?>
        >
            Paid
        </option>

        <option
            value="unpaid"
            <?= $statusFilter === 'unpaid'
                ? 'selected'
                : ''
            ?>
        >
            Unpaid
        </option>

        <option
            value="partial"
            <?= $statusFilter === 'partial'
                ? 'selected'
                : ''
            ?>
        >
            Partial
        </option>

        <option
            value="cancelled"
            <?= $statusFilter === 'cancelled'
                ? 'selected'
                : ''
            ?>
        >
            Cancelled
        </option>

    </select>

</div>


<div class="col-12 col-md-3 d-grid">

    <button class="btn btn-dark btn-lg">

        <i class="fa-solid fa-magnifying-glass me-1"></i>

        Show

    </button>

</div>


<div class="col-12 col-md-3 d-grid">

    <a
        class="btn btn-outline-secondary btn-lg"
        href="sales_report.php"
    >

        <i class="fa-solid fa-rotate-left me-1"></i>

        Reset

    </a>

</div>


<div class="col-12 col-md-3 d-grid">

    <a
        class="btn btn-outline-dark btn-lg"
        href="?<?= htmlspecialchars(
            http_build_query(
                array_merge(
                    $_GET,
                    ['export' => 'csv']
                )
            ),
            ENT_QUOTES,
            'UTF-8'
        ) ?>"
    >

        <i class="fa-solid fa-file-arrow-down me-1"></i>

        CSV

    </a>

</div>


</form>

</div>


<!-- =====================================================
     REPORT CONTENT
====================================================== -->

<div class="p-3">


<!-- =====================================================
     KPI CARDS
====================================================== -->

<div class="row g-3 mb-4">

<?php

metric_card(
    'Today',
    '₱' . number_format(
        $periodStats['daily']['total_rev'],
        2
    ),
    $periodStats['daily']['sales_count'] . ' sale(s)',
    'fa-sun'
);

metric_card(
    'This Week',
    '₱' . number_format(
        $periodStats['weekly']['total_rev'],
        2
    ),
    $periodStats['weekly']['sales_count'] . ' sale(s)',
    'fa-calendar-week'
);

metric_card(
    'This Month',
    '₱' . number_format(
        $periodStats['monthly']['total_rev'],
        2
    ),
    $periodStats['monthly']['sales_count'] . ' sale(s)',
    'fa-calendar-days'
);

metric_card(
    'This Year',
    '₱' . number_format(
        $periodStats['yearly']['total_rev'],
        2
    ),
    $periodStats['yearly']['sales_count'] . ' sale(s)',
    'fa-calendar'
);

?>

</div>


<!-- =====================================================
     COMPARISON + OVERVIEW
====================================================== -->

<div class="row g-3 mb-4">


<!-- SALES COMPARISON -->

<div class="col-12 col-xl-6">

<div class="card modern-card h-100">

<div class="card-body">

<div class="d-flex justify-content-between align-items-start gap-2 mb-3">

<div>

<h5 class="fw-bold mb-1">
    Sales Comparison
</h5>

<div class="text-muted small">
    Current range vs previous equivalent range
</div>

</div>


<span
    class="badge <?= $comparison['growth_pct'] >= 0
        ? 'bg-success'
        : 'bg-danger'
    ?>"
>

<?= $comparison['growth_pct'] >= 0
    ? '+'
    : ''
?>

<?= number_format(
    $comparison['growth_pct'],
    1
) ?>%

</span>

</div>


<div class="d-flex justify-content-between mb-2">

<span class="text-muted">
    Current period
</span>

<strong>
    ₱<?= number_format(
        $comparison['current']['total_rev'],
        2
    ) ?>
</strong>

</div>


<div class="d-flex justify-content-between mb-2">

<span class="text-muted">
    Previous period
</span>

<strong>
    ₱<?= number_format(
        $comparison['previous']['total_rev'],
        2
    ) ?>
</strong>

</div>


<div
    class="progress"
    style="height: 12px;"
>

<?php

$currentComp =
    max(
        0.0,
        (float)$comparison['current']['total_rev']
    );

$previousComp =
    max(
        0.0,
        (float)$comparison['previous']['total_rev']
    );

$totalComp =
    max(
        1.0,
        $currentComp + $previousComp
    );

$currentPct =
    ($currentComp / $totalComp) * 100;

?>


<div
    class="progress-bar bg-success"
    style="width: <?= number_format(
        $currentPct,
        2
    ) ?>%"
></div>


<div
    class="progress-bar bg-secondary"
    style="width: <?= number_format(
        100 - $currentPct,
        2
    ) ?>%"
></div>


</div>


<div class="small text-muted mt-2">

Delta:
₱<?= number_format(
    $comparison['delta'],
    2
) ?>

</div>


</div>

</div>

</div>


<!-- SALES OVERVIEW -->

<div class="col-12 col-xl-6">

<div class="card modern-card h-100">

<div class="card-body">

<h5 class="fw-bold mb-1">
    Sales Overview
</h5>

<div class="text-muted small mb-3">
    Within the selected date range
</div>


<div class="row g-3">


<div class="col-6">

<div class="border rounded p-3 bg-white">

<div class="text-muted small">
    Total Sales
</div>

<div class="fw-bold fs-4">

₱<?= number_format(
    (float)$summary['total_rev'],
    2
) ?>

</div>

</div>

</div>


<div class="col-6">

<div class="border rounded p-3 bg-white">

<div class="text-muted small">
    Average Ticket
</div>

<div class="fw-bold fs-4">

₱<?= number_format(
    (float)$summary['avg_ticket'],
    2
) ?>

</div>

</div>

</div>


<div class="col-6">

<div class="border rounded p-3 bg-white">

<div class="text-muted small">
    Paid Sales
</div>

<div class="fw-bold fs-4">

<?= (int)$summary['cash_sales'] ?>

</div>

</div>

</div>


<div class="col-6">

<div class="border rounded p-3 bg-white">

<div class="text-muted small">
    Utang Sales
</div>

<div class="fw-bold fs-4">

<?= (int)$summary['utang_sales'] ?>

</div>

</div>

</div>


</div>

</div>

</div>

</div>

</div>


<!-- =====================================================
     SALES BY PRODUCT
====================================================== -->

<div class="card modern-card mb-4">

<div class="card-body">

<div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">

<div>

<h5 class="fw-bold mb-1">
    Sales by Product
</h5>

<div class="text-muted small">
    Top products by revenue in the selected range
</div>

</div>

</div>


<div class="table-responsive">

<table class="table align-middle mb-0">

<thead class="table-light">

<tr>

<th>
    Product
</th>

<th class="text-end">
    Qty (kg)
</th>

<th class="text-end">
    Sales
</th>

<th class="text-end">
    Sales Count
</th>

</tr>

</thead>


<tbody>


<?php if (!empty($productSales)): ?>

<?php foreach ($productSales as $row): ?>

<tr>

<td>

<?= htmlspecialchars(
    (string)($row['product_name'] ?? ''),
    ENT_QUOTES,
    'UTF-8'
) ?>

</td>


<td class="text-end">

<?= number_format(
    (float)($row['total_kg'] ?? 0),
    2
) ?>

</td>


<td class="text-end">

₱<?= number_format(
    (float)($row['total_sales'] ?? 0),
    2
) ?>

</td>


<td class="text-end">

<?= (int)($row['sale_count'] ?? 0) ?>

</td>

</tr>

<?php endforeach; ?>


<?php else: ?>

<tr>

<td
    colspan="4"
    class="text-center text-muted py-4"
>

No product sales found for the selected range.

</td>

</tr>

<?php endif; ?>


</tbody>

</table>

</div>

</div>

</div>


<!-- =====================================================
     SALES BY CASHIER
====================================================== -->

<div class="card modern-card mb-4">

<div class="card-body">

<h5 class="fw-bold mb-1">
    Sales by Cashier
</h5>

<div class="text-muted small mb-3">
    Performance by cashier in the selected range
</div>


<div class="table-responsive">

<table class="table align-middle mb-0">

<thead class="table-light">

<tr>

<th>
    Cashier
</th>

<th class="text-end">
    Sales
</th>

<th class="text-end">
    Transactions
</th>

<th class="text-end">
    Paid
</th>

<th class="text-end">
    Utang
</th>

</tr>

</thead>


<tbody>


<?php if (!empty($cashierSales)): ?>

<?php foreach ($cashierSales as $row): ?>

<tr>

<td>

<?= htmlspecialchars(
    (string)($row['username'] ?? 'Cashier'),
    ENT_QUOTES,
    'UTF-8'
) ?>

</td>


<td class="text-end">

₱<?= number_format(
    (float)($row['total_sales'] ?? 0),
    2
) ?>

</td>


<td class="text-end">

<?= (int)($row['sale_count'] ?? 0) ?>

</td>


<td class="text-end">

₱<?= number_format(
    (float)($row['cash_sales'] ?? 0),
    2
) ?>

</td>


<td class="text-end">

₱<?= number_format(
    (float)($row['utang_sales'] ?? 0),
    2
) ?>

</td>

</tr>

<?php endforeach; ?>


<?php else: ?>

<tr>

<td
    colspan="5"
    class="text-center text-muted py-4"
>

No cashier sales found for the selected range.

</td>

</tr>

<?php endif; ?>


</tbody>

</table>

</div>

</div>

</div>


<!-- =====================================================
     TREND BREAKDOWN
====================================================== -->

<div class="card modern-card mb-4">

<div class="card-body">

<h5 class="fw-bold mb-1">
    Trend Breakdown
</h5>

<div class="text-muted small mb-3">
    Daily and weekly sales show the current year; monthly and yearly totals use the selected range
</div>

<div class="trend-tabs mb-3" role="tablist" aria-label="Trend breakdown periods">
    <button type="button" class="trend-tab active" data-trend-tab="daily" role="tab" aria-selected="true">Daily</button>
    <button type="button" class="trend-tab" data-trend-tab="weekly" role="tab" aria-selected="false">Weekly</button>
    <button type="button" class="trend-tab" data-trend-tab="monthly" role="tab" aria-selected="false">Monthly</button>
    <button type="button" class="trend-tab" data-trend-tab="yearly" role="tab" aria-selected="false">Yearly</button>
</div>

<style>
    .trend-tabs { display: flex; flex-wrap: wrap; gap: 8px; }
    .trend-tab { border: 1px solid #cbd5e1; border-radius: 999px; background: #fff; color: #2d4055; padding: 7px 16px; font-weight: 600; cursor: pointer; }
    .trend-tab.active, .trend-tab:hover { background: #2d4055; border-color: #2d4055; color: #fff; }
    .trend-panel:not(.is-active) { display: none; }
</style>

<div class="row g-3 trend-panels">


<!-- DAILY -->

<div class="col-12 trend-panel is-active" data-trend-panel="daily" role="tabpanel">

<div class="border rounded p-3 bg-white h-100">

<div class="fw-bold mb-2">
    Daily Sales
</div>


<div class="table-responsive">

<table class="table table-sm mb-0">

<thead class="table-light">

<tr>

<th>
    Date
</th>

<th class="text-end">
    Sales
</th>

<th class="text-end">
    Count
</th>

</tr>

</thead>


<tbody>


<?php if (!empty($dailySeries)): ?>

<?php foreach ($dailySeries as $row): ?>

<tr>

<td>

<?= htmlspecialchars(
    date(
        'M d, Y',
        strtotime(
            (string)$row['bucket_date']
        )
    ),
    ENT_QUOTES,
    'UTF-8'
) ?>

</td>


<td class="text-end">

₱<?= number_format(
    (float)$row['total_rev'],
    2
) ?>

</td>


<td class="text-end">

<?= (int)$row['sales_count'] ?>

</td>

</tr>

<?php endforeach; ?>


<?php else: ?>

<tr>

<td
    colspan="3"
    class="text-center text-muted py-3"
>

No daily records found.

</td>

</tr>

<?php endif; ?>


</tbody>

</table>

</div>

</div>

</div>


<!-- WEEKLY -->

<div class="col-12 trend-panel" data-trend-panel="weekly" role="tabpanel">

<div class="border rounded p-3 bg-white h-100">

<div class="fw-bold mb-2">
    Weekly Sales
</div>


<div class="table-responsive">

<table class="table table-sm mb-0">

<thead class="table-light">

<tr>

<th>
    Week
</th>

<th class="text-end">
    Sales
</th>

<th class="text-end">
    Count
</th>

</tr>

</thead>


<tbody>


<?php if (!empty($weeklySeries)): ?>

<?php foreach ($weeklySeries as $row): ?>

<tr>

<td>

<?= htmlspecialchars(

date(
    'M d',
    strtotime(
        (string)$row['week_start']
    )
)

. ' - ' .

date(
    'M d, Y',
    strtotime(
        (string)$row['week_end']
    )
),

ENT_QUOTES,
'UTF-8'

) ?>

</td>


<td class="text-end">

₱<?= number_format(
    (float)$row['total_rev'],
    2
) ?>

</td>


<td class="text-end">

<?= (int)$row['sales_count'] ?>

</td>

</tr>

<?php endforeach; ?>


<?php else: ?>

<tr>

<td
    colspan="3"
    class="text-center text-muted py-3"
>

No weekly records found.

</td>

</tr>

<?php endif; ?>


</tbody>

</table>

</div>

</div>

</div>


<!-- MONTHLY -->

<div class="col-12 trend-panel" data-trend-panel="monthly" role="tabpanel">

<div class="border rounded p-3 bg-white h-100">

<div class="fw-bold mb-2">
    Monthly Sales
</div>


<div class="table-responsive">

<table class="table table-sm mb-0">

<thead class="table-light">

<tr>

<th>
    Month
</th>

<th class="text-end">
    Sales
</th>

<th class="text-end">
    Count
</th>

</tr>

</thead>


<tbody>


<?php if (!empty($monthlySeries)): ?>

<?php foreach ($monthlySeries as $row): ?>

<tr>

<td>

<?= htmlspecialchars(

date(
    'F Y',
    strtotime(
        (string)$row['period_start']
    )
),

ENT_QUOTES,
'UTF-8'

) ?>

</td>


<td class="text-end">

₱<?= number_format(
    (float)$row['total_rev'],
    2
) ?>

</td>


<td class="text-end">

<?= (int)$row['sales_count'] ?>

</td>

</tr>

<?php endforeach; ?>


<?php else: ?>

<tr>

<td
    colspan="3"
    class="text-center text-muted py-3"
>

No monthly records found.

</td>

</tr>

<?php endif; ?>


</tbody>

</table>

</div>

</div>

</div>


<!-- YEARLY -->

<div class="col-12 trend-panel" data-trend-panel="yearly" role="tabpanel">

<div class="border rounded p-3 bg-white h-100">

<div class="fw-bold mb-2">
    Yearly Sales
</div>


<div class="table-responsive">

<table class="table table-sm mb-0">

<thead class="table-light">

<tr>

<th>
    Year
</th>

<th class="text-end">
    Sales
</th>

<th class="text-end">
    Count
</th>

</tr>

</thead>


<tbody>


<?php if (!empty($yearlySeries)): ?>

<?php foreach ($yearlySeries as $row): ?>

<tr>

<td>

<?= htmlspecialchars(
    (string)$row['bucket_key'],
    ENT_QUOTES,
    'UTF-8'
) ?>

</td>


<td class="text-end">

₱<?= number_format(
    (float)$row['total_rev'],
    2
) ?>

</td>


<td class="text-end">

<?= (int)$row['sales_count'] ?>

</td>

</tr>

<?php endforeach; ?>


<?php else: ?>

<tr>

<td
    colspan="3"
    class="text-center text-muted py-3"
>

No yearly records found.

</td>

</tr>

<?php endif; ?>


</tbody>

</table>

</div>

</div>

</div>


</div>

</div>

</div>


</div>


<!-- =====================================================
     SALES LOG TABLE
====================================================== -->

<div class="card-body p-0">

<div class="table-responsive">

<table class="table table-hover align-middle mb-0 report-table">


<thead>

<tr>

<th>
    Invoice #
</th>

<th>
    Date Recorded
</th>

<th>
    Cashier
</th>

<th>
    Customer
</th>

<th>
    Sale Type
</th>

<th>
    Total (₱)
</th>

<th>
    Status
</th>

<th>
    Balance
</th>

<th class="no-print"></th>

</tr>

</thead>


<tbody>


<?php if (!empty($rows)): ?>


<?php foreach ($rows as $r): ?>


<?php

$st =
    strtolower(
        trim(
            (string)($r['status'] ?? '')
        )
    );

$saleType = 'CASH';

if (
    in_array(
        $st,
        ['unpaid', 'partial'],
        true
    )
) {

    $saleType = 'UTANG';

} elseif ($st === 'cancelled') {

    $saleType = 'CANCELLED';
}


$balanceValue =
    (float)($r['balance'] ?? 0);

$hasBalance =
    $st !== 'paid'
    &&
    $balanceValue > 0;

?>


<tr>


<td class="fw-semibold">

INV-<?= str_pad(
    (string)(int)$r['sale_id'],
    6,
    '0',
    STR_PAD_LEFT
) ?>

</td>


<td>

<?= !empty($r['sale_date'])

    ? date(
        'M d, Y h:i A',
        strtotime($r['sale_date'])
    )

    : ''

?>

</td>


<td>

<?= htmlspecialchars(
    trim(
        $r['cashier_name'] ?? ''
    ) ?: 'Cashier'
) ?>

</td>


<td>

<?= htmlspecialchars(
    trim(
        $r['customer'] ?? ''
    ) ?: 'Walk-in Customer'
) ?>

</td>


<td>

<span
    class="badge
    <?= $saleType === 'UTANG'

        ? 'bg-warning text-dark'

        : (
            $saleType === 'CANCELLED'
                ? 'bg-secondary'
                : 'bg-success'
        )

    ?>"
>

<?= htmlspecialchars($saleType) ?>

</span>

</td>


<td>

<?= number_format(
    (float)$r['amount'],
    2
) ?>

</td>


<td>


<?php if ($st === 'paid'): ?>

<span class="badge bg-success">
    PAID
</span>


<?php elseif ($st === 'unpaid'): ?>

<span class="badge bg-warning text-dark">
    UNPAID
</span>


<?php elseif ($st === 'partial'): ?>

<span class="badge bg-info text-dark">
    PARTIAL
</span>


<?php elseif ($st === 'cancelled'): ?>

<span class="badge bg-secondary">
    CANCELLED
</span>


<?php else: ?>

<span class="badge bg-dark">

<?= htmlspecialchars(
    strtoupper(
        $st ?: 'N/A'
    )
) ?>

</span>

<?php endif; ?>


</td>


<td>

<?= $hasBalance

    ? '₱' . number_format(
        $balanceValue,
        2
    )

    : '-'

?>

</td>


<td class="no-print">

<button
    class="btn btn-sm btn-outline-dark"
    data-bs-toggle="modal"
    data-bs-target="#saleModal<?= (int)$r['sale_id'] ?>"
>

<i class="fa-regular fa-eye"></i>

</button>

</td>


</tr>


<?php endforeach; ?>


<?php else: ?>


<tr>

<td
    colspan="9"
    class="text-center text-muted py-4"
>

No sales for selected range.

</td>

</tr>


<?php endif; ?>


</tbody>


<tfoot>

<tr>

<td
    colspan="5"
    class="fw-semibold text-end"
>

Total Sales (All Time):

</td>


<td class="fw-semibold">

₱<?= number_format(
    $allTimeSalesTotal,
    2
) ?>

</td>


<td colspan="3"></td>

</tr>

</tfoot>


</table>

</div>

</div>


<!-- =====================================================
     REPORT FOOTER / PAGINATION
====================================================== -->

<div class="report-footer d-flex flex-wrap gap-3 align-items-center justify-content-between">


<div>

Showing <?= count($rows) ?> record(s)
on page <?= $page ?> of <?= $totalPages ?>

</div>


<nav>

<ul class="pagination pagination-sm mb-0">


<li
    class="page-item
    <?= $page <= 1 ? 'disabled' : '' ?>"
>

<a
    class="page-link"
    href="?<?= http_build_query(
        array_merge(
            $_GET,
            [
                'page' =>
                    max(
                        1,
                        $page - 1
                    )
            ]
        )
    ) ?>"
>

Prev

</a>

</li>


<?php

$startPage =
    max(
        1,
        $page - 2
    );

$endPage =
    min(
        $totalPages,
        $page + 2
    );

for (
    $i = $startPage;
    $i <= $endPage;
    $i++
):

?>


<li
    class="page-item
    <?= $i === $page
        ? 'active'
        : ''
    ?>"
>

<a
    class="page-link"
    href="?<?= http_build_query(
        array_merge(
            $_GET,
            [
                'page' => $i
            ]
        )
    ) ?>"
>

<?= $i ?>

</a>

</li>


<?php endfor; ?>


<li
    class="page-item
    <?= $page >= $totalPages
        ? 'disabled'
        : ''
    ?>"
>

<a
    class="page-link"
    href="?<?= http_build_query(
        array_merge(
            $_GET,
            [
                'page' =>
                    min(
                        $totalPages,
                        $page + 1
                    )
            ]
        )
    ) ?>"
>

Next

</a>

</li>


</ul>

</nav>


</div>


</div>


</div>


<!-- =====================================================
     SALE DETAIL MODALS
====================================================== -->


<?php if (!empty($rows)): ?>


<?php foreach ($rows as $r): ?>


<?php

$saleId =
    (int)$r['sale_id'];

$saleItems = [];


$itemsStmt = $conn->prepare("
    SELECT

        si.qty_kg,
        si.unit_price,
        si.line_total,

        p.variety,
        p.grade

    FROM sales_items si

    LEFT JOIN products p
        ON p.product_id = si.product_id

    WHERE si.sale_id = ?

    ORDER BY si.sales_item_id ASC
");


if ($itemsStmt) {

    $itemsStmt->bind_param(
        'i',
        $saleId
    );

    $itemsStmt->execute();

    $itemsRes =
        $itemsStmt->get_result();

    while (
        $itemRow =
            $itemsRes->fetch_assoc()
    ) {

        $saleItems[] =
            $itemRow;
    }

    $itemsStmt->close();
}

?>


<div
    class="modal fade"
    id="saleModal<?= $saleId ?>"
    tabindex="-1"
    aria-hidden="true"
>

<div
    class="modal-dialog modal-lg modal-dialog-scrollable"
>

<div class="modal-content">


<div class="modal-header">

<h5 class="modal-title">

Sale #<?= $saleId ?>
Details

</h5>


<button
    type="button"
    class="btn-close"
    data-bs-dismiss="modal"
></button>

</div>


<div class="modal-body">


<div class="row g-2 mb-3">


<div class="col-md-4">

<b>Cashier:</b>

<?= htmlspecialchars(
    trim(
        $r['cashier_name'] ?? ''
    ) ?: 'Cashier'
) ?>

</div>


<div class="col-md-4">

<b>Customer:</b>

<?= htmlspecialchars(
    trim(
        $r['customer'] ?? ''
    ) ?: 'Walk-in Customer'
) ?>

</div>


<div class="col-md-4">

<b>Status:</b>

<?= htmlspecialchars(
    strtoupper(
        $r['status'] ?? 'N/A'
    )
) ?>

</div>


<div class="col-md-4">

<b>Date:</b>

<?= !empty($r['sale_date'])

    ? date(
        'M d, Y h:i A',
        strtotime(
            $r['sale_date']
        )
    )

    : ''

?>

</div>


<div class="col-md-4">

<b>Total:</b>

₱<?= number_format(
    (float)$r['amount'],
    2
) ?>

</div>


<div class="col-md-4">

<b>Balance:</b>

<?= (
    ($r['status'] ?? '') === 'paid'
    ||
    (float)($r['balance'] ?? 0) <= 0
)

    ? '-'

    : '₱' . number_format(
        (float)($r['balance'] ?? 0),
        2
    )

?>

</div>


</div>


<div class="table-responsive">


<table
    class="table table-bordered align-middle mb-0"
>


<thead class="table-dark">

<tr>

<th>
    Product
</th>

<th class="text-end">
    Qty (kg)
</th>

<th class="text-end">
    Unit Price
</th>

<th class="text-end">
    Line Total
</th>

</tr>

</thead>


<tbody>


<?php if (!empty($saleItems)): ?>


<?php foreach ($saleItems as $item): ?>


<tr>


<td>

<?= htmlspecialchars(
    trim(
        ($item['variety'] ?? 'N/A')
        .
        ' - '
        .
        ($item['grade'] ?? '')
    )
) ?>

</td>


<td class="text-end">

<?= number_format(
    (float)($item['qty_kg'] ?? 0),
    2
) ?>

</td>


<td class="text-end">

₱<?= number_format(
    (float)($item['unit_price'] ?? 0),
    2
) ?>

</td>


<td class="text-end">

₱<?= number_format(
    (float)($item['line_total'] ?? 0),
    2
) ?>

</td>


</tr>


<?php endforeach; ?>


<?php else: ?>


<tr>

<td
    colspan="4"
    class="text-center text-muted"
>

No items found for this sale.

</td>

</tr>


<?php endif; ?>


</tbody>


</table>


</div>


</div>


<div class="modal-footer">

<button
    class="btn btn-secondary"
    data-bs-dismiss="modal"
>

Close

</button>

</div>


</div>

</div>

</div>


<?php endforeach; ?>


<?php endif; ?>


</div>

</main>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
(function () {
    document.addEventListener('click', function (event) {
        const tab = event.target.closest('[data-trend-tab]');
        if (!tab) return;

        const key = tab.getAttribute('data-trend-tab');
        document.querySelectorAll('[data-trend-tab]').forEach(function (item) {
            const active = item.getAttribute('data-trend-tab') === key;
            item.classList.toggle('active', active);
            item.setAttribute('aria-selected', active ? 'true' : 'false');
        });
        document.querySelectorAll('[data-trend-panel]').forEach(function (panel) {
            panel.classList.toggle('is-active', panel.getAttribute('data-trend-panel') === key);
        });
    });

    const pollIntervalMs = 5000;
    let pollingInFlight = false;

    // ✅ PRESERVE ALL FILTER VALUES BEFORE REFRESH
    function getFilterValues() {
        return {
            from: document.querySelector('input[name="from"]')?.value || '',
            to: document.querySelector('input[name="to"]')?.value || '',
            sale_id: document.querySelector('input[name="sale_id"]')?.value || '',
            cashier_id: document.querySelector('select[name="cashier_id"]')?.value || '',
            status: document.querySelector('select[name="status"]')?.value || ''
        };
    }

    // ✅ RESTORE ALL FILTER VALUES AFTER REFRESH
    function restoreFilterValues(saved) {
        const fromInput = document.querySelector('input[name="from"]');
        const toInput = document.querySelector('input[name="to"]');
        const searchInput = document.querySelector('input[name="sale_id"]');
        const cashierSelect = document.querySelector('select[name="cashier_id"]');
        const statusSelect = document.querySelector('select[name="status"]');

        if (fromInput) fromInput.value = saved.from;
        if (toInput) toInput.value = saved.to;
        if (searchInput) searchInput.value = saved.sale_id;
        if (cashierSelect) cashierSelect.value = saved.cashier_id;
        if (statusSelect) statusSelect.value = saved.status;
    }

    async function pollLiveMain() {
        if (pollingInFlight) return;
        pollingInFlight = true;

        try {
            // Save EVERYTHING in the filter section BEFORE updating
            const savedFilters = getFilterValues();

            const url = new URL(window.location.href);
            url.searchParams.set('_live', Date.now().toString());

            const response = await fetch(url.toString(), {
                credentials: 'same-origin',
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            });

            const html = await response.text();
            const doc = new DOMParser().parseFromString(html, 'text/html');

            // ✅ ONLY update the REPORT CONTENT — leave the filter toolbar COMPLETELY ALONE
            const sourceContent = doc.querySelector('.report-frame > .p-3');
            const targetContent = document.querySelector('.report-frame > .p-3');

            if (sourceContent && targetContent) {
                targetContent.innerHTML = sourceContent.innerHTML;
            }

            // ✅ Restore all date/search/dropdown values so nothing changes
            restoreFilterValues(savedFilters);

        } catch (error) {
            console.error('Sales report live poll failed:', error);
        } finally {
            pollingInFlight = false;
        }
    }

    pollLiveMain();
    window.setInterval(pollLiveMain, pollIntervalMs);
})();
</script>


<style>
:root {

    --system-navy: #2D4055;
    --system-navy-dark: #24364A;
    --system-navy-light: #344B63;

    --system-bg: #EDF1F5;
    --system-card: #F6F8FA;
    --system-white: #FFFFFF;

    --system-border: #D5DDE5;
    --system-border-dark: #C3CED9;

    --system-text: #24364A;
    --system-muted: #60758A;

    --system-hover: #E8EDF2;
}


/* =========================================================
   PAGE
========================================================= */

body {

    background:
        var(--system-bg) !important;

    color:
        var(--system-text);

}


.main-content {

    background:
        var(--system-bg);

    min-height:
        calc(100vh - 60px);

}


.main-content > .py-4 {

    padding-top:
        28px !important;

}


/* =========================================================
   PAGE TITLE
========================================================= */

.main-content h3 {

    color:
        var(--system-navy-dark) !important;

    font-weight:
        700;

    letter-spacing:
        -0.3px;

}


.main-content .text-muted {

    color:
        var(--system-muted) !important;

}


/* =========================================================
   MODERN CARDS
========================================================= */

.modern-card,
.card {

    background:
        var(--system-card) !important;

    border:
        1px solid var(--system-border) !important;

    border-radius:
        10px !important;

    box-shadow:
        0 2px 7px
        rgba(36, 54, 74, 0.08) !important;

}


.card-body {

    background:
        transparent;

}


/* =========================================================
   REPORT FRAME
========================================================= */

.report-frame {

    background:
        var(--system-card) !important;

    border:
        1px solid var(--system-border) !important;

    border-radius:
        10px !important;

    overflow:
        hidden;

}


.report-toolbar {

    background:
        var(--system-navy) !important;

    border-bottom:
        1px solid var(--system-navy-dark);

    padding:
        20px;

}


/* =========================================================
   TOOLBAR LABELS
========================================================= */

.report-toolbar .form-label {

    color:
        #FFFFFF !important;

    margin-bottom:
        6px;

}


/* =========================================================
   FORM CONTROLS
========================================================= */

.form-control,
.form-select {

    border:
        1px solid var(--system-border-dark);

    border-radius:
        6px;

    color:
        var(--system-text);

    background-color:
        #FFFFFF;

    min-height:
        42px;

}


.form-control:focus,
.form-select:focus {

    border-color:
        var(--system-navy);

    box-shadow:
        0 0 0 0.2rem
        rgba(45, 64, 85, 0.15);

}


/* =========================================================
   BUTTONS
========================================================= */

.btn-dark {

    background-color:
        var(--system-navy) !important;

    border-color:
        var(--system-navy) !important;

}


.btn-dark:hover {

    background-color:
        var(--system-navy-dark) !important;

    border-color:
        var(--system-navy-dark) !important;

}


.btn-outline-dark {

    color:
        var(--system-navy) !important;

    border-color:
        var(--system-navy) !important;

}


.btn-outline-dark:hover {

    background-color:
        var(--system-navy) !important;

    border-color:
        var(--system-navy) !important;

    color:
        #FFFFFF !important;

}


.btn-outline-secondary {

    color:
        var(--system-muted) !important;

    border-color:
        var(--system-border-dark) !important;

}


.btn-outline-secondary:hover {

    background-color:
        var(--system-hover) !important;

    color:
        var(--system-navy-dark) !important;

    border-color:
        var(--system-border-dark) !important;

}


/* =========================================================
   KPI CARDS
========================================================= */

.kpi-card {

    border:
        1px solid var(--system-border) !important;

}


.kpi-icon {

    width:
        44px;

    height:
        44px;

    min-width:
        44px;

    display:
        flex;

    align-items:
        center;

    justify-content:
        center;

    border-radius:
        8px;

    background:
        var(--system-navy);

    color:
        #FFFFFF;

    font-size:
        18px;

}


.kpi-icon i {

    color:
        #FFFFFF !important;

}


.kpi-label {

    color:
        var(--system-muted);

    font-size:
        13px;

    font-weight:
        600;

    margin-bottom:
        2px;

}


.kpi-value {

    color:
        var(--system-navy-dark);

    font-size:
        21px;

    font-weight:
        700;

    line-height:
        1.2;

}


.kpi-sub {

    color:
        var(--system-muted);

    font-size:
        12px;

    margin-top:
        3px;

}


/* =========================================================
   SECTION HEADINGS
========================================================= */

.card h5 {

    color:
        var(--system-navy-dark);

}


.fw-bold {

    color:
        var(--system-navy-dark);

}


/* =========================================================
   INNER SUMMARY BOXES
========================================================= */

.border.rounded,
.border.rounded-4 {

    border-color:
        var(--system-border) !important;

}


.bg-white {

    background-color:
        #FFFFFF !important;

}


/* =========================================================
   TABLES
========================================================= */

.table {

    color:
        var(--system-text);

}


.table thead,
.table-dark {

    background-color:
        var(--system-navy) !important;

    color:
        #FFFFFF !important;

}


.table thead th,
.table-dark th {

    background-color:
        var(--system-navy) !important;

    color:
        #FFFFFF !important;

    border-color:
        var(--system-navy-light) !important;

    font-weight:
        600;

}


.table-light th {

    background-color:
        var(--system-navy) !important;

    color:
        #FFFFFF !important;

    border-color:
        var(--system-navy-light) !important;

}


.table tbody td {

    border-color:
        var(--system-border) !important;

}


.table tbody tr {

    background-color:
        #FFFFFF;

}


.table-hover tbody tr:hover {

    background-color:
        var(--system-hover) !important;

}


/* =========================================================
   MAIN REPORT TABLE
========================================================= */

.report-table {

    border-collapse:
        separate;

    border-spacing:
        0;

}


.report-table thead th {

    background-color:
        var(--system-navy) !important;

    color:
        #FFFFFF !important;

    border-color:
        var(--system-navy-light) !important;

    padding:
        12px 14px;

    font-weight:
        600;

    white-space:
        nowrap;

}


.report-table tbody td {

    padding:
        12px 14px;

    vertical-align:
        middle;

}


.report-table tbody tr:nth-child(even) {

    background-color:
        #F8FAFC;

}


.report-table tbody tr:hover {

    background-color:
        var(--system-hover) !important;

}


/* =========================================================
   TABLE FOOTER
========================================================= */

.report-table tfoot td {

    background-color:
        #E8EDF2 !important;

    color:
        var(--system-navy-dark);

    border-top:
        2px solid var(--system-border-dark);

}


/* =========================================================
   BADGES
========================================================= */

.badge.bg-dark {

    background-color:
        var(--system-navy) !important;

}


.badge.bg-secondary {

    background-color:
        #6B7C8E !important;

}


/* Business status colors */

.badge.bg-success {

    background-color:
        #3F7D5A !important;

}


.badge.bg-warning {

    background-color:
        #D7A63D !important;

}


.badge.bg-info {

    background-color:
        #5E879B !important;

}


.badge.bg-danger {

    background-color:
        #A95353 !important;

}


/* =========================================================
   PROGRESS BAR
========================================================= */

.progress {

    background-color:
        #DDE4EA !important;

    border-radius:
        8px;

    overflow:
        hidden;

}


.progress-bar.bg-success {

    background-color:
        var(--system-navy) !important;

}


.progress-bar.bg-secondary {

    background-color:
        #9AA8B5 !important;

}


/* =========================================================
   PAGINATION
========================================================= */

.pagination .page-link {

    color:
        var(--system-navy);

    border-color:
        var(--system-border);

    background-color:
        #FFFFFF;

}


.pagination .page-link:hover {

    background-color:
        var(--system-hover);

    color:
        var(--system-navy-dark);

}


.pagination .page-item.active .page-link {

    background-color:
        var(--system-navy) !important;

    border-color:
        var(--system-navy) !important;

    color:
        #FFFFFF !important;

}


.pagination .page-item.disabled .page-link {

    color:
        #9AA8B5;

    background-color:
        #F3F5F7;

}


/* =========================================================
   MODALS
========================================================= */

.modal-content {

    border:
        1px solid var(--system-border);

    border-radius:
        10px;

    overflow:
        hidden;

}


.modal-header {

    background-color:
        var(--system-navy);

    color:
        #FFFFFF;

    border-bottom:
        1px solid var(--system-navy-dark);

}


.modal-header .modal-title {

    color:
        #FFFFFF;

    font-weight:
        700;

}


.modal-header .btn-close {

    filter:
        brightness(0) invert(1);

}


.modal-body {

    background-color:
        var(--system-card);

}


.modal-footer {

    background-color:
        #EEF2F5;

    border-top:
        1px solid var(--system-border);

}


.modal .table thead th {

    background-color:
        var(--system-navy) !important;

    color:
        #FFFFFF !important;

}


/* =========================================================
   REPORT FOOTER
========================================================= */

.report-footer {

    background-color:
        #E8EDF2;

    border-top:
        1px solid var(--system-border);

    padding:
        14px 18px;

    color:
        var(--system-muted);

}


/* =========================================================
   SIDEBAR
========================================================= */

#sidebarMenu,
.sidebar {

    background-color:
        var(--system-navy) !important;

}


/* =========================================================
   TOP NAV
========================================================= */

.topbar,
.navbar {

    border-bottom:
        1px solid var(--system-border);

}


/* =========================================================
   SMALL TABLES
========================================================= */

.table-sm thead th {

    background-color:
        var(--system-navy) !important;

    color:
        #FFFFFF !important;

}


.table-sm tbody td {

    padding:
        9px 10px;

}


/* =========================================================
   PRIMARY TEXT
========================================================= */

.text-primary {

    color:
        var(--system-navy) !important;

}


/* =========================================================
   PRINT
========================================================= */

@media print {

    body {

        background:
            #FFFFFF !important;

    }


    .no-print,
    #sidebarMenu,
    .topbar,
    .navbar,
    .btn,
    form {

        display:
            none !important;

    }


    .main-content {

        margin:
            0 !important;

        padding:
            0 !important;

        background:
            #FFFFFF !important;

        width:
            100% !important;

    }


    .modern-card,
    .card,
    .report-frame {

        box-shadow:
            none !important;

        border:
            1px solid #CCCCCC !important;

        background:
            #FFFFFF !important;

    }


    .table thead th,
    .table-dark th {

        background:
            #2D4055 !important;

        color:
            #FFFFFF !important;

        -webkit-print-color-adjust:
            exact;

        print-color-adjust:
            exact;

    }


    .report-table tbody tr:nth-child(even) {

        background:
            #F5F5F5 !important;

        -webkit-print-color-adjust:
            exact;

        print-color-adjust:
            exact;

    }

}


/* =========================================================
   TABLET
========================================================= */

@media (max-width: 991.98px) {

    .container-fluid > .row {
        margin-left: 0;
        margin-right: 0;
    }

    .main-content {
        width: 100%;
        max-width: 100%;
        margin-left: 0 !important;
    }

    .main-content {

        padding-left:
            15px !important;

        padding-right:
            15px !important;

    }


    .report-toolbar {

        padding:
            15px;

    }


    .kpi-value {

        font-size:
            19px;

    }

}


/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 575.98px) {

    .main-content {
        padding-left: 10px !important;
        padding-right: 10px !important;
    }

    .main-content > .py-4 {
        padding-left: 0 !important;
        padding-right: 0 !important;
    }

    .report-frame {
        overflow: visible;
        border-radius: 10px !important;
    }

    .report-toolbar form > [class*="col-"] {
        width: 100%;
    }

    .report-toolbar .btn,
    .report-toolbar button,
    .report-toolbar input[type="submit"] {
        min-height: 42px;
    }

    .kpi-card {
        padding: 12px !important;
    }

    .trend-tabs {
        display: grid !important;
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .trend-tab {
        padding: 8px 10px !important;
    }

    .modal-dialog {
        margin: .5rem !important;
    }

    .modal-dialog.modal-lg {
        max-width: calc(100% - 1rem);
    }

    .modal-content {
        max-height: calc(100dvh - 1rem);
        overflow-y: auto;
    }

    .main-content > .py-4 {

        padding-top:
            18px !important;

    }


    .report-toolbar {

        padding:
            12px;

    }


    .report-table {

        font-size:
            13px;

    }


    .report-table thead th,
    .report-table tbody td {

        padding:
            9px 10px;

    }

    .table-responsive {
        max-width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }


    .kpi-icon {

        width:
            38px;

        height:
            38px;

        min-width:
            38px;

        font-size:
            15px;

    }


    .kpi-value {

        font-size:
            17px;

    }

}

</style>


</body>

</html>
