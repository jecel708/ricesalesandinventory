<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$role     = $_SESSION['role'] ?? '';
$username = $_SESSION['username'] ?? 'User';
$user_id  = (int)($_SESSION['user_id'] ?? 0);

include '../config/db.php';


// ============================================================
// ACCESS CONTROL
// ============================================================

if ($role !== 'admin') {
    header("Location: dashboard.php");
    exit;
}


// ============================================================
// CSRF TOKEN
// ============================================================

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$CSRF_TOKEN = $_SESSION['csrf_token'];


// ============================================================
// GRADE TABLE
// ============================================================

$conn->query("
    CREATE TABLE IF NOT EXISTS rice_grades (
        id INT AUTO_INCREMENT PRIMARY KEY,
        grade_name VARCHAR(50) NOT NULL UNIQUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
");


// ============================================================
// SEED DEFAULT GRADES
// ============================================================

$res = $conn->query("
    SELECT COUNT(*) AS c
    FROM rice_grades
");

if ($res) {

    $countRow = $res->fetch_assoc();

    if ((int)$countRow['c'] === 0) {

        $conn->query("
            INSERT INTO rice_grades (grade_name)
            VALUES
                ('Premium'),
                ('Special'),
                ('Regular'),
                ('Broken')
        ");
    }
}


// ============================================================
// LOAD ALLOWED GRADES
// ============================================================

$ALLOWED_GRADES = [];

$gres = $conn->query("
    SELECT grade_name
    FROM rice_grades
    ORDER BY grade_name
");

if ($gres) {

    while ($grow = $gres->fetch_assoc()) {
        $ALLOWED_GRADES[] = $grow['grade_name'];
    }
}


// ============================================================
// LOAD GRADES WITH PRODUCT USAGE
// ============================================================

$GRADE_MANAGEMENT = [];

$gradeManageRes = $conn->query("
    SELECT
        rg.id,
        rg.grade_name,
        COUNT(p.product_id) AS product_count
    FROM rice_grades rg
    LEFT JOIN products p
        ON p.grade = rg.grade_name
    GROUP BY rg.id, rg.grade_name
    ORDER BY rg.grade_name ASC
");

if ($gradeManageRes) {

    while ($grow = $gradeManageRes->fetch_assoc()) {
        $GRADE_MANAGEMENT[] = $grow;
    }
}


// ============================================================
// AUTO-MIGRATE DELIVERY DATE
// ============================================================

$deliveryColCheck = $conn->query("
    SHOW COLUMNS FROM products LIKE 'delivery_date'
");

if ($deliveryColCheck && $deliveryColCheck->num_rows === 0) {

    $conn->query("
        ALTER TABLE products
        ADD COLUMN delivery_date DATE NULL
        AFTER price_per_kg
    ");
}


// ============================================================
// AUTO-MIGRATE SELL PRICE PER SACK
// ============================================================

$sellSackColCheck = $conn->query("
    SHOW COLUMNS FROM products LIKE 'sell_price_per_sack'
");

if ($sellSackColCheck && $sellSackColCheck->num_rows === 0) {

    $conn->query("
        ALTER TABLE products
        ADD COLUMN sell_price_per_sack DECIMAL(10,2) NOT NULL DEFAULT 0
        AFTER price_per_sack
    ");
}


// ============================================================
// PAGE SETTINGS
// ============================================================

$activePage  = 'products';
$profileLink = 'profile.php';
$logoutLink  = '../logout.php';


// ============================================================
// VIEW / SORT
// ============================================================

$viewParam = strtolower((string)($_GET['view'] ?? 'active'));

if (!in_array($viewParam, ['active', 'archived'], true)) {
    $viewParam = 'active';
}

$sortParam = strtolower((string)($_GET['sort'] ?? 'newest'));

if (!in_array($sortParam, ['newest', 'id', 'stock'], true)) {
    $sortParam = 'newest';
}

$returnQuery =
    'view=' . urlencode($viewParam) .
    '&sort=' . urlencode($sortParam);


// ============================================================
// ACTIVITY LOG
// ============================================================

function logActivity($conn, $user_id, $type, $desc)
{
    $stmt = $conn->prepare("
        INSERT INTO activity_logs
        (
            user_id,
            activity_type,
            description,
            created_at
        )
        VALUES (?, ?, ?, NOW())
    ");

    if ($stmt) {

        $stmt->bind_param(
            "iss",
            $user_id,
            $type,
            $desc
        );

        $stmt->execute();
        $stmt->close();
    }
}


// ============================================================
// STOCK SETTINGS
// ============================================================

$DEFAULT_LOW_STOCK_THRESHOLD = 10;
$DEFAULT_OVERSTOCK_THRESHOLD = 1000;

$NEW_STOCK_DAYS = 7;
$OLD_STOCK_DAYS = 30;

$settingsRow = null;

$settingsRes = $conn->query("
    SELECT
        low_threshold_kg,
        over_threshold_kg
    FROM stock_settings
    WHERE id = 1
    LIMIT 1
");

if ($settingsRes) {
    $settingsRow = $settingsRes->fetch_assoc();
}

$LOW_STOCK_THRESHOLD =
    (float)($settingsRow['low_threshold_kg']
        ?? $DEFAULT_LOW_STOCK_THRESHOLD);

$OVERSTOCK_THRESHOLD =
    (float)($settingsRow['over_threshold_kg']
        ?? $DEFAULT_OVERSTOCK_THRESHOLD);


// ============================================================
// ADD NEW GRADE
// ============================================================

if (isset($_POST['add_grade'])) {

    if (($role ?? '') !== 'admin') {
        http_response_code(403);
        exit('Forbidden');
    }

    $postedToken = (string)($_POST['csrf_token'] ?? '');

    if (
        !$postedToken ||
        !hash_equals(
            $_SESSION['csrf_token'] ?? '',
            $postedToken
        )
    ) {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Security check failed.")
        );

        exit;
    }

    $new_grade = trim(
        $_POST['new_grade_name'] ?? ''
    );

    if ($new_grade === '') {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Grade name cannot be empty.")
        );

        exit;
    }

    if (mb_strlen($new_grade) > 50) {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Grade name is too long.")
        );

        exit;
    }


    // Case-insensitive duplicate check

    $stmt = $conn->prepare("
        SELECT id
        FROM rice_grades
        WHERE LOWER(grade_name) = LOWER(?)
        LIMIT 1
    ");

    $stmt->bind_param(
        "s",
        $new_grade
    );

    $stmt->execute();

    $existing =
        $stmt->get_result()->fetch_assoc();

    $stmt->close();


    if ($existing) {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("This grade already exists.")
        );

        exit;
    }


    // Insert grade

    $stmt = $conn->prepare("
        INSERT INTO rice_grades
        (
            grade_name
        )
        VALUES (?)
    ");

    $stmt->bind_param(
        "s",
        $new_grade
    );

    if ($stmt->execute()) {

        logActivity(
            $conn,
            $user_id,
            "SETTING",
            "Added new rice grade: {$new_grade}"
        );

        $stmt->close();

        header(
            "Location: products.php?{$returnQuery}&success=grade_added"
        );

        exit;
    }

    $stmt->close();

    header(
        "Location: products.php?{$returnQuery}&error=" .
        urlencode("Failed to add grade.")
    );

    exit;
}


// ============================================================
// EDIT / RENAME GRADE
// ============================================================

if (isset($_POST['edit_grade'])) {

    if (($role ?? '') !== 'admin') {
        http_response_code(403);
        exit('Forbidden');
    }

    $postedToken = (string)($_POST['csrf_token'] ?? '');

    if (
        !$postedToken ||
        !hash_equals(
            $_SESSION['csrf_token'] ?? '',
            $postedToken
        )
    ) {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Security check failed.")
        );

        exit;
    }

    $grade_id =
        (int)($_POST['grade_id'] ?? 0);

    $new_grade_name =
        trim($_POST['edit_grade_name'] ?? '');


    if (
        $grade_id <= 0 ||
        $new_grade_name === ''
    ) {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Invalid grade information.")
        );

        exit;
    }


    if (mb_strlen($new_grade_name) > 50) {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Grade name is too long.")
        );

        exit;
    }


    // Get current grade

    $stmt = $conn->prepare("
        SELECT grade_name
        FROM rice_grades
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->bind_param(
        "i",
        $grade_id
    );

    $stmt->execute();

    $gradeRow =
        $stmt->get_result()->fetch_assoc();

    $stmt->close();


    if (!$gradeRow) {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Grade not found.")
        );

        exit;
    }


    $old_grade_name =
        $gradeRow['grade_name'];


    // Check duplicate name

    $stmt = $conn->prepare("
        SELECT id
        FROM rice_grades
        WHERE LOWER(grade_name) = LOWER(?)
        AND id != ?
        LIMIT 1
    ");

    $stmt->bind_param(
        "si",
        $new_grade_name,
        $grade_id
    );

    $stmt->execute();

    $duplicate =
        $stmt->get_result()->fetch_assoc();

    $stmt->close();


    if ($duplicate) {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Another grade already uses that name.")
        );

        exit;
    }


    // Nothing changed

    if ($old_grade_name === $new_grade_name) {

        header(
            "Location: products.php?{$returnQuery}&success=grade_updated"
        );

        exit;
    }


    // Rename grade AND update products

    $conn->begin_transaction();

    try {

        // Update grade master record

        $stmt = $conn->prepare("
            UPDATE rice_grades
            SET grade_name = ?
            WHERE id = ?
        ");

        $stmt->bind_param(
            "si",
            $new_grade_name,
            $grade_id
        );

        $stmt->execute();
        $stmt->close();


        // Update all products using old grade

        $stmt = $conn->prepare("
            UPDATE products
            SET grade = ?
            WHERE grade = ?
        ");

        $stmt->bind_param(
            "ss",
            $new_grade_name,
            $old_grade_name
        );

        $stmt->execute();

        $updatedProducts =
            $stmt->affected_rows;

        $stmt->close();


        $conn->commit();


        logActivity(
            $conn,
            $user_id,
            "SETTING",
            "Renamed rice grade: {$old_grade_name} → {$new_grade_name}; updated {$updatedProducts} product(s)"
        );


        header(
            "Location: products.php?{$returnQuery}&success=grade_updated"
        );

        exit;

    } catch (Throwable $e) {

        $conn->rollback();

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Failed to update grade.")
        );

        exit;
    }
}


// ============================================================
// DELETE GRADE
// ============================================================

if (isset($_POST['delete_grade'])) {

    if (($role ?? '') !== 'admin') {
        http_response_code(403);
        exit('Forbidden');
    }

    $postedToken = (string)($_POST['csrf_token'] ?? '');

    if (
        !$postedToken ||
        !hash_equals(
            $_SESSION['csrf_token'] ?? '',
            $postedToken
        )
    ) {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Security check failed.")
        );

        exit;
    }


    $grade_id =
        (int)($_POST['grade_id'] ?? 0);


    if ($grade_id <= 0) {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Invalid grade.")
        );

        exit;
    }


    // Get grade name

    $stmt = $conn->prepare("
        SELECT grade_name
        FROM rice_grades
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->bind_param(
        "i",
        $grade_id
    );

    $stmt->execute();

    $gradeRow =
        $stmt->get_result()->fetch_assoc();

    $stmt->close();


    if (!$gradeRow) {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Grade not found.")
        );

        exit;
    }


    $grade_name =
        $gradeRow['grade_name'];


    // Check product usage

    $stmt = $conn->prepare("
        SELECT COUNT(*) AS total
        FROM products
        WHERE grade = ?
    ");

    $stmt->bind_param(
        "s",
        $grade_name
    );

    $stmt->execute();

    $usageRow =
        $stmt->get_result()->fetch_assoc();

    $stmt->close();


    $usageCount =
        (int)($usageRow['total'] ?? 0);


    if ($usageCount > 0) {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode(
                "Cannot delete '{$grade_name}' because {$usageCount} product(s) are using this grade. Reassign those products first."
            )
        );

        exit;
    }


    // Delete

    $stmt = $conn->prepare("
        DELETE FROM rice_grades
        WHERE id = ?
    ");

    $stmt->bind_param(
        "i",
        $grade_id
    );


    if ($stmt->execute()) {

        logActivity(
            $conn,
            $user_id,
            "SETTING",
            "Deleted rice grade: {$grade_name}"
        );

        $stmt->close();

        header(
            "Location: products.php?{$returnQuery}&success=grade_deleted"
        );

        exit;
    }


    $stmt->close();


    header(
        "Location: products.php?{$returnQuery}&error=" .
        urlencode("Failed to delete grade.")
    );

    exit;
}


// ============================================================
// SAVE STOCK THRESHOLDS
// ============================================================

if (isset($_POST['save_thresholds'])) {

    if (($role ?? '') !== 'admin') {
        http_response_code(403);
        exit('Forbidden');
    }

    $postedToken =
        (string)($_POST['csrf_token'] ?? '');

    if (
        !$postedToken ||
        !hash_equals(
            $_SESSION['csrf_token'] ?? '',
            $postedToken
        )
    ) {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Security check failed.")
        );

        exit;
    }


    $admin_password =
        (string)($_POST['admin_password'] ?? '');


    if ($admin_password === '') {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Admin password required.")
        );

        exit;
    }


    $stmt = $conn->prepare("
        SELECT password
        FROM users
        WHERE user_id = ?
        LIMIT 1
    ");

    $stmt->bind_param(
        "i",
        $user_id
    );

    $stmt->execute();

    $urow =
        $stmt->get_result()->fetch_assoc();

    $stmt->close();


    if (
        !$urow ||
        !password_verify(
            $admin_password,
            $urow['password']
        )
    ) {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Incorrect admin password.")
        );

        exit;
    }


    $low_raw =
        $_POST['low_stock_threshold'] ?? null;

    $over_raw =
        $_POST['overstock_threshold'] ?? null;


    if (
        !is_numeric($low_raw) ||
        !is_numeric($over_raw)
    ) {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Invalid threshold values.")
        );

        exit;
    }


    $low  = (float)$low_raw;
    $over = (float)$over_raw;


    $MAX_LOW  = 100000;
    $MAX_OVER = 1000000;


    if ($low < 0) {
        $low = 0;
    }

    if ($low > $MAX_LOW) {
        $low = $MAX_LOW;
    }


    if ($over <= 0) {
        $over = $DEFAULT_OVERSTOCK_THRESHOLD;
    }

    if ($over > $MAX_OVER) {
        $over = $MAX_OVER;
    }


    if ($over <= $low) {
        $over = min(
            $MAX_OVER,
            $low + 1
        );
    }


    $stmt = $conn->prepare("
        UPDATE stock_settings
        SET
            low_threshold_kg = ?,
            over_threshold_kg = ?
        WHERE id = 1
    ");

    $stmt->bind_param(
        "dd",
        $low,
        $over
    );

    $stmt->execute();
    $stmt->close();


    logActivity(
        $conn,
        $user_id,
        "SECURITY",
        "Updated stock thresholds (LOW={$low}, OVER={$over})"
    );


    header(
        "Location: products.php?{$returnQuery}&success=thresholds_saved"
    );

    exit;
}

if (isset($_POST['add_product'])) {

    $postedToken = (string)($_POST['csrf_token'] ?? '');

    if (
        !$postedToken ||
        !hash_equals(
            $_SESSION['csrf_token'] ?? '',
            $postedToken
        )
    ) {
        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Security check failed.")
        );
        exit;
    }

    $variety =
        trim($_POST['variety'] ?? '');

    $grade =
        trim($_POST['grade'] ?? '');

    $unit_weight_kg =
        (float)($_POST['unit_weight_kg'] ?? 0);


    if (
        $variety === '' ||
        $grade === '' ||
        !in_array(
            $grade,
            $ALLOWED_GRADES,
            true
        ) ||
        $unit_weight_kg <= 0
    ) {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Please complete all required fields.")
        );

        exit;
    }


    $stmt = $conn->prepare("
        INSERT INTO products
        (
            variety,
            grade,
            unit_weight_kg,
            price_per_sack,
            sell_price_per_sack,
            price_per_kg,
            created_at,
            archived
        )
        VALUES
        (?, ?, ?, 0, 0, 0, NOW(), 0)
    ");

    if (!$stmt) {
        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Product could not be added: {$conn->error}")
        );
        exit;
    }

    $stmt->bind_param(
        "ssd",
        $variety,
        $grade,
        $unit_weight_kg
    );

    if (!$stmt->execute()) {
        $dbError = $stmt->error;
        $stmt->close();
        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Product could not be added: {$dbError}")
        );
        exit;
    }
    $newProductId = (int)$stmt->insert_id;
    $stmt->close();


    logActivity(
        $conn,
        $user_id,
        "PRODUCT",
        "Added product #{$newProductId}: $variety - $grade ({$unit_weight_kg}kg/sack)"
    );


    header(
        "Location: products.php?{$returnQuery}&success=added"
    );

    exit;
}


// ============================================================
// EDIT PRODUCT
// ============================================================

if (isset($_POST['edit_product'])) {

    $product_id =
        (int)($_POST['product_id'] ?? 0);

    $variety =
        trim($_POST['variety'] ?? '');

    $grade =
        trim($_POST['grade'] ?? '');

    $unit_weight_kg =
        (float)($_POST['unit_weight_kg'] ?? 0);

    $price_per_sack =
        (float)($_POST['price_per_sack'] ?? 0);

    $sell_price_per_sack =
        (float)($_POST['sell_price_per_sack'] ?? 0);

    $price_per_kg =
        (float)($_POST['price_per_kg'] ?? 0);

    $delivery_date =
        trim(
            (string)($_POST['delivery_date'] ?? '')
        );

    $delivery_date =
        $delivery_date === ''
            ? null
            : $delivery_date;


    if (
        $product_id <= 0 ||
        $variety === '' ||
        $grade === '' ||
        !in_array(
            $grade,
            $ALLOWED_GRADES,
            true
        ) ||
        $unit_weight_kg <= 0
    ) {

        header(
            "Location: products.php?{$returnQuery}&error=" .
            urlencode("Invalid edit request.")
        );

        exit;
    }


    $stmt = $conn->prepare("
        UPDATE products
        SET
            variety = ?,
            grade = ?,
            unit_weight_kg = ?,
            price_per_sack = ?,
            sell_price_per_sack = ?,
            price_per_kg = ?,
            delivery_date = ?
        WHERE product_id = ?
    ");


    $stmt->bind_param(
        "ssddddsi",
        $variety,
        $grade,
        $unit_weight_kg,
        $price_per_sack,
        $sell_price_per_sack,
        $price_per_kg,
        $delivery_date,
        $product_id
    );


    $stmt->execute();
    $stmt->close();


    logActivity(
        $conn,
        $user_id,
        "PRODUCT",
        "Edited product #$product_id: $variety - $grade ({$unit_weight_kg}kg/sack)"
    );


    header(
        "Location: products.php?{$returnQuery}&success=updated"
    );

    exit;
}


// ============================================================
// ARCHIVE PRODUCT
// ============================================================

if (isset($_GET['archive'])) {

    $archive_id =
        (int)($_GET['archive'] ?? 0);


    $stmt = $conn->prepare("
        UPDATE products
        SET archived = 1
        WHERE product_id = ?
    ");

    $stmt->bind_param(
        "i",
        $archive_id
    );

    $stmt->execute();
    $stmt->close();


    logActivity(
        $conn,
        $user_id,
        "PRODUCT",
        "Archived product #$archive_id"
    );


    header(
        "Location: products.php?{$returnQuery}&success=archived"
    );

    exit;
}


// ============================================================
// VIEW VARIABLES
// ============================================================

$view =
    $viewParam;

$sort =
    $sortParam;

$isArchivedView =
    ($view === 'archived');


// ============================================================
// RESTORE PRODUCT
// ============================================================

if (isset($_GET['restore'])) {

    $restore_id =
        (int)($_GET['restore'] ?? 0);


    $stmt = $conn->prepare("
        UPDATE products
        SET archived = 0
        WHERE product_id = ?
    ");

    $stmt->bind_param(
        "i",
        $restore_id
    );

    $stmt->execute();
    $stmt->close();


    logActivity(
        $conn,
        $user_id,
        "PRODUCT",
        "Restored product #$restore_id"
    );


    header(
        "Location: products.php?{$returnQuery}&success=restored"
    );

    exit;
}


// ============================================================
// PRODUCT COUNTS
// ============================================================

$countsRow =
    $conn->query("
        SELECT
            SUM(
                CASE
                    WHEN archived = 0 THEN 1
                    ELSE 0
                END
            ) AS active_count,

            SUM(
                CASE
                    WHEN archived = 1 THEN 1
                    ELSE 0
                END
            ) AS archived_count

        FROM products
    ")->fetch_assoc();


$activeCount =
    (int)($countsRow['active_count'] ?? 0);

$archivedCount =
    (int)($countsRow['archived_count'] ?? 0);


// ============================================================
// STOCK CONDITION COUNT
// ============================================================

$conditionCount = 0;

$stockConditionTable =
    $conn->query("
        SHOW TABLES LIKE 'stock_condition'
    ");

if (
    $stockConditionTable &&
    $stockConditionTable->num_rows > 0
) {

    $cc =
        $conn->query("
            SELECT COUNT(*) AS c
            FROM stock_condition
        ");

    if ($cc) {

        $cr =
            $cc->fetch_assoc();

        $conditionCount =
            (int)($cr['c'] ?? 0);
    }
}


// ============================================================
// SORTING
// ============================================================

$orderBy =
    "p.created_at DESC, p.product_id DESC";

if ($sort === 'id') {

    $orderBy =
        "p.product_id ASC";

} elseif ($sort === 'stock') {

    $orderBy =
        "stock_kg DESC, p.product_id ASC";
}


// ============================================================
// PRODUCT QUERY
// ============================================================

$sql = "
    SELECT
        p.*,

        IFNULL(
            SUM(sb.remaining_qty_kg),
            0
        ) AS stock_kg,

        MAX(sb.arrived_at)
            AS last_in_date,

        CASE
            WHEN MIN(
                CASE
                    WHEN sb.remaining_qty_kg > 0
                    THEN sb.arrived_at
                END
            ) IS NULL

            THEN NULL

            ELSE DATEDIFF(
                CURDATE(),
                MIN(
                    CASE
                        WHEN sb.remaining_qty_kg > 0
                        THEN sb.arrived_at
                    END
                )
            )
        END AS stock_age_days

    FROM products p

    LEFT JOIN stock_batches sb
        ON sb.product_id = p.product_id

    WHERE p.archived =
        " . ($isArchivedView ? "1" : "0") . "

    GROUP BY p.product_id

    ORDER BY {$orderBy}
";


$productsRes =
    $conn->query($sql);


if (!$productsRes) {
    die(
        "Query Error: " .
        $conn->error
    );
}


// ============================================================
// BUILD PRODUCT ARRAY
// ============================================================

$overItems = [];
$products  = [];


if (
    $productsRes &&
    $productsRes->num_rows > 0
) {

    while (
        $r = $productsRes->fetch_assoc()
    ) {

        $products[] = $r;


        if (
            !$isArchivedView &&
            (float)$r['stock_kg'] >=
            $OVERSTOCK_THRESHOLD
        ) {

            $overItems[] = [
                'product_id' =>
                    (int)$r['product_id'],

                'product' =>
                    $r['variety'] .
                    ' - ' .
                    $r['grade'],

                'stock' =>
                    (float)$r['stock_kg']
            ];
        }
    }
}


if (count($overItems) > 1) {

    usort(
        $overItems,
        fn($a, $b) =>
            $b['stock'] <=> $a['stock']
    );
}

// Load each product's batch records for the per-product history modal.
$batchesByProduct = [];
$visibleProductIds = array_values(array_filter(array_map(
    fn($product) => (int)($product['product_id'] ?? 0),
    $products
)));
if ($visibleProductIds) {
    $batchIdsSql = implode(',', $visibleProductIds);
    $batchHistoryRes = $conn->query("
        SELECT batch_id, product_id, batch_code, arrived_at, unit_weight_kg,
               remaining_qty_kg, regular_qty_kg, discounted_qty_kg,
               regular_price_per_kg, discounted_price_per_kg
        FROM stock_batches
        WHERE product_id IN ({$batchIdsSql})
        ORDER BY product_id ASC, arrived_at DESC, batch_id DESC
    ");
    if ($batchHistoryRes) {
        while ($batch = $batchHistoryRes->fetch_assoc()) {
            $batchesByProduct[(int)$batch['product_id']][] = $batch;
        }
    }
}

?>
<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1"
>

<title>
    Products | DO HIYS
</title>


<link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
    rel="stylesheet"
>


<link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    rel="stylesheet"
>


<link
    href="../css/layout.css"
    rel="stylesheet"
>


<link
    href="../css/admin-mobile.css"
    rel="stylesheet"
>


<link
    href="../css/admin-products.css"
    rel="stylesheet"
>


<style>

.size-img-placeholder {
    width: 100%;
    height: 140px;
    background: #e9ecef;
    border: 2px dashed #adb5bd;
    border-radius: 8px;

    display: flex;
    align-items: center;
    justify-content: center;

    color: #6c757d;
    font-size: 0.9rem;

    margin-bottom: 0.5rem;
}

.size-img-placeholder i {
    font-size: 1.8rem;
    margin-bottom: 0.3rem;
    display: block;
}


/* Grade management */

.grade-manage-table th,
.grade-manage-table td {
    vertical-align: middle;
}

.grade-action-btn {
    min-width: 36px;
}

.grade-usage-badge {
    min-width: 90px;
    display: inline-block;
}


/* Prevent modal from becoming too tall */

#manageGradesModal .modal-body {
    max-height: 60vh;
    overflow-y: auto;
}

</style>

</head>


<body>


<?php include '../includes/topnav.php'; ?>


<div class="container-fluid">

<div class="row">


<?php include '../includes/admin_sidebar.php'; ?>


<main class="col-lg-10 ms-sm-auto px-4 main-content">


<!-- ========================================================
     PAGE HEADER
======================================================== -->

<div
    class="d-flex justify-content-between align-items-center flex-wrap gap-2"
>

    <h2 class="mb-0">
        Products
    </h2>


    <div
        class="d-flex gap-2 align-items-center flex-wrap"
    >

        <form
            method="GET"
            class="d-flex align-items-center gap-2"
        >

            <input
                type="hidden"
                name="view"
                value="<?= htmlspecialchars($view) ?>"
            >


            <label class="small text-muted mb-0">
                Sort
            </label>


            <select
                name="sort"
                class="form-select form-select-sm"
                onchange="this.form.submit()"
            >

                <option
                    value="newest"
                    <?= $sort === 'newest' ? 'selected' : '' ?>
                >
                    Newest
                </option>


                <option
                    value="id"
                    <?= $sort === 'id' ? 'selected' : '' ?>
                >
                    ID
                </option>


                <option
                    value="stock"
                    <?= $sort === 'stock' ? 'selected' : '' ?>
                >
                    Stock
                </option>

            </select>

        </form>


        <button
            class="btn btn-outline-dark"
            data-bs-toggle="modal"
            data-bs-target="#thresholdModal"
        >

            <i class="fas fa-sliders-h"></i>

            Thresholds

        </button>


        <button
            class="btn btn-primary"
            data-bs-toggle="modal"
            data-bs-target="#addProductModal"
        >

            <i class="fas fa-plus"></i>

            Add Product

        </button>

    </div>

</div>


<!-- ========================================================
     NAV TABS
======================================================== -->

<ul class="nav nav-pills mt-3">

    <li class="nav-item">

        <a
            class="nav-link <?= $isArchivedView ? '' : 'active' ?>"
            href="products.php?view=active&sort=<?= urlencode($sort) ?>"
        >

            Active

            <span class="badge bg-light text-dark ms-1">
                <?= $activeCount ?>
            </span>

        </a>

    </li>


    <li class="nav-item">

        <a
            class="nav-link <?= $isArchivedView ? 'active' : '' ?>"
            href="products.php?view=archived&sort=<?= urlencode($sort) ?>"
        >

            Archived

            <span class="badge bg-light text-dark ms-1">
                <?= $archivedCount ?>
            </span>

        </a>

    </li>


    <li class="nav-item">

        <a
            class="nav-link"
            href="stock_condition.php"
        >

            Condition

            <span class="badge bg-light text-dark ms-1">
                <?= $conditionCount ?>
            </span>

        </a>

    </li>

</ul>


<!-- ========================================================
     ALERTS
======================================================== -->

<?php if (isset($_GET['error'])): ?>

    <div class="alert alert-danger mt-3">

        <?= htmlspecialchars($_GET['error']) ?>

    </div>

<?php endif; ?>


<?php if (isset($_GET['success'])): ?>

    <?php if ($_GET['success'] === 'added'): ?>

        <div class="alert alert-success mt-3">
            Product added successfully!
        </div>


    <?php elseif ($_GET['success'] === 'updated'): ?>

        <div class="alert alert-success mt-3">
            Product updated successfully!
        </div>


    <?php elseif ($_GET['success'] === 'archived'): ?>

        <div class="alert alert-success mt-3">
            Product archived successfully!
        </div>


    <?php elseif ($_GET['success'] === 'restored'): ?>

        <div class="alert alert-success mt-3">
            Product restored successfully!
        </div>


    <?php elseif ($_GET['success'] === 'thresholds_saved'): ?>

        <div class="alert alert-success mt-3">
            Stock thresholds updated!
        </div>


    <?php elseif ($_GET['success'] === 'grade_added'): ?>

        <div class="alert alert-success mt-3">
            New grade added successfully!
        </div>


    <?php elseif ($_GET['success'] === 'grade_updated'): ?>

        <div class="alert alert-success mt-3">
            Grade updated successfully!
        </div>


    <?php elseif ($_GET['success'] === 'grade_deleted'): ?>

        <div class="alert alert-success mt-3">
            Grade deleted successfully!
        </div>

    <?php endif; ?>

<?php endif; ?>


<!-- ========================================================
     THRESHOLD BADGES
======================================================== -->

<div class="mt-3 d-flex flex-wrap gap-2">

    <span class="badge bg-warning text-dark">

        LOW ≤
        <?= number_format($LOW_STOCK_THRESHOLD, 2) ?>
        kg

    </span>


    <span class="badge bg-danger">

        OVER ≥
        <?= number_format($OVERSTOCK_THRESHOLD, 2) ?>
        kg

    </span>

</div>


<!-- ========================================================
     SEARCH
======================================================== -->

<div
    class="mt-3"
    style="max-width:260px;"
>

    <input
        type="text"
        id="productSearch"
        class="form-control form-control-sm"
        placeholder="Search products..."
    >

</div>


<!-- ========================================================
     PRODUCT TABLE
======================================================== -->

<div class="d-flex justify-content-end mt-1 mb-1">
    <button
        type="button"
        class="btn btn-sm btn-outline-info py-0 px-1"
        style="font-size:0.75em"
        data-bs-toggle="modal"
        data-bs-target="#sizeGuideModal"
        aria-label="Open sack size guide"
    >
        <i class="fas fa-ruler"></i>
        Guide
    </button>
</div>

<div class="table-responsive mt-0">

<table
    class="table table-striped table-bordered modern-card align-middle products-table"
    style="font-size:0.875rem;"
>

<thead class="table-dark">

<tr>

    <th>
        Variety
    </th>

    <th>
        Grade
    </th>

    <th class="text-nowrap">
        Unit Size
    </th>

    <th class="text-nowrap">
        Stock (kg)
    </th>

    <th class="text-nowrap">
        Stocks Left
    </th>

    <th class="text-nowrap">
        Palit ₱/sack
    </th>

    <th class="text-nowrap">
        Baligya ₱/kg
    </th>

    <th class="text-nowrap">
        Baligya ₱/sack
    </th>

    <th class="text-nowrap">
        Delivery
    </th>

    <th class="text-nowrap">
        Stock Age
    </th>

    <th>
        Status
    </th>

    <th>
        Actions
    </th>

</tr>

</thead>


<tbody>


<?php if (count($products) > 0): ?>


<?php foreach ($products as $row): ?>


<?php

$stock =
    (float)$row['stock_kg'];

$unit_weight =
    (float)($row['unit_weight_kg'] ?? 0);


$full_sacks =
    $unit_weight > 0
        ? floor($stock / $unit_weight)
        : 0;


$remaining_kg =
    $unit_weight > 0
        ? $stock -
          $full_sacks * $unit_weight
        : 0;


$lastStockDate =
    $row['last_in_date']
    ?: (
        $row['delivery_date']
        ?: (
            $row['created_at']
            ?? null
        )
    );


$stockAgeDays = null;


if (
    $row['stock_age_days'] !== null
) {

    $stockAgeDays =
        (int)$row['stock_age_days'];

} elseif (!empty($lastStockDate)) {

    $ts =
        strtotime($lastStockDate);

    if ($ts) {

        $stockAgeDays =
            max(
                0,
                (int)floor(
                    (time() - $ts) / 86400
                )
            );
    }
}


// STATUS

if ($stock <= 0) {

    $statusBadge =
        '<span class="badge bg-secondary">OUT</span>';

} elseif (
    $stock >= $OVERSTOCK_THRESHOLD
) {

    $statusBadge =
        '<span class="badge bg-danger">OVER</span>';

} elseif (
    $stock <= $LOW_STOCK_THRESHOLD &&
    $stock > 0
) {

    $statusBadge =
        '<span class="badge bg-warning text-dark">LOW</span>';

} else {

    $statusBadge =
        '<span class="badge bg-success">OK</span>';
}


$rowClass =
    $stock >= $OVERSTOCK_THRESHOLD
        ? 'table-danger'
        : (
            ($stock <= $LOW_STOCK_THRESHOLD && $stock > 0)
                ? 'table-warning'
                : ''
        );


// STOCK AGE

if ($stock <= 0) {

    $ageBadge =
        '<span class="badge bg-secondary">NO STOCK</span>';

} elseif (
    $stockAgeDays !== null &&
    $stockAgeDays <= $NEW_STOCK_DAYS
) {

    $ageBadge =
        '<span class="badge bg-info text-dark">
            NEW • ' . $stockAgeDays . 'd
        </span>';

} elseif (
    $stockAgeDays !== null &&
    $stockAgeDays >= $OLD_STOCK_DAYS
) {

    $ageBadge =
        '<span class="badge bg-secondary">
            OLD • ' . $stockAgeDays . 'd
        </span>';

} elseif ($stockAgeDays !== null) {

    $ageBadge =
        '<span class="badge bg-success">
            Fresh • ' . $stockAgeDays . 'd
        </span>';

} else {

    $ageBadge =
        '<span class="text-muted">—</span>';
}


$delivery_disp =
    !empty($row['delivery_date'])
        ? date(
            'M d, Y',
            strtotime($row['delivery_date'])
        )
        : (
            $row['created_at']
                ? date(
                    'M d, Y',
                    strtotime($row['created_at'])
                )
                : '—'
        );


$archivedBadge =
    $isArchivedView
        ? '<span class="badge bg-secondary">Archived</span>'
        : '<span class="badge bg-primary">Active</span>';

?>


<tr class="<?= $rowClass ?>">


<td>

    <?= htmlspecialchars($row['variety']) ?>

</td>


<td>

    <?= htmlspecialchars($row['grade']) ?>

</td>


<td class="text-nowrap">

    <?= number_format($unit_weight, 0) ?>
    kg

</td>


<td class="text-nowrap">

    <strong>
        <?= number_format($stock, 2) ?>
    </strong>

</td>


<td class="text-center text-nowrap">

    <strong>
        <?= $full_sacks ?>
    </strong>

    <?php if ($remaining_kg > 0): ?>

        <div class="small text-muted">

            +
            <?= number_format($remaining_kg, 0) ?>
            kg

        </div>

    <?php endif; ?>

</td>


<td class="text-nowrap">

    ₱<?= number_format(
        (float)($row['price_per_sack'] ?? 0),
        2
    ) ?>

</td>


<td class="text-nowrap">

    ₱<?= number_format(
        (float)($row['price_per_kg'] ?? 0),
        2
    ) ?>

</td>


<td class="text-nowrap">

    ₱<?= number_format(
        (float)($row['sell_price_per_sack'] ?? 0),
        2
    ) ?>

</td>


<td class="text-nowrap small">

    <?= $delivery_disp ?>

</td>


<td class="text-nowrap">

    <?= $ageBadge ?>

</td>


<td class="text-nowrap">

    <?= $statusBadge ?>

    <?= $archivedBadge ?>

</td>


<td class="text-nowrap">


    <button
        type="button"
        class="btn btn-sm btn-outline-primary"
        data-bs-toggle="modal"
        data-bs-target="#batchHistoryModal<?= (int)$row['product_id'] ?>"
        title="View batch history"
    >
        <i class="fas fa-clock-rotate-left"></i>
    </button>

<?php if ($isArchivedView): ?>


    <a
        href="products.php?<?= htmlspecialchars($returnQuery) ?>&restore=<?= (int)$row['product_id'] ?>"
        class="btn btn-sm btn-success"
        onclick="return confirm('Restore this product?')"
        title="Restore"
    >

        <i class="fas fa-rotate-left"></i>

    </a>


<?php else: ?>


    <button
        class="btn btn-sm btn-info"
        data-bs-toggle="modal"
        data-bs-target="#editProductModal<?= (int)$row['product_id'] ?>"
        title="Edit"
    >

        <i class="fas fa-edit"></i>

    </button>


    <a
        href="products.php?<?= htmlspecialchars($returnQuery) ?>&archive=<?= (int)$row['product_id'] ?>"
        class="btn btn-sm btn-danger"
        onclick="return confirm('Archive this product?')"
        title="Archive"
    >

        <i class="fas fa-archive"></i>

    </a>


<?php endif; ?>


</td>


</tr>

<!-- ======================================================
     EDIT PRODUCT MODAL
====================================================== -->

<?php if (!$isArchivedView): ?>


<div
    class="modal fade"
    id="editProductModal<?= (int)$row['product_id'] ?>"
    tabindex="-1"
>

<div class="modal-dialog">

<div class="modal-content">


<div class="modal-header">

    <h5 class="modal-title">
        Edit Product
    </h5>

    <button
        class="btn-close"
        data-bs-dismiss="modal"
    ></button>

</div>


<form method="POST">


<div class="modal-body">


<input
    type="hidden"
    name="product_id"
    value="<?= (int)$row['product_id'] ?>"
>


<!-- VARIETY -->

<div class="mb-3">

    <label class="form-label">
        Variety
    </label>

    <input
        class="form-control"
        type="text"
        name="variety"
        value="<?= htmlspecialchars($row['variety']) ?>"
        required
    >

</div>


<!-- GRADE -->

<div class="mb-3">

    <label class="form-label d-block">

        Grade


        <button
            type="button"
            class="btn btn-sm btn-outline-success py-0 px-1 ms-2"
            style="font-size:0.75em"
            data-bs-toggle="modal"
            data-bs-target="#addGradeModal"
        >

            <i class="fas fa-plus"></i>
            New

        </button>


        <button
            type="button"
            class="btn btn-sm btn-outline-dark py-0 px-1 ms-1"
            style="font-size:0.75em"
            data-bs-toggle="modal"
            data-bs-target="#manageGradesModal"
        >

            <i class="fas fa-gear"></i>
            Manage

        </button>

    </label>


    <select
        class="form-select"
        name="grade"
        required
    >

        <?php foreach ($ALLOWED_GRADES as $g): ?>

            <option
                value="<?= htmlspecialchars($g) ?>"
                <?= $row['grade'] === $g ? 'selected' : '' ?>
            >

                <?= htmlspecialchars($g) ?>

            </option>

        <?php endforeach; ?>

    </select>

</div>


<!-- UNIT SIZE -->

<div class="mb-3">

    <label class="form-label d-block">

        Unit Size (kg per sack)


        <button
            type="button"
            class="btn btn-sm btn-outline-info py-0 px-1 ms-2"
            style="font-size:0.75em"
            data-bs-toggle="modal"
            data-bs-target="#sizeGuideModal"
        >

            <i class="fas fa-ruler"></i>
            Guide

        </button>

    </label>


    <select
        class="form-select"
        name="unit_weight_kg"
        required
    >

        <?php foreach ([5,10,25,50] as $s): ?>

            <option
                value="<?= $s ?>"
                <?= $s == $unit_weight ? 'selected' : '' ?>
            >

                <?= $s ?> kg

            </option>

        <?php endforeach; ?>

    </select>

</div>


<!-- PRICES -->

<div class="row g-2">


<div class="col-md-4">

    <label>
        Palit Price (₱/sack)
    </label>

    <input
        class="form-control"
        type="number"
        step="0.01"
        name="price_per_sack"
        value="<?= htmlspecialchars($row['price_per_sack'] ?? '0') ?>"
        required
    >

</div>


<div class="col-md-4">

    <label>
        Baligya (₱/kg)
    </label>

    <input
        class="form-control"
        type="number"
        step="0.01"
        name="price_per_kg"
        value="<?= htmlspecialchars($row['price_per_kg'] ?? '0') ?>"
        required
    >

</div>


<div class="col-md-4">

    <label>
        Baligya (₱/sack)
    </label>

    <input
        class="form-control"
        type="number"
        step="0.01"
        name="sell_price_per_sack"
        value="<?= htmlspecialchars($row['sell_price_per_sack'] ?? '0') ?>"
        required
    >

</div>


</div>


<!-- DELIVERY DATE -->

<div class="mb-3 mt-3">

    <label>
        Delivery Date
    </label>

    <input
        class="form-control"
        type="date"
        name="delivery_date"
        value="<?= !empty($row['delivery_date'])
            ? htmlspecialchars($row['delivery_date'])
            : '' ?>"
    >

</div>


<div class="alert alert-info mb-0">

    <small>
        Stock cannot be edited here —
        use Stock In.
    </small>

</div>


</div>


<div class="modal-footer">


<button
    class="btn btn-secondary"
    type="button"
    data-bs-dismiss="modal"
>
    Cancel
</button>


<button
    type="submit"
    name="edit_product"
    class="btn btn-primary"
>

    <i class="fas fa-save me-1"></i>

    Save Changes

</button>


</div>


</form>


</div>

</div>

</div>


<?php endif; ?>


<?php endforeach; ?>


<?php else: ?>


<tr>

<td
    colspan="12"
    class="text-center text-muted py-4"
>

    <?= $isArchivedView
        ? 'No archived products.'
        : 'No active products.' ?>

</td>

</tr>


<?php endif; ?>


</tbody>

</table>

</div>


<?php foreach ($products as $historyProduct): ?>
<?php
    $productBatches = $batchesByProduct[(int)$historyProduct['product_id']] ?? [];
    $historyUnitWeight = (float)($historyProduct['unit_weight_kg'] ?? 0);
    $historyStockKg = (float)($historyProduct['stock_kg'] ?? 0);
    $historySacks = $historyUnitWeight > 0 ? (int)floor($historyStockKg / $historyUnitWeight) : 0;
    $historyLooseKg = $historyUnitWeight > 0 ? $historyStockKg - ($historySacks * $historyUnitWeight) : $historyStockKg;
?>
<div class="modal fade" id="batchHistoryModal<?= (int)$historyProduct['product_id'] ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <h5 class="modal-title">Batch History</h5>
                    <div class="small text-muted"><?= htmlspecialchars($historyProduct['variety'] . ' - ' . $historyProduct['grade'], ENT_QUOTES, 'UTF-8') ?></div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row g-2 mb-3">
                    <div class="col-6 col-md-3"><div class="border rounded p-2 h-100"><div class="small text-muted">Sack size</div><strong><?= number_format($historyUnitWeight, 2) ?> kg</strong></div></div>
                    <div class="col-6 col-md-3"><div class="border rounded p-2 h-100"><div class="small text-muted">Total stock left</div><strong><?= number_format($historyStockKg, 2) ?> kg</strong></div></div>
                    <div class="col-6 col-md-3"><div class="border rounded p-2 h-100"><div class="small text-muted">Full sacks left</div><strong><?= $historySacks ?> sack(s)</strong></div></div>
                    <div class="col-6 col-md-3"><div class="border rounded p-2 h-100"><div class="small text-muted">Loose stock</div><strong><?= number_format($historyLooseKg, 2) ?> kg</strong></div></div>
                </div>
                <?php if (!$productBatches): ?>
                    <div class="text-center text-muted py-4">No batch records found for this product.</div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm table-hover table-striped align-middle mb-0">
                            <thead class="table-light">
                                <tr><th>Batch</th><th>Delivered</th><th>Regular left</th><th>Discounted left</th><th>Total left</th><th>Sacks left</th><th>Regular price/kg</th><th>Discount price/kg</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($productBatches as $batch): ?>
                                    <?php
                                        $regularLeft = (float)($batch['regular_qty_kg'] ?? 0);
                                        $discountLeft = (float)($batch['discounted_qty_kg'] ?? 0);
                                        $batchTotalLeft = (float)($batch['remaining_qty_kg'] ?? ($regularLeft + $discountLeft));
                                        $batchSacksLeft = $historyUnitWeight > 0 ? (int)floor($batchTotalLeft / $historyUnitWeight) : 0;
                                        $batchLooseKg = $historyUnitWeight > 0 ? $batchTotalLeft - ($batchSacksLeft * $historyUnitWeight) : $batchTotalLeft;
                                        $deliveredAt = trim((string)($batch['arrived_at'] ?? ''));
                                    ?>
                                    <tr>
                                        <td><?= htmlspecialchars((string)($batch['batch_code'] ?: ('B' . $batch['batch_id'])), ENT_QUOTES, 'UTF-8') ?></td>
                                        <td><?= $deliveredAt !== '' ? htmlspecialchars(date('M d, Y', strtotime($deliveredAt)), ENT_QUOTES, 'UTF-8') : 'Date unavailable' ?></td>
                                        <td><?= number_format($regularLeft, 2) ?> kg</td>
                                        <td><?= number_format($discountLeft, 2) ?> kg</td>
                                        <td><?= number_format($batchTotalLeft, 2) ?> kg</td>
                                        <td class="text-nowrap"><strong><?= $batchSacksLeft ?> sack(s)</strong><?php if ($batchLooseKg > 0.004): ?><div class="small text-muted">+ <?= number_format($batchLooseKg, 2) ?> kg loose</div><?php endif; ?></td>
                                        <td>₱<?= number_format((float)($batch['regular_price_per_kg'] ?? 0), 2) ?></td>
                                        <td>₱<?= number_format((float)($batch['discounted_price_per_kg'] ?? 0), 2) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>
<!-- ========================================================
     SIZE GUIDE MODAL
======================================================== -->

<div
    class="modal fade"
    id="sizeGuideModal"
    tabindex="-1"
>

<div class="modal-dialog modal-lg">

<div class="modal-content">


<div class="modal-header py-2">

<h5 class="modal-title">

    <i class="fas fa-ruler me-2"></i>

    Sack Size Guide

</h5>


<button
    type="button"
    class="btn-close"
    data-bs-dismiss="modal"
></button>

</div>


<div class="modal-body">


<p class="text-muted small mb-3">

    Standard sack sizes used in
    Cagayan de Oro & Northern Mindanao:

</p>


<div class="row g-3">


<!-- 5KG -->

<div class="col-6 col-md-3 text-center">

<img
    src="../assets/5kg.png"
    class="img-fluid rounded border"
    alt="5kg Sack"
    onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
>


<div
    class="size-img-placeholder"
    style="display:none;"
>

<div>

<i class="fas fa-image"></i>

<br>

5kg Sack Image

</div>

</div>


<h5 class="mt-2 mb-1">
    5 kg
</h5>

<small class="text-muted">
    Small retail / family pack
</small>

</div>


<!-- 10KG -->

<div class="col-6 col-md-3 text-center">

<img
    src="../assets/10kg.png"
    class="img-fluid rounded border"
    alt="10kg Sack"
    onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
>


<div
    class="size-img-placeholder"
    style="display:none;"
>

<div>

<i class="fas fa-image"></i>

<br>

10kg Sack Image

</div>

</div>


<h5 class="mt-2 mb-1">
    10 kg
</h5>

<small class="text-muted">
    Medium household pack
</small>

</div>


<!-- 25KG -->

<div class="col-6 col-md-3 text-center">

<img
    src="../assets/25kg.png"
    class="img-fluid rounded border"
    alt="25kg Sack"
    onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
>


<div
    class="size-img-placeholder"
    style="display:none;"
>

<div>

<i class="fas fa-image"></i>

<br>

25kg Sack Image

</div>

</div>


<h5 class="mt-2 mb-1">
    25 kg
</h5>

<small class="text-muted">
    Commercial standard sack
</small>

</div>


<!-- 50KG -->

<div class="col-6 col-md-3 text-center">

<img
    src="../assets/50kg.png"
    class="img-fluid rounded border border-primary"
    alt="50kg Sack"
    onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
>


<div
    class="size-img-placeholder border-primary"
    style="display:none;"
>

<div>

<i class="fas fa-image"></i>

<br>

50kg Sack Image

</div>

</div>


<h5 class="mt-2 mb-1 text-primary">
    50 kg ⭐
</h5>

<small class="text-muted">
    Wholesale standard — most common
</small>

</div>


</div>

</div>


<div class="modal-footer py-2">

<button
    type="button"
    class="btn btn-primary"
    data-bs-dismiss="modal"
>
    Got it!
</button>

</div>


</div>

</div>

</div>


<!-- ========================================================
     ADD GRADE MODAL
======================================================== -->

<div
    class="modal fade"
    id="addGradeModal"
    tabindex="-1"
>

<div class="modal-dialog modal-sm">

<div class="modal-content">


<div class="modal-header py-2">

<h5 class="modal-title fs-6">

    <i class="fas fa-plus-circle text-success me-2"></i>

    Add New Grade

</h5>


<button
    type="button"
    class="btn-close"
    data-bs-dismiss="modal"
></button>

</div>


<form method="POST">


<input
    type="hidden"
    name="csrf_token"
    value="<?= htmlspecialchars($CSRF_TOKEN) ?>"
>


<div class="modal-body">


<label class="form-label fw-semibold">

    Grade Name

</label>


<input
    type="text"
    name="new_grade_name"
    class="form-control"
    placeholder="e.g. Special Premium"
    maxlength="50"
    required
>


<div class="form-text">

    Grade names should be clear and unique.

</div>


</div>


<div class="modal-footer py-2">


<button
    type="button"
    class="btn btn-sm btn-secondary"
    data-bs-dismiss="modal"
>

    Cancel

</button>


<button
    type="submit"
    name="add_grade"
    class="btn btn-sm btn-success"
>

    <i class="fas fa-plus me-1"></i>

    Add Grade

</button>


</div>


</form>


</div>

</div>

</div>


<!-- ========================================================
     MANAGE GRADES MODAL
======================================================== -->

<div
    class="modal fade"
    id="manageGradesModal"
    tabindex="-1"
>

<div class="modal-dialog modal-lg modal-dialog-scrollable">

<div class="modal-content">


<div class="modal-header">


<div>

<h5 class="modal-title mb-1">

    <i class="fas fa-tags me-2"></i>

    Manage Rice Grades

</h5>


<small class="text-muted">

    Add, rename, or remove grades used by your products.

</small>

</div>


<button
    type="button"
    class="btn-close"
    data-bs-dismiss="modal"
></button>


</div>


<div class="modal-body">


<div class="alert alert-info small">

    <i class="fas fa-circle-info me-1"></i>

    Renaming a grade will automatically update
    all products currently using that grade.

    A grade cannot be deleted while it is being
    used by a product.

</div>


<div class="table-responsive">


<table
    class="table table-bordered table-hover align-middle mb-0 grade-manage-table"
>


<thead class="table-dark">

<tr>

<th style="width:60px;">
    #
</th>

<th>
    Grade
</th>

<th class="text-center">
    Products Using It
</th>

<th
    class="text-end"
    style="width:150px;"
>
    Actions
</th>

</tr>

</thead>


<tbody>


<?php if (count($GRADE_MANAGEMENT) > 0): ?>


<?php foreach (
    $GRADE_MANAGEMENT
    as $index => $gradeRow
): ?>


<?php

$gid =
    (int)$gradeRow['id'];

$gname =
    $gradeRow['grade_name'];

$usage =
    (int)$gradeRow['product_count'];

?>


<tr>


<td>

    <?= $index + 1 ?>

</td>


<td>

<strong>

    <?= htmlspecialchars($gname) ?>

</strong>

</td>


<td class="text-center">


<?php if ($usage > 0): ?>


<span
    class="badge bg-primary grade-usage-badge"
>

    <?= $usage ?>

    <?= $usage === 1
        ? 'product'
        : 'products' ?>

</span>


<?php else: ?>


<span
    class="badge bg-secondary grade-usage-badge"
>

    Not used

</span>


<?php endif; ?>


</td>


<td class="text-end">


<!-- EDIT -->

<button
    type="button"
    class="btn btn-sm btn-info text-white grade-action-btn"
    data-bs-toggle="modal"
    data-bs-target="#editGradeModal<?= $gid ?>"
    title="Edit grade"
>

    <i class="fas fa-edit"></i>

</button>


<!-- DELETE -->

<?php if ($usage === 0): ?>


<form
    method="POST"
    class="d-inline"
    onsubmit="return confirm('Delete the grade &quot;<?= htmlspecialchars($gname, ENT_QUOTES) ?>&quot;? This cannot be undone.');"
>


<input
    type="hidden"
    name="csrf_token"
    value="<?= htmlspecialchars($CSRF_TOKEN) ?>"
>


<input
    type="hidden"
    name="grade_id"
    value="<?= $gid ?>"
>


<button
    type="submit"
    name="delete_grade"
    class="btn btn-sm btn-danger grade-action-btn"
    title="Delete grade"
>

    <i class="fas fa-trash"></i>

</button>


</form>


<?php else: ?>


<button
    type="button"
    class="btn btn-sm btn-outline-danger grade-action-btn"
    disabled
    title="Cannot delete because products are using this grade"
>

    <i class="fas fa-lock"></i>

</button>


<?php endif; ?>


</td>


</tr>


<?php endforeach; ?>


<?php else: ?>


<tr>

<td
    colspan="4"
    class="text-center text-muted py-4"
>

    No grades found.

</td>

</tr>


<?php endif; ?>


</tbody>


</table>


</div>


</div>


<div class="modal-footer">


<button
    type="button"
    class="btn btn-secondary"
    data-bs-dismiss="modal"
>

    Close

</button>


<button
    type="button"
    class="btn btn-success"
    data-bs-dismiss="modal"
    data-bs-toggle="modal"
    data-bs-target="#addGradeModal"
>

    <i class="fas fa-plus me-1"></i>

    Add Grade

</button>


</div>


</div>

</div>

</div>


<!-- ========================================================
     EDIT GRADE MODALS
======================================================== -->

<?php foreach (
    $GRADE_MANAGEMENT
    as $gradeRow
): ?>


<?php

$gid =
    (int)$gradeRow['id'];

$gname =
    $gradeRow['grade_name'];

$usage =
    (int)$gradeRow['product_count'];

?>


<div
    class="modal fade"
    id="editGradeModal<?= $gid ?>"
    tabindex="-1"
>

<div class="modal-dialog modal-sm">

<div class="modal-content">


<div class="modal-header">


<h5 class="modal-title">

    <i class="fas fa-edit text-info me-2"></i>

    Edit Grade

</h5>


<button
    type="button"
    class="btn-close"
    data-bs-dismiss="modal"
></button>


</div>


<form method="POST">


<input
    type="hidden"
    name="csrf_token"
    value="<?= htmlspecialchars($CSRF_TOKEN) ?>"
>


<input
    type="hidden"
    name="grade_id"
    value="<?= $gid ?>"
>


<div class="modal-body">


<div class="mb-3">


<label class="form-label fw-semibold">

    Grade Name

</label>


<input
    type="text"
    name="edit_grade_name"
    class="form-control"
    value="<?= htmlspecialchars($gname) ?>"
    maxlength="50"
    required
>


</div>


<?php if ($usage > 0): ?>


<div class="alert alert-warning small mb-0">

    <i class="fas fa-triangle-exclamation me-1"></i>

    This grade is currently used by

    <strong>

        <?= $usage ?>

        <?= $usage === 1
            ? 'product'
            : 'products' ?>

    </strong>.

    Renaming it will automatically update
    those products.

</div>


<?php else: ?>


<div class="alert alert-info small mb-0">

    <i class="fas fa-info-circle me-1"></i>

    This grade is currently not assigned
    to any product.

</div>


<?php endif; ?>


</div>


<div class="modal-footer">


<button
    type="button"
    class="btn btn-secondary"
    data-bs-dismiss="modal"
>

    Cancel

</button>


<button
    type="submit"
    name="edit_grade"
    class="btn btn-primary"
>

    <i class="fas fa-save me-1"></i>

    Save Changes

</button>


</div>


</form>


</div>

</div>

</div>


<?php endforeach; ?>


<!-- ========================================================
     ADD PRODUCT MODAL
======================================================== -->

<div
    class="modal fade"
    id="addProductModal"
    tabindex="-1"
>

<div class="modal-dialog">

<div class="modal-content">


<div class="modal-header">

<h5 class="modal-title">

    Add Product

</h5>


<button
    class="btn-close"
    data-bs-dismiss="modal"
></button>

</div>


<form method="POST">


<input
    type="hidden"
    name="csrf_token"
    value="<?= htmlspecialchars($CSRF_TOKEN) ?>"
>


<div class="modal-body">


<!-- VARIETY -->

<div class="mb-3">

<label class="form-label">

    Variety

</label>


<input
    class="form-control"
    type="text"
    name="variety"
    required
>

</div>


<!-- GRADE -->

<div class="mb-3">


<label class="form-label d-block">

    Grade


<button
    type="button"
    class="btn btn-sm btn-outline-success py-0 px-1 ms-2"
    style="font-size:0.75em"
    data-bs-toggle="modal"
    data-bs-target="#addGradeModal"
>

    <i class="fas fa-plus"></i>
    New

</button>


<button
    type="button"
    class="btn btn-sm btn-outline-dark py-0 px-1 ms-1"
    style="font-size:0.75em"
    data-bs-toggle="modal"
    data-bs-target="#manageGradesModal"
>

    <i class="fas fa-gear"></i>
    Manage

</button>


</label>


<select
    class="form-select"
    name="grade"
    required
>


<option value="">
    Select grade
</option>


<?php foreach ($ALLOWED_GRADES as $g): ?>


<option
    value="<?= htmlspecialchars($g) ?>"
>

    <?= htmlspecialchars($g) ?>

</option>


<?php endforeach; ?>


</select>


</div>


<!-- UNIT SIZE -->

<div class="mb-3">


<label class="form-label d-block">

    Unit Size (kg per sack)


<button
    type="button"
    class="btn btn-sm btn-outline-info py-0 px-1 ms-2"
    style="font-size:0.75em"
    data-bs-toggle="modal"
    data-bs-target="#sizeGuideModal"
>

    <i class="fas fa-ruler"></i>
    Guide

</button>


</label>


<select
    class="form-select"
    name="unit_weight_kg"
    required
>


<option value="">
    Select unit size
</option>


<option value="5">
    5 kg
</option>


<option value="10">
    10 kg
</option>


<option value="25">
    25 kg
</option>


<option value="50">
    50 kg
</option>


</select>


</div>


<div class="alert alert-info mb-0">

    Add product first, then use
    <b>Stock In (Receiving)</b>
    to set pricing.

</div>


</div>


<div class="modal-footer">


<button
    class="btn btn-secondary"
    type="button"
    data-bs-dismiss="modal"
>

    Cancel

</button>


<button
    type="submit"
    name="add_product"
    class="btn btn-primary"
>

    <i class="fas fa-plus me-1"></i>

    Add Product

</button>


</div>


</form>


</div>

</div>

</div>


<!-- ========================================================
     THRESHOLD MODAL
======================================================== -->

<div
    class="modal fade"
    id="thresholdModal"
    tabindex="-1"
>

<div class="modal-dialog">

<div class="modal-content">


<div class="modal-header">


<h5 class="modal-title">

    Stock Threshold Settings

</h5>


<button
    class="btn-close"
    data-bs-dismiss="modal"
></button>


</div>


<form method="POST">


<input
    type="hidden"
    name="csrf_token"
    value="<?= htmlspecialchars($CSRF_TOKEN) ?>"
>


<div class="modal-body">


<div class="mb-3">


<label>
    Low Stock Threshold (kg)
</label>


<input
    type="number"
    step="0.01"
    name="low_stock_threshold"
    class="form-control"
    value="<?= htmlspecialchars($LOW_STOCK_THRESHOLD) ?>"
    required
>


</div>


<div class="mb-3">


<label>
    Overstock Threshold (kg)
</label>


<input
    type="number"
    step="0.01"
    name="overstock_threshold"
    class="form-control"
    value="<?= htmlspecialchars($OVERSTOCK_THRESHOLD) ?>"
    required
>


</div>


<hr>


<div class="mb-3">


<label
    class="form-label fw-bold text-danger"
>

    Admin Password

</label>


<input
    type="password"
    name="admin_password"
    class="form-control"
    placeholder="Enter password to save"
    required
>


</div>


</div>


<div class="modal-footer">


<button
    type="button"
    class="btn btn-secondary"
    data-bs-dismiss="modal"
>

    Cancel

</button>


<button
    type="submit"
    name="save_thresholds"
    class="btn btn-dark"
>

    <i class="fas fa-save me-1"></i>

    Save

</button>


</div>


</form>


</div>

</div>

</div>


</main>

</div>

</div>

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
></script>


<script>


document.addEventListener(
    'DOMContentLoaded',
    function () {

        const searchInput =
            document.getElementById(
                'productSearch'
            );


        const tableRows =
            document.querySelectorAll(
                '.products-table tbody tr'
            );


        if (!searchInput) {
            return;
        }


        searchInput.addEventListener(
            'input',
            function () {

                const searchTerm =
                    this.value
                        .toLowerCase()
                        .trim();


                tableRows.forEach(
                    function (row) {

                        const variety =
                            (
                                row.cells[0]
                                    ?.textContent
                                || ''
                            ).toLowerCase();


                        const grade =
                            (
                                row.cells[1]
                                    ?.textContent
                                || ''
                            ).toLowerCase();


                        const fullText =
                            variety +
                            ' ' +
                            grade;


                        row.style.display =
                            (
                                !searchTerm ||
                                variety.includes(searchTerm) ||
                                grade.includes(searchTerm) ||
                                fullText.includes(searchTerm)
                            )
                                ? ''
                                : 'none';
                    }
                );
            }
        );

    }
);


// ============================================================
// HANDLE MODAL BACKDROP CLEANUP
// ============================================================

document.addEventListener(
    'hidden.bs.modal',
    function (event) {

        // If modal is closed, make sure
        // body does not remain locked.

        document.body.classList.remove(
            'modal-open'
        );

        document
            .querySelectorAll(
                '.modal-backdrop'
            )
            .forEach(
                backdrop => backdrop.remove()
            );

    }
);

</script>


</body>

</html>
