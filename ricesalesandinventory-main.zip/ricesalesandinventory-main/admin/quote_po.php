<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

include '../config/db.php';

$po_id = (int)($_GET['id'] ?? $_POST['po_id'] ?? 0);

if ($po_id <= 0) {
    die("Invalid Purchase Order.");
}

/*
|--------------------------------------------------------------------------
| SAVE QUOTATION
|--------------------------------------------------------------------------
*/
if (isset($_POST['save_prices'])) {

    $grandTotal = 0;

    $itemIds = $_POST['item_id'] ?? [];
    $prices  = $_POST['price'] ?? [];

    foreach ($itemIds as $index => $itemId) {

        $itemId = (int)$itemId;
        $price  = (float)($prices[$index] ?? 0);

        $qtyStmt = $conn->prepare("
            SELECT quantity_sacks
            FROM purchase_items
            WHERE purchase_item_id = ?
            LIMIT 1
        ");

        $qtyStmt->bind_param("i", $itemId);
        $qtyStmt->execute();

        $qtyResult = $qtyStmt->get_result();
        $qtyRow = $qtyResult->fetch_assoc();

        $qtyStmt->close();

        if (!$qtyRow) {
            continue;
        }

        $qty = (int)$qtyRow['quantity_sacks'];

        $lineTotal = $qty * $price;

        $grandTotal += $lineTotal;

        $updateItem = $conn->prepare("
            UPDATE purchase_items
            SET supplier_price = ?,
                line_total = ?
            WHERE purchase_item_id = ?
        ");

        $updateItem->bind_param(
            "ddi",
            $price,
            $lineTotal,
            $itemId
        );

        $updateItem->execute();
        $updateItem->close();
    }

    $updatePO = $conn->prepare("
        UPDATE purchases
        SET total_amount = ?
        WHERE purchases_id = ?
    ");

    $updatePO->bind_param(
        "di",
        $grandTotal,
        $po_id
    );

    $updatePO->execute();
    $updatePO->close();

    header("Location: suppliers.php?tab=po&success=Supplier quotation saved successfully.");
    exit;
}

/*
|--------------------------------------------------------------------------
| LOAD PO ITEMS
|--------------------------------------------------------------------------
*/
$stmt = $conn->prepare("
    SELECT
        pi.purchase_item_id,
        pi.quantity_sacks,
        pi.estimated_price,
        pi.supplier_price,
        pr.variety,
        pr.grade
    FROM purchase_items pi
    INNER JOIN products pr
        ON pr.product_id = pi.product_id
    WHERE pi.purchases_id = ?
    ORDER BY pr.variety ASC
");

$stmt->bind_param("i", $po_id);
$stmt->execute();

$items = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Supplier Quotation</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="../css/admin-mobile.css" rel="stylesheet">
<style>
@media (max-width: 575.98px){
    .container.mt-4{
        padding-left: 12px;
        padding-right: 12px;
    }

    .d-flex.justify-content-between.align-items-center.mb-3{
        flex-direction: column;
        align-items: stretch !important;
        gap: 12px;
    }

    .d-flex.justify-content-between.align-items-center.mb-3 .btn{
        width: 100%;
    }

    .table{
        font-size: .93rem;
    }

    .card-body{
        padding: 1rem;
    }
}
</style>
</head>
<body>

<div class="container mt-4">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Enter Supplier Quotation</h3>

        <a href="suppliers.php?tab=po"
           class="btn btn-secondary">
            Back
        </a>
    </div>

    <div class="card">

        <div class="card-header">
            Purchase Order #<?= $po_id ?>
        </div>

        <div class="card-body">

            <form method="POST">

                <input type="hidden"
                       name="po_id"
                       value="<?= $po_id ?>">

                <div class="table-responsive">

                    <table class="table table-bordered align-middle">

                        <thead class="table-dark">
                            <tr>
                                <th>Product</th>
                                <th width="120">Quantity</th>
                                <th width="180">Supplier Price</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php while ($item = $items->fetch_assoc()): ?>

                            <tr>

                                <td>
                                    <strong>
                                        <?= htmlspecialchars($item['variety']) ?>
                                    </strong>

                                    <br>

                                    <small class="text-muted">
                                        Grade:
                                        <?= htmlspecialchars($item['grade']) ?>
                                    </small>

                                    <input
                                        type="hidden"
                                        name="item_id[]"
                                        value="<?= (int)$item['purchase_item_id'] ?>">
                                </td>

                                <td>
                                    <?= (int)$item['quantity_sacks'] ?>
                                </td>

                                <td>
                                    <input
                                        type="number"
                                        name="price[]"
                                        class="form-control"
                                        min="0"
                                        step="0.01"
                                        required
                                        value="<?= (float)($item['supplier_price'] ?: $item['estimated_price']) ?>">
                                </td>

                            </tr>

                        <?php endwhile; ?>

                        </tbody>

                    </table>

                </div>

                <div class="text-end">

                    <button
                        type="submit"
                        name="save_prices"
                        class="btn btn-success">

                        Save Supplier Quotation

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>

</body>
</html>
