<?php
declare(strict_types=1);

header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');

$secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
session_set_cookie_params([
  'lifetime' => 0,
  'path' => '/',
  'secure' => $secure,
  'httponly' => true,
  'samesite' => 'Lax',
]);

session_start();
require_once 'config/db.php';
require_once 'includes/mailer.php';

function h(string $v): string {
  return htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
}

function flash_and_redirect(string $message): void {
  $_SESSION['flash_success'] = $message;
  header('Location: login.php');
  exit;
}

if (empty($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $csrfPost = (string)($_POST['csrf_token'] ?? '');
  $csrfSess = (string)($_SESSION['csrf_token'] ?? '');
  if ($csrfPost === '' || $csrfSess === '' || !hash_equals($csrfSess, $csrfPost)) {
    $message = 'Invalid request. Please refresh and try again.';
  } else {
    $email = trim((string)($_POST['email'] ?? ''));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      flash_and_redirect('If an account with that email exists, a password reset link has been sent.');
    }

    $stmt = $conn->prepare('SELECT user_id, email FROM users WHERE LOWER(email) = LOWER(?) LIMIT 1');
    if ($stmt) {
      $stmt->bind_param('s', $email);
      $stmt->execute();
      $user = $stmt->get_result()->fetch_assoc();
      $stmt->close();
    } else {
      $user = null;
    }

    if ($user && !empty($user['email'])) {
      $rawToken = bin2hex(random_bytes(32));
      $tokenHash = hash('sha256', $rawToken);
      $expiresAt = date('Y-m-d H:i:s', time() + (30 * 60));

      $update = $conn->prepare('UPDATE users SET reset_token = ?, reset_token_expires_at = ? WHERE user_id = ?');
      if ($update) {
        $userId = (int)$user['user_id'];
        $update->bind_param('ssi', $tokenHash, $expiresAt, $userId);
        $update->execute();
        $update->close();

        $baseUrl = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://')
          . ($_SERVER['HTTP_HOST'] ?? 'localhost')
          . rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
        $resetLink = $baseUrl . '/reset_password.php?token=' . urlencode($rawToken);

        if (!send_password_reset_email((string)$user['email'], $resetLink)) {
          error_log('Password reset email failed for user_id: ' . $userId);
        }
      }
    }

    flash_and_redirect('If an account with that email exists, a password reset link has been sent.');
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Forgot Password | Rice Control System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="css/login.css?v=5" rel="stylesheet">
</head>
<body>
<div class="container-fluid">
<div class="row min-vh-100">
  <div class="col-md-6 d-flex align-items-center login-column">
    <div class="w-100 px-3 px-md-5 panel-wrap">
      <div class="login-panel">
        <div class="brand-row mb-3">
          <img src="assets/logo.jpg" alt="Logo" class="brand-logo">
          <div class="brand-text">
            <strong>Rice Control</strong>
            <span>System</span>
          </div>
        </div>

        <h2 class="fw-bold mb-1">Reset your password</h2>
        <p class="text-muted mb-4">Enter your registered email address.</p>

        <?php if ($message): ?>
          <div class="alert alert-danger"><?= h($message) ?></div>
        <?php endif; ?>

        <form method="POST" action="forgot_password.php" class="needs-validation" novalidate>
          <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">

          <div class="mb-3">
            <label class="form-label">Email Address</label>
            <input type="email" class="form-control" name="email" required autocomplete="email">
            <div class="invalid-feedback">Please enter your registered email.</div>
          </div>

          <button type="submit" class="btn btn-dark w-100">Send Reset Link</button>
        </form>

        <div class="text-center mt-3">
          <a href="login.php" class="small text-decoration-none">Back to Login</a>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-6 hero-image d-none d-md-block"></div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
