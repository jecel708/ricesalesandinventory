<?php
$activePage = (string)($activePage ?? '');
if ($activePage === '') {
  $currentPage = basename((string)($_SERVER['SCRIPT_NAME'] ?? ''));
    $activePage = match ($currentPage) {
      'dashboard.php' => 'dashboard',
      'inventory_monitoring.php' => 'stock_monitoring',
      'sales_report.php' => 'sales_report',
      'supplier_payables.php' => 'supplier_payables',
      'purchase_orders.php', 'get_po_details.php' => 'purchase_orders',
      'approved_purchases.php' => 'approved_purchases',
      'payments.php' => 'payments',
      'returns_report.php' => 'returns_report',
      'analytics.php' => 'analytics',
      'system_logs.php' => 'logs',
      'profile.php' => 'profile',
      default => '',
    };
  }
  $purchaseOrderPages = ['supplier_payables','purchase_orders','approved_purchases'];
  $reportPages = ['sales_report','returns_report','analytics','stock_monitoring'];
?>
<nav id="sidebarMenu" class="col-lg-2 d-lg-block sidebar collapse">
  <div class="pt-4">
    <ul class="nav flex-column gap-1">

      <li class="nav-item">
        <a class="nav-link <?= ($activePage==='dashboard'?'active':'') ?>" href="dashboard.php">
          <i class="fas fa-gauge-high me-2"></i>Owner Dashboard
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link <?= ($activePage==='stock_monitoring'?'active':'') ?>" href="inventory_monitoring.php">
          <i class="fas fa-boxes-stacked me-2"></i>Stock Monitoring
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link <?= ($activePage==='payments'?'active':'') ?>" href="../owner/payments.php">
          <i class="fas fa-coins me-2"></i>Utang Payments
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link <?= in_array($activePage,$purchaseOrderPages,true)?'active':'' ?>" data-bs-toggle="collapse" href="#purchaseOrderMenu">
          <i class="fas fa-file-invoice me-2"></i>Purchase Order
          <i class="fas fa-chevron-down float-end"></i>
        </a>
        <div class="collapse submenu <?= in_array($activePage,$purchaseOrderPages,true)?'show':'' ?>" id="purchaseOrderMenu">
          <a class="<?= ($activePage==='purchase_orders'?'active':'') ?>" href="../owner/purchase_orders.php">Pending Purchase Requests</a>
          <a class="<?= ($activePage==='approved_purchases'?'active':'') ?>" href="../owner/approved_purchases.php">Approved Purchases</a>
          <a class="<?= ($activePage==='supplier_payables'?'active':'') ?>" href="../owner/supplier_payables.php">Supplier Payables</a>
        </div>
      </li>

      <li class="nav-item">
        <a class="nav-link <?= in_array($activePage,$reportPages,true)?'active':'' ?>" data-bs-toggle="collapse" href="#reportsMenu">
          <i class="fas fa-chart-column me-2"></i>Reports
          <i class="fas fa-chevron-down float-end"></i>
        </a>
        <div class="collapse submenu <?= in_array($activePage,$reportPages,true)?'show':'' ?>" id="reportsMenu">
          <a class="<?= ($activePage==='sales_report'?'active':'') ?>" href="sales_report.php">Sales Reports</a>
          <a class="<?= ($activePage==='returns_report'?'active':'') ?>" href="returns_report.php">Returns Report</a>
          <a class="<?= ($activePage==='inventory_report'?'active':'') ?>" href="inventory_report.php">Inventory Reports</a>
          <a class="<?= ($activePage==='analytics'?'active':'') ?>" href="analytics.php">Analytics & Forecasting</a>
        </div>
      </li>

      <li class="nav-item">
        <a class="nav-link <?= ($activePage==='logs'?'active':'') ?>" href="system_logs.php">
          <i class="fas fa-file-shield me-2"></i>System Logs
        </a>
      </li>

    </ul>

    <div class="px-3 mt-4">
      <div class="alert alert-light small mb-0">
        <i class="fa-solid fa-circle-info me-1"></i>
        Owner access is <b>monitoring + finance approval</b>.
      </div>
    </div>
  </div>
</nav>
