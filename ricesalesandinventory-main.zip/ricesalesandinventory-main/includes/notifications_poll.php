<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if(!isset($_SESSION['user_id'])){
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => 'Unauthorized']);
    exit;
}

include '../config/db.php';

$init = (int)($_GET['init'] ?? 0);
$lastId = (int)($_GET['last_id'] ?? 0);
if($lastId < 0) $lastId = 0;

if($init === 1){
    $res = $conn->query("SELECT IFNULL(MAX(push_notif_id),0) AS max_id FROM push_notif_logs");
    $maxId = 0;
    if($res){
        $row = $res->fetch_assoc();
        $maxId = (int)($row['max_id'] ?? 0);
    }
    echo json_encode([
        'ok' => true,
        'max_id' => $maxId,
        'notifications' => []
    ]);
    exit;
}

$stmt = $conn->prepare("
    SELECT
      pn.push_notif_id,
      pn.message,
      pn.sent_at,
      pn.status,
      pn.customer_id,
      c.first_name,
      c.last_name
    FROM push_notif_logs pn
    LEFT JOIN customers c ON c.customer_id = pn.customer_id
    WHERE pn.push_notif_id > ?
    ORDER BY pn.push_notif_id ASC
    LIMIT 20
");

if(!$stmt){
    echo json_encode(['ok' => false, 'message' => 'DB error']);
    exit;
}

$stmt->bind_param("i", $lastId);
$stmt->execute();
$res = $stmt->get_result();

$rows = [];
$maxId = $lastId;
while($r = $res->fetch_assoc()){
    $id = (int)($r['push_notif_id'] ?? 0);
    if($id > $maxId) $maxId = $id;

    $customerName = trim((string)($r['first_name'] ?? '').' '.(string)($r['last_name'] ?? ''));
    if($customerName === ''){
        $customerName = 'Customer #'.(int)($r['customer_id'] ?? 0);
    }

    $rows[] = [
        'id' => $id,
        'message' => (string)($r['message'] ?? ''),
        'sent_at' => (string)($r['sent_at'] ?? ''),
        'status' => (string)($r['status'] ?? ''),
        'customer' => $customerName
    ];
}
$stmt->close();

echo json_encode([
    'ok' => true,
    'max_id' => $maxId,
    'notifications' => $rows
]);
