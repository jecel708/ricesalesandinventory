<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
  http_response_code(401);
  echo json_encode(['ok' => false, 'message' => 'Unauthorized']);
  exit;
}

include __DIR__ . '/../config/db.php';

$userId = (int)($_SESSION['user_id'] ?? 0);
$action = (string)($_GET['action'] ?? 'state');

function json_ok(array $data = []): void
{
  echo json_encode(['ok' => true] + $data);
  exit;
}

function json_err(string $message, int $code = 400): void
{
  http_response_code($code);
  echo json_encode(['ok' => false, 'message' => $message]);
  exit;
}

function notif_max_id(mysqli $conn): int
{
  $res = $conn->query("SELECT IFNULL(MAX(push_notif_id),0) AS max_id FROM push_notif_logs");
  if (!$res) {
    return 0;
  }
  $row = $res->fetch_assoc();
  return (int)($row['max_id'] ?? 0);
}

function notif_last_seen(mysqli $conn, int $userId): int
{
  $stmt = $conn->prepare("SELECT last_seen_push_notif_id FROM user_notif_state WHERE user_id=?");
  if (!$stmt) {
    return 0;
  }
  $stmt->bind_param("i", $userId);
  $stmt->execute();
  $res = $stmt->get_result();
  $row = $res ? $res->fetch_assoc() : null;
  $stmt->close();

  if ($row && isset($row['last_seen_push_notif_id'])) {
    return (int)$row['last_seen_push_notif_id'];
  }

  $ins = $conn->prepare("INSERT IGNORE INTO user_notif_state (user_id, last_seen_push_notif_id) VALUES (?, 0)");
  if ($ins) {
    $ins->bind_param("i", $userId);
    $ins->execute();
    $ins->close();
  }
  return 0;
}

function notif_unread_count(mysqli $conn, int $lastSeen): int
{
  $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM push_notif_logs WHERE push_notif_id > ?");
  if (!$stmt) {
    return 0;
  }
  $stmt->bind_param("i", $lastSeen);
  $stmt->execute();
  $res = $stmt->get_result();
  $row = $res ? $res->fetch_assoc() : null;
  $stmt->close();
  return (int)($row['c'] ?? 0);
}

if ($userId <= 0) {
  json_err('Unauthorized', 401);
}

if ($action === 'state') {
  $maxId = notif_max_id($conn);
  $lastSeen = notif_last_seen($conn, $userId);
  $unread = notif_unread_count($conn, $lastSeen);
  json_ok([
    'max_id' => $maxId,
    'last_seen' => $lastSeen,
    'unread_count' => $unread,
  ]);
}

if ($action === 'list') {
  $limit = (int)($_GET['limit'] ?? 10);
  if ($limit < 1) $limit = 1;
  if ($limit > 50) $limit = 50;

  $maxId = notif_max_id($conn);
  $lastSeen = notif_last_seen($conn, $userId);
  $unread = notif_unread_count($conn, $lastSeen);

  $stmt = $conn->prepare("
    SELECT
      pn.push_notif_id,
      pn.message,
      pn.sent_at,
      pn.status,
      pn.customer_id,
      c.first_name,
      c.last_name
    FROM push_notif_logs pn
    LEFT JOIN customers c ON c.customer_id = pn.customer_id
    ORDER BY pn.push_notif_id DESC
    LIMIT ?
  ");
  if (!$stmt) {
    json_err('DB error', 500);
  }
  $stmt->bind_param("i", $limit);
  $stmt->execute();
  $res = $stmt->get_result();

  $rows = [];
  while ($r = $res->fetch_assoc()) {
    $id = (int)($r['push_notif_id'] ?? 0);
    $customerName = trim((string)($r['first_name'] ?? '') . ' ' . (string)($r['last_name'] ?? ''));
    if ($customerName === '') {
      $customerName = 'Customer #' . (int)($r['customer_id'] ?? 0);
    }

    $rows[] = [
      'id' => $id,
      'message' => (string)($r['message'] ?? ''),
      'sent_at' => (string)($r['sent_at'] ?? ''),
      'status' => (string)($r['status'] ?? ''),
      'customer' => $customerName,
      'is_unread' => ($id > $lastSeen),
    ];
  }
  $stmt->close();

  json_ok([
    'max_id' => $maxId,
    'last_seen' => $lastSeen,
    'unread_count' => $unread,
    'notifications' => $rows,
  ]);
}

if ($action === 'mark_all_read') {
  if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
    json_err('Method not allowed', 405);
  }

  $maxId = notif_max_id($conn);
  $stmt = $conn->prepare("
    INSERT INTO user_notif_state (user_id, last_seen_push_notif_id)
    VALUES (?, ?)
    ON DUPLICATE KEY UPDATE last_seen_push_notif_id=VALUES(last_seen_push_notif_id)
  ");
  if (!$stmt) {
    json_err('DB error', 500);
  }
  $stmt->bind_param("ii", $userId, $maxId);
  $stmt->execute();
  $stmt->close();

  json_ok([
    'max_id' => $maxId,
    'last_seen' => $maxId,
    'unread_count' => 0,
  ]);
}

json_err('Unknown action', 400);

