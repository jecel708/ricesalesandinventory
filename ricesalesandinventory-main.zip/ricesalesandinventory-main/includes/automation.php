<?php

function automationColumnExists(mysqli $conn, string $table, string $column): bool {
    $tableEsc = $conn->real_escape_string($table);
    $colEsc = $conn->real_escape_string($column);
    $res = $conn->query("SHOW COLUMNS FROM `{$tableEsc}` LIKE '{$colEsc}'");
    return (bool)($res && $res->num_rows > 0);
}

function ensureAutomationSchema(mysqli $conn): void {
    $conn->query("
        CREATE TABLE IF NOT EXISTS finance_settings (
            id TINYINT PRIMARY KEY,
            auto_apply TINYINT(1) NOT NULL DEFAULT 1,
            grace_days INT NOT NULL DEFAULT 0,
            ap_interest_monthly_pct DECIMAL(6,2) NOT NULL DEFAULT 2.00,
            ap_penalty_flat DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            ar_interest_monthly_pct DECIMAL(6,2) NOT NULL DEFAULT 2.00,
            ar_penalty_flat DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            last_run_date DATE NULL,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    ");
    $conn->query("
        INSERT INTO finance_settings (id)
        SELECT 1
        WHERE NOT EXISTS (SELECT 1 FROM finance_settings WHERE id=1)
    ");

    $conn->query("
        CREATE TABLE IF NOT EXISTS finance_charge_logs (
            charge_id INT AUTO_INCREMENT PRIMARY KEY,
            account_type ENUM('AP','AR') NOT NULL,
            account_id INT NOT NULL,
            charge_date DATE NOT NULL,
            interest_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            penalty_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            total_charge DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            balance_before DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            balance_after DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            note VARCHAR(255) NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_charge_once (account_type, account_id, charge_date)
        )
    ");

    foreach(['account_payable', 'account_receivable'] as $tbl){
        if(!automationColumnExists($conn, $tbl, 'accrued_interest')){
            $conn->query("ALTER TABLE {$tbl} ADD COLUMN accrued_interest DECIMAL(10,2) NOT NULL DEFAULT 0.00");
        }
        if(!automationColumnExists($conn, $tbl, 'accrued_penalty')){
            $conn->query("ALTER TABLE {$tbl} ADD COLUMN accrued_penalty DECIMAL(10,2) NOT NULL DEFAULT 0.00");
        }
        if(!automationColumnExists($conn, $tbl, 'last_charge_date')){
            $conn->query("ALTER TABLE {$tbl} ADD COLUMN last_charge_date DATE NULL");
        }
    }
}

function applyOverdueChargesForTable(
    mysqli $conn,
    string $table,
    string $idColumn,
    string $accountType,
    float $monthlyRatePct,
    float $flatPenalty,
    int $graceDays,
    string $today
): void {
    $monthlyRatePct = max(0, $monthlyRatePct);
    $flatPenalty = max(0, $flatPenalty);
    $dailyRate = ($monthlyRatePct / 100.0) / 30.0;

    $joinSql = '';
    $sackCountSelect = '0 AS sack_count';
    if ($accountType === 'AR') {
        $joinSql = ' LEFT JOIN sales_items si ON ar.sales_id = si.sale_id AND si.unit_type = \'sack\'';
        $sackCountSelect = 'COALESCE(SUM(IFNULL(si.qty_input,0)), 0) AS sack_count';
    }

    $eligibilitySql = '';
    if ($accountType === 'AP') {
        if (automationColumnExists($conn, $table, 'approved')) {
            $eligibilitySql .= ' AND IFNULL(ar.approved,0) = 1';
        }
        if (automationColumnExists($conn, $table, 'rejected')) {
            $eligibilitySql .= ' AND IFNULL(ar.rejected,0) = 0';
        }
    }

    $sql = "
        SELECT {$idColumn} AS doc_id, balance, due_date, status, last_charge_date, {$sackCountSelect}
        FROM {$table} ar
        {$joinSql}
        WHERE IFNULL(balance,0) > 0
          AND due_date IS NOT NULL
          AND due_date < CURDATE()
          AND LOWER(IFNULL(status,'')) <> 'paid'
          {$eligibilitySql}
        GROUP BY {$idColumn}
    ";
    $res = $conn->query($sql);
    if(!$res){
        return;
    }

    while($row = $res->fetch_assoc()){
        $docId = (int)($row['doc_id'] ?? 0);
        if($docId <= 0){
            continue;
        }

        $balanceBefore = (float)($row['balance'] ?? 0);
        $dueDateRaw = (string)($row['due_date'] ?? '');
        $lastChargeRaw = trim((string)($row['last_charge_date'] ?? ''));
        $sackCount = (float)($row['sack_count'] ?? 0);
        if($balanceBefore <= 0 || $dueDateRaw === ''){
            continue;
        }

        $daysOverdue = (int)floor((strtotime($today) - strtotime($dueDateRaw)) / 86400);
        if($daysOverdue < 1){
            continue;
        }

        $interest = 0.0;
        $penalty = 0.0;
        $hasChargedToday = ($lastChargeRaw === $today);

        if(!$hasChargedToday && $daysOverdue > $graceDays){
            $interest = round($balanceBefore * $dailyRate, 2);
            if($lastChargeRaw === ''){
                if ($accountType === 'AR') {
                    $penalty = $sackCount > 0
                        ? round($flatPenalty * $sackCount, 2)
                        : round(100.00, 2);
                } else {
                    $penalty = round($flatPenalty, 2);
                }
            }
        }

        $totalCharge = round(max(0, $interest) + max(0, $penalty), 2);
        $balanceAfter = $balanceBefore;
        $totalExpr = 'total_amount';
        $updateParams = [];
        $types = '';

        if($totalCharge > 0){
            $balanceAfter = round($balanceBefore + $totalCharge, 2);
            $totalExpr = 'IFNULL(total_amount,0) + ?';
            $updateParams[] = $totalCharge;
            $types .= 'd';
        }

        $updateSql = "
            UPDATE {$table}
            SET total_amount = {$totalExpr},
                balance = ?,
                accrued_interest = IFNULL(accrued_interest,0) + ?,
                accrued_penalty = IFNULL(accrued_penalty,0) + ?,
                status = 'overdue',
                last_charge_date = ?
            WHERE {$idColumn} = ?
        ";
        $stmt = $conn->prepare($updateSql);
        if(!$stmt){
            continue;
        }

        $updateParams[] = $balanceAfter;
        $updateParams[] = $interest;
        $updateParams[] = $penalty;
        $updateParams[] = $today;
        $updateParams[] = $docId;
        $types .= "dddsi";
        $stmt->bind_param($types, ...$updateParams);
        $stmt->execute();
        $stmt->close();

        if($totalCharge > 0){
            $logStmt = $conn->prepare("
                INSERT IGNORE INTO finance_charge_logs
                (account_type, account_id, charge_date, interest_amount, penalty_amount, total_charge, balance_before, balance_after, note, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            if($logStmt){
                $note = "Auto overdue charge";
                $logStmt->bind_param(
                    "sisddddds",
                    $accountType,
                    $docId,
                    $today,
                    $interest,
                    $penalty,
                    $totalCharge,
                    $balanceBefore,
                    $balanceAfter,
                    $note
                );
                $logStmt->execute();
                $logStmt->close();
            }
        }
    }
}

function runDailyAutomation(mysqli $conn): void {
    static $ran = false;
    if($ran){
        return;
    }
    $ran = true;

    ensureAutomationSchema($conn);

    $today = date('Y-m-d');

    $financeRes = $conn->query("
        SELECT auto_apply, grace_days,
               ap_interest_monthly_pct, ap_penalty_flat,
               ar_interest_monthly_pct, ar_penalty_flat,
               last_run_date
        FROM finance_settings
        WHERE id=1
        LIMIT 1
    ");
    if($financeRes && $financeRes->num_rows > 0){
        $f = $financeRes->fetch_assoc();
        $autoApply = (int)($f['auto_apply'] ?? 1) === 1;
        $lastRunDate = trim((string)($f['last_run_date'] ?? ''));
        if($autoApply && $lastRunDate !== $today){
            $graceDays = max(0, min(60, (int)($f['grace_days'] ?? 0)));

            applyOverdueChargesForTable(
                $conn,
                'account_payable',
                'ap_id',
                'AP',
                (float)($f['ap_interest_monthly_pct'] ?? 2),
                (float)($f['ap_penalty_flat'] ?? 0),
                $graceDays,
                $today
            );

            applyOverdueChargesForTable(
                $conn,
                'account_receivable',
                'ar_id',
                'AR',
                (float)($f['ar_interest_monthly_pct'] ?? 2),
                (float)($f['ar_penalty_flat'] ?? 0),
                $graceDays,
                $today
            );

            $stmt = $conn->prepare("UPDATE finance_settings SET last_run_date=? WHERE id=1");
            if($stmt){
                $stmt->bind_param("s", $today);
                $stmt->execute();
                $stmt->close();
            }
        }
    }
}
