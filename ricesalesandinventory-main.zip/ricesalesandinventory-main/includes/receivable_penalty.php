<?php

function ensurePenaltyPaymentColumn(mysqli $conn): void {
    foreach (['amount_paid', 'waived_amount'] as $column) {
        $result = $conn->query("SHOW COLUMNS FROM penalties LIKE '{$column}'");
        if (!$result) {
            throw new RuntimeException("Unable to inspect penalty tracking: " . $conn->error);
        }

        if ($result->num_rows === 0 && !$conn->query("
            ALTER TABLE penalties
            ADD COLUMN `{$column}` DECIMAL(10,2) NOT NULL DEFAULT 0.00
        ")) {
            throw new RuntimeException("Unable to add penalty tracking: " . $conn->error);
        }
    }
}

function receivablePenaltyAmountSql(): string {
    $sackCount = "(
        SELECT IFNULL(SUM(si.qty_input),0)
        FROM sales_items si
        WHERE si.sale_id = ar.sales_id
          AND si.unit_type = 'sack'
    )";

    return "
        CASE
            WHEN p.penalty_id IS NOT NULL THEN p.penalty_amount
            WHEN ar.status <> 'paid' AND ar.due_date < CURDATE()
                THEN CASE WHEN {$sackCount} > 0 THEN {$sackCount} * 50 ELSE 100 END
            ELSE 0
        END
    ";
}

function receivablePenaltyOutstandingSql(): string {
    return "GREATEST((" . receivablePenaltyAmountSql() . ") - IFNULL(p.amount_paid,0) - IFNULL(p.waived_amount,0), 0)";
}
