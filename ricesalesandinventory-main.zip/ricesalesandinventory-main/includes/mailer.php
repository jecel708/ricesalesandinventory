<?php
declare(strict_types=1);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../vendor/autoload.php';


const SMTP_USER = 'dohiys.system.otp@gmail.com';

const SMTP_PASS = 'ewhx kmtp tnhy zpye';

function send_otp_email(string $toEmail, string $otpCode): bool
{
    if (!filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
        error_log('Invalid email address: ' . $toEmail);
        return false;
    }

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USER;
        $mail->Password   = SMTP_PASS;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;

        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer'       => false,
                'verify_peer_name'  => false,
                'allow_self_signed' => true,
            ],
        ];

        $mail->setFrom(SMTP_USER, 'DE ORO HIYS GENERAL MERCHANDISE');
        $mail->addAddress($toEmail);

        $safeOtp = htmlspecialchars($otpCode, ENT_QUOTES, 'UTF-8');

        $mail->isHTML(true);
        $mail->Subject = 'Your verification code - DE ORO HIYS GENERAL MERCHANDISE';
        $mail->Body = <<<HTML
<!doctype html>
<html lang="en">
<body style="margin:0;padding:0;background-color:#f4f7f3;font-family:Arial,Helvetica,sans-serif;color:#243126;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="background-color:#f4f7f3;">
    <tr>
      <td align="center" style="padding:32px 16px;">
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="max-width:560px;background:#ffffff;border-radius:14px;overflow:hidden;box-shadow:0 4px 18px rgba(30,65,35,.10);">
          <tr>
            <td style="padding:28px 32px 24px;background:#2f7d32;text-align:center;">
              <div style="font-size:22px;font-weight:700;letter-spacing:.2px;color:#ffffff;">DE ORO HIYS GENERAL MERCHANDISE</div>
              <div style="margin-top:7px;font-size:13px;letter-spacing:1px;text-transform:uppercase;color:#dff0dc;">Security Verification</div>
            </td>
          </tr>
          <tr>
            <td style="padding:32px 32px 14px;text-align:center;">
              <h1 style="margin:0 0 14px;font-size:24px;line-height:1.3;color:#285b2b;">Your verification code</h1>
              <p style="margin:0;font-size:15px;line-height:1.6;color:#58635a;">Use the code below to continue securely. It expires in <strong>5 minutes</strong>.</p>
            </td>
          </tr>
          <tr>
            <td style="padding:16px 32px 24px;text-align:center;">
              <div style="display:inline-block;padding:16px 28px;background:#edf8ed;border:1px dashed #61a864;border-radius:10px;font-size:30px;font-weight:700;letter-spacing:8px;color:#236b28;">{$safeOtp}</div>
            </td>
          </tr>
          <tr>
            <td style="padding:0 32px 30px;text-align:center;">
              <p style="margin:0;font-size:14px;line-height:1.6;color:#58635a;">For your security, do not share this code with anyone. Our staff will never ask for it.</p>
            </td>
          </tr>
          <tr>
            <td style="padding:18px 32px;background:#f7faf7;border-top:1px solid #e6eee6;text-align:center;">
              <p style="margin:0;font-size:12px;line-height:1.5;color:#7a847b;">This is an automated message from DE ORO HIYS GENERAL MERCHANDISE. Please do not reply to this email.</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
HTML;
        $mail->AltBody = "DE ORO HIYS GENERAL MERCHANDISE\n\nYour verification code: {$otpCode}\n\nThis code expires in 5 minutes. Do not share it with anyone.";

        return $mail->send();

    } catch (Exception $e) {
        error_log('PHPMailer error: ' . $mail->ErrorInfo);
        error_log('PHPMailer exception: ' . $e->getMessage());
        return false;
    }
}

function send_password_reset_email(string $toEmail, string $resetLink): bool
{
    if (!filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
        error_log('Invalid email address: ' . $toEmail);
        return false;
    }

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USER;
        $mail->Password   = SMTP_PASS;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;

        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer'       => false,
                'verify_peer_name'  => false,
                'allow_self_signed' => true,
            ],
        ];

        $mail->setFrom(SMTP_USER, 'DE ORO HIYS GENERAL MERCHANDISE');
        $mail->addAddress($toEmail);

        $safeResetLink = htmlspecialchars($resetLink, ENT_QUOTES, 'UTF-8');

        $mail->isHTML(true);
        $mail->Subject = 'Reset your password - DE ORO HIYS GENERAL MERCHANDISE';
        $mail->Body = <<<HTML
<!doctype html>
<html lang="en">
<body style="margin:0;padding:0;background-color:#f4f7f3;font-family:Arial,Helvetica,sans-serif;color:#243126;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="background-color:#f4f7f3;">
    <tr>
      <td align="center" style="padding:32px 16px;">
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="max-width:560px;background:#ffffff;border-radius:14px;overflow:hidden;box-shadow:0 4px 18px rgba(30,65,35,.10);">
          <tr>
            <td style="padding:28px 32px 24px;background:#2f7d32;text-align:center;">
              <div style="font-size:22px;font-weight:700;letter-spacing:.2px;color:#ffffff;">DE ORO HIYS GENERAL MERCHANDISE</div>
              <div style="margin-top:7px;font-size:13px;letter-spacing:1px;text-transform:uppercase;color:#dff0dc;">Account Security</div>
            </td>
          </tr>
          <tr>
            <td style="padding:32px 32px 12px;text-align:center;">
              <h1 style="margin:0 0 14px;font-size:24px;line-height:1.3;color:#285b2b;">Reset your password</h1>
              <p style="margin:0;font-size:15px;line-height:1.6;color:#58635a;">We received a request to reset your account password. Select the button below to create a new one.</p>
            </td>
          </tr>
          <tr>
            <td style="padding:22px 32px 28px;text-align:center;">
              <a href="{$safeResetLink}" style="display:inline-block;padding:14px 24px;background:#2f7d32;border-radius:8px;color:#ffffff;font-size:15px;font-weight:700;text-decoration:none;">Reset Password</a>
            </td>
          </tr>
          <tr>
            <td style="padding:0 32px 30px;text-align:center;">
              <p style="margin:0 0 10px;font-size:14px;line-height:1.6;color:#58635a;">This reset link expires in <strong>30 minutes</strong>.</p>
              <p style="margin:0;font-size:14px;line-height:1.6;color:#58635a;">If you did not request a password reset, you can safely ignore this email. Your password will not change.</p>
            </td>
          </tr>
          <tr>
            <td style="padding:18px 32px;background:#f7faf7;border-top:1px solid #e6eee6;text-align:center;">
              <p style="margin:0 0 8px;font-size:12px;line-height:1.5;color:#7a847b;">If the button does not work, copy and paste this link into your browser:</p>
              <p style="margin:0;font-size:11px;line-height:1.5;word-break:break-all;color:#2f7d32;">{$safeResetLink}</p>
              <p style="margin:14px 0 0;font-size:12px;line-height:1.5;color:#7a847b;">This is an automated message from DE ORO HIYS GENERAL MERCHANDISE. Please do not reply to this email.</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
HTML;
        $mail->AltBody = "DE ORO HIYS GENERAL MERCHANDISE\n\nWe received a request to reset your password.\n\nReset your password using this link:\n{$resetLink}\n\nThis link expires in 30 minutes. If you did not request this, you can ignore this email.";

        return $mail->send();
    } catch (Exception $e) {
        error_log('PHPMailer error: ' . $mail->ErrorInfo);
        error_log('PHPMailer exception: ' . $e->getMessage());
        return false;
    }
}
