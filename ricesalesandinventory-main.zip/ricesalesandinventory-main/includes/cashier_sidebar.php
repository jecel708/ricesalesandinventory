<?php
$activePage = (string)($activePage ?? '');
if ($activePage === '') {
  $currentPage = basename((string)($_SERVER['SCRIPT_NAME'] ?? ''));
  $activePage = match ($currentPage) {
    'dashboard.php' => 'dashboard',
    'pos.php' => 'pos',
    'sales_history.php', 'receipt.php', 'reprint_receipt.php' => 'sales_history',
    'payments.php', 'payment_receipt.php' => 'payments',
    'returns.php' => 'returns',
    'customers.php' => 'customers',
    'inventory_view.php' => 'inventory',
    'cashier_profile.php' => 'profile',
    default => '',
  };
}
?>
<nav id="sidebarMenu" class="col-lg-2 d-lg-block sidebar collapse">
<div class="pt-4">
<ul class="nav flex-column gap-1 px-2">
<li class="nav-item"><a class="nav-link <?= ($activePage==='dashboard'?'active':'') ?>" href="dashboard.php"><i class="fas fa-home me-2"></i>Dashboard</a></li>
<li class="nav-item"><a class="nav-link <?= ($activePage==='pos'?'active':'') ?>" href="pos.php"><i class="fas fa-cash-register me-2"></i>Sale</a></li>
<li class="nav-item"><a class="nav-link <?= ($activePage==='sales_history'?'active':'') ?>" href="sales_history.php"><i class="fas fa-receipt me-2"></i>Sales History</a></li>
<li class="nav-item"><a class="nav-link <?= ($activePage==='payments'?'active':'') ?>" href="payments.php"><i class="fas fa-hand-holding-dollar me-2"></i>Utang Payments</a></li>
<li class="nav-item"><a class="nav-link <?= ($activePage==='returns'?'active':'') ?>" href="returns.php"><i class="fas fa-rotate-left me-2"></i>Returns</a></li>
<li class="nav-item"><a class="nav-link <?= ($activePage==='customers'?'active':'') ?>" href="customers.php"><i class="fas fa-users me-2"></i>Customers</a></li>
<li class="nav-item"><a class="nav-link <?= ($activePage==='inventory'?'active':'') ?>" href="inventory_view.php"><i class="fas fa-boxes-stacked me-2"></i>Stocks View</a></li>
</ul>
</div>
</nav>
