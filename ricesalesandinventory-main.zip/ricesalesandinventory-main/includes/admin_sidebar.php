<?php
$activePage = (string)($activePage ?? '');
if ($activePage === '') {
  $currentPage = basename((string)($_SERVER['SCRIPT_NAME'] ?? ''));
  $activePage = match ($currentPage) {
    'dashboard.php' => 'dashboard',
    'sales.php' => 'sales',
    'products.php' => 'products',
    'inventory_monitoring.php' => 'stock_monitoring',
    'add_stock.php' => 'add_stock',
    'adjust_stock.php' => 'adjust_stock',
    'stock_condition.php' => 'stock_condition',
    'inventory.php' => 'inventory',
    'inventory_report.php' => 'inventory_report',
    'suppliers.php', 'purchase_orders.php' => 'suppliers',
    'penalties.php' => 'penalty',
    'analytics.php' => 'analytics',
    'users.php', 'add_user.php' => 'users',
    'system_logs.php' => 'logs',
    'profile.php' => 'profile',
    default => '',
  };
}
$adminBase = (string)($adminBase ?? '');
$inventoryBase = (string)($inventoryBase ?? $adminBase);
$ownerBase = (string)($ownerBase ?? '../owner/');
$inventoryPages = ['products','stock_monitoring','stock_in','stock_adjust','add_stock','adjust_stock','stock_condition','inv_logs','inventory'];
$reportPages = ['sales','inventory_report','analytics'];
?>
<nav id="sidebarMenu" class="col-lg-2 d-lg-block sidebar collapse">
  <div class="pt-4">
    <ul class="nav flex-column gap-1">

      <li class="nav-item">
        <a class="nav-link <?= ($activePage==='dashboard'?'active':'') ?>" href="<?= htmlspecialchars($adminBase . 'dashboard.php', ENT_QUOTES, 'UTF-8') ?>">
          <i class="fas fa-home me-2"></i>Dashboard
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link <?= in_array($activePage,$inventoryPages,true)?'active':'' ?>"
           data-bs-toggle="collapse" href="#inventoryMenu">
          <i class="fas fa-warehouse me-2"></i>Stock Monitoring
          <i class="fas fa-chevron-down float-end"></i>
        </a>

        <div class="collapse submenu <?= in_array($activePage,$inventoryPages,true)?'show':'' ?>" id="inventoryMenu">
          <a class="<?= ($activePage === 'products' ? 'fw-bold' : '') ?>" href="<?= htmlspecialchars($adminBase . 'products.php', ENT_QUOTES, 'UTF-8') ?>">Products</a>
          <a class="<?= ($activePage === 'stock_monitoring' ? 'fw-bold' : '') ?>" href="<?= htmlspecialchars($ownerBase . 'inventory_monitoring.php', ENT_QUOTES, 'UTF-8') ?>">Stock Levels</a>
          <a class="<?= ($activePage === 'add_stock' ? 'fw-bold' : '') ?>" href="<?= htmlspecialchars($inventoryBase . 'add_stock.php', ENT_QUOTES, 'UTF-8') ?>">Stock In (Receiving)</a>
          <a class="<?= ($activePage === 'inventory' ? 'fw-bold' : '') ?>" href="<?= htmlspecialchars($inventoryBase . 'inventory.php', ENT_QUOTES, 'UTF-8') ?>">Stock Logs</a>
        </div>
      </li>

      <li class="nav-item">
        <a class="nav-link <?= ($activePage==='suppliers'?'active':'') ?>" href="<?= htmlspecialchars($adminBase . 'suppliers.php', ENT_QUOTES, 'UTF-8') ?>">
          <i class="fas fa-truck-loading me-2"></i>Suppliers & P.O.
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link <?= ($activePage==='penalty'?'active':'') ?>" href="<?= htmlspecialchars($adminBase . 'penalties.php', ENT_QUOTES, 'UTF-8') ?>">
          <i class="fa-solid fa-money-bill-1-wave"></i> Penalty Management
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link <?= ($activePage==='users'?'active':'') ?>" href="<?= htmlspecialchars($adminBase . 'users.php', ENT_QUOTES, 'UTF-8') ?>">
          <i class="fas fa-users me-2"></i>User Management
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link <?= in_array($activePage, $reportPages, true) ? 'active' : '' ?>"
           data-bs-toggle="collapse" href="#reportsMenu">
          <i class="fas fa-chart-column me-2"></i>Reports
          <i class="fas fa-chevron-down float-end"></i>
        </a>

        <div class="collapse submenu <?= in_array($activePage, $reportPages, true) ? 'show' : '' ?>" id="reportsMenu">
          <a class="<?= ($activePage === 'sales' ? 'fw-bold' : '') ?>" href="<?= htmlspecialchars($adminBase . 'sales.php', ENT_QUOTES, 'UTF-8') ?>">Sales Report</a>
          <a class="<?= ($activePage === 'inventory_report' ? 'fw-bold' : '') ?>" href="<?= htmlspecialchars($inventoryBase . 'inventory_report.php', ENT_QUOTES, 'UTF-8') ?>">Inventory Reports</a>
          <a class="<?= ($activePage === 'analytics' ? 'fw-bold' : '') ?>" href="<?= htmlspecialchars($adminBase . 'analytics.php', ENT_QUOTES, 'UTF-8') ?>">Analytics &amp; Forecasting</a>
        </div>
      </li>

      <li class="nav-item">
        <a class="nav-link <?= ($activePage==='logs'?'active':'') ?>" href="<?= htmlspecialchars($adminBase . 'system_logs.php', ENT_QUOTES, 'UTF-8') ?>">
          <i class="fas fa-archive me-2"></i>System Logs
        </a>
      </li>

     
    </ul>
  </div>
</nav>
