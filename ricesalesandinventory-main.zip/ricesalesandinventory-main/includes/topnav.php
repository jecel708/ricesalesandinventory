<?php
$role = strtolower($_SESSION['role'] ?? '');
$roleLabel = ucfirst($role !== '' ? $role : 'User');
$displayName = trim((string)($username ?? $_SESSION['username'] ?? ''));

// Profiles store the person's display name in first_name and last_name.
// Resolve it from the current account so changes appear in the navbar immediately.
if (!empty($_SESSION['user_id']) && isset($conn) && $conn instanceof mysqli) {
    $nameStmt = $conn->prepare('SELECT display_name, first_name, last_name FROM users WHERE user_id = ? LIMIT 1');
    if ($nameStmt) {
        $navUserId = (int)$_SESSION['user_id'];
        $nameStmt->bind_param('i', $navUserId);
        if ($nameStmt->execute()) {
            $navUser = $nameStmt->get_result()->fetch_assoc();
            if ($navUser) {
                $savedName = trim((string)($navUser['display_name'] ?? ''));
                if ($savedName === '') {
                    $savedName = trim((string)($navUser['first_name'] ?? '') . ' ' . (string)($navUser['last_name'] ?? ''));
                }
                if ($savedName !== '') {
                    $displayName = $savedName;
                }
            }
        }
        $nameStmt->close();
    }
}

if ($displayName === '') {
    $displayName = $roleLabel;
}

if ($role === 'admin') {
    $profileLink = '../admin/profile.php';
    $backupLink = '../admin/backup.php';       // ✅ Admin: Backup
    $restoreLink = '../admin/restore.php';     // ✅ Admin: Restore
} elseif ($role === 'cashier') {
    $profileLink = '../cashier/cashier_profile.php';
    $backupLink = '';                           // ❌ Cashier: NO ACCESS
    $restoreLink = '';                          // ❌ Cashier: NO ACCESS
} elseif ($role === 'owner') {
    $profileLink = '../owner/profile.php';
    $backupLink = '../owner/backup.php';       // ✅ Owner: ONLY Backup
    $restoreLink = '';                          // ❌ Owner: RESTORE HIDDEN
} else {
    $profileLink = '#';
    $backupLink = '';
    $restoreLink = '';
}
?>
<?php if ($role === 'cashier'): ?>
<script>
  window.CASHIER_IDLE_TIMEOUT_MINUTES = 10;
  window.CASHIER_IDLE_WARNING_SECONDS = 15;
</script>
<script src="../js/cashier-idle-timeout.js?v=2" defer></script>
<?php endif; ?>
<link rel="stylesheet" href="../css/responsive.css?v=1">
<script src="../js/process-loading.js?v=2" defer></script>
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm fixed-top">
  <div class="container-fluid">

    <button class="btn btn-outline-dark d-lg-none"
            data-bs-toggle="collapse"
            data-bs-target="#sidebarMenu">
      ☰
    </button>

    <a class="navbar-brand fw-bold ms-2 text-decoration-none" href="dashboard.php">
      DE ORO HIYS GENERAL MERCHANDISE
    </a>

    <div class="ms-auto d-flex align-items-center gap-2">
      <div class="dropdown">
        <button class="btn btn-outline-secondary position-relative" type="button" id="notifToggle" data-bs-toggle="dropdown" aria-expanded="false">
          <i class="fas fa-bell"></i>
          <span id="notifCountBadge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none" style="font-size:0.70rem; min-width:1.2rem; height:1.2rem; line-height:1.2rem;">0</span>
        </button>
        <div class="dropdown-menu dropdown-menu-end p-0" aria-labelledby="notifToggle" style="min-width:320px; max-width:360px;">
          <div class="d-flex align-items-center justify-content-between px-3 py-2 border-bottom">
            <span class="fw-semibold">Notifications</span>
            <button type="button" class="btn btn-sm btn-link text-decoration-none" id="notifMarkAllReadBtn">Mark all read</button>
          </div>
          <div id="notifList" class="list-group list-group-flush" style="max-height:320px; overflow-y:auto;">
            <div id="notifEmpty" class="list-group-item text-center text-muted small py-3">Loading notifications...</div>
          </div>
          <div class="text-center py-2 border-top">
            <button type="button" class="btn btn-sm btn-outline-secondary" id="notifRefreshBtn">Refresh</button>
          </div>
        </div>
      </div>

      <div class="dropdown">
        <a class="nav-link dropdown-toggle d-flex align-items-center gap-2"
           data-bs-toggle="dropdown"
           href="#">
          <i class="fas fa-user-circle"></i>
          <?= htmlspecialchars($roleLabel . ' (' . $displayName . ')', ENT_QUOTES, 'UTF-8') ?>
        </a>

        <ul class="dropdown-menu dropdown-menu-end">

          <li>
            <span class="dropdown-item-text text-muted">
              <?= htmlspecialchars(ucfirst($_SESSION['role'] ?? 'User')) ?>
            </span>
          </li>

          <li><hr class="dropdown-divider"></li>

          <li>
            <a class="dropdown-item" href="<?= htmlspecialchars($profileLink) ?>">
              <i class="fas fa-user me-2"></i> Profile
            </a>
          </li>

          <?php if (!empty($backupLink)): ?>
          <li>
            <a class="dropdown-item" href="<?= htmlspecialchars($backupLink) ?>">
              <i class="fas fa-download me-2"></i> Create Backup
            </a>
          </li>
          <?php endif; ?>

          <?php if (!empty($restoreLink)): ?>
          <li>
            <a class="dropdown-item text-danger" href="<?= htmlspecialchars($restoreLink) ?>">
              <i class="fas fa-undo me-2"></i> Restore Data
            </a>
          </li>
          <?php endif; ?>

          <li><hr class="dropdown-divider"></li>

          <li>
            <a class="dropdown-item text-danger"
               href="<?= htmlspecialchars($logoutLink ?? '../logout.php') ?>"
               onclick="return confirm('Are you sure you want to logout?')">
              <i class="fas fa-sign-out-alt me-2"></i> Logout
            </a>
          </li>

        </ul>
      </div>
    </div>

  </div>
</nav>

<!-- ⬇️ YOUR SCRIPT REMAINS THE SAME ⬇️ -->
<div id="notifToastContainer" class="toast-container position-fixed top-0 end-0 p-3" style="z-index:10850;"></div>

<script>
(function(){
  const notifCountBadge = document.getElementById('notifCountBadge');
  const notifList = document.getElementById('notifList');
  const notifEmpty = document.getElementById('notifEmpty');
  const notifRefreshBtn = document.getElementById('notifRefreshBtn');
  const notifMarkAllReadBtn = document.getElementById('notifMarkAllReadBtn');
  const notifToggle = document.getElementById('notifToggle');
  const notifToastContainer = document.getElementById('notifToastContainer');
  const apiUrl = '../includes/notifications_api.php';
  let isLoading = false;
  let listLoaded = false;
  let lastUnreadCount = null;

  function setUnreadCount(count){
    if(!notifCountBadge) return;
    if(count > 0){
      notifCountBadge.textContent = String(count);
      notifCountBadge.classList.remove('d-none');
    } else {
      notifCountBadge.classList.add('d-none');
    }
  }

  async function fetchState(){
    if(isLoading) return;
    isLoading = true;
    try {
      const resp = await fetch(`${apiUrl}?action=state`, { credentials: 'same-origin' });
      const data = await resp.json();
      if(data && data.ok){
        const unread = Number(data.unread_count || 0);
        if(lastUnreadCount !== null && unread > lastUnreadCount){
          showToast('New notification', `${unread - lastUnreadCount} new item(s) received.`);
        }
        lastUnreadCount = unread;
        setUnreadCount(unread);
      }
    } catch (error) {
      console.error('Notification state error', error);
    } finally {
      isLoading = false;
    }
  }

  function renderNotifications(items){
    if(!notifList) return;
    notifList.innerHTML = '';
    if(!Array.isArray(items) || items.length === 0){
      notifList.innerHTML = '<div id="notifEmpty" class="list-group-item text-center text-muted small py-3">No notifications.</div>';
      return;
    }
    items.forEach((item) => {
      const elem = document.createElement('button');
      elem.type = 'button';
      elem.className = 'list-group-item list-group-item-action';
      elem.innerHTML = `
        <div class="fw-semibold">${item.customer || 'Notification'}</div>
        <div class="small text-muted">${item.message}</div>
        <div class="small text-muted mt-1">${item.sent_at}</div>
      `;
      elem.onclick = () => {};
      notifList.appendChild(elem);
    });
  }

  async function fetchList(){
    if(!notifList) return;
    notifList.innerHTML = '<div class="list-group-item text-center text-muted small py-3">Loading...</div>';
    try {
      const resp = await fetch(`${apiUrl}?action=list&limit=10`, { credentials: 'same-origin' });
      const data = await resp.json();
      if(data && data.ok){
        renderNotifications(data.notifications || []);
        setUnreadCount(Number(data.unread_count || 0));
        listLoaded = true;
      } else {
        notifList.innerHTML = `<div class="list-group-item text-center text-danger small py-3">${data.message || 'Unable to load notifications'}</div>`;
      }
    } catch (error) {
      notifList.innerHTML = '<div class="list-group-item text-center text-danger small py-3">Failed to load notifications.</div>';
      console.error('Notification list error', error);
    }
  }

  function showToast(title, body){
    if(!notifToastContainer) return;
    const toastId = `notifToast-${Date.now()}`;
    const toast = document.createElement('div');
    toast.className = 'toast align-items-center text-bg-primary border-0';
    toast.id = toastId;
    toast.role = 'alert';
    toast.ariaLive = 'assertive';
    toast.ariaAtomic = 'true';
    toast.style.minWidth = '280px';
    toast.innerHTML = `
      <div class="d-flex">
        <div class="toast-body">
          <strong>${title}</strong><br>${body}
        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
    `;
    notifToastContainer.appendChild(toast);
    const bsToast = new bootstrap.Toast(toast, { delay: 5000 });
    bsToast.show();
    toast.addEventListener('hidden.bs.toast', () => toast.remove());
  }

  async function markAllRead(){
    if(!notifList) return;
    try {
      const resp = await fetch(`${apiUrl}?action=mark_all_read`, { method: 'POST', credentials: 'same-origin' });
      const data = await resp.json();
      if(data && data.ok){
        setUnreadCount(0);
        if(listLoaded){
          const nodes = notifList.querySelectorAll('.list-group-item');
          nodes.forEach((node) => node.classList.remove('active'));
        }
      }
    } catch (error) {
      console.error('Notification mark-all-read error', error);
    }
  }

  notifToggle?.addEventListener('click', () => {
    if(!listLoaded){
      fetchList();
    }
  });

  notifRefreshBtn?.addEventListener('click', (event) => {
    event.preventDefault();
    fetchList();
  });

  notifMarkAllReadBtn?.addEventListener('click', (event) => {
    event.preventDefault();
    markAllRead();
  });

  fetchState();
  window.setInterval(fetchState, 15000);
})();
</script>
