<?php
declare(strict_types=1);

function mfa_issue_otp(mysqli $conn, int $userId): ?string {
    $otp = (string)random_int(100000, 999999);

    $otpHash = password_hash($otp, PASSWORD_DEFAULT);
    if ($otpHash === false) {
        return null;
    }

    $clear = $conn->prepare(
        'UPDATE user_email_otp_challenges
         SET used_at = NOW()
         WHERE user_id = ? AND used_at IS NULL'
    );

    if ($clear) {
        $clear->bind_param('i', $userId);
        $clear->execute();
        $clear->close();
    }

    $stmt = $conn->prepare(
        'INSERT INTO user_email_otp_challenges
        (user_id, otp_hash, expires_at, attempts, max_attempts)
        VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 5 MINUTE), 0, 5)'
    );

    if (!$stmt) {
        return null;
    }

    $stmt->bind_param('is', $userId, $otpHash);
    $ok = $stmt->execute();
    $stmt->close();

    return $ok ? $otp : null;
}

function mfa_send_otp_for_user(mysqli $conn, int $userId, string $email): bool {
    require_once __DIR__ . '/mailer.php';

    $otp = mfa_issue_otp($conn, $userId);

    if ($otp === null) {
        return false;
    }

    return send_otp_email($email, $otp);
}

function mfa_redirect_by_role(string $role): void {
    $role = strtolower(trim($role));

    if ($role === 'admin') {
        header('Location: admin/dashboard.php');
        exit;
    }

    if ($role === 'cashier') {
        header('Location: cashier/dashboard.php');
        exit;
    }

    if ($role === 'owner') {
        header('Location: owner/dashboard.php');
        exit;
    }

    header('Location: logout.php');
    exit;
}