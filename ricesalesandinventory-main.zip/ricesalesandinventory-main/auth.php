<?php
declare(strict_types=1);

ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');

$secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

session_set_cookie_params([
  'lifetime' => 0,
  'path'     => '/',
  'secure'   => $secure,
  'httponly' => true,
  'samesite' => 'Lax',
]);

session_start();
require_once 'config/db.php';
require_once 'includes/mfa.php';


function redirect_login(string $msg, string $type='error'): void {
  $_SESSION['flash_'.$type] = $msg;
  header('Location: login.php');
  exit;
}

function refresh_captcha(): void {
  $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  $captcha = '';
  $maxIndex = strlen($alphabet) - 1;

  for ($index = 0; $index < 6; $index++) {
    $captcha .= $alphabet[random_int(0, $maxIndex)];
  }

  $_SESSION['captcha_code'] = $captcha;
  $_SESSION['captcha_generated_at'] = time();
}

function complete_login(mysqli $conn, array $user): void {
  session_regenerate_id(true);

  $_SESSION['user_id'] = (int)$user['user_id'];
  $_SESSION['username'] = (string)$user['username'];
  $_SESSION['role'] = (string)$user['role'];
  $_SESSION['mfa_verified'] = true;

  unset(
    $_SESSION['mfa_pending'],
    $_SESSION['preauth_user_id'],
    $_SESSION['preauth_role'],
    $_SESSION['preauth_username']
  );


  $device = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown Device';
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown IP';
  $logStmt = $conn->prepare('INSERT INTO login_logs (user_id, login_time, device_info, ip_address) VALUES (?, NOW(), ?, ?)');
  if ($logStmt) {
    $uid = (int)$user['user_id'];
    $logStmt->bind_param('iss', $uid, $device, $ip);
    $logStmt->execute();
    $logStmt->close();
  }

  mfa_redirect_by_role((string)$user['role']);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: login.php');
  exit;
}

$csrf_post = (string)($_POST['csrf_token'] ?? '');
$csrf_sess = (string)($_SESSION['csrf_token'] ?? '');
if ($csrf_post === '' || $csrf_sess === '' || !hash_equals($csrf_sess, $csrf_post)) {
  redirect_login('Invalid request. Please refresh and try again.');
}

$username = trim((string)($_POST['username'] ?? ''));
$password = (string)($_POST['password'] ?? '');
$captchaInput = strtoupper(trim((string)($_POST['captcha'] ?? '')));

if ($username === '' || $password === '') {
  redirect_login('Please enter username and password.');
}

$captchaSession = strtoupper((string)($_SESSION['captcha_code'] ?? ''));
$captchaIssuedAt = (int)($_SESSION['captcha_generated_at'] ?? 0);

if ($captchaInput === '' || $captchaSession === '') {
  refresh_captcha();
  redirect_login('Please enter the captcha code.');
}

if ((time() - $captchaIssuedAt) > 300) {
  refresh_captcha();
  redirect_login('Captcha expired. Please try again.');
}

if (!hash_equals($captchaSession, $captchaInput)) {
  refresh_captcha();
  redirect_login('Incorrect captcha. Please try again.');
}

refresh_captcha();

$now = time();
$_SESSION['login_fail_count'] = (int)($_SESSION['login_fail_count'] ?? 0);
$_SESSION['login_lock_until'] = (int)($_SESSION['login_lock_until'] ?? 0);

if ($now < $_SESSION['login_lock_until']) {
  $remain = $_SESSION['login_lock_until'] - $now;
  redirect_login("Too many attempts. Try again in {$remain} seconds.");
}

$stmt = $conn->prepare('SELECT user_id, username, password, role, status, email FROM users WHERE username=? LIMIT 1');
if (!$stmt) {
  redirect_login('Server error. Please apply the MFA SQL migration and try again.');
}
$stmt->bind_param('s', $username);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
  $_SESSION['login_fail_count']++;
  if ($_SESSION['login_fail_count'] >= 5) {
    $_SESSION['login_lock_until'] = $now + 60;
    $_SESSION['login_fail_count'] = 0;
  }
  redirect_login('Invalid username or password.');
}

if (isset($user['status']) && strtolower((string)$user['status']) !== 'active') {
  redirect_login('Account is not active. Please contact admin.');
}

$stored = (string)($user['password'] ?? '');
$isValid = password_verify($password, $stored);

if (!$isValid && $stored !== '' && hash_equals($stored, $password)) {
  $isValid = true;
  $newHash = password_hash($password, PASSWORD_DEFAULT);
  $u = $conn->prepare('UPDATE users SET password=? WHERE user_id=?');
  if ($u) {
    $uid = (int)$user['user_id'];
    $u->bind_param('si', $newHash, $uid);
    $u->execute();
    $u->close();
  }
}

if (!$isValid) {
  $_SESSION['login_fail_count']++;
  if ($_SESSION['login_fail_count'] >= 5) {
    $_SESSION['login_lock_until'] = $now + 60;
    $_SESSION['login_fail_count'] = 0;
  }
  redirect_login('Invalid username or password.');
}

$_SESSION['login_fail_count'] = 0;
$_SESSION['login_lock_until'] = 0;

$userId = (int)$user['user_id'];
$email = trim((string)($user['email'] ?? ''));

if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
  redirect_login('No valid email is set for this account. Please contact admin.');
}

if (!mfa_send_otp_for_user($conn, $userId, $email)) {
  redirect_login('Unable to send OTP email right now. Please try again.');
}

session_regenerate_id(true);
$_SESSION['preauth_user_id'] = $userId;
$_SESSION['preauth_username'] = (string)$user['username'];
$_SESSION['preauth_role'] = (string)$user['role'];
$_SESSION['mfa_pending'] = true;
$_SESSION['mfa_last_sent_at'] = time();

header('Location: verify_otp.php');
exit;
