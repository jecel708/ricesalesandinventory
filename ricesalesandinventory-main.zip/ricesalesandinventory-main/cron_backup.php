<?php
// RUNS AUTOMATICALLY via Windows Task Scheduler
$db_host = 'localhost';
$db_name = 'rice_inventory';
$db_user = 'root';
$db_pass = '';

$backupDir = __DIR__ . '/backups/';
if (!is_dir($backupDir)) mkdir($backupDir, 0755, true);

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    
    $sql = "-- Auto Backup\n-- Generated: " . date('Y-m-d H:i:s') . "\n-- Database: $db_name\n\n";
    foreach ($tables as $table) {
        $sql .= "DROP TABLE IF EXISTS `$table`;\n";
        $row = $pdo->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_ASSOC);
        $sql .= $row['Create Table'] . ";\n\n";
        
        $rows = $pdo->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
        if ($rows) {
            $cols = array_keys($rows[0]);
            $sql .= "INSERT INTO `$table` (`" . implode("`, `", $cols) . "`) VALUES\n";
            $vals = [];
            foreach ($rows as $r) {
                $esc = [];
                foreach ($r as $val) {
                    $esc[] = $val === null ? 'NULL' : "'" . addslashes($val) . "'";
                }
                $vals[] = "(" . implode(", ", $esc) . ")";
            }
            $sql .= implode(",\n", $vals) . ";\n";
        }
        $sql .= "\n";
    }

    $filename = $backupDir . $db_name . '_auto_' . date('Y-m-d_His') . '.sql';
    file_put_contents($filename, $sql);
    echo "✅ Backup created: $filename\n";

} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}