<?php
declare(strict_types=1);

$purchaseOrdersMode = 'approved';
require __DIR__ . '/purchase_orders.php';
