<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit;
}
if(strtolower($_SESSION['role'] ?? '') !== 'owner'){
    header("Location: ../login.php");
    exit;
}

$username = $_SESSION['username'] ?? 'Owner';
include '../config/db.php';

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$VALID_SALE_STATUSES = "('paid','unpaid')";
$MONTHS_HISTORY = 12;
$FORECAST_MONTHS = 3;
$DEFAULT_LOW_STOCK_THRESHOLD = 10.0;

$settingsRow = null;
$settingsRes = $conn->query("SELECT low_threshold_kg FROM stock_settings WHERE id=1 LIMIT 1");
if ($settingsRes) {
    $settingsRow = $settingsRes->fetch_assoc();
}
$LOW_STOCK_THRESHOLD = (float)($settingsRow['low_threshold_kg'] ?? $DEFAULT_LOW_STOCK_THRESHOLD);

// Total products (not archived)
$totalProductsRow = $conn->query("SELECT COUNT(*) AS cnt FROM products WHERE archived=0");
$totalProducts = $totalProductsRow ? (int)$totalProductsRow->fetch_assoc()['cnt'] : 0;

// Current stock and inventory value based on current on-hand stock
$inventoryRows = [];
$inventoryRes = $conn->query("
    SELECT
        p.product_id,
        p.variety,
        p.grade,
        IFNULL(SUM(sb.remaining_qty_kg),0) AS stock_kg,
        IFNULL(MAX(NULLIF(p.price_per_kg, 0)),0) AS cost_per_kg
    FROM products p
    LEFT JOIN stock_batches sb ON sb.product_id = p.product_id
    WHERE p.archived = 0
    GROUP BY p.product_id
");
if ($inventoryRes) {
    while ($row = $inventoryRes->fetch_assoc()) {
        $row['stock_kg'] = (float)($row['stock_kg'] ?? 0);
        $row['cost_per_kg'] = (float)($row['cost_per_kg'] ?? 0);
        $inventoryRows[] = $row;
    }
}

$totalStock = array_sum(array_map(fn($r) => (float)$r['stock_kg'], $inventoryRows));
$inventoryValue = 0.0;
foreach ($inventoryRows as $row) {
    $inventoryValue += ((float)$row['stock_kg'] * (float)$row['cost_per_kg']);
}

// Sales today and this month
$salesTodayRow = $conn->query("
    SELECT IFNULL(SUM(total_amount),0) AS revenue
    FROM sales
    WHERE DATE(sale_date) = CURDATE()
      AND LOWER(status) IN $VALID_SALE_STATUSES
      AND sale_date <> '0000-00-00 00:00:00'
");
$dailySales = $salesTodayRow ? (float)$salesTodayRow->fetch_assoc()['revenue'] : 0.0;

$salesMonthRow = $conn->query("
    SELECT IFNULL(SUM(total_amount),0) AS revenue_month
    FROM sales
    WHERE YEAR(sale_date) = YEAR(CURDATE())
      AND MONTH(sale_date) = MONTH(CURDATE())
      AND LOWER(status) IN $VALID_SALE_STATUSES
      AND sale_date <> '0000-00-00 00:00:00'
");
$monthlySales = $salesMonthRow ? (float)$salesMonthRow->fetch_assoc()['revenue_month'] : 0.0;

// Pending returns count
$pendingReturnsRow = $conn->query("SELECT COUNT(*) AS cnt FROM returns WHERE LOWER(status)='pending'");
$pendingReturns = $pendingReturnsRow ? (int)$pendingReturnsRow->fetch_assoc()['cnt'] : 0;

$OVERSTOCK_LIMIT_KG = 1000;

$overCountRow = $conn->query("
  SELECT COUNT(*) AS cnt
  FROM (
    SELECT p.product_id,
      (
        IFNULL(SUM(CASE WHEN LOWER(it.type)='in' THEN it.qty_kg ELSE 0 END),0)
        - IFNULL(SUM(CASE WHEN LOWER(it.type)='out' THEN it.qty_kg ELSE 0 END),0)
        + IFNULL(SUM(CASE WHEN LOWER(it.type)='adjust' THEN it.qty_kg ELSE 0 END),0)
      ) AS stock_kg
    FROM products p
    LEFT JOIN inventory_transactions it ON it.product_id = p.product_id
    WHERE IFNULL(p.archived,0)=0
    GROUP BY p.product_id
  ) x
  WHERE stock_kg >= $OVERSTOCK_LIMIT_KG
");
$overCount = $overCountRow ? (int)$overCountRow->fetch_assoc()['cnt'] : 0;

$overstockList = $conn->query("
  SELECT p.product_id, p.variety, p.grade,
    (
      IFNULL(SUM(CASE WHEN LOWER(it.type)='in' THEN it.qty_kg ELSE 0 END),0)
      - IFNULL(SUM(CASE WHEN LOWER(it.type)='out' THEN it.qty_kg ELSE 0 END),0)
      + IFNULL(SUM(CASE WHEN LOWER(it.type)='adjust' THEN it.qty_kg ELSE 0 END),0)
    ) AS stock_kg
  FROM products p
  LEFT JOIN inventory_transactions it ON it.product_id = p.product_id
  WHERE IFNULL(p.archived,0)=0
  GROUP BY p.product_id
  HAVING stock_kg >= $OVERSTOCK_LIMIT_KG
  ORDER BY stock_kg DESC
  LIMIT 8
");

$arRow = $conn->query("
  SELECT
    IFNULL(SUM(total_amount),0) AS total_ar,
    IFNULL(SUM(balance),0) AS balance_ar
  FROM account_receivable
");
$ar = $arRow ? $arRow->fetch_assoc() : ['total_ar'=>0,'balance_ar'=>0];

$apEligibility = automationColumnExists($conn, 'account_payable', 'approved')
  ? 'COALESCE(approved,0)=1'
  : '1=1';
if (automationColumnExists($conn, 'account_payable', 'rejected')) {
  $apEligibility .= ' AND COALESCE(rejected,0)=0';
}

$apRow = $conn->query("
  SELECT
    IFNULL(SUM(CASE WHEN {$apEligibility} THEN total_amount ELSE 0 END),0) AS total_ap,
    IFNULL(SUM(CASE WHEN {$apEligibility} THEN balance ELSE 0 END),0) AS balance_ap
  FROM account_payable
");
$ap = $apRow ? $apRow->fetch_assoc() : ['total_ap'=>0,'balance_ap'=>0];

$lowStockItems = [];
$outOfStockItems = [];
foreach ($inventoryRows as $row) {
    if ($row['stock_kg'] <= 0) {
        $outOfStockItems[] = $row;
    } elseif ($row['stock_kg'] <= $LOW_STOCK_THRESHOLD) {
        $lowStockItems[] = $row;
    }
}

$bestSellingProducts = [];
$bestSellingRes = $conn->query("
    SELECT
        p.product_id,
        p.variety,
        p.grade,
        IFNULL(SUM(si.qty_kg),0) AS total_sold
    FROM sales_items si
    JOIN sales s ON si.sale_id = s.sale_id
    JOIN products p ON p.product_id = si.product_id
    WHERE p.archived = 0
      AND LOWER(s.status) IN $VALID_SALE_STATUSES
      AND s.sale_date <> '0000-00-00 00:00:00'
    GROUP BY p.product_id
    ORDER BY total_sold DESC
    LIMIT 5
");
if ($bestSellingRes) {
    while ($row = $bestSellingRes->fetch_assoc()) {
        $bestSellingProducts[] = $row;
    }
}

$recentTransactions = $conn->query("
    SELECT
        s.sale_id,
        s.sale_date,
        s.total_amount,
        u.username AS cashier_name
    FROM sales s
    LEFT JOIN users u ON u.user_id = s.user_id
    WHERE LOWER(s.status) = 'paid'
      AND s.sale_date <> '0000-00-00 00:00:00'
    ORDER BY s.sale_date DESC, s.sale_id DESC
    LIMIT 10
");

$topProductRow = $conn->query("
    SELECT p.variety, p.grade, IFNULL(SUM(si.qty_kg),0) AS total_sold
    FROM sales_items si
    JOIN sales s ON si.sale_id = s.sale_id
    JOIN products p ON si.product_id = p.product_id
    WHERE LOWER(s.status) IN $VALID_SALE_STATUSES
      AND IFNULL(p.archived,0)=0
      AND s.sale_date <> '0000-00-00 00:00:00'
    GROUP BY p.product_id
    ORDER BY total_sold DESC
    LIMIT 1
");
$topProduct = ($topProductRow && $topProductRow->num_rows) ? $topProductRow->fetch_assoc() : null;

$recentInventory = $conn->query("
    SELECT it.created_at, it.product_id, it.qty_kg, it.type, it.reference_type, it.reference_id, it.note,
           p.variety, p.grade
    FROM inventory_transactions it
    LEFT JOIN products p ON it.product_id = p.product_id
    ORDER BY it.created_at DESC
    LIMIT 8
");

$months = [];
$salesData = [];
$monthsY = [];
$monthsM = [];
$monthMap = [];

$monthly = $conn->query("
    SELECT
      DATE_FORMAT(s.sale_date,'%b %Y') AS month_label,
      YEAR(s.sale_date) AS y,
      MONTH(s.sale_date) AS m,
      COALESCE(SUM(si.qty_kg),0) AS total_kg
    FROM sales_items si
    JOIN sales s ON si.sale_id = s.sale_id
    WHERE LOWER(s.status) IN $VALID_SALE_STATUSES
      AND s.sale_date >= DATE_SUB(CURDATE(), INTERVAL {$MONTHS_HISTORY} MONTH)
      AND s.sale_date <> '0000-00-00 00:00:00'
    GROUP BY y,m,month_label
    ORDER BY y,m
");
if($monthly){
    while($r = $monthly->fetch_assoc()){
        $y = (int)$r['y'];
        $m = (int)$r['m'];
        $key = sprintf('%04d-%02d', $y, $m);
        $monthMap[$key] = (float)$r['total_kg'];
    }
}

// Build continuous month series (fill missing months with 0)
$start = new DateTime('first day of this month');
$start->modify('-' . max(0, $MONTHS_HISTORY - 1) . ' months');
$end = new DateTime('first day of this month');

for($dt = clone $start; $dt <= $end; $dt->modify('+1 month')){
    $y = (int)$dt->format('Y');
    $m = (int)$dt->format('m');
    $key = sprintf('%04d-%02d', $y, $m);

    $months[] = $dt->format('M Y');
    $monthsY[] = $y;
    $monthsM[] = $m;
    $salesData[] = (float)($monthMap[$key] ?? 0);
}
function nextMonthsLabelsFromLast(array $monthsY, array $monthsM, int $n = 3){
    $labels = [];

    if(empty($monthsY) || empty($monthsM)){
        $dt = new DateTime('first day of this month');
    } else {
        $lastY = (int)end($monthsY);
        $lastM = (int)end($monthsM);
        $dt = new DateTime(sprintf('%04d-%02d-01', $lastY, $lastM));
    }

    for($i=1;$i<=$n;$i++){
        $dt->modify('+1 month');
        $labels[] = $dt->format('M Y');
    }
    return $labels;
}

$forecastLabels = nextMonthsLabelsFromLast($monthsY, $monthsM, (int)$FORECAST_MONTHS);
$forecastValues = [];
$window = 3;

if(count($salesData) >= 3){
    $series = $salesData;
    for($i=0;$i<$FORECAST_MONTHS;$i++){
        $slice = array_slice($series, -$window);
        $avg = array_sum($slice) / max(1,count($slice));
        $forecastValues[] = round($avg, 2);
        $series[] = $avg;
    }
} elseif(count($salesData) > 0){
    $baseline = (float)end($salesData);
    $forecastValues = array_fill(0, $FORECAST_MONTHS, round($baseline,2));
} else {
    $forecastValues = array_fill(0, $FORECAST_MONTHS, 0);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Owner Dashboard | De ORO HIYS</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<link href="../css/layout.css" rel="stylesheet">

<link href="../css/owner-dashboard.css" rel="stylesheet">
<link href="../css/owner-mobile.css" rel="stylesheet">
</head>

<body>

<?php
$profileLink = 'profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>

<div class="container-fluid">
<div class="row">

<?php include '../includes/owner_sidebar.php'; ?>

<main class="col-lg-10 ms-sm-auto px-4 main-content">
<div class="py-4">

  <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
    <div>
      <h3 class="fw-bold mb-1">Owner Overview</h3>
      <div class="text-muted">Monitoring & decision dashboard</div>
    </div>
    <span class="badge rounded-pill bg-dark px-3 py-2">
      <i class="fa-solid fa-chart-simple me-1"></i> Overview
    </span>
  </div>

  <div class="row g-4 mt-1">
    <div class="col-12">
      <div class="row g-3 mb-3">
      <div class="col-12 col-md-6 col-xl-3">
        <div class="card modern-card card-kpi h-100">
          <div class="card-body">
            <div class="d-flex justify-content-between align-items-start gap-3">
              <div>
                <div class="kpi-label">Daily Sales</div>
                <div id="dailySalesValue" class="kpi-value">₱<?= number_format((float)$dailySales, 2) ?></div>
                <div class="kpi-sub">Current day total</div>
              </div>
              <span class="kpi-icon"><i class="fa-solid fa-cash-register"></i></span>
            </div>
          </div>
        </div>
      </div>
      <div class="col-12 col-md-6 col-xl-3">
        <div class="card modern-card card-kpi h-100">
          <div class="card-body">
            <div class="d-flex justify-content-between align-items-start gap-3">
              <div>
                <div class="kpi-label">Monthly Sales</div>
                <div id="monthlySalesValue" class="kpi-value">₱<?= number_format((float)$monthlySales, 2) ?></div>
                <div class="kpi-sub">Current month total</div>
              </div>
              <span class="kpi-icon"><i class="fa-solid fa-chart-column"></i></span>
            </div>
          </div>
        </div>
      </div>
      <div class="col-12 col-md-6 col-xl-3">
        <div class="card modern-card card-kpi h-100">
          <div class="card-body">
            <div class="d-flex justify-content-between align-items-start gap-3">
              <div>
                <div class="kpi-label">Total Products</div>
                <div id="totalProductsValue" class="kpi-value"><?= (int)$totalProducts ?></div>
                <div class="kpi-sub">Active inventory items</div>
              </div>
              <span class="kpi-icon"><i class="fa-solid fa-boxes-stacked"></i></span>
            </div>
          </div>
        </div>
      </div>
      <div class="col-12 col-md-6 col-xl-3">
        <div class="card modern-card card-kpi h-100">
          <div class="card-body">
            <div class="d-flex justify-content-between align-items-start gap-3">
              <div>
                <div class="kpi-label">Inventory Value</div>
                <div id="inventoryValue" class="kpi-value">₱<?= number_format((float)$inventoryValue, 2) ?></div>
                <div class="kpi-sub">Stock × cost price</div>
              </div>
              <span class="kpi-icon"><i class="fa-solid fa-coins"></i></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 col-lg-6">
    <div class="card modern-card h-100">
      <div class="card-body">
        <h5 class="fw-bold mb-3">Required Inventory Alerts</h5>
        <div class="row g-3">
          <div class="col-6">
            <div class="p-3 rounded bg-light h-100">
              <div class="text-muted small">Low Stock Alert</div>
              <div id="lowStockCount" class="h3 mb-0"><?= count($lowStockItems) ?></div>
              <div class="small text-muted">Threshold: <?= number_format((float)$LOW_STOCK_THRESHOLD, 2) ?> kg</div>
            </div>
          </div>
          <div class="col-6">
            <div class="p-3 rounded bg-light h-100">
              <div class="text-muted small">Out of Stock Items</div>
              <div id="outOfStockCount" class="h3 mb-0"><?= count($outOfStockItems) ?></div>
              <div class="small text-muted">Zero current stock</div>
            </div>
          </div>
          <div class="col-6">
            <div class="p-3 rounded bg-light h-100">
              <div class="text-muted small">Best Seller</div>
              <div class="h6 mb-0 text-truncate"><?= h((string)($topProduct['variety'] ?? 'N/A')) ?></div>
              <div class="small text-muted"><?= h((string)($topProduct['grade'] ?? '')) ?></div>
            </div>
          </div>
          <div class="col-6">
            <div class="p-3 rounded bg-light h-100">
              <div class="text-muted small">Inventory Value</div>
              <div class="h6 mb-0">₱<?= number_format((float)$inventoryValue, 2) ?></div>
              <div class="small text-muted">Stock × cost price</div>
            </div>
          </div>
        </div>
        <div class="mt-3">
          <div class="small text-muted mb-1">Low Stock Products</div>
          <div class="table-responsive">
            <table class="table table-sm mb-0">
              <thead class="table-light">
                <tr><th>Product</th><th class="text-end">Stock</th></tr>
              </thead>
              <tbody>
                <?php if (!empty($lowStockItems)): ?>
                  <?php foreach (array_slice($lowStockItems, 0, 5) as $item): ?>
                    <tr>
                      <td><?= h(trim($item['variety'] . ' - ' . $item['grade'])) ?></td>
                      <td class="text-end"><?= number_format((float)$item['stock_kg'], 2) ?> kg</td>
                    </tr>
                  <?php endforeach; ?>
                <?php else: ?>
                  <tr><td colspan="2" class="text-center text-muted">No low stock products.</td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
        <div class="mt-3">
          <div class="small text-muted mb-1">Out of Stock Products</div>
          <div class="table-responsive">
            <table class="table table-sm mb-0">
              <thead class="table-light">
                <tr><th>Product</th><th class="text-end">Stock</th></tr>
              </thead>
              <tbody>
                <?php if (!empty($outOfStockItems)): ?>
                  <?php foreach (array_slice($outOfStockItems, 0, 5) as $item): ?>
                    <tr>
                      <td><?= h(trim($item['variety'] . ' - ' . $item['grade'])) ?></td>
                      <td class="text-end">0.00 kg</td>
                    </tr>
                  <?php endforeach; ?>
                <?php else: ?>
                  <tr><td colspan="2" class="text-center text-muted">No out of stock products.</td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 col-lg-6">
    <div class="card modern-card h-100">
      <div class="card-body">
        <h5 class="fw-bold mb-3">Recent Transactions</h5>
        <div class="table-responsive">
          <table class="table table-sm align-middle mb-0">
            <thead class="table-dark">
              <tr>
                <th>Transaction #</th>
                <th>Date / Time</th>
                <th>Cashier</th>
                <th class="text-end">Total</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($recentTransactions && $recentTransactions->num_rows > 0): ?>
                <?php while ($tx = $recentTransactions->fetch_assoc()): ?>
                  <tr>
                    <td class="fw-semibold">#<?= (int)$tx['sale_id'] ?></td>
                    <td><?= h(date('M d, Y h:i A', strtotime((string)$tx['sale_date']))) ?></td>
                    <td><?= h((string)($tx['cashier_name'] ?? 'N/A')) ?></td>
                    <td class="text-end fw-semibold">₱<?= number_format((float)$tx['total_amount'], 2) ?></td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="4" class="text-center text-muted">No completed transactions found.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

  <!-- CHART ROW -->
  <div class="row g-4 mt-1">
    <div class="col-12 col-xl-7">
      <div class="card card-soft">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <h5 class="fw-bold mb-0">Sales Over Time (kg)</h5>
            <span class="text-muted small">Last <?= (int)$MONTHS_HISTORY ?> months</span>
          </div>

          <div class="chart-wrap">
            <canvas id="salesChart"></canvas>
          </div>

          <div class="mt-3 text-muted small">
            <i class="fa-solid fa-info-circle me-1"></i>
            Uses paid+unpaid sales only
          </div>
        </div>
      </div>
    </div>

    <div class="col-12 col-xl-5">
      <div class="card modern-card mb-4">
        <div class="card-body">
          <h5 class="fw-bold mb-2">Top Selling Product</h5>
          <?php if($topProduct): ?>
            <div class="d-flex align-items-center justify-content-between">
              <div>
                <div class="h4 mb-0"><span id="topProductVariety"><?= h($topProduct['variety']) ?></span>
                  <small class="text-muted">- <span id="topProductGrade"><?= h($topProduct['grade']) ?></span></small>
                </div>
                <div class="text-muted">Total Sold: <?= number_format((float)$topProduct['total_sold'],2) ?> kg</div>
              </div>
              <i class="fa-solid fa-trophy fa-2x text-warning"></i>
            </div>
          <?php else: ?>
            <div class="text-muted">No sales data yet.</div>
          <?php endif; ?>
        </div>
      </div>

      <div class="card card-soft">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <h5 class="fw-bold mb-0">Forecast (SMA)</h5>
            <span class="badge badge-soft">Next <?= (int)$FORECAST_MONTHS ?> months</span>
          </div>

          <div class="chart-wrap sm">
            <canvas id="forecastChart"></canvas>
          </div>

          <div class="mt-3 text-muted small">
            <i class="fa-solid fa-flask me-1"></i>
            Forecast uses Simple Moving Average
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- RECENT INVENTORY -->
  <div class="card modern-card mt-4">
    <div class="card-body">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
        <h5 class="fw-bold mb-0">Recent Inventory Movements</h5>
        <a class="btn btn-sm btn-outline-dark" href="inventory_monitoring.php">
          <i class="fa-solid fa-arrow-right me-1"></i> View Full Monitoring
        </a>
      </div>

      <div class="table-responsive">
        <table class="table table-striped align-middle mb-0">
          <thead class="table-dark">
            <tr>
              <th>Date</th>
              <th>Product</th>
              <th>Qty</th>
              <th>Type</th>
              <th>Reference</th>
              <th>Note</th>
            </tr>
          </thead>
          <tbody>
            <?php if($recentInventory && $recentInventory->num_rows > 0): ?>
              <?php while($row = $recentInventory->fetch_assoc()): ?>
                <?php
                  $dt = $row['created_at'] ? date("M d, Y h:i A", strtotime($row['created_at'])) : '';
                  $prod = trim(($row['variety'] ?? 'N/A') . " - " . ($row['grade'] ?? ''));
                  $t = strtolower(trim($row['type'] ?? ''));
                  $qtyNum = (float)($row['qty_kg'] ?? 0);

                  if($t === 'adjust'){
                      $sign = ($qtyNum >= 0) ? '+' : '-';
                      $qty = $sign . number_format(abs($qtyNum),2) . " kg";
                  } else {
                      $sign = ($t === 'in') ? '+' : (($t === 'out') ? '-' : '');
                      $qty = $sign . number_format(abs($qtyNum),2) . " kg";
                  }

                  $ref = strtoupper((string)($row['reference_type'] ?? ''));
                  $refId = $row['reference_id'] !== null ? ("#".$row['reference_id']) : '';
                  $note = $row['note'] ?? '';
                ?>
                <tr>
                  <td><?= h($dt) ?></td>
                  <td><?= h($prod) ?></td>
                  <td class="fw-bold"><?= h($qty) ?></td>
                  <td>
                    <?php if($t === 'in'): ?>
                      <span class="badge bg-success">IN</span>
                    <?php elseif($t === 'out'): ?>
                      <span class="badge bg-danger">OUT</span>
                    <?php else: ?>
                      <span class="badge bg-secondary"><?= h(strtoupper($t ?: 'N/A')) ?></span>
                    <?php endif; ?>
                  </td>
                  <td><?= h(trim($ref . " " . $refId)) ?></td>
                  <td><?= h($note) ?></td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="6" class="text-center text-muted">No inventory transactions yet.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

    </div>
            </div>

</div>
</main>

</div>
</div>

<script>
function fmtNum(v){
  const n = Number(v || 0);
  return n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function fmtKg(v){ return `${fmtNum(v)} kg`; }

Chart.defaults.font.family = "system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif";
Chart.defaults.color = '#ffffff';
Chart.defaults.borderColor = 'rgba(255, 255, 255, 0.16)';

// Palette aligned with owner/admin analytics charts
const colorPrimary = 'rgb(13, 110, 253)';
const colorPrimaryFill = 'rgba(13, 110, 253, 0.20)';
const colorWarning = 'rgb(245, 158, 11)';
const colorWarningFill = 'rgba(245, 158, 11, 0.78)';

const commonGrid = {
  color: 'rgba(255, 255, 255, 0.12)',
  drawBorder: false
};

const commonTicks = {
  color: '#ffffff',
  font: { size: 11, weight: '600' }
};

const commonPlugins = {
  legend: {
    labels: {
      usePointStyle: true,
      pointStyle: 'circle',
      boxWidth: 10,
      boxHeight: 10,
      padding: 16
    }
  },
  tooltip: {
    backgroundColor: 'rgba(15, 23, 42, 0.96)',
    titleColor: '#ffffff',
    bodyColor: '#e5e7eb',
    padding: 12,
    cornerRadius: 12,
    boxPadding: 6,
    titleFont: { size: 12, weight: '700' },
    bodyFont: { size: 12, weight: '600' }
  }
};

// ===== SALES CHART =====
(() => {
  const el = document.getElementById('salesChart');
  if(!el) return;

  new Chart(el, {
    type: 'line',
    data: {
      labels: <?= json_encode($months) ?>,
      datasets: [{
        label: 'Sales (kg)',
        data: <?= json_encode($salesData) ?>,
        tension: 0.35,
        fill: true,
        borderWidth: 3,
        pointRadius: 4,
        pointHoverRadius: 6,
        pointBorderWidth: 2,
        pointBackgroundColor: '#ffffff',
        borderColor: colorPrimary,
        backgroundColor: colorPrimaryFill
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        ...commonPlugins,
        tooltip: {
          ...commonPlugins.tooltip,
          mode: 'index',
          intersect: false,
          callbacks: { label: (ctx) => `${ctx.dataset.label}: ${fmtKg(ctx.parsed.y ?? 0)}` }
        },
      },
      interaction: { mode:'index', intersect:false },
      scales: {
        x: {
          grid: { display: false },
          ticks: commonTicks
        },
        y: {
          beginAtZero: true,
          grid: commonGrid,
          ticks: { ...commonTicks, callback: (v) => fmtKg(v) }
        }
      }
    }
  });
})();

// ===== FORECAST CHART (SMA) =====
(() => {
  const el = document.getElementById('forecastChart');
  if(!el) return;

  new Chart(el, {
    type: 'bar',
    data: {
      labels: <?= json_encode($forecastLabels) ?>,
      datasets: [{
        label: 'Forecast (kg)',
        data: <?= json_encode($forecastValues) ?>,
        borderWidth: 1,
        backgroundColor: colorWarningFill,
        borderColor: colorWarning,
        borderRadius: 10,
        borderSkipped: false
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        ...commonPlugins,
        tooltip: {
          ...commonPlugins.tooltip,
          callbacks: { label: (ctx) => `${ctx.dataset.label}: ${fmtKg(ctx.parsed.y ?? 0)}` }
        },
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: commonTicks
        },
        y: {
          beginAtZero: true,
          grid: commonGrid,
          ticks: { ...commonTicks, callback: (v) => fmtKg(v) }
        }
      }
    }
  });
})();
</script>

<script>
(function () {
  const pollIntervalMs = 10000;
  let pollingInFlight = false;

  function updateTextContent(id, value) {
    const el = document.getElementById(id);
    if (el && value !== null) {
      el.textContent = value;
    }
  }

  async function refreshOwnerMetrics() {
    if (pollingInFlight) return;
    pollingInFlight = true;
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('_live', Date.now().toString());
      const response = await fetch(url.toString(), {
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      });
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');

      const fields = [
        'dailySalesValue',
        'monthlySalesValue',
        'totalProductsValue',
        'inventoryValue',
        'lowStockCount',
        'outOfStockCount',
        'topProductVariety',
        'topProductGrade'
      ];

      fields.forEach((id) => {
        const source = doc.getElementById(id);
        const target = document.getElementById(id);
        if (source && target) {
          target.textContent = source.textContent;
        }
      });
    } catch (error) {
      console.error('Owner dashboard metric refresh failed:', error);
    } finally {
      pollingInFlight = false;
    }
  }

  window.setInterval(refreshOwnerMetrics, pollIntervalMs);
})();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Removed live polling to preserve rendered owner dashboard charts.
</script>
</body>
</html>
