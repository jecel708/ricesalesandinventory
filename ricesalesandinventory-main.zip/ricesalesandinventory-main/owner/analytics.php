<?php
session_start();
if(!isset($_SESSION['user_id'])){ header("Location: ../login.php"); exit; }
if(strtolower($_SESSION['role'] ?? '') !== 'owner'){ header("Location: ../login.php"); exit; }

$username = $_SESSION['username'] ?? 'Owner';
include '../config/db.php';

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$LEAD_TIME_DAYS = 2;
$SAFETY_STOCK_KG = 10;
$TARGET_DAYS_COVER= 7;
$RESTOCK_LOOKBACK_DAYS = 30;

$MONTHS_HISTORY = 60;
$FORECAST_MONTHS = 3;

$VALID_SALE_STATUSES = "('paid','unpaid')";

$salesPerProduct = [];
$sql = "
SELECT
  p.product_id,
  CONCAT(p.variety,' - ',p.grade) AS product_label,
  SUM(si.qty_kg) AS total_sold_kg,
  SUM(si.line_total) AS total_revenue
FROM sales_items si
JOIN sales s ON si.sale_id = s.sale_id
JOIN products p ON si.product_id = p.product_id
WHERE p.archived=0
  AND LOWER(s.status) IN $VALID_SALE_STATUSES
GROUP BY p.product_id
ORDER BY total_sold_kg DESC
";
$res = $conn->query($sql);
if($res){
  while($row = $res->fetch_assoc()){
    $row['total_sold_kg'] = (float)($row['total_sold_kg'] ?? 0);
    $row['total_revenue'] = (float)($row['total_revenue'] ?? 0);
    $salesPerProduct[] = $row;
  }
}

$months = [];
$salesKgData = [];
$salesRevData = [];

// used for correct forecast labels (base from last visible month)
$monthsY = [];
$monthsM = [];
$monthMapKg = [];
$monthMapRev = [];

$sql = "
SELECT
  DATE_FORMAT(s.sale_date,'%b %Y') AS month_label,
  YEAR(s.sale_date) AS y,
  MONTH(s.sale_date) AS m,
  COALESCE(SUM(si.qty_kg),0) AS total_kg,
  COALESCE(SUM(si.line_total),0) AS total_rev
FROM sales_items si
JOIN sales s ON si.sale_id = s.sale_id
WHERE LOWER(s.status) IN $VALID_SALE_STATUSES
  AND s.sale_date >= DATE_SUB(CURDATE(), INTERVAL {$MONTHS_HISTORY} MONTH)
  AND s.sale_date <> '0000-00-00 00:00:00'
GROUP BY y,m,month_label
ORDER BY y,m
";
$res = $conn->query($sql);
if($res){
  while($row = $res->fetch_assoc()){
    $y = (int)$row['y'];
    $m = (int)$row['m'];
    $key = sprintf('%04d-%02d', $y, $m);
    $monthMapKg[$key] = (float)$row['total_kg'];
    $monthMapRev[$key] = (float)$row['total_rev'];
  }
}

// Build continuous month series (fills missing months with 0)
$start = new DateTime('first day of this month');
$start->modify('-' . max(0, $MONTHS_HISTORY - 1) . ' months');
$end = new DateTime('first day of this month');

for($dt = clone $start; $dt <= $end; $dt->modify('+1 month')){
  $y = (int)$dt->format('Y');
  $m = (int)$dt->format('m');
  $key = sprintf('%04d-%02d', $y, $m);

  $months[] = $dt->format('M Y');
  $monthsY[] = $y;
  $monthsM[] = $m;
  $salesKgData[] = (float)($monthMapKg[$key] ?? 0);
  $salesRevData[] = (float)($monthMapRev[$key] ?? 0);
}

$topProduct = $salesPerProduct[0]['product_label'] ?? 'N/A';
$totalSoldKg = array_sum($salesKgData);
$totalRevenue = array_sum($salesRevData);

$avgSellPricePerKg = ($totalSoldKg > 0) ? ($totalRevenue / $totalSoldKg) : 0;

$totalMonths = count($salesKgData);
$growth = 0;
if($totalMonths >= 2 && (float)$salesKgData[$totalMonths-2] > 0){
  $growth = (($salesKgData[$totalMonths-1] - $salesKgData[$totalMonths-2]) / $salesKgData[$totalMonths-2]) * 100;
}

function nextMonthsLabelsFromLast(array $monthsY, array $monthsM, int $n = 3){
  $labels = [];

  if(empty($monthsY) || empty($monthsM)){
    $dt = new DateTime('first day of this month');
  } else {
    $lastY = (int)end($monthsY);
    $lastM = (int)end($monthsM);
    $dt = new DateTime(sprintf('%04d-%02d-01', $lastY, $lastM));
  }

  for($i=1; $i<=$n; $i++){
    $dt->modify('+1 month');
    $labels[] = $dt->format('M Y');
  }
  return $labels;
}

$forecastLabels = nextMonthsLabelsFromLast($monthsY, $monthsM, (int)$FORECAST_MONTHS);
$forecastData = [];

if(count($salesKgData) > 0){
  $series = $salesKgData;

  for($i=0; $i<$FORECAST_MONTHS; $i++){
    $win = min(3, count($series));                  // ✅ adaptive SMA window
    $slice = array_slice($series, -$win);
    $avg = array_sum($slice) / max(1, count($slice));
    $avg = round($avg, 2);

    $forecastData[] = $avg;
    $series[] = $avg;                               // rolling forecast
  }
} else {
  $forecastData = array_fill(0, (int)$FORECAST_MONTHS, 0.00);
}

$combinedLabels = array_merge($months, $forecastLabels);
$actualPadded = array_merge($salesKgData, array_fill(0, count($forecastLabels), null));
$forecastPadded = array_merge(array_fill(0, count($months), null), $forecastData);

$forecastTable = [];
for($i=0; $i<count($forecastLabels); $i++){
  $forecastTable[] = ['month'=>$forecastLabels[$i], 'pred'=>$forecastData[$i]];
}

$daysOrder = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
$daySalesMap = array_fill_keys($daysOrder, 0.0);

$sql = "
SELECT
  DAYOFWEEK(s.sale_date) AS dow,
  SUM(si.qty_kg) AS total_kg
FROM sales_items si
JOIN sales s ON si.sale_id = s.sale_id
WHERE LOWER(s.status) IN $VALID_SALE_STATUSES
  AND s.sale_date >= (CURDATE() - INTERVAL 90 DAY)
  AND s.sale_date <> '0000-00-00 00:00:00'
GROUP BY dow
";
$res = $conn->query($sql);
if($res){
  while($r = $res->fetch_assoc()){
    $dow = (int)$r['dow']; // 1=Sun ... 7=Sat
    $kg = (float)$r['total_kg'];

    $label = 'Sun';
    if($dow===2) $label='Mon';
    if($dow===3) $label='Tue';
    if($dow===4) $label='Wed';
    if($dow===5) $label='Thu';
    if($dow===6) $label='Fri';
    if($dow===7) $label='Sat';
    if($dow===1) $label='Sun';

    $daySalesMap[$label] = $kg;
  }
}
$daySalesLabels = array_keys($daySalesMap);
$daySalesData = array_values($daySalesMap);

$peakDay = 'N/A';
$peakKg = 0;
foreach($daySalesMap as $d=>$kg){
  if($kg > $peakKg){ $peakKg=$kg; $peakDay=$d; }
}

$restockRows = [];
$fastMovers = [];
$slowMovers = [];
$deadStock = [];

$sql = "
SELECT
  p.product_id,
  CONCAT(p.variety,' - ',p.grade) AS product_label,

  /* CURRENT STOCK */
  IFNULL(SUM(
    CASE
      WHEN LOWER(it.type)='in' THEN it.qty_kg
      WHEN LOWER(it.type)='out' THEN -it.qty_kg
      WHEN LOWER(it.type)='adjust' THEN it.qty_kg
      ELSE 0
    END
  ), 0) AS current_stock,

  /* SOLD LAST N DAYS */
  (
    SELECT IFNULL(SUM(si.qty_kg),0)
    FROM sales_items si
    JOIN sales s ON s.sale_id = si.sale_id
    WHERE si.product_id = p.product_id
      AND LOWER(s.status) IN $VALID_SALE_STATUSES
      AND s.sale_date >= (CURDATE() - INTERVAL {$RESTOCK_LOOKBACK_DAYS} DAY)
      AND s.sale_date <> '0000-00-00 00:00:00'
  ) AS sold_last_n

FROM products p
LEFT JOIN inventory_transactions it ON it.product_id = p.product_id
WHERE p.archived=0
GROUP BY p.product_id
ORDER BY sold_last_n DESC
";
$res = $conn->query($sql);
$allProdForRestock = [];
if($res){
  while($r = $res->fetch_assoc()){
    $r['current_stock'] = (float)($r['current_stock'] ?? 0);
    $r['sold_last_n'] = (float)($r['sold_last_n'] ?? 0);
    $allProdForRestock[] = $r;
  }
}

foreach($allProdForRestock as &$r){
  $current = (float)$r['current_stock'];
  $soldN = (float)$r['sold_last_n'];

  $avgDaily = $soldN / max(1, $RESTOCK_LOOKBACK_DAYS);
  $reorderPoint = ($avgDaily * $LEAD_TIME_DAYS) + $SAFETY_STOCK_KG;
  $targetStock = ($avgDaily * $TARGET_DAYS_COVER);

  $suggested = $targetStock - $current;
  if($suggested < 0) $suggested = 0;

  $status = 'OK';
  if($current <= 0) $status = 'OUT';
  else if($current <= $reorderPoint) $status = 'REORDER';

  $r['_avgDaily'] = $avgDaily;
  $r['_reorderPoint'] = $reorderPoint;
  $r['_suggested'] = $suggested;
  $r['_status'] = $status;
}
unset($r);

$restockCandidates = [];
foreach($allProdForRestock as $r){
  $avgDaily = (float)($r['_avgDaily'] ?? 0);
  $current = (float)$r['current_stock'];
  $daysCover = ($avgDaily > 0) ? ($current / $avgDaily) : 9999;

  if(($r['_status'] ?? 'OK') !== 'OK'){
    $r['_daysCover'] = $daysCover;
    $restockCandidates[] = $r;
  }
}

usort($restockCandidates, function($a,$b){
  $prio = ['OUT'=>0,'REORDER'=>1,'OK'=>2];
  $pa = $prio[$a['_status']] ?? 9;
  $pb = $prio[$b['_status']] ?? 9;
  if($pa !== $pb) return $pa <=> $pb;

  $da = (float)($a['_daysCover'] ?? 9999);
  $db = (float)($b['_daysCover'] ?? 9999);
  return $da <=> $db;
});

$restockRows = array_slice($restockCandidates, 0, 5);
$fastMovers = array_slice($allProdForRestock, 0, 5);

$slowMovers = $allProdForRestock;
usort($slowMovers, fn($a,$b)=> (float)$a['sold_last_n'] <=> (float)$b['sold_last_n']);
$slowMovers = array_slice($slowMovers, 0, 5);

/* KPI totals (match admin analytics) */
$restockAlertCount = count($restockCandidates);
$outOfStockCount = 0;
$slowMovingCount = 0;
$totalSoldLastN = 0.0;
foreach($allProdForRestock as $r){
  $totalSoldLastN += (float)($r['sold_last_n'] ?? 0);

  if(($r['_status'] ?? 'OK') === 'OUT'){
    $outOfStockCount++;
  }

  if((float)($r['sold_last_n'] ?? 0) <= 5){
    $slowMovingCount++;
  }

  if((float)($r['current_stock'] ?? 0) > 0 && (float)($r['sold_last_n'] ?? 0) <= 0){
    $deadStock[] = $r;
  }
}
$deadStock = array_slice($deadStock, 0, 5);

$fastTop = $fastMovers[0] ?? null;
$slowTop = $slowMovers[0] ?? null;
$maxFastSold = 0.0;
$maxSlowSold = 0.0;
foreach($fastMovers as $r){
  if((float)$r['sold_last_n'] > $maxFastSold) $maxFastSold = (float)$r['sold_last_n'];
}
foreach($slowMovers as $r){
  if((float)$r['sold_last_n'] > $maxSlowSold) $maxSlowSold = (float)$r['sold_last_n'];
}
$growthClass = ($growth >= 0) ? 'text-success' : 'text-danger';
$growthIcon = ($growth >= 0) ? 'fa-arrow-trend-up' : 'fa-arrow-trend-down';

$topProdLabels = [];
$topProdKg = [];
foreach(array_slice($salesPerProduct, 0, 10) as $r){
  $topProdLabels[] = (string)$r['product_label'];
  $topProdKg[] = (float)$r['total_sold_kg'];
}

$stockLabels = [];
$stockData = [];
$stockSorted = $allProdForRestock;
usort($stockSorted, fn($a,$b)=> (float)$b['current_stock'] <=> (float)$a['current_stock']);
foreach(array_slice($stockSorted, 0, 10) as $r){
  $stockLabels[] = (string)$r['product_label'];
  $stockData[] = (float)$r['current_stock'];
}

$analyticsTab = strtolower((string)($_GET['tab'] ?? 'overview'));
if (!in_array($analyticsTab, ['overview', 'tax-discount'], true)) {
  $analyticsTab = 'overview';
}

$activePage = 'analytics';

$taxMode = 'EXEMPT';
$taxRate = 0.12;
$taxSummaryResult = $conn->query("
  SELECT
    COUNT(*) AS sales_count,
    COALESCE(SUM(gross_total), 0) AS gross_total,
    COALESCE(SUM(net_total), 0) AS net_total,
    COALESCE(SUM(discount_amount), 0) AS discount_total,
    COALESCE(SUM(CASE WHEN discount_amount > 0 THEN 1 ELSE 0 END), 0) AS discounted_sales
  FROM (
    SELECT
      s.sale_id,
      SUM(si.line_total) AS gross_total,
      COALESCE(s.total_amount, 0) AS net_total,
      GREATEST(SUM(si.line_total) - COALESCE(s.total_amount, 0), 0) AS discount_amount
    FROM sales s
    LEFT JOIN sales_items si ON si.sale_id = s.sale_id
    WHERE (s.status IS NULL OR LOWER(s.status) <> 'cancelled')
      AND s.sale_date IS NOT NULL
      AND s.sale_date <> '0000-00-00 00:00:00'
    GROUP BY s.sale_id
  ) tx
");
$taxSummary = $taxSummaryResult ? $taxSummaryResult->fetch_assoc() : [
  'sales_count' => 0,
  'gross_total' => 0,
  'net_total' => 0,
  'discount_total' => 0,
  'discounted_sales' => 0,
];

$recentDiscountsResult = $conn->query("
  SELECT
    s.sale_id,
    s.sale_date,
    CONCAT(IFNULL(c.first_name, ''), ' ', IFNULL(c.last_name, '')) AS customer_name,
    SUM(si.line_total) AS gross_total,
    COALESCE(s.total_amount, 0) AS net_total,
    GREATEST(SUM(si.line_total) - COALESCE(s.total_amount, 0), 0) AS discount_amount
  FROM sales s
  LEFT JOIN customers c ON c.customer_id = s.customer_id
  LEFT JOIN sales_items si ON si.sale_id = s.sale_id
  WHERE (s.status IS NULL OR LOWER(s.status) <> 'cancelled')
    AND s.sale_date IS NOT NULL
    AND s.sale_date <> '0000-00-00 00:00:00'
  GROUP BY s.sale_id
  HAVING discount_amount > 0
  ORDER BY s.sale_date DESC, s.sale_id DESC
  LIMIT 10
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Analytics & Forecasting | DE ORO HIYS</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<link href="../css/layout.css" rel="stylesheet">

<link href="../css/admin-analytics.css" rel="stylesheet">
<link href="../css/owner-mobile.css" rel="stylesheet">
<link href="../css/report-print.css" rel="stylesheet">
</head>
<body>

<?php
$profileLink = 'profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>

<div class="container-fluid">
<div class="row">

<?php include '../includes/owner_sidebar.php'; ?>

<main class="col-lg-10 ms-sm-auto px-4 main-content">
<div class="py-4">

<div id="adminPageHeader" class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
  <div>
    <div class="section-subtitle mb-1">Owner Dashboard</div>
    <h3 class="fw-bold mb-1">Analytics & Forecasting</h3>
    <div class="text-muted">Simple view for sales trend, stock movement, and restock priorities</div>
  </div>
  <button class="btn btn-outline-dark" onclick="window.print()">
    <i class="fa-solid fa-print me-1"></i> Print Report
  </button>
</div>

<ul class="nav nav-pills mb-4">
  <li class="nav-item">
    <a class="nav-link <?= $analyticsTab === 'overview' ? 'active' : '' ?>" href="analytics.php?tab=overview">Overview</a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?= $analyticsTab === 'tax-discount' ? 'active' : '' ?>" href="analytics.php?tab=tax-discount">Tax & Discount</a>
  </li>
</ul>

<?php if ($analyticsTab === 'tax-discount'): ?>
<div class="row g-3 mb-4">
  <div class="col-12 col-md-6 col-xl-3">
    <div class="card modern-card card-kpi h-100">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center gap-3">
          <div>
            <div class="kpi-label">Gross Sales</div>
            <div class="kpi-value">₱<?= number_format((float)$taxSummary['gross_total'], 2) ?></div>
            <div class="kpi-sub">All non-cancelled sales</div>
          </div>
          <div class="kpi-icon"><i class="fa-solid fa-cart-shopping"></i></div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 col-md-6 col-xl-3">
    <div class="card modern-card card-kpi h-100">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center gap-3">
          <div>
            <div class="kpi-label">Discounts Given</div>
            <div class="kpi-value">₱<?= number_format((float)$taxSummary['discount_total'], 2) ?></div>
            <div class="kpi-sub"><?= (int)$taxSummary['discounted_sales'] ?> discounted sale(s)</div>
          </div>
          <div class="kpi-icon"><i class="fa-solid fa-tags"></i></div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 col-md-6 col-xl-3">
    <div class="card modern-card card-kpi h-100">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center gap-3">
          <div>
            <div class="kpi-label">Net Sales</div>
            <div class="kpi-value">₱<?= number_format((float)$taxSummary['net_total'], 2) ?></div>
            <div class="kpi-sub">After discounts</div>
          </div>
          <div class="kpi-icon"><i class="fa-solid fa-receipt"></i></div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 col-md-6 col-xl-3">
    <div class="card modern-card card-kpi h-100">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center gap-3">
          <div>
            <div class="kpi-label">VAT Status</div>
            <div class="kpi-value"><?= htmlspecialchars($taxMode) ?></div>
            <div class="kpi-sub">Rate <?= number_format($taxRate * 100, 0) ?>%, currently not posted</div>
          </div>
          <div class="kpi-icon"><i class="fa-solid fa-percent"></i></div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="card modern-card mb-4">
  <div class="card-body p-4">
    <div class="alert alert-info mb-0">
      VAT is currently set to <strong><?= htmlspecialchars($taxMode) ?></strong> in the receipt flow, so the system does not record VAT collection yet.
      Discount totals are derived from the difference between gross line totals and the final sale amount.
    </div>
  </div>
</div>

<div class="card modern-card">
  <div class="card-body p-0">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 p-3 border-bottom">
      <div>
        <h5 class="fw-bold mb-1">Recent Discounted Sales</h5>
        <div class="small-note">Latest 10 sales with a computed discount impact</div>
      </div>
    </div>
    <div class="table-responsive">
      <table class="table table-striped align-middle mb-0">
        <thead class="table-dark">
          <tr>
            <th>Sale ID</th>
            <th>Date</th>
            <th>Customer</th>
            <th class="text-end">Gross</th>
            <th class="text-end">Discount</th>
            <th class="text-end">Net</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($recentDiscountsResult && $recentDiscountsResult->num_rows > 0): ?>
            <?php while ($row = $recentDiscountsResult->fetch_assoc()): ?>
              <tr>
                <td class="fw-semibold">#<?= (int)$row['sale_id'] ?></td>
                <td><?= htmlspecialchars($row['sale_date'] ? date('M d, Y h:i A', strtotime((string)$row['sale_date'])) : '') ?></td>
                <td><?= htmlspecialchars(trim((string)$row['customer_name']) ?: 'Walk-in') ?></td>
                <td class="text-end">₱<?= number_format((float)$row['gross_total'], 2) ?></td>
                <td class="text-end text-danger fw-semibold">₱<?= number_format((float)$row['discount_amount'], 2) ?></td>
                <td class="text-end">₱<?= number_format((float)$row['net_total'], 2) ?></td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr>
              <td colspan="6" class="text-center text-muted py-4">No discounted sales found yet.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php else: ?>

<div class="row g-3 mb-4">
  <div class="col-12 col-md-4 col-xl-2">
    <div class="card modern-card card-kpi h-100">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center gap-3">
          <div>
            <div class="kpi-label">Sold (Last <?= (int)$RESTOCK_LOOKBACK_DAYS ?> days)</div>
            <div class="kpi-value"><?= number_format((float)$totalSoldLastN, 2) ?> <span>kg</span></div>
            <div class="kpi-sub">Movement window</div>
          </div>
          <div class="kpi-icon"><i class="fa-solid fa-boxes-stacked"></i></div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 col-md-4 col-xl-2">
    <div class="card modern-card card-kpi h-100">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center gap-3">
          <div>
            <div class="kpi-label">Restock Alerts</div>
            <div class="kpi-value"><?= (int)$restockAlertCount ?></div>
            <div class="kpi-sub">Needs attention</div>
          </div>
          <div class="kpi-icon"><i class="fa-solid fa-triangle-exclamation"></i></div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 col-md-4 col-xl-2">
    <div class="card modern-card card-kpi h-100">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center gap-3">
          <div>
            <div class="kpi-label">Out of Stock</div>
            <div class="kpi-value"><?= (int)$outOfStockCount ?></div>
            <div class="kpi-sub">Critical items</div>
          </div>
          <div class="kpi-icon"><i class="fa-solid fa-ban"></i></div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 col-md-4 col-xl-2">
    <div class="card modern-card card-kpi h-100">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center gap-3">
          <div>
            <div class="kpi-label">Slow Movers</div>
            <div class="kpi-value"><?= (int)$slowMovingCount ?></div>
            <div class="kpi-sub">Low movement</div>
          </div>
          <div class="kpi-icon"><i class="fa-solid fa-hourglass-half"></i></div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 col-md-4 col-xl-2">
    <div class="card modern-card card-kpi h-100">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center gap-3">
          <div>
            <div class="kpi-label">Next Month Forecast</div>
            <div class="kpi-value"><?= number_format((float)$forecastData[0], 2) ?> <span>kg</span></div>
            <div class="kpi-sub <?= $growthClass ?>">
              <i class="fa-solid <?= $growthIcon ?> me-1"></i>Monthly growth: <?= number_format((float)$growth, 1) ?>%
            </div>
          </div>
          <div class="kpi-icon"><i class="fa-solid fa-chart-line"></i></div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 col-md-4 col-xl-2">
    <div class="card modern-card card-kpi h-100">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-start gap-3">
          <div class="flex-grow-1 min-w-0">
            <div class="kpi-label">Top Product</div>
            <div class="kpi-title text-truncate"><?= h($topProduct) ?></div>
            <div class="kpi-sub">Best seller</div>
          </div>
          <div class="kpi-icon"><i class="fa-solid fa-crown"></i></div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="mb-2">
  <div class="section-title">Sales Insights</div>
  <div class="section-subtitle">Quick visual overview of product movement and demand</div>
</div>

<div class="analytics-row mb-4">
  <div class="analytics-box">
    <div class="box-head">
      <div>
        <h5 class="fw-bold mb-1">Monthly Sales Trend</h5>
        <div class="small-note">Monthly totals in kilograms</div>
      </div>
    </div>
    <div class="chartWrap"><canvas id="monthlyKgChart"></canvas></div>
  </div>

  <div class="analytics-box">
    <div class="box-head">
      <div>
        <h5 class="fw-bold mb-1">Sales Forecast</h5>
        <div class="small-note">Simple Moving Average based on recent monthly sales</div>
      </div>
    </div>
    <div class="chartWrap"><canvas id="salesChart"></canvas></div>
  </div>
</div>

<div class="analytics-row mb-4">
  <div class="analytics-box">
    <div class="box-head">
      <div>
        <h5 class="fw-bold mb-1">Top Products</h5>
        <div class="small-note">Top 10 by kilograms sold</div>
      </div>
    </div>
    <div class="chartWrap"><canvas id="topProductsChart"></canvas></div>
  </div>

  <div class="analytics-box">
    <div class="box-head">
      <div>
        <h5 class="fw-bold mb-1">Current Stock Levels</h5>
        <div class="small-note">Top 10 products by stock on hand</div>
      </div>
    </div>
    <div class="chartWrap"><canvas id="stockChart"></canvas></div>
  </div>
</div>

<div class="analytics-row mb-4">
  <div class="analytics-box">
    <div class="box-head">
      <div>
        <h5 class="fw-bold mb-1">Sales by Day of Week</h5>
        <div class="small-note">Last 90 days • Peak day: <b><?= h($peakDay) ?></b> (<?= number_format((float)$peakKg, 2) ?> kg)</div>
      </div>
    </div>
    <div class="chartWrap"><canvas id="dowChart"></canvas></div>
  </div>

  <div class="analytics-box">
    <div class="box-head">
      <div>
        <h5 class="fw-bold mb-1">Forecast (Next <?= (int)$FORECAST_MONTHS ?> Months)</h5>
        <div class="small-note">Predicted demand based on monthly sales pattern</div>
      </div>
    </div>

    <div class="table-responsive modern-table">
      <table class="table table-sm align-middle mb-0">
        <thead>
          <tr>
            <th>Month</th>
            <th class="text-end">Predicted Demand (kg)</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($forecastTable as $f): ?>
            <tr>
              <td class="fw-semibold"><?= h($f['month']) ?></td>
              <td class="text-end"><?= number_format((float)$f['pred'], 2) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="mb-2 mt-2">
  <div class="section-title">Inventory Actions</div>
  <div class="section-subtitle">Items that need restocking, review, or movement attention</div>
</div>

<div class="analytics-row mb-4">
  <div class="analytics-box">
    <div class="box-head">
      <div>
        <h5 class="fw-bold mb-1">Suggested Restock</h5>
        <div class="small-note">
          Avg Daily Sales (last <?= (int)$RESTOCK_LOOKBACK_DAYS ?> days),
          Lead Time = <?= (int)$LEAD_TIME_DAYS ?> day(s),
          Safety Stock = <?= number_format($SAFETY_STOCK_KG, 0) ?>kg,
          Target Cover = <?= (int)$TARGET_DAYS_COVER ?> day(s)
        </div>
      </div>
    </div>

    <?php if(empty($restockRows)): ?>
      <div class="alert alert-success mb-0">
        No urgent restocks right now based on current stock and recent movement.
      </div>
    <?php else: ?>
      <div class="table-responsive modern-table">
        <table class="table table-sm align-middle mb-0">
          <thead>
            <tr>
              <th>Product</th>
              <th class="text-end">Stock</th>
              <th class="text-end">Avg/Day</th>
              <th class="text-end">Reorder Point</th>
              <th class="text-end">Suggested Order</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($restockRows as $r): ?>
              <?php
              $badge = "success";
              if(($r['_status'] ?? 'OK') === 'REORDER') $badge = "warning";
              if(($r['_status'] ?? 'OK') === 'OUT') $badge = "danger";
              ?>
              <tr>
                <td class="fw-semibold"><?= h($r['product_label']) ?></td>
                <td class="text-end"><?= number_format((float)$r['current_stock'], 2) ?> kg</td>
                <td class="text-end"><?= number_format((float)$r['_avgDaily'], 2) ?> kg</td>
                <td class="text-end"><?= number_format((float)$r['_reorderPoint'], 2) ?></td>
                <td class="text-end fw-bold"><?= number_format((float)$r['_suggested'], 2) ?> kg</td>
                <td><span class="badge bg-<?= $badge ?>"><?= h($r['_status']) ?></span></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <div class="analytics-box">
    <div class="box-head">
      <div>
        <h5 class="fw-bold mb-1">Dead Stock / No Sales</h5>
        <div class="small-note">Products with stock on hand but no sales in the last <?= (int)$RESTOCK_LOOKBACK_DAYS ?> days</div>
      </div>
    </div>

    <?php if(empty($deadStock)): ?>
      <div class="alert alert-success mb-0">
        No dead stock detected in this period.
      </div>
    <?php else: ?>
      <div class="table-responsive modern-table">
        <table class="table table-sm align-middle mb-0">
          <thead>
            <tr>
              <th>Product</th>
              <th class="text-end">Current Stock</th>
              <th class="text-end">Sold Last <?= (int)$RESTOCK_LOOKBACK_DAYS ?> Days</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($deadStock as $r): ?>
              <tr>
                <td class="fw-semibold"><?= h($r['product_label']) ?></td>
                <td class="text-end"><?= number_format((float)$r['current_stock'], 2) ?> kg</td>
                <td class="text-end"><?= number_format((float)$r['sold_last_n'], 2) ?> kg</td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<div class="mover-feature mt-2">
  <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
    <div>
      <h5 class="fw-bold mb-1"><i class="fa-solid fa-bolt me-1 text-primary"></i>Fast & Slow Movers Spotlight</h5>
      <div class="small text-muted">Based on sales in the last <?= (int)$RESTOCK_LOOKBACK_DAYS ?> days</div>
    </div>
    <div class="d-flex flex-wrap gap-2">
      <span class="mover-kpi">
        <i class="fa-solid fa-fire text-success"></i>
        Fastest: <?= h((string)($fastTop['product_label'] ?? 'N/A')) ?>
      </span>
      <span class="mover-kpi">
        <i class="fa-solid fa-snowflake text-danger"></i>
        Slowest: <?= h((string)($slowTop['product_label'] ?? 'N/A')) ?>
      </span>
    </div>
  </div>

  <div class="analytics-row">
    <div class="analytics-box mover-card fast">
      <div class="box-head">
        <div>
          <h6 class="fw-bold mb-1 text-success">Fast Moving Products</h6>
          <div class="small-note">Best recent movers</div>
        </div>
      </div>
      <?php if(empty($fastMovers)): ?>
        <div class="alert alert-light border mb-0">No sales movement yet in this window.</div>
      <?php else: ?>
        <div class="table-responsive modern-table">
          <table class="table table-sm align-middle mb-0">
            <thead>
              <tr>
                <th style="width:56px">Rank</th>
                <th>Product</th>
                <th class="text-end">Sold</th>
                <th class="text-end">Stock</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($fastMovers as $idx => $r): ?>
                <?php $pct = $maxFastSold > 0 ? (((float)$r['sold_last_n'] / $maxFastSold) * 100) : 0; ?>
                <tr>
                  <td><span class="mover-rank"><?= (int)($idx + 1) ?></span></td>
                  <td>
                    <div class="fw-semibold"><?= h($r['product_label']) ?></div>
                    <div class="mover-bar mt-1">
                      <span class="mover-fill fast" style="width: <?= number_format($pct, 1, '.', '') ?>%"></span>
                    </div>
                  </td>
                  <td class="text-end fw-semibold"><?= number_format((float)$r['sold_last_n'], 2) ?> kg</td>
                  <td class="text-end"><?= number_format((float)$r['current_stock'], 2) ?> kg</td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>

    <div class="analytics-box mover-card slow">
      <div class="box-head">
        <div>
          <h6 class="fw-bold mb-1 text-danger">Slow Moving Products</h6>
          <div class="small-note">Useful to avoid overstock or spoilage</div>
        </div>
      </div>
      <?php if(empty($slowMovers)): ?>
        <div class="alert alert-light border mb-0">No products available for movement ranking.</div>
      <?php else: ?>
        <div class="table-responsive modern-table">
          <table class="table table-sm align-middle mb-0">
            <thead>
              <tr>
                <th style="width:56px">Rank</th>
                <th>Product</th>
                <th class="text-end">Sold</th>
                <th class="text-end">Stock</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($slowMovers as $idx => $r): ?>
                <?php
                $ratio = $maxSlowSold > 0 ? (((float)$r['sold_last_n'] / $maxSlowSold) * 100) : 0;
                $stagnantPct = 100 - $ratio;
                if($stagnantPct < 8) $stagnantPct = 8;
                ?>
                <tr>
                  <td><span class="mover-rank"><?= (int)($idx + 1) ?></span></td>
                  <td>
                    <div class="fw-semibold"><?= h($r['product_label']) ?></div>
                    <div class="mover-bar mt-1">
                      <span class="mover-fill slow" style="width: <?= number_format($stagnantPct, 1, '.', '') ?>%"></span>
                    </div>
                  </td>
                  <td class="text-end fw-semibold"><?= number_format((float)$r['sold_last_n'], 2) ?> kg</td>
                  <td class="text-end"><?= number_format((float)$r['current_stock'], 2) ?> kg</td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="analytics-row mt-4">
  <div class="analytics-box">
    <div class="box-head">
      <div>
        <h5 class="fw-bold mb-1">Sales per Product</h5>
        <div class="small-note">All-time kilograms sold</div>
      </div>
    </div>

    <?php if(empty($salesPerProduct)): ?>
      <div class="alert alert-warning mb-0">
        No sales data yet. This section will populate once transactions are recorded.
      </div>
    <?php else: ?>
      <?php
      $maxSold = max(array_map(fn($r) => (float)$r['total_sold_kg'], $salesPerProduct));
      if($maxSold <= 0) $maxSold = 1;
      ?>
      <?php foreach(array_slice($salesPerProduct, 0, 10) as $row): ?>
        <?php $pct = ((float)$row['total_sold_kg'] / $maxSold) * 100; ?>
        <div class="product-progress-item">
          <div class="d-flex justify-content-between align-items-center gap-3">
            <span class="fw-semibold product-name"><?= h($row['product_label']) ?></span>
            <span class="text-muted small"><?= number_format((float)$row['total_sold_kg'], 2) ?> kg</span>
          </div>
          <div class="bar mt-2">
            <div style="width:<?= max(3, min(100, $pct)) ?>%"></div>
          </div>
        </div>
      <?php endforeach; ?>
      <div class="small-note mt-2">Showing top 10 products.</div>
    <?php endif; ?>
  </div>
</div>

<?php endif; ?>

</div>
</main>

</div>
</div>

<script id="adminAnalyticsData" type="application/json"><?= json_encode([
  'months' => $months,
  'salesKgData' => $salesKgData,
  'combinedLabels' => $combinedLabels,
  'actualPadded' => $actualPadded,
  'forecastPadded' => $forecastPadded,
  'daySalesLabels' => $daySalesLabels,
  'daySalesData' => $daySalesData,
  'topProdLabels' => $topProdLabels,
  'topProdKg' => $topProdKg,
  'stockLabels' => $stockLabels,
  'stockData' => $stockData,
], JSON_UNESCAPED_SLASHES) ?></script>

<script src="../js/admin_analytics.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
