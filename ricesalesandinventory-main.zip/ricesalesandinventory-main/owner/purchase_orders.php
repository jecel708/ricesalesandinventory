<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

if (strtolower($_SESSION['role'] ?? '') !== 'owner') {
    header("Location: ../login.php");
    exit;
}

include '../config/db.php';

function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

$username = $_SESSION['username'] ?? 'Owner';
$owner_id = (int)($_SESSION['user_id'] ?? 0);
$purchaseOrdersMode = strtolower((string)($purchaseOrdersMode ?? ($_GET['mode'] ?? 'approval')));
if (!in_array($purchaseOrdersMode, ['approval', 'approved'], true)) {
    $purchaseOrdersMode = 'approval';
}
$pageHeading = $purchaseOrdersMode === 'approved' ? 'Approved Purchases' : 'Pending Purchase Requests';
$pageSubtitle = $purchaseOrdersMode === 'approved'
    ? 'View already-approved purchase records.'
    : 'Review purchase requests and approve them here.';

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}
$csrf_token = (string)$_SESSION['csrf_token'];

function csrfOk(): bool {
    $posted = (string)($_POST['csrf_token'] ?? '');
    $stored = (string)($_SESSION['csrf_token'] ?? '');
    return $posted !== '' && $stored !== '' && hash_equals($stored, $posted);
}

function logOwnerPurchaseActivity(mysqli $conn, int $userId, string $desc, string $activityType = 'PO_APPROVAL'): void {
    $stmt = $conn->prepare("
        INSERT INTO activity_logs (user_id, activity_type, description, created_at)
        VALUES (?, ?, ?, NOW())
    ");
    if ($stmt) {
        $stmt->bind_param("iss", $userId, $activityType, $desc);
        $stmt->execute();
        $stmt->close();
    }
}

function purchaseStatusIsLocked(string $status): bool {
    return in_array($status, ['received', 'completed', 'cancelled'], true);
}

function activityLogsAvailable(mysqli $conn): bool {
    $res = $conn->query("SHOW TABLES LIKE 'activity_logs'");
    return $res && $res->num_rows > 0;
}

function logPurchaseOrderAudit(mysqli $conn, int $userId, string $activityType, string $description): void {
    if (!activityLogsAvailable($conn)) {
        return;
    }

    $stmt = $conn->prepare("
        INSERT INTO activity_logs (user_id, activity_type, description, created_at)
        VALUES (?, ?, ?, NOW())
    ");
    if ($stmt) {
        $stmt->bind_param('iss', $userId, $activityType, $description);
        $stmt->execute();
        $stmt->close();
    }
}

function fetchCurrentPasswordHash(mysqli $conn, int $userId): ?string {
    $stmt = $conn->prepare("SELECT password FROM users WHERE user_id = ? LIMIT 1");
    if (!$stmt) {
        return null;
    }
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return isset($row['password']) ? (string)$row['password'] : null;
}

function stringifyChanges(array $changes): string {
    $parts = [];
    foreach ($changes as $change) {
        $parts[] = $change;
    }
    return implode('; ', $parts);
}

function isApprovedEditMode(string $mode, array $row): bool {
    return $mode === 'approved' && (int)($row['po_approved'] ?? 0) === 1;
}

function isEditableApprovedPurchase(array $row): bool {
    return (int)($row['po_approved'] ?? 0) === 1;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve_po'])) {
    if (!csrfOk()) {
        header("Location: purchase_orders.php?error=" . urlencode("Invalid request. Please refresh and try again."));
        exit;
    }

    $purchaseId = (int)($_POST['purchase_id'] ?? 0);
    if ($purchaseId <= 0) {
        header("Location: purchase_orders.php?error=" . urlencode("Invalid purchase request."));
        exit;
    }

    $stmt = $conn->prepare("
        UPDATE purchases
        SET po_approved = 1, po_approved_by = ?, po_approved_at = NOW(), status = 'completed'
        WHERE purchases_id = ? AND (po_approved = 0 OR po_approved IS NULL)
    ");
    if (!$stmt) {
        header("Location: purchase_orders.php?error=" . urlencode("DB error: " . $conn->error));
        exit;
    }
    $stmt->bind_param("ii", $owner_id, $purchaseId);
    $stmt->execute();
    $affected = $stmt->affected_rows;
    $stmt->close();

    if ($affected > 0) {
        logOwnerPurchaseActivity($conn, $owner_id, "Approved purchase request #{$purchaseId}");
        header("Location: purchase_orders.php?success=" . urlencode("Purchase request approved. The PO is now approved and ready for stock-in."));
        exit;
    }

    header("Location: purchase_orders.php?error=" . urlencode("Purchase request was already approved or no longer exists."));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reject_po'])) {
    if (!csrfOk()) {
        header("Location: purchase_orders.php?error=" . urlencode("Invalid request. Please refresh and try again."));
        exit;
    }

    $purchaseId = (int)($_POST['purchase_id'] ?? 0);
    if ($purchaseId <= 0) {
        header("Location: purchase_orders.php?error=" . urlencode("Invalid purchase request."));
        exit;
    }

    $stmt = $conn->prepare("
        UPDATE purchases
        SET po_approved = 0,
            po_approved_by = NULL,
            po_approved_at = NULL,
            status = 'cancelled'
        WHERE purchases_id = ? AND (po_approved = 0 OR po_approved IS NULL)
    ");
    if (!$stmt) {
        header("Location: purchase_orders.php?error=" . urlencode("DB error: " . $conn->error));
        exit;
    }
    $stmt->bind_param("i", $purchaseId);
    $stmt->execute();
    $affected = $stmt->affected_rows;
    $stmt->close();

    if ($affected > 0) {
        logPurchaseOrderAudit($conn, $owner_id, 'PO_REJECT', "Rejected purchase request #{$purchaseId}");
        header("Location: purchase_orders.php?success=" . urlencode("Purchase request rejected."));
        exit;
    }

    header("Location: purchase_orders.php?error=" . urlencode("Purchase request was already processed or no longer exists."));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_po_edits'])) {
    if (!csrfOk()) {
        header("Location: purchase_orders.php?error=" . urlencode("Invalid request. Please refresh and try again."));
        exit;
    }

    $purchaseId = (int)($_POST['purchase_id'] ?? 0);
    if ($purchaseId <= 0) {
        header("Location: purchase_orders.php?error=" . urlencode("Invalid purchase request."));
        exit;
    }

    $headerStmt = $conn->prepare("
        SELECT purchases_id, po_approved, status
        FROM purchases
        WHERE purchases_id = ?
        LIMIT 1
    ");
    if (!$headerStmt) {
        header("Location: purchase_orders.php?error=" . urlencode("DB error: " . $conn->error));
        exit;
    }

    $headerStmt->bind_param("i", $purchaseId);
    $headerStmt->execute();
    $purchaseRow = $headerStmt->get_result()->fetch_assoc();
    $headerStmt->close();

    if (!$purchaseRow) {
        header("Location: purchase_orders.php?error=" . urlencode("Purchase request not found."));
        exit;
    }

    $purchaseStatus = strtolower((string)($purchaseRow['status'] ?? 'pending'));
    $isApprovedEdit = isApprovedEditMode($purchaseOrdersMode, $purchaseRow);

    if (!$isApprovedEdit && ((int)($purchaseRow['po_approved'] ?? 0) === 1 || purchaseStatusIsLocked($purchaseStatus))) {
        header("Location: purchase_orders.php?error=" . urlencode("This purchase request can no longer be edited."));
        exit;
    }

    $editReason = '';
    if ($isApprovedEdit) {
        $currentPassword = trim((string)($_POST['current_password'] ?? ''));
        $editReason = trim((string)($_POST['edit_reason'] ?? ''));

        if ($currentPassword === '') {
            header("Location: purchase_orders.php?mode=approved&error=" . urlencode("Please enter your current password to edit an approved purchase order."));
            exit;
        }

        if ($editReason === '') {
            header("Location: purchase_orders.php?mode=approved&error=" . urlencode("Please provide a reason for editing this approved purchase order."));
            exit;
        }

        $storedHash = fetchCurrentPasswordHash($conn, $owner_id);
        if ($storedHash === null || !password_verify($currentPassword, $storedHash)) {
            header("Location: purchase_orders.php?mode=approved&error=" . urlencode("Incorrect owner password."));
            exit;
        }
    }

    $itemIds = $_POST['item_id'] ?? [];
    $productIds = $_POST['product_id'] ?? [];
    $quantities = $_POST['quantity_sacks'] ?? [];
    $supplierPrices = $_POST['supplier_price'] ?? [];

    if (empty($itemIds) || count($itemIds) === 0) {
        header("Location: purchase_orders.php?error=" . urlencode("No purchase items were submitted for editing."));
        exit;
    }

    $validProducts = [];
    $prodRes = $conn->query("
        SELECT product_id
        FROM products
        WHERE archived = 0
    ");
    if ($prodRes) {
        while ($prod = $prodRes->fetch_assoc()) {
            $validProducts[(int)$prod['product_id']] = true;
        }
    }

    $conn->begin_transaction();

    try {
        $beforeStmt = $conn->prepare("
            SELECT purchase_item_id, product_id, quantity_sacks, estimated_price, supplier_price, line_total
            FROM purchase_items
            WHERE purchases_id = ?
        ");
        if (!$beforeStmt) {
            throw new Exception("DB error: " . $conn->error);
        }
        $beforeStmt->bind_param("i", $purchaseId);
        $beforeStmt->execute();
        $beforeItemsRes = $beforeStmt->get_result();
        $beforeItems = [];
        while ($beforeRow = $beforeItemsRes->fetch_assoc()) {
            $beforeItems[(int)$beforeRow['purchase_item_id']] = $beforeRow;
        }
        $beforeStmt->close();

        $itemCheck = $conn->prepare("
            SELECT purchase_item_id
            FROM purchase_items
            WHERE purchase_item_id = ? AND purchases_id = ?
            LIMIT 1
        ");
        if (!$itemCheck) {
            throw new Exception("DB error: " . $conn->error);
        }

        $itemUpdate = $conn->prepare("
            UPDATE purchase_items
            SET product_id = ?, quantity_sacks = ?, estimated_price = ?, supplier_price = ?, line_total = ?
            WHERE purchase_item_id = ? AND purchases_id = ?
        ");
        if (!$itemUpdate) {
            throw new Exception("DB error: " . $conn->error);
        }

        $totalAmount = 0.0;
        $changeLines = [];

        foreach ($itemIds as $idx => $rawItemId) {
            $itemId = (int)$rawItemId;
            $productId = (int)($productIds[$idx] ?? 0);
            $qty = (float)($quantities[$idx] ?? 0);
            $price = (float)($supplierPrices[$idx] ?? 0);

            if ($itemId <= 0 || $productId <= 0 || $qty <= 0 || $price < 0) {
                throw new Exception("Please provide valid product, quantity, and price for every item.");
            }

            if (!isset($validProducts[$productId])) {
                throw new Exception("One of the selected products is no longer available.");
            }

            $itemCheck->bind_param("ii", $itemId, $purchaseId);
            $itemCheck->execute();
            $exists = $itemCheck->get_result()->fetch_assoc();
            if (!$exists) {
                throw new Exception("One of the purchase items is invalid.");
            }

            $lineTotal = round($qty * $price, 2);

            $beforeRow = $beforeItems[$itemId] ?? null;
            if ($beforeRow) {
                $beforeProductId = (int)($beforeRow['product_id'] ?? 0);
                $beforeQty = (float)($beforeRow['quantity_sacks'] ?? 0);
                $beforePrice = (float)($beforeRow['supplier_price'] ?? $beforeRow['estimated_price'] ?? 0);

                if ($beforeProductId !== $productId) {
                    $changeLines[] = "Item #{$itemId}: product {$beforeProductId} -> {$productId}";
                }
                if (abs($beforeQty - $qty) > 0.0001) {
                    $changeLines[] = "Item #{$itemId}: quantity {$beforeQty} -> {$qty}";
                }
                if (abs($beforePrice - $price) > 0.0001) {
                    $changeLines[] = "Item #{$itemId}: price " . number_format($beforePrice, 2) . " -> " . number_format($price, 2);
                }
            }

            $itemUpdate->bind_param("iddddii", $productId, $qty, $price, $price, $lineTotal, $itemId, $purchaseId);
            $itemUpdate->execute();
            $totalAmount += $lineTotal;
        }

        $itemCheck->close();
        $itemUpdate->close();

        if ($isApprovedEdit) {
            $poUpdate = $conn->prepare("
                UPDATE purchases
                SET total_amount = ?
                WHERE purchases_id = ? AND po_approved = 1
            ");
        } else {
            $poUpdate = $conn->prepare("
                UPDATE purchases
                SET total_amount = ?
                WHERE purchases_id = ? AND po_approved = 0
            ");
        }
        if (!$poUpdate) {
            throw new Exception("DB error: " . $conn->error);
        }
        $poUpdate->bind_param("di", $totalAmount, $purchaseId);
        $poUpdate->execute();
        $affected = $poUpdate->affected_rows;
        $poUpdate->close();

        if ($affected < 0) {
            throw new Exception("Unable to update purchase total.");
        }

        if ($isApprovedEdit) {
            $changeSummary = stringifyChanges($changeLines);
            if ($changeSummary === '') {
                $changeSummary = 'No field-level changes detected.';
            }
            $auditDescription = "Edited approved purchase request #{$purchaseId} by Owner. Reason: {$editReason}. Changes: {$changeSummary}. New total: " . number_format($totalAmount, 2);
            logPurchaseOrderAudit($conn, $owner_id, 'PO_EDIT_APPROVED', $auditDescription);
        } else {
            logPurchaseOrderAudit($conn, $owner_id, 'PO_EDIT', "Edited purchase request #{$purchaseId} before approval. New total: " . number_format($totalAmount, 2));
        }

        $conn->commit();
        $redirectMode = $isApprovedEdit ? '&mode=approved' : '';
        header("Location: purchase_orders.php?success=" . urlencode("Purchase request updated successfully.") . $redirectMode);
        exit;
    } catch (Throwable $ex) {
        $conn->rollback();
        $redirectMode = $isApprovedEdit ? '&mode=approved' : '';
        header("Location: purchase_orders.php?error=" . urlencode("Unable to save edits: " . $ex->getMessage()) . $redirectMode);
        exit;
    }
}

/*
|--------------------------------------------------------------------------
| Filters
|--------------------------------------------------------------------------
*/
$search = trim($_GET['search'] ?? '');
$status = trim($_GET['status'] ?? '');
$apApproval = trim($_GET['ap_approval'] ?? '');

$where = [];
$params = [];
$types = '';

if ($purchaseOrdersMode === 'approval') {
    // ✅ Show ALL pending requests — even if status is NULL/empty — EXCEPT cancelled
    $where[] = "(p.po_approved = 0 OR p.po_approved IS NULL) 
                AND (p.status <> 'cancelled' OR p.status IS NULL OR p.status = '')";
} else {
    $where[] = "p.po_approved = 1";
}

if ($search !== '') {
    $where[] = "(
        CAST(p.purchases_id AS CHAR) LIKE ?
        OR s.name LIKE ?
        OR u.username LIKE ?
    )";
    $like = "%{$search}%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $types .= 'sss';
}

if ($status !== '') {
    if ($status === 'completed') {
        $where[] = "p.status IN ('completed', 'received')";
    } else {
        $where[] = "p.status = ?";
        $params[] = $status;
        $types .= 's';
    }
}

if ($apApproval !== '') {
    if ($apApproval === 'approved') {
        $where[] = "ap.approved = 1";
    } elseif ($apApproval === 'unapproved') {
        $where[] = "(ap.approved = 0 OR ap.approved IS NULL)";
    }
}

$whereSql = '';
if (!empty($where)) {
    $whereSql = 'WHERE ' . implode(' AND ', $where);
}

/*
|--------------------------------------------------------------------------
| Metrics
|--------------------------------------------------------------------------
*/
$metrics = [
    'total_purchases' => 0,
    'pending' => 0,
    'completed' => 0,
    'cancelled' => 0,
    'total_amount' => 0,
];

$metricsSql = "
    SELECT
        COUNT(*) AS total_purchases,
        SUM(CASE WHEN status IN ('ordered', 'pending') THEN 1 ELSE 0 END) AS pending,
        SUM(CASE WHEN status IN ('completed', 'received') AND po_approved = 1 THEN 1 ELSE 0 END) AS completed,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled,
        SUM(CASE WHEN po_approved = 0 THEN 1 ELSE 0 END) AS approval_pending,
        SUM(total_amount) AS total_amount
    FROM purchases
";
$metricsRes = $conn->query($metricsSql);
if ($metricsRes) {
    $metrics = $metricsRes->fetch_assoc() ?: $metrics;
}

/*
|--------------------------------------------------------------------------
| Purchases list (REAL DATA SOURCE)
|--------------------------------------------------------------------------
*/
$sql = "
    SELECT
        p.purchases_id,
        p.request_reason,
        p.supplier_id,
        p.purchase_date,
        p.total_amount,
        p.status,
        p.received_at,
        p.po_approved,
        p.po_approved_at,
        p.created_at,
        s.name AS supplier_name,
        u.username AS created_by_name,
        approver.username AS approved_by_name,
        ap.ap_id,
        ap.balance AS ap_balance,
        ap.status AS ap_status,
        ap.approved,
        ap.due_date AS ap_due_date
    FROM purchases p
    LEFT JOIN suppliers s ON s.supplier_id = p.supplier_id
    LEFT JOIN users u ON u.user_id = p.created_by
    LEFT JOIN users approver ON approver.user_id = p.po_approved_by
    LEFT JOIN account_payable ap ON ap.purchase_id = p.purchases_id
    $whereSql
    ORDER BY p.created_at DESC, p.purchases_id DESC
";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("SQL PREPARE ERROR: " . $conn->error);
}

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$stmt->close();

$rows = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
}

$purchaseItems = [];

$itemSql = "
    SELECT
        pi.purchase_item_id,
        pi.purchases_id,
        pi.product_id,
        pi.quantity_sacks,
        pi.estimated_price,
        pi.supplier_price,
        pi.line_total,
        p.variety,
        p.grade,
        p.unit_weight_kg
    FROM purchase_items pi
    JOIN products p
        ON p.product_id = pi.product_id
    ORDER BY pi.purchase_item_id ASC
";

$itemRes = $conn->query($itemSql);

if ($itemRes) {
    while ($item = $itemRes->fetch_assoc()) {
        $purchaseItems[$item['purchases_id']][] = $item;
    }
}

$products = [];
$prodRes = $conn->query("
    SELECT product_id, variety, grade, unit_weight_kg
    FROM products
    WHERE archived = 0
    ORDER BY variety ASC, grade ASC
");
if ($prodRes) {
    while ($prod = $prodRes->fetch_assoc()) {
        $products[] = $prod;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pending Purchase Requests | DE ORO HIYS</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="../css/layout.css" rel="stylesheet">
<link href="../css/owner-purchase-orders.css" rel="stylesheet">
<link href="../css/owner-mobile.css" rel="stylesheet">
</head>
<body>

<?php
$profileLink = 'profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>

<div class="container-fluid">
<div class="row">

<?php include '../includes/owner_sidebar.php'; ?>

<main class="col-lg-10 ms-sm-auto px-4 main-content">
<div class="py-4">

  <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
    <div>
      <h3 class="fw-bold mb-1"><?= h($pageHeading) ?></h3>
      <div class="text-muted"><?= h($pageSubtitle) ?></div>
    </div>
  </div>

  <?php if (isset($_GET['error']) && trim((string)$_GET['error']) !== ''): ?>
    <div class="alert alert-danger"><?= h($_GET['error']) ?></div>
  <?php endif; ?>

  <?php if (isset($_GET['success']) && trim((string)$_GET['success']) !== ''): ?>
    <div class="alert alert-success"><?= h($_GET['success']) ?></div>
  <?php endif; ?>

  <?php if ($purchaseOrdersMode !== 'approved'): ?>
  <!-- Metrics -->
  <div class="row g-3 mb-4" id="poMetricsRow">
    <div class="col-md-3">
      <div class="card modern-card card-kpi h-100">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-start gap-3">
            <div class="flex-grow-1 min-w-0">
              <div class="kpi-label">Total Purchases</div>
              <div class="kpi-value"><?= (int)($metrics['total_purchases'] ?? 0) ?></div>
              <div class="kpi-sub">All records</div>
            </div>
            <span class="kpi-icon"><i class="fa-solid fa-file-invoice"></i></span>
          </div>
        </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card modern-card card-kpi h-100">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-start gap-3">
            <div class="flex-grow-1 min-w-0">
              <div class="kpi-label">Pending</div>
              <div class="kpi-value"><?= (int)($metrics['pending'] ?? 0) ?></div>
              <div class="kpi-sub">Purchase requests</div>
            </div>
            <span class="kpi-icon"><i class="fa-solid fa-hourglass-half"></i></span>
          </div>
        </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card modern-card card-kpi h-100">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-start gap-3">
            <div class="flex-grow-1 min-w-0">
              <div class="kpi-label">Completed</div>
              <div class="kpi-value"><?= (int)($metrics['completed'] ?? 0) ?></div>
              <div class="kpi-sub">Approved POs ready for printing</div>
            </div>
            <span class="kpi-icon"><i class="fa-solid fa-check"></i></span>
          </div>
        </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card modern-card card-kpi h-100">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-start gap-3">
            <div class="flex-grow-1 min-w-0">
              <div class="kpi-label">Total Amount</div>
              <div class="kpi-value">₱<?= number_format((float)($metrics['total_amount'] ?? 0), 2) ?></div>
              <div class="kpi-sub"><?= (int)($metrics['approval_pending'] ?? 0) ?> awaiting approval</div>
            </div>
            <span class="kpi-icon"><i class="fa-solid fa-peso-sign"></i></span>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <!-- Filters -->
  <div class="card modern-card mb-3" id="poFiltersCard">
    <div class="card-body">
      <form method="GET" class="row g-2 align-items-end">
        <input type="hidden" name="mode" value="<?= h($purchaseOrdersMode) ?>">
        <div class="col-md-4">
          <label class="form-label small fw-bold">Search</label>
          <input
            type="text"
            name="search"
            class="form-control form-control-sm"
            placeholder="Purchase ID, supplier, creator..."
            value="<?= h($search) ?>"
          >
        </div>

        <div class="col-md-3">
          <label class="form-label small fw-bold">Purchase Status</label>
          <select name="status" class="form-select form-select-sm">
            <option value="">All</option>
            <option value="ordered" <?= $status === 'ordered' ? 'selected' : '' ?>>Ordered</option>
            <option value="pending" <?= $status === 'pending' ? 'selected' : '' ?>>Pending</option>
            <option value="completed" <?= $status === 'completed' ? 'selected' : '' ?>>Completed</option>
            <option value="cancelled" <?= $status === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
          </select>
        </div>

        <div class="col-md-3">
          <label class="form-label small fw-bold">AP Approval</label>
          <select name="ap_approval" class="form-select form-select-sm">
            <option value="">All</option>
            <option value="approved" <?= $apApproval === 'approved' ? 'selected' : '' ?>>Approved</option>
            <option value="unapproved" <?= $apApproval === 'unapproved' ? 'selected' : '' ?>>Unapproved</option>
          </select>
        </div>

        <div class="col-md-2 d-flex gap-2">
          <button type="submit" class="btn btn-sm btn-dark flex-grow-1">
            <i class="fa-solid fa-magnifying-glass me-1"></i>Filter
          </button>
          <a href="purchase_orders.php?mode=<?= h($purchaseOrdersMode) ?>" class="btn btn-sm btn-outline-secondary">
            <i class="fa-solid fa-rotate-left"></i>
          </a>
        </div>
      </form>
    </div>
  </div>

  <!-- Table -->
  <div class="card modern-card" id="poListCard">
    <div class="card-body table-responsive">
      <table class="table table-striped table-hover align-middle mb-0">
        <thead class="table-dark">
          <tr>
            <th>Purchase #</th>
            <th>Supplier</th>
            <th>Reason</th>
            <th>Purchase Date</th>
            <th>Amount</th>
            <th>Purchase Status</th>
            <th>Request Approval</th>
            <th>AP</th>
            <th>AP Approval</th>
            <th>Created By</th>
            <th>Details</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!empty($rows)): ?>
              <?php foreach ($rows as $row): ?>
              <?php
                $purchaseStatus = strtolower(trim((string)($row['status'] ?? '')));
                if (in_array($purchaseStatus, ['received', 'completed'], true)) {
                    $purchaseStatus = 'completed';
                }
                $purchaseBadge = 'bg-secondary';
                if ($purchaseStatus === 'pending') $purchaseBadge = 'bg-warning text-dark';
                elseif ($purchaseStatus === 'ordered') $purchaseBadge = 'bg-primary';
                elseif ($purchaseStatus === 'completed') $purchaseBadge = 'bg-success';
                elseif ($purchaseStatus === 'cancelled') $purchaseBadge = 'bg-danger';

                $apExists = !empty($row['ap_id']);
                $approved = isset($row['approved']) ? (int)$row['approved'] : 0;
                $poApproved = (int)($row['po_approved'] ?? 0) === 1;
                $canOwnerEditApproved = $purchaseOrdersMode === 'approved' && $poApproved && !in_array($purchaseStatus, ['cancelled'], true);
              ?>
              <tr>
                <td class="fw-bold">#<?= (int)$row['purchases_id'] ?></td>
                <td><?= h($row['supplier_name'] ?? 'N/A') ?></td>

<td>
    <?= h($row['request_reason'] ?? '-') ?>
</td>

<td>
    <?= !empty($row['purchase_date'])
        ? h(date('M d, Y', strtotime($row['purchase_date'])))
        : '-' ?>
</td>
                <td class="fw-bold">₱<?= number_format((float)($row['total_amount'] ?? 0), 2) ?></td>

                <td>
                  <span class="badge <?= $purchaseBadge ?>">
                    <?= h(strtoupper($purchaseStatus ?: 'N/A')) ?>
                  </span>
                </td>

                <td>
                  <?php if ($poApproved): ?>
                    <span class="badge bg-success">Approved</span>
                    <div class="small text-muted">
                      <?= h($row['approved_by_name'] ?? 'Owner') ?>
                      <?= !empty($row['po_approved_at']) ? ' - ' . h($row['po_approved_at']) : '' ?>
                    </div>
                  <?php else: ?>
                    <span class="badge bg-warning text-dark">Pending Owner</span>
                  <?php endif; ?>
                </td>

                <td>
                  <?php if ($apExists): ?>
                    <div><strong>#<?= (int)$row['ap_id'] ?></strong></div>
                    <small class="text-muted">
                      Bal: ₱<?= number_format((float)($row['ap_balance'] ?? 0), 2) ?>
                    </small>
                  <?php else: ?>
                    <span class="text-muted">No AP yet</span>
                  <?php endif; ?>
                </td>

                <td>
                  <?php if ($apExists): ?>
                    <?php if ($approved === 1): ?>
                      <span class="badge bg-success">Approved</span>
                    <?php else: ?>
                      <span class="badge bg-warning text-dark">Unapproved</span>
                    <?php endif; ?>

                    <?php if (!empty($row['ap_status'])): ?>
                      <br><small class="text-muted"><?= h(ucfirst((string)$row['ap_status'])) ?></small>
                    <?php endif; ?>
                  <?php else: ?>
                    <span class="text-muted">-</span>
                  <?php endif; ?>
                </td>

               <td><?= h($row['created_by_name'] ?? 'N/A') ?></td>

<td>
  <?php if ($purchaseOrdersMode === 'approval'): ?>
    <?php if (!$poApproved): ?>
      <div class="d-flex flex-wrap gap-2">
        <button
          type="button"
          class="btn btn-sm btn-warning"
          data-bs-toggle="modal"
          data-bs-target="#editPoModal<?= (int)$row['purchases_id'] ?>">
          Edit
        </button>

          <form method="POST" class="m-0">
            <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
            <input type="hidden" name="purchase_id" value="<?= (int)$row['purchases_id'] ?>">
            <button type="submit" name="approve_po" class="btn btn-sm btn-success">
              Approve
            </button>
          </form>

          <form method="POST" class="m-0" onsubmit="return confirm('Reject this purchase request?');">
            <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
            <input type="hidden" name="purchase_id" value="<?= (int)$row['purchases_id'] ?>">
            <button type="submit" name="reject_po" class="btn btn-sm btn-danger">
              Reject
            </button>
          </form>
        </div>
    <?php else: ?>
      <span class="text-muted small">Approved</span>
    <?php endif; ?>
  <?php elseif ($purchaseOrdersMode === 'approved'): ?>
    <?php if ($canOwnerEditApproved): ?>
      <div class="d-flex flex-wrap gap-2">
        <button
          type="button"
          class="btn btn-sm btn-warning"
          data-bs-toggle="modal"
          data-bs-target="#editPoModal<?= (int)$row['purchases_id'] ?>">
          Edit
        </button>
      </div>
    <?php else: ?>
      <span class="text-muted small">Read only</span>
    <?php endif; ?>
  <?php else: ?>
    <span class="text-muted small">Read only</span>
  <?php endif; ?>
</td>

<td>
  <button
      type="button"
      class="btn btn-sm btn-info"
      data-bs-toggle="modal"
      data-bs-target="#viewPoModal<?= (int)$row['purchases_id'] ?>">
      <i class="fa-solid fa-eye me-1"></i>
      View
  </button>
</td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr>
              <td colspan="12" class="text-center text-muted py-4">No purchase records found.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

</div>
</main>

</div>
</div>

<?php foreach ($rows as $row): ?>

<div class="modal fade"
     id="viewPoModal<?= (int)$row['purchases_id'] ?>"
     tabindex="-1"
     aria-hidden="true">

    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">
                    Purchase Request #<?= (int)$row['purchases_id'] ?>
                </h5>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <div class="row mb-3">

                    <div class="col-md-6">
                        <strong>Supplier:</strong><br>
                        <?= h($row['supplier_name'] ?? 'N/A') ?>
                    </div>

                    <div class="col-md-6">
                        <strong>Purchase Date:</strong><br>
                        <?= !empty($row['purchase_date'])
                            ? h(date('M d, Y', strtotime($row['purchase_date'])))
                            : '-' ?>
                    </div>

                </div>

                <div class="mb-3">
                    <strong>Reason:</strong>
                    <div class="border rounded p-2 bg-light">
                        <?= h($row['request_reason'] ?? '-') ?>
                    </div>
                </div>

                <div class="mb-3">
                    <strong>Total Amount:</strong><br>
                    ₱<?= number_format((float)($row['total_amount'] ?? 0), 2) ?>
                </div>

                <hr>

                <h6 class="fw-bold mb-3">
                    Requested Items
                </h6>

                <table class="table table-bordered">

                    <thead class="table-light">
                        <tr>
                            <th>Product</th>
                            <th>Grade</th>
                            <th>Weight</th>
                            <th>Quantity</th>
                            <th>Price / Sack</th>
                            <th>Line Total</th>
                        </tr>
                    </thead>

                    <tbody>

<?php
$items = $purchaseItems[$row['purchases_id']] ?? [];
?>

<?php if (!empty($items)): ?>

    <?php foreach ($items as $item): ?>

        <tr>

            <td>
                <?= h($item['variety']) ?>
            </td>

            <td>
                <?= h($item['grade']) ?>
            </td>

            <td>
                <?= number_format((float)$item['unit_weight_kg'], 2) ?> kg
            </td>

            <td>
                <?= (int)$item['quantity_sacks'] ?> sacks
            </td>

            <td>
                ₱<?= number_format((float)($item['supplier_price'] ?? $item['estimated_price'] ?? 0), 2) ?>
            </td>

            <td>
                ₱<?= number_format((float)($item['line_total'] ?? (($item['supplier_price'] ?? $item['estimated_price'] ?? 0) * (float)$item['quantity_sacks'])), 2) ?>
            </td>

        </tr>

    <?php endforeach; ?>

<?php else: ?>

    <tr>
        <td colspan="6" class="text-center text-muted">
            No items found.
        </td>
    </tr>

<?php endif; ?>

</tbody>

                </table>

            </div>

        </div>
    </div>

</div>

<?php endforeach; ?>

<?php foreach ($rows as $row): ?>
  <?php
    $rowStatus = strtolower(trim((string)($row['status'] ?? 'pending')));
    $poApproved = (int)($row['po_approved'] ?? 0) === 1;
    $isApprovedEdit = $purchaseOrdersMode === 'approved' && $poApproved;
    $isEditable = (!$poApproved && !in_array($rowStatus, ['completed', 'cancelled'], true)) || $isApprovedEdit;
    $items = $purchaseItems[$row['purchases_id']] ?? [];
  ?>
  <div class="modal fade" id="editPoModal<?= (int)$row['purchases_id'] ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
      <div class="modal-content">
        <form method="POST" class="po-edit-form" data-purchase-id="<?= (int)$row['purchases_id'] ?>">
          <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
          <input type="hidden" name="purchase_id" value="<?= (int)$row['purchases_id'] ?>">

          <div class="modal-header">
            <div>
              <h5 class="modal-title mb-0">Edit Purchase Request #<?= (int)$row['purchases_id'] ?></h5>
              <div class="small text-muted">Correct the item details before approving this request.</div>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>

          <div class="modal-body">
            <?php if (!$isEditable): ?>
              <div class="alert alert-warning">This purchase request is no longer editable.</div>
            <?php elseif ($isApprovedEdit): ?>
              <div class="alert alert-info">
                Approved purchase orders can only be edited by the Owner after password verification.
              </div>
            <?php endif; ?>

            <?php if ($isApprovedEdit): ?>
              <div class="border rounded p-3 bg-light mb-3">
                <div class="row g-3">
                  <div class="col-md-5">
                    <label class="form-label fw-semibold">Current Owner Password</label>
                    <input type="password" class="form-control" name="current_password" autocomplete="current-password" required>
                  </div>
                  <div class="col-md-7">
                    <label class="form-label fw-semibold">Reason for Editing</label>
                    <textarea class="form-control" name="edit_reason" rows="2" required placeholder="Explain why this approved purchase order is being modified."></textarea>
                  </div>
                </div>
                <div class="d-flex justify-content-end mt-3">
                  <button type="submit" name="save_po_edits" class="btn btn-primary">
                    Save Approved Changes
                  </button>
                </div>
              </div>
            <?php endif; ?>

            <div class="row g-3 mb-3">
              <div class="col-md-4">
                <label class="form-label fw-semibold">Supplier</label>
                <input type="text" class="form-control" value="<?= h($row['supplier_name'] ?? 'N/A') ?>" readonly>
              </div>
              <div class="col-md-4">
                <label class="form-label fw-semibold">Purchase Date</label>
                <input type="text" class="form-control" value="<?= !empty($row['purchase_date']) ? h(date('M d, Y', strtotime($row['purchase_date']))) : '-' ?>" readonly>
              </div>
              <div class="col-md-4">
                <label class="form-label fw-semibold">Current Total</label>
                <input type="text" class="form-control po-total-display" value="₱<?= number_format((float)($row['total_amount'] ?? 0), 2) ?>" readonly>
              </div>
            </div>

            <div class="table-responsive">
              <table class="table table-bordered align-middle po-edit-table">
                <thead class="table-light">
                  <tr>
                    <th style="min-width: 240px;">Product</th>
                    <th style="width: 140px;">Qty (Sacks)</th>
                    <th style="width: 180px;">Supplier Price / Sack</th>
                    <th style="width: 180px;">Line Total</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if (!empty($items)): ?>
                    <?php foreach ($items as $idx => $item): ?>
                      <?php $unitPrice = (float)($item['supplier_price'] ?? $item['estimated_price'] ?? 0); ?>
                      <tr class="po-item-row">
                        <td>
                          <input type="hidden" name="item_id[]" value="<?= (int)$item['purchase_item_id'] ?>">
                          <select class="form-select po-product-select" name="product_id[]" <?= $isEditable ? '' : 'disabled' ?>>
                            <?php foreach ($products as $product): ?>
                              <?php
                                $selected = (int)$product['product_id'] === (int)$item['product_id'];
                                $label = $product['variety'] . ' | ' . $product['grade'] . ' (' . number_format((float)$product['unit_weight_kg'], 2) . ' kg/sack)';
                              ?>
                              <option value="<?= (int)$product['product_id'] ?>" <?= $selected ? 'selected' : '' ?>>
                                <?= h($label) ?>
                              </option>
                            <?php endforeach; ?>
                          </select>
                        </td>
                        <td>
                          <input
                            type="number"
                            step="1"
                            min="1"
                            class="form-control po-qty-input"
                            name="quantity_sacks[]"
                            value="<?= (float)$item['quantity_sacks'] ?>"
                            <?= $isEditable ? '' : 'disabled' ?>>
                        </td>
                        <td>
                          <input
                            type="number"
                            step="0.01"
                            min="0"
                            class="form-control po-price-input"
                            name="supplier_price[]"
                            value="<?= number_format($unitPrice, 2, '.', '') ?>"
                            <?= $isEditable ? '' : 'disabled' ?>>
                        </td>
                        <td>
                          <input
                            type="text"
                            class="form-control po-line-total"
                            value="₱<?= number_format((float)($item['line_total'] ?? ($unitPrice * (float)$item['quantity_sacks'])), 2) ?>"
                            readonly>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  <?php else: ?>
                    <tr>
                      <td colspan="4" class="text-center text-muted py-4">No items found.</td>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>

            <div class="row g-3 mt-2">
              <div class="col-md-4 ms-auto">
                <label class="form-label fw-semibold">Recalculated Total</label>
                <input type="text" class="form-control po-grand-total" value="₱<?= number_format((float)($row['total_amount'] ?? 0), 2) ?>" readonly>
              </div>
            </div>

          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <?php if ($isEditable && !$isApprovedEdit): ?>
              <button type="submit" name="save_po_edits" class="btn btn-primary">
                Save Changes
              </button>
            <?php endif; ?>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php endforeach; ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
  const pollIntervalMs = 3000;
  let pollingInFlight = false;
  let lastUserActivityAt = Date.now();
  const interactionQuietMs = 1200;

  function isModalOpen() {
    return !!document.querySelector('.modal.show');
  }

  function isPointerOverProtectedArea() {
    const active = document.activeElement;
    return !!(
      active &&
      (
        document.getElementById('poListCard')?.contains(active) ||
        document.getElementById('poFiltersCard')?.contains(active)
      )
    );
  }

  async function pollPurchaseOrders() {
    if (pollingInFlight) return;
    if (isModalOpen() || isPointerOverProtectedArea() || (Date.now() - lastUserActivityAt) < interactionQuietMs) {
      return;
    }
    pollingInFlight = true;

    try {
      const url = new URL(window.location.href);
      url.searchParams.set('ajax', 'live');

      const response = await fetch(url.toString(), {
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      });
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');

      const metrics = doc.getElementById('poMetricsRow');
      const metricsTarget = document.getElementById('poMetricsRow');
      if (metrics && metricsTarget) {
        metricsTarget.innerHTML = metrics.innerHTML;
      }

      const filters = doc.getElementById('poFiltersCard');
      const filtersTarget = document.getElementById('poFiltersCard');
      if (filters && filtersTarget) {
        filtersTarget.innerHTML = filters.innerHTML;
      }

      const list = doc.getElementById('poListCard');
      const listTarget = document.getElementById('poListCard');
      if (list && listTarget) {
        listTarget.innerHTML = list.innerHTML;
      }
    } catch (error) {
      console.error('Purchase orders live poll failed:', error);
    } finally {
      pollingInFlight = false;
    }
  }

  document.addEventListener('mousemove', () => { lastUserActivityAt = Date.now(); }, { passive: true });
  document.addEventListener('keydown', () => { lastUserActivityAt = Date.now(); });
  document.addEventListener('click', () => { lastUserActivityAt = Date.now(); });
  document.addEventListener('focusin', () => { lastUserActivityAt = Date.now(); });

  function formatPeso(value) {
    return '₱' + Number(value || 0).toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  }

  function recalcEditForm(form) {
    if (!form) return;

    let grandTotal = 0;
    form.querySelectorAll('.po-item-row').forEach((row) => {
      const qty = parseFloat(row.querySelector('.po-qty-input')?.value || '0') || 0;
      const price = parseFloat(row.querySelector('.po-price-input')?.value || '0') || 0;
      const lineTotal = qty * price;
      grandTotal += lineTotal;

      const lineInput = row.querySelector('.po-line-total');
      if (lineInput) {
        lineInput.value = formatPeso(lineTotal);
      }
    });

    const totalInput = form.querySelector('.po-grand-total');
    if (totalInput) {
      totalInput.value = formatPeso(grandTotal);
    }

    const displayInput = form.querySelector('.po-total-display');
    if (displayInput) {
      displayInput.value = formatPeso(grandTotal);
    }
  }

  document.querySelectorAll('.po-edit-form').forEach((form) => {
    recalcEditForm(form);
    form.addEventListener('input', (event) => {
      if (event.target.matches('.po-qty-input, .po-price-input')) {
        recalcEditForm(form);
      }
    });
    form.addEventListener('change', (event) => {
      if (event.target.matches('.po-qty-input, .po-price-input, .po-product-select')) {
        recalcEditForm(form);
      }
    });
  });

  pollPurchaseOrders();
  window.setInterval(pollPurchaseOrders, pollIntervalMs);
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
