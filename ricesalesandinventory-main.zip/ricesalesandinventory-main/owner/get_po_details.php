<?php
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Not logged in.'
    ]);
    exit;
}

if (strtolower($_SESSION['role'] ?? '') !== 'owner') {
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized access.'
    ]);
    exit;
}

include '../config/db.php';

$po_id = (int)($_GET['po_id'] ?? 0);

if ($po_id <= 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid PO ID.'
    ]);
    exit;
}

/*
|--------------------------------------------------------------------------
| Get PO header details
|--------------------------------------------------------------------------
*/
$stmt = $conn->prepare("
    SELECT
        po.po_id,
        po.supplier_id,
        po.order_date,
        po.status,
        po.total_amount,
        po.notes,
        po.rating,
        po.comment,
        s.name AS supplier_name
    FROM purchase_orders po
    INNER JOIN suppliers s ON po.supplier_id = s.supplier_id
    WHERE po.po_id = ?
    LIMIT 1
");

if (!$stmt) {
    echo json_encode([
        'success' => false,
        'message' => 'Prepare failed: ' . $conn->error
    ]);
    exit;
}

$stmt->bind_param("i", $po_id);
$stmt->execute();
$result = $stmt->get_result();
$po = $result ? $result->fetch_assoc() : null;
$stmt->close();

if (!$po) {
    echo json_encode([
        'success' => false,
        'message' => 'Purchase order not found.'
    ]);
    exit;
}

/*
|--------------------------------------------------------------------------
| Get PO items
|--------------------------------------------------------------------------
| Adjust table/column names here if your schema differs.
|--------------------------------------------------------------------------
*/
$items = [];

$itemStmt = $conn->prepare("
    SELECT
        poi.po_item_id,
        poi.product_id,
        poi.quantity,
        poi.price_per_unit,
        p.variety AS product_variety,
        p.grade AS product_grade
    FROM purchase_order_items poi
    LEFT JOIN products p ON poi.product_id = p.product_id
    WHERE poi.po_id = ?
    ORDER BY poi.po_item_id ASC
");

if (!$itemStmt) {
    echo json_encode([
        'success' => false,
        'message' => 'Item query prepare failed: ' . $conn->error
    ]);
    exit;
}

$itemStmt->bind_param("i", $po_id);
$itemStmt->execute();
$itemRes = $itemStmt->get_result();

if ($itemRes) {
    while ($row = $itemRes->fetch_assoc()) {
        $items[] = $row;
    }
}
$itemStmt->close();

echo json_encode([
    'success' => true,
    'po' => $po,
    'items' => $items
]);