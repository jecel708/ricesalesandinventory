<?php
require_once __DIR__ . '/../cashier/payment_receipt.php';
