<?php
if(!function_exists('mfa_clear_trusted_cookie')){
  function mfa_clear_trusted_cookie(): void {
    $cookieName = 'mfa_trusted';
    if(isset($_COOKIE[$cookieName])){
      setcookie($cookieName, '', time() - 3600, '/');
      unset($_COOKIE[$cookieName]);
    }
  }
}
session_start();
if(!isset($_SESSION['user_id'])){ header("Location: ../login.php"); exit; }
if(strtolower($_SESSION['role'] ?? '') !== 'owner'){ header("Location: ../login.php"); exit; }

include "../config/db.php";
require_once "../includes/mfa.php";

$user_id = (int)$_SESSION['user_id'];
$username = $_SESSION['username'] ?? 'Owner';

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$csrf_token = (string)($_SESSION['csrf_token'] ?? '');
if($csrf_token === ''){
  $csrf_token = bin2hex(random_bytes(32));
  $_SESSION['csrf_token'] = $csrf_token;
}

function require_csrf_token_or_redirect(string $target): void {
  $posted = (string)($_POST['csrf_token'] ?? '');
  $stored = (string)($_SESSION['csrf_token'] ?? '');
  if($posted === '' || $stored === '' || !hash_equals($stored, $posted)){
    header("Location: {$target}?error=" . urlencode("Session expired. Please try again."));
    exit;
  }
}

$success = $_GET['success'] ?? '';
$error = $_GET['error'] ?? '';

// Load current user info (adjust columns if your users table differs)
$stmt = $conn->prepare("SELECT user_id, username, display_name, email, role FROM users WHERE user_id=? LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if(!$user){
  die("User not found.");
}
if (empty($user['display_name'])) {
  $user['display_name'] = (string)($user['username'] ?? '');
}

// compute trusted device expiry for UI badge
$trustedDeviceExpiry = null;
try {
  if (isset($conn) && $conn instanceof mysqli) {
    $trustedDeviceExpiry = mfa_get_trusted_device_expiry($conn, $user_id);
  }
} catch (Throwable $e) {
  $trustedDeviceExpiry = null;
}

if($_SERVER['REQUEST_METHOD'] === 'POST'){
  require_csrf_token_or_redirect('profile.php');
}

/* =========================
Update username (optional)
========================= */
if(isset($_POST['update_profile'])){
  $new_username = trim($_POST['username'] ?? '');
  $displayName = trim($_POST['display_name'] ?? '');
  $new_email = trim(strtolower((string)($_POST['email'] ?? '')));

  if($new_username === ''){
    header("Location: profile.php?error=" . urlencode("Username cannot be empty."));
    exit;
  }
  if($displayName === ''){
    header("Location: profile.php?error=" . urlencode("Display name cannot be empty."));
    exit;
  }
  if($new_email === '' || !filter_var($new_email, FILTER_VALIDATE_EMAIL)){
    header("Location: profile.php?error=" . urlencode("A valid email is required."));
    exit;
  }

  // prevent duplicate usernames
  $stmt = $conn->prepare("SELECT user_id FROM users WHERE username=? AND user_id<>? LIMIT 1");
  $stmt->bind_param("si", $new_username, $user_id);
  $stmt->execute();
  $dup = $stmt->get_result()->fetch_assoc();
  $stmt->close();

  if($dup){
    header("Location: profile.php?error=" . urlencode("Username already exists."));
    exit;
  }

  $stmt = $conn->prepare("SELECT user_id FROM users WHERE LOWER(email)=LOWER(?) AND user_id<>? LIMIT 1");
  $stmt->bind_param("si", $new_email, $user_id);
  $stmt->execute();
  $dupEmail = $stmt->get_result()->fetch_assoc();
  $stmt->close();

  if($dupEmail){
    header("Location: profile.php?error=" . urlencode("Email already exists."));
    exit;
  }

  $stmt = $conn->prepare("UPDATE users SET username=?, display_name=?, email=? WHERE user_id=?");
  $stmt->bind_param("sssi", $new_username, $displayName, $new_email, $user_id);
  $stmt->execute();
  $stmt->close();

  // keep session username in sync
  $_SESSION['username'] = $new_username;

  // activity log (optional)
  if($conn->query("SHOW TABLES LIKE 'activity_logs'")->num_rows > 0){
    $type = "PROFILE_UPDATE";
    $desc = "Updated profile username to '{$new_username}'";
    $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, activity_type, description, created_at) VALUES (?,?,?,NOW())");
    $stmt->bind_param("iss", $user_id, $type, $desc);
    $stmt->execute();
    $stmt->close();
  }

  header("Location: profile.php?success=" . urlencode("Profile updated."));
  exit;
}

/* =========================
Change password
========================= */
if(isset($_POST['change_password'])){
  if(empty($_SESSION['owner_pwd_change_pending'])){
    header("Location: profile.php?error=" . urlencode("No pending OTP verification. Start password change again."));
    exit;
  }

  $otp = trim((string)($_POST['otp'] ?? ''));
  if(!preg_match('/^[0-9]{6}$/', $otp)){
    header("Location: profile.php?error=" . urlencode("Enter a valid 6-digit OTP code."));
    exit;
  }

  $stmt = $conn->prepare("SELECT id, otp_hash, expires_at, attempts, max_attempts, used_at FROM user_email_otp_challenges WHERE user_id=? ORDER BY id DESC LIMIT 1");
  $stmt->bind_param("i", $user_id);
  $stmt->execute();
  $challenge = $stmt->get_result()->fetch_assoc();
  $stmt->close();

  if(!$challenge){
    header("Location: profile.php?error=" . urlencode("No OTP challenge found. Please request a new OTP."));
    exit;
  }
  if(!empty($challenge['used_at'])){
    header("Location: profile.php?error=" . urlencode("This OTP was already used. Request a new OTP."));
    exit;
  }
  if(strtotime((string)$challenge['expires_at']) < time()){
    header("Location: profile.php?error=" . urlencode("OTP expired. Request a new OTP."));
    exit;
  }

  $attempts = (int)($challenge['attempts'] ?? 0);
  $maxAttempts = (int)($challenge['max_attempts'] ?? 5);
  if($attempts >= $maxAttempts){
    header("Location: profile.php?error=" . urlencode("Too many OTP attempts. Request a new OTP."));
    exit;
  }
  if(!password_verify($otp, (string)$challenge['otp_hash'])){
    $up = $conn->prepare("UPDATE user_email_otp_challenges SET attempts=attempts+1 WHERE id=?");
    if($up){
      $cid = (int)$challenge['id'];
      $up->bind_param("i", $cid);
      $up->execute();
      $up->close();
    }
    $left = max(0, $maxAttempts - ($attempts + 1));
    header("Location: profile.php?error=" . urlencode("Incorrect OTP. {$left} attempt(s) left."));
    exit;
  }

  $mark = $conn->prepare("UPDATE user_email_otp_challenges SET used_at=NOW() WHERE id=?");
  if($mark){
    $cid = (int)$challenge['id'];
    $mark->bind_param("i", $cid);
    $mark->execute();
    $mark->close();
  }

  $pendingHash = (string)($_SESSION['owner_pwd_change_hash'] ?? '');
  if($pendingHash === ''){
    header("Location: profile.php?error=" . urlencode("Pending password data missing. Start again."));
    exit;
  }

  $stmt = $conn->prepare("UPDATE users SET password=? WHERE user_id=?");
  $stmt->bind_param("si", $pendingHash, $user_id);
  $stmt->execute();
  $stmt->close();

  $wipe = $conn->prepare("DELETE FROM user_trusted_devices WHERE user_id=?");
  if($wipe){
    $wipe->bind_param("i", $user_id);
    $wipe->execute();
    $wipe->close();
  }
  mfa_clear_trusted_cookie();

  unset($_SESSION['owner_pwd_change_pending'], $_SESSION['owner_pwd_change_hash']);

  if($conn->query("SHOW TABLES LIKE 'activity_logs'")->num_rows > 0){
    $type = "PASSWORD_CHANGE";
    $desc = "Changed account password with OTP verification and revoked trusted devices";
    $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, activity_type, description, created_at) VALUES (?,?,?,NOW())");
    $stmt->bind_param("iss", $user_id, $type, $desc);
    $stmt->execute();
    $stmt->close();
  }

  header("Location: profile.php?success=" . urlencode("Password changed successfully."));
  exit;
}

if(isset($_POST['request_change_password_otp'])){
  $current = $_POST['current_password'] ?? '';
  $new1 = $_POST['new_password'] ?? '';
  $new2 = $_POST['confirm_password'] ?? '';

  if($new1 === '' || $new2 === '' || $current === ''){
    header("Location: profile.php?error=" . urlencode("Please fill up all password fields."));
    exit;
  }
  if($new1 !== $new2){
    header("Location: profile.php?error=" . urlencode("New password and confirm password do not match."));
    exit;
  }
  if(strlen($new1) < 6){
    header("Location: profile.php?error=" . urlencode("New password must be at least 6 characters."));
    exit;
  }

  // verify current password
  $stmt = $conn->prepare("SELECT password, email FROM users WHERE user_id=? LIMIT 1");
  $stmt->bind_param("i", $user_id);
  $stmt->execute();
  $row = $stmt->get_result()->fetch_assoc();
  $stmt->close();

  $hash = $row['password'] ?? '';
  if(!$hash || !password_verify($current, $hash)){
    header("Location: profile.php?error=" . urlencode("Current password is incorrect."));
    exit;
  }

  $email = trim((string)($row['email'] ?? ''));
  if($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)){
    header("Location: profile.php?error=" . urlencode("No valid email found for this account."));
    exit;
  }

  $newHash = password_hash($new1, PASSWORD_DEFAULT);
  if($newHash === false){
    header("Location: profile.php?error=" . urlencode("Unable to process new password. Try again."));
    exit;
  }

  if(!mfa_send_otp_for_user($conn, $user_id, $email)){
    header("Location: profile.php?error=" . urlencode("Unable to send OTP email right now."));
    exit;
  }

  $_SESSION['owner_pwd_change_pending'] = true;
  $_SESSION['owner_pwd_change_hash'] = $newHash;

  header("Location: profile.php?success=" . urlencode("OTP sent to your email. Enter it below to confirm password change."));
  exit;
}

if(isset($_POST['resend_change_password_otp'])){
  if(empty($_SESSION['owner_pwd_change_pending'])){
    header("Location: profile.php?error=" . urlencode("No pending OTP verification. Start password change again."));
    exit;
  }

  $stmt = $conn->prepare("SELECT email FROM users WHERE user_id=? LIMIT 1");
  $stmt->bind_param("i", $user_id);
  $stmt->execute();
  $row = $stmt->get_result()->fetch_assoc();
  $stmt->close();

  $email = trim((string)($row['email'] ?? ''));
  if($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)){
    header("Location: profile.php?error=" . urlencode("No valid email found for this account."));
    exit;
  }

  if(!mfa_send_otp_for_user($conn, $user_id, $email)){
    header("Location: profile.php?error=" . urlencode("Unable to resend OTP email right now."));
    exit;
  }

  header("Location: profile.php?success=" . urlencode("A new OTP has been sent to your email."));
  exit;
}

if(isset($_POST['cancel_change_password'])){
  unset($_SESSION['owner_pwd_change_pending'], $_SESSION['owner_pwd_change_hash']);
  header("Location: profile.php?success=" . urlencode("Pending password change canceled."));
  exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Owner Profile | DOHIVES</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="../css/layout.css" rel="stylesheet">

<link href="../css/owner-profile.css" rel="stylesheet">
<link href="../css/owner-mobile.css" rel="stylesheet">
<style>
.strength-container { margin-top: 0.5rem; margin-bottom: 0.25rem; }
.strength-bar { height: 8px; border-radius: 4px; background: #e9ecef; overflow: hidden; }
.strength-fill { height: 100%; width: 0%; border-radius: 4px; transition: all 0.3s ease; }
.strength-text { font-size: 0.85rem; font-weight: 500; margin-top: 0.25rem; }
.strength-weak { background-color: #dc3545; width: 25%; }
.strength-fair { background-color: #ffc107; width: 50%; }
.strength-good { background-color: #0dcaf0; width: 75%; }
.strength-strong { background-color: #198754; width: 100%; }
.requirement-list { list-style: none; padding: 0; margin: 0.5rem 0; font-size: 0.85rem; }
.requirement-list li { padding: 0.15rem 0; }
.requirement-list li i { margin-right: 0.5rem; font-size: 0.9rem; }
.req-pass { color: #198754; }
.req-fail { color: #6c757d; }
.match-text { font-size: 0.85rem; margin-top: 0.25rem; }
.match-yes { color: #198754; }
.match-no { color: #dc3545; }
.password-wrapper { position: relative; }
.password-wrapper .toggle-password {
  position: absolute;
  right: 15px;
  top: 50%;
  transform: translateY(-50%);
  cursor: pointer;
  color: #6c757d;
  font-size: 18px;
  user-select: none;
}
</style>
</head>
<body>

<?php include '../includes/topnav.php'; ?>

<div class="container-fluid">
<div class="row">

<?php include '../includes/owner_sidebar.php'; ?>

<!-- MAIN -->
<main class="col-lg-10 ms-sm-auto px-4 main-content">
<div class="py-4">

<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
<div>
<div class="section-subtitle mb-1">Owner Dashboard</div>
<h3 class="fw-bold mb-1">Owner Profile</h3>
<div class="text-muted">Manage your account details.</div>
</div>
</div>

<?php if($success): ?><div class="alert alert-success py-2"><?= h($success) ?></div><?php endif; ?>
<?php if($error): ?><div class="alert alert-danger py-2"><?= h($error) ?></div><?php endif; ?>

<div class="row g-4">
<!-- PROFILE INFO -->
<div class="col-12 col-xl-6">
<div class="card modern-card">
<div class="panel-head">
<div class="user-avatar"><i class="fa-solid fa-user"></i></div>
<h5 class="fw-bold mb-1">Profile Details</h5>
<div class="small text-muted">Update your identity and notification email.</div>
</div>
<div class="panel-body">

<form method="post">
<input type="hidden" name="update_profile" value="1">
<input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">

<div class="mb-3">
<label class="form-label fw-semibold">Role</label>
<input class="form-control" value="<?= h($user['role'] ?? 'owner') ?>" disabled>
</div>

<div class="mb-3">
<label class="form-label fw-semibold">Username <span class="text-danger">*</span></label>
<input class="form-control" name="username" value="<?= h($user['username'] ?? '') ?>" required>
</div>

<div class="mb-3">
<label class="form-label fw-semibold">Display Name <span class="text-danger">*</span></label>
<input class="form-control" name="display_name" value="<?= h($user['display_name'] ?? '') ?>" maxlength="100" required>
<div class="text-muted small mt-1">This is the name shown in the navbar.</div>
</div>

<div class="mb-3">
<label class="form-label fw-semibold">Email <span class="text-danger">*</span></label>
<input type="email" class="form-control" name="email" value="<?= h($user['email'] ?? '') ?>" required>
<div class="text-muted small mt-1">OTP and alerts are sent to this email.</div>
</div>

<div class="profile-meta mb-3">
  <span class="profile-badge">MFA Enabled</span>
  <?php if (is_array($trustedDeviceExpiry) && ($trustedDeviceExpiry['days_left'] ?? 0) > 0): ?>
    <span class="profile-badge" style="border:1px solid #dc3545;color:#dc3545;padding:6px 10px;border-radius:20px;font-weight:700;margin-left:8px;">
      Expires in <?= (int)$trustedDeviceExpiry['days_left'] ?> Day<?= ((int)$trustedDeviceExpiry['days_left'] === 1) ? '' : 's' ?>
    </span>
    <div class="small text-muted mt-1">After it expires, you’ll be asked for OTP again.</div>
  <?php endif; ?>
</div>

<button class="btn btn-dark w-100">
<i class="fa-solid fa-save me-1"></i> Save Changes
</button>
</form>

</div>
</div>
</div>

<!-- CHANGE PASSWORD -->
<div class="col-12 col-xl-6">
<div class="card modern-card">
<div class="panel-head">
<h5 class="fw-bold mb-1"><i class="fa-solid fa-key me-2"></i>Change Password</h5>
<div class="small text-muted">OTP verification required before password is updated.</div>
</div>
<div class="panel-body">

<?php if(empty($_SESSION['owner_pwd_change_pending'])): ?>
<form method="post">
<input type="hidden" name="request_change_password_otp" value="1">
<input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">

<div class="mb-3">
  <label class="form-label fw-semibold">Current Password <span class="text-danger">*</span></label>
  <div class="password-wrapper">
    <input type="password" class="form-control pe-5" id="current_password" name="current_password" required>
    <span class="toggle-password" data-target="current_password" aria-label="Toggle password">
      <i class="fa-solid fa-eye"></i>
    </span>
  </div>
</div>

<div class="mb-3">
  <label class="form-label fw-semibold">New Password <span class="text-danger">*</span></label>
  <div class="password-wrapper">
    <input type="password" class="form-control pe-5" id="new_password" name="new_password" minlength="6" required oninput="checkPasswordStrength(this.value)">
    <span class="toggle-password" data-target="new_password" aria-label="Toggle password">
      <i class="fa-solid fa-eye"></i>
    </span>
  </div>
  <div class="text-muted small mt-1">
    Password policy: at least 6 characters. A longer password with letters, numbers, and symbols is recommended.
  </div>
  <div class="strength-container">
    <div class="strength-bar"><div id="strengthFill" class="strength-fill"></div></div>
    <div id="strengthText" class="strength-text text-muted">Start typing a password...</div>
  </div>
  <ul class="requirement-list">
    <li id="req-length" data-label="At least 6 characters" class="req-fail"><i class="fa-solid fa-circle-xmark"></i> At least 6 characters</li>
    <li id="req-upper" data-label="One uppercase letter (A-Z)" class="req-fail"><i class="fa-solid fa-circle-xmark"></i> One uppercase letter (A-Z)</li>
    <li id="req-lower" data-label="One lowercase letter (a-z)" class="req-fail"><i class="fa-solid fa-circle-xmark"></i> One lowercase letter (a-z)</li>
    <li id="req-number" data-label="One number (0-9)" class="req-fail"><i class="fa-solid fa-circle-xmark"></i> One number (0-9)</li>
    <li id="req-special" data-label="One special character (!@#$%^&* etc.)" class="req-fail"><i class="fa-solid fa-circle-xmark"></i> One special character (!@#$%^&* etc.)</li>
  </ul>
</div>

<div class="mb-3">
  <label class="form-label fw-semibold">Confirm New Password <span class="text-danger">*</span></label>
  <div class="password-wrapper">
    <input type="password" class="form-control pe-5" id="confirm_password" name="confirm_password" required oninput="checkPasswordMatch()">
    <span class="toggle-password" data-target="confirm_password" aria-label="Toggle password">
      <i class="fa-solid fa-eye"></i>
    </span>
  </div>
  <div id="matchText" class="match-text"></div>
</div>

<button class="btn btn-outline-dark w-100">
<i class="fa-solid fa-paper-plane me-1"></i> Send OTP and Continue
</button>

<div class="text-muted small mt-2">
Tip: Use at least 6 characters.
</div>
</form>
<?php else: ?>
<form method="post">
<input type="hidden" name="change_password" value="1">
<input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
<div class="mb-3">
  <label class="form-label fw-semibold">OTP Code <span class="text-danger">*</span></label>
  <input type="text" class="form-control" name="otp" maxlength="6" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" placeholder="123456" required>
  <div class="text-muted small mt-1">Check your email for the 6-digit code.</div>
</div>
<button class="btn btn-dark w-100">
<i class="fa-solid fa-shield-halved me-1"></i> Verify OTP and Update Password
</button>
</form>
<form method="post" class="mt-2">
  <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
  <button class="btn btn-outline-primary w-100" name="resend_change_password_otp" value="1">
    <i class="fa-solid fa-rotate-right me-1"></i> Request New Code
  </button>
</form>
<form method="post" class="mt-2">
  <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
  <button class="btn btn-outline-secondary w-100" name="cancel_change_password" value="1">Cancel Pending Change</button>
</form>
<?php endif; ?>

</div>
</div>
</div>

</div>

</div>
</main>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
document.querySelectorAll('.toggle-password').forEach(function(btn){
  btn.addEventListener('click', function(){
    const id = btn.getAttribute('data-target');
    const input = document.getElementById(id);
    if(!input) return;
    const icon = btn.querySelector('i');
    if(input.type === 'password'){
      input.type = 'text';
      if(icon){ icon.classList.remove('fa-eye'); icon.classList.add('fa-eye-slash'); }
    } else {
      input.type = 'password';
      if(icon){ icon.classList.remove('fa-eye-slash'); icon.classList.add('fa-eye'); }
    }
  });
});

function updateReq(el, passed) {
  if(!el) return;
  const label = el.getAttribute('data-label') || el.textContent.trim();
  if(passed){
    el.classList.remove('req-fail');
    el.classList.add('req-pass');
    el.innerHTML = '<i class="fa-solid fa-circle-check"></i> ' + label;
  } else {
    el.classList.remove('req-pass');
    el.classList.add('req-fail');
    el.innerHTML = '<i class="fa-solid fa-circle-xmark"></i> ' + label;
  }
}

function checkPasswordStrength(pwd) {
  const fill = document.getElementById('strengthFill');
  const text = document.getElementById('strengthText');
  if(!fill || !text) return;

  const hasLength = pwd.length >= 6;
  const hasUpper = /[A-Z]/.test(pwd);
  const hasLower = /[a-z]/.test(pwd);
  const hasNumber = /[0-9]/.test(pwd);
  const hasSpecial = /[^A-Za-z0-9]/.test(pwd);

  updateReq(document.getElementById('req-length'), hasLength);
  updateReq(document.getElementById('req-upper'), hasUpper);
  updateReq(document.getElementById('req-lower'), hasLower);
  updateReq(document.getElementById('req-number'), hasNumber);
  updateReq(document.getElementById('req-special'), hasSpecial);

  const score = [hasLength, hasUpper, hasLower, hasNumber, hasSpecial].filter(Boolean).length;
  fill.className = 'strength-fill';

  if(pwd.length === 0){
    fill.style.width = '0%';
    text.textContent = 'Start typing a password...';
    text.className = 'strength-text text-muted';
  } else if(score <= 2){
    fill.classList.add('strength-weak');
    text.textContent = 'Weak - add more variety';
    text.className = 'strength-text text-danger';
  } else if(score === 3){
    fill.classList.add('strength-fair');
    text.textContent = 'Fair - could be stronger';
    text.className = 'strength-text text-warning';
  } else if(score === 4){
    fill.classList.add('strength-good');
    text.textContent = 'Good password';
    text.className = 'strength-text text-info';
  } else {
    fill.classList.add('strength-strong');
    text.textContent = 'Strong password!';
    text.className = 'strength-text text-success';
  }

  checkPasswordMatch();
}

function checkPasswordMatch() {
  const p1 = document.getElementById('new_password');
  const p2 = document.getElementById('confirm_password');
  const matchText = document.getElementById('matchText');
  if(!p1 || !p2 || !matchText) return;

  if(p2.value.length === 0){
    matchText.textContent = '';
    return;
  }

  if(p1.value === p2.value){
    matchText.innerHTML = '<span class="match-yes"><i class="fa-solid fa-check"></i> Passwords match</span>';
  } else {
    matchText.innerHTML = '<span class="match-no"><i class="fa-solid fa-xmark"></i> Passwords do not match</span>';
  }
}

document.addEventListener('DOMContentLoaded', function(){
  const newPassword = document.getElementById('new_password');
  if(newPassword) checkPasswordStrength(newPassword.value || '');
});
</script>

</body>
</html>
