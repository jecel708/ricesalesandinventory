<?php
session_start();
if(!isset($_SESSION['user_id'])){ header("Location: ../login.php"); exit; }
$role = strtolower($_SESSION['role'] ?? '');
if(!in_array($role, ['owner', 'admin'], true)){ header("Location: ../login.php"); exit; }

$username = $_SESSION['username'] ?? ($role === 'admin' ? 'Admin' : 'Owner');
$activePage = 'stock_monitoring';
include '../config/db.php';

$DEFAULT_LOW = 10.0;
$DEFAULT_OVER = 1000.0;

$settingsRow = null;
$settingsRes = $conn->query("SELECT low_threshold_kg, over_threshold_kg FROM stock_settings WHERE id=1 LIMIT 1");
if($settingsRes){
$settingsRow = $settingsRes->fetch_assoc();
}

$dbLow = (float)($settingsRow['low_threshold_kg'] ?? $DEFAULT_LOW);
$dbOver = (float)($settingsRow['over_threshold_kg'] ?? $DEFAULT_OVER);

/* Thresholds are system/admin rules, not page filters. */
$search = trim($_GET['search'] ?? '');
$low = $dbLow;
$over = $dbOver;
$AGE_LIMIT_DAYS = 30; // aging rule; not user-editable on this page
$NEW_STOCK_DAYS = 7;

if($low < 0) $low = 0;
if($over <= 0) $over = $dbOver;
if($over <= $low) $over = $low + 1;

$productsRows = [];

$sql = "
SELECT
p.product_id,
p.variety,
p.grade,
p.unit_weight_kg,
p.sell_price_per_sack,
p.price_per_kg,

IFNULL(SUM(sb.remaining_qty_kg),0) AS stock_kg,

MAX(sb.arrived_at) AS last_in_date,

CASE
WHEN MIN(CASE WHEN sb.remaining_qty_kg > 0 THEN sb.arrived_at END) IS NULL
THEN NULL
ELSE DATEDIFF(
CURDATE(),
MIN(CASE WHEN sb.remaining_qty_kg > 0 THEN sb.arrived_at END)
)
END AS age_days

FROM products p
LEFT JOIN stock_batches sb
ON sb.product_id = p.product_id

WHERE p.archived = 0
";

/* Prepared search */
$params = [];
$types = "";

if($search !== ''){
  $searchParts = preg_split('/\s+-\s+/', $search, 2);
  if (count($searchParts) === 2 && trim($searchParts[0]) !== '' && trim($searchParts[1]) !== '') {
    // Suggestion labels combine variety and grade ("Variety - Grade").
    // Match each part against its corresponding database field.
    $sql .= " AND p.variety LIKE ? AND p.grade LIKE ? ";
    $params[] = '%' . trim($searchParts[0]) . '%';
    $params[] = '%' . trim($searchParts[1]) . '%';
  } else {
    $sql .= " AND (p.variety LIKE ? OR p.grade LIKE ?) ";
    $like = "%{$search}%";
    $params[] = $like;
    $params[] = $like;
  }
  $types .= "ss";
}

$sql .= "
GROUP BY
p.product_id, p.variety, p.grade, p.unit_weight_kg, p.sell_price_per_sack, p.price_per_kg, p.stock_kg
ORDER BY stock_kg ASC, p.variety ASC
";

$stmt = $conn->prepare($sql);
if(!$stmt){
die("SQL Prepare Error: " . htmlspecialchars($conn->error));
}
if(!empty($params)){
$stmt->bind_param($types, ...$params);
}
$stmt->execute();
$res = $stmt->get_result();

if($res){
while($row = $res->fetch_assoc()){
$productsRows[] = $row;
}
}
$stmt->close();

$batchesByProduct = [];
$monitorProductIds = array_values(array_filter(array_map(
  fn($product) => (int)($product['product_id'] ?? 0),
  $productsRows
)));
if($monitorProductIds){
  $monitorProductIdList = implode(',', $monitorProductIds);
  $batchHistoryRes = $conn->query("
    SELECT batch_id, product_id, batch_code, arrived_at, remaining_qty_kg,
           regular_qty_kg, discounted_qty_kg, regular_price_per_kg,
           discounted_price_per_kg
    FROM stock_batches
    WHERE product_id IN ({$monitorProductIdList})
    ORDER BY product_id ASC, arrived_at DESC, batch_id DESC
  ");
  if($batchHistoryRes){
    while($batch = $batchHistoryRes->fetch_assoc()){
      $batchesByProduct[(int)$batch['product_id']][] = $batch;
    }
  }
}

/* =========================
PREP: ALERT LISTS
========================= */
$lowItems = [];
$overItems = [];
$agingItems = [];

foreach($productsRows as $row){
$stock = (float)($row['stock_kg'] ?? 0);
$ageDays = ($row['age_days'] !== null) ? (int)$row['age_days'] : null;

$label = ($row['variety'].' - '.$row['grade']);
$sackSize = (float)($row['unit_weight_kg'] ?? 0);

if($stock >= $over){
$overItems[] = [
'product' => $label,
'sack' => $sackSize,
'stock' => $stock
];
}

if($stock <= $low){
$lowItems[] = [
'product' => $label,
'sack' => $sackSize,
'stock' => $stock
];
}

if($stock > 0 && $ageDays !== null && $ageDays >= $AGE_LIMIT_DAYS){
$agingItems[] = [
'product' => $label,
'sack' => $sackSize,
'stock' => $stock,
'age_days' => $ageDays,
'last_in_date' => $row['last_in_date'] ?? null,
];
}
}

$autoModal = null;
if(count($overItems) > 0) $autoModal = 'overStockModal';
elseif(count($lowItems) > 0) $autoModal = 'lowStockModal';
elseif(count($agingItems) > 0) $autoModal = 'agingStockModal';

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Stocks Monitoring | DE ORO HIYS</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="../css/layout.css" rel="stylesheet">

<link href="../css/owner-inventory-monitoring.css" rel="stylesheet">
<link href="../css/owner-mobile.css" rel="stylesheet">
</head>
<body>

<?php
$profileLink = ($role === 'admin') ? '../admin/profile.php' : 'profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>

<div class="container-fluid">
<div class="row">

<?php
if($role === 'admin'){
  $adminBase = '../admin/';
  $inventoryBase = '../admin/';
  $ownerBase = '';
  include '../includes/admin_sidebar.php';
} else {
  include '../includes/owner_sidebar.php';
}
?>

<!-- MAIN -->
<main class="col-lg-10 ms-sm-auto px-4 main-content">
<div class="py-4">

<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
<div>
<h3 class="fw-bold mb-1">Stocks Monitoring</h3>
</div>
<button class="btn btn-outline-dark" onclick="window.print()">
<i class="fa-solid fa-print me-1"></i> Print
</button>
</div>


<!-- ALERT BUTTONS -->
<div class="d-flex flex-wrap gap-2 mb-3 mt-3">
<button type="button" class="btn btn-dark"
data-bs-toggle="modal" data-bs-target="#overStockModal"
<?= count($overItems) ? "" : "disabled" ?>>
<i class="fa-solid fa-triangle-exclamation me-1"></i>
Overstock
<span class="badge bg-danger ms-1"><?= (int)count($overItems) ?></span>
</button>

<button type="button" class="btn btn-outline-dark"
data-bs-toggle="modal" data-bs-target="#lowStockModal"
<?= count($lowItems) ? "" : "disabled" ?>>
<i class="fa-solid fa-cart-shopping me-1"></i>
Low Stock
<span class="badge bg-warning text-dark ms-1"><?= (int)count($lowItems) ?></span>
</button>

<button type="button" class="btn btn-outline-dark"
data-bs-toggle="modal" data-bs-target="#agingStockModal"
<?= count($agingItems) ? "" : "disabled" ?>>
<i class="fa-solid fa-clock me-1"></i>
Aging Stock
<span class="badge bg-secondary ms-1"><?= (int)count($agingItems) ?></span>
</button>
</div>

<!-- FILTER CARD -->
<div class="card filter-card mb-3 border-0">
  <div class="card-body py-3">
    <form class="row g-3 align-items-end" method="get">

      <!-- SEARCH -->
      <!-- SEARCH -->
<div class="col-12 col-lg-5 search-wrapper position-relative">
  <label class="form-label filter-label mb-1">Find Product (Variety or Grade)</label>
  <input class="form-control form-control-lg"
         name="search" id="searchInput"
         value="<?= h($search) ?>"
         placeholder="Try: Valencia, Jasmine, Premium, Regular"
         autocomplete="off">
  <div id="searchSuggestions" class="search-suggestions list-group position-absolute w-100 shadow-sm d-none"></div>
  <small class="text-muted">Type a variety or grade to narrow the list.</small>
</div>

      <!-- APPLY -->
      <div class="col-12 col-md-3 col-lg-3">
        <label class="form-label filter-label mb-1 invisible">Apply</label>
        <div class="d-flex gap-2">
        <button class="btn btn-dark btn-lg w-100 filter-action">
          <i class="fa-solid fa-magnifying-glass me-2"></i>Apply Filters
        </button>
        <a class="btn btn-outline-secondary btn-lg filter-action" href="inventory_monitoring.php" title="Reset filters">
          <i class="fa-solid fa-rotate-left"></i>
        </a>
        </div>
        <!-- reserve same helper height -->
        <small class="text-muted invisible">.</small>
      </div>

    </form>
  </div>
</div>

<!-- TABLE -->
<div class="card modern-card" id="stockTable">
<div class="card-body">
<div class="table-responsive">
<table class="table table-striped align-middle mb-0">
<thead class="table-dark">
<tr>
<th>Product</th>
<th class="text-end">Sack Size</th>
<th class="text-end">Stock (kg)</th>
<th class="text-end">Stocks Left (sacks)</th>
<th class="text-end">Price / Sack</th>
<th class="text-end">Price / Kg</th>
<th>Last Stock-in</th>
<th class="text-end">Age (days)</th>
<th>Status</th>
</tr>
</thead>
<tbody>
<?php if(count($productsRows) > 0): ?>
<?php foreach($productsRows as $p):
$stock = (float)($p['stock_kg'] ?? 0);
$ageDays = ($p['age_days'] !== null) ? (int)$p['age_days'] : null;
$sackSize = (float)($p['unit_weight_kg'] ?? 0);
$fullSacks = $sackSize > 0 ? floor($stock / $sackSize) : 0;
$looseKg = $sackSize > 0 ? ($stock - ($fullSacks * $sackSize)) : 0;

$isLow = ($stock <= $low);
$isOver = ($stock >= $over);
$isNewArrival = ($stock > 0 && $ageDays !== null && $ageDays <= $NEW_STOCK_DAYS);
$isAging = ($stock > 0 && $ageDays !== null && $ageDays >= $AGE_LIMIT_DAYS);

$rowClass = '';
if($isOver) $rowClass = 'table-danger';
elseif($isLow) $rowClass = 'table-warning';
elseif($isAging) $rowClass = 'table-secondary';
?>
<tr class="<?= $rowClass ?>">
<td class="fw-bold text-nowrap">
  <?= h($p['variety'].' - '.$p['grade']) ?>
  <button type="button" class="btn btn-sm btn-outline-primary ms-1" data-bs-toggle="modal" data-bs-target="#ownerBatchHistory<?= (int)$p['product_id'] ?>" title="View batch history" aria-label="View batch history for <?= h($p['variety'].' - '.$p['grade']) ?>">
    <i class="fa-solid fa-clock-rotate-left"></i>
  </button>
</td>
<td class="text-end"><?= number_format((float)($p['unit_weight_kg'] ?? 0),0) ?> kg</td>
<td class="text-end fw-bold"><?= number_format($stock,2) ?></td>
<td class="text-end">
  <span class="fw-bold"><?= number_format($fullSacks,0) ?></span>
  <?php if($looseKg > 0): ?>
    <div><small class="text-muted">+ <?= number_format($looseKg,2) ?> kg loose</small></div>
  <?php endif; ?>
</td>
<td class="text-end">₱<?= number_format((float)($p['sell_price_per_sack'] ?? 0),2) ?></td>
<td class="text-end">₱<?= number_format((float)($p['price_per_kg'] ?? 0),2) ?></td>
<td>
<?php if(!empty($p['last_in_date'])): ?>
<?= h(date("M d, Y", strtotime($p['last_in_date']))) ?>
<?php else: ?>
—
<?php endif; ?>
</td>
<td class="text-end"><?= ($ageDays !== null ? (int)$ageDays : '—') ?></td>
<td>
<?php if($stock <= 0): ?>
<span class="badge bg-secondary">OUT</span>
<?php elseif($isOver): ?>
<span class="badge bg-danger">OVER</span>
<?php elseif($isLow): ?>
<span class="badge bg-warning text-dark">LOW</span>
<?php elseif($isAging): ?>
<span class="badge bg-secondary">OLD STOCK</span>
<?php elseif($isNewArrival): ?>
<span class="badge bg-info text-dark">NEW ARRIVAL</span>
<?php elseif($ageDays !== null): ?>
<span class="badge bg-success">NEW STOCK</span>
<?php else: ?>
<span class="badge bg-success">OK</span>
<?php endif; ?>
</td>
</tr>
<?php endforeach; ?>
<?php else: ?>
<tr><td colspan="9" class="text-center text-muted">No active products found.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
<div class="text-muted small mt-2">
Tip: Stock status is based on the system rules configured by the administrator. Aging is based on each product's last stock-in date.
</div>
</div>
</div>
</div>
</main>
</div>
</div>

<!-- =========================
MODALS
========================= -->

<?php foreach($productsRows as $historyProduct): ?>
<?php
  $historyBatches = $batchesByProduct[(int)$historyProduct['product_id']] ?? [];
  $unitWeight = (float)($historyProduct['unit_weight_kg'] ?? 0);
  $totalStock = (float)($historyProduct['stock_kg'] ?? 0);
  $totalSacks = $unitWeight > 0 ? (int)floor($totalStock / $unitWeight) : 0;
  $looseStock = $unitWeight > 0 ? $totalStock - ($totalSacks * $unitWeight) : $totalStock;
?>
<div class="modal fade" id="ownerBatchHistory<?= (int)$historyProduct['product_id'] ?>" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-scrollable modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <div>
          <h5 class="modal-title fw-bold">Batch History</h5>
          <div class="small text-muted"><?= h($historyProduct['variety'].' - '.$historyProduct['grade']) ?></div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="row g-2 mb-3">
          <div class="col-6 col-md-3"><div class="border rounded p-2 h-100"><div class="small text-muted">Sack size</div><strong><?= number_format($unitWeight, 2) ?> kg</strong></div></div>
          <div class="col-6 col-md-3"><div class="border rounded p-2 h-100"><div class="small text-muted">Stock remaining</div><strong><?= number_format($totalStock, 2) ?> kg</strong></div></div>
          <div class="col-6 col-md-3"><div class="border rounded p-2 h-100"><div class="small text-muted">Full sacks left</div><strong><?= $totalSacks ?> sack(s)</strong></div></div>
          <div class="col-6 col-md-3"><div class="border rounded p-2 h-100"><div class="small text-muted">Loose stock</div><strong><?= number_format($looseStock, 2) ?> kg</strong></div></div>
        </div>
        <?php if(!$historyBatches): ?>
          <div class="text-center text-muted py-4">No batch records found for this product.</div>
        <?php else: ?>
          <div class="table-responsive">
            <table class="table table-sm table-hover table-striped align-middle mb-0">
              <thead class="table-light"><tr><th>Batch</th><th>Delivered</th><th>Regular left</th><th>Discounted left</th><th>Total left</th><th>Sacks left</th><th>Regular price/kg</th><th>Discount price/kg</th></tr></thead>
              <tbody>
                <?php foreach($historyBatches as $batch): ?>
                  <?php
                    $regularLeft = (float)($batch['regular_qty_kg'] ?? 0);
                    $discountedLeft = (float)($batch['discounted_qty_kg'] ?? 0);
                    $batchTotal = (float)($batch['remaining_qty_kg'] ?? ($regularLeft + $discountedLeft));
                    $batchSacks = $unitWeight > 0 ? (int)floor($batchTotal / $unitWeight) : 0;
                    $batchLoose = $unitWeight > 0 ? $batchTotal - ($batchSacks * $unitWeight) : $batchTotal;
                    $deliveredAt = trim((string)($batch['arrived_at'] ?? ''));
                  ?>
                  <tr>
                    <td><?= h($batch['batch_code'] ?: ('B'.$batch['batch_id'])) ?></td>
                    <td><?= $deliveredAt !== '' ? h(date('M d, Y', strtotime($deliveredAt))) : 'Date unavailable' ?></td>
                    <td><?= number_format($regularLeft, 2) ?> kg</td>
                    <td><?= number_format($discountedLeft, 2) ?> kg</td>
                    <td><?= number_format($batchTotal, 2) ?> kg</td>
                    <td class="text-nowrap"><strong><?= $batchSacks ?> sack(s)</strong><?php if($batchLoose > 0.004): ?><div class="small text-muted">+ <?= number_format($batchLoose, 2) ?> kg loose</div><?php endif; ?></td>
                    <td>₱<?= number_format((float)($batch['regular_price_per_kg'] ?? 0), 2) ?></td>
                    <td>₱<?= number_format((float)($batch['discounted_price_per_kg'] ?? 0), 2) ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button></div>
    </div>
  </div>
</div>
<?php endforeach; ?>
<div class="modal fade" id="lowStockModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog modal-lg modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title fw-bold">Low Stock Alert</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<?php if(count($lowItems) === 0): ?>
<div class="alert alert-success mb-0">No low stock items right now.</div>
<?php else: ?>
<div class="alert alert-warning mb-3">
There are <?= (int)count($lowItems) ?> product(s) at or below <?= number_format($low,2) ?> kg.
</div>
<div class="table-responsive">
<table class="table table-sm table-striped align-middle mb-0">
<thead class="table-dark">
<tr>
<th>Product</th>
<th class="text-end">Sack Size</th>
<th class="text-end">Remaining (kg)</th>
<th>Status</th>
</tr>
</thead>
<tbody>
<?php foreach($lowItems as $li): ?>
<tr>
<td class="fw-semibold"><?= h($li['product']) ?></td>
<td class="text-end"><?= number_format((float)$li['sack'],0) ?> kg</td>
<td class="text-end fw-bold"><?= number_format((float)$li['stock'],2) ?></td>
<td>
<?php if((float)$li['stock'] <= 0): ?>
<span class="badge bg-secondary">OUT</span>
<?php else: ?>
<span class="badge bg-warning text-dark">LOW</span>
<?php endif; ?>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<?php endif; ?>
</div>
<div class="modal-footer">
<button class="btn btn-outline-dark" data-bs-dismiss="modal">Close</button>
<a class="btn btn-dark" href="#stockTable">Go to table</a>
</div>
</div>
</div>
</div>

<!-- OVERSTOCK MODAL -->
<div class="modal fade" id="overStockModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog modal-lg modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title fw-bold">Overstock Alert</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<?php if(count($overItems) === 0): ?>
<div class="alert alert-success mb-0">No overstock items right now.</div>
<?php else: ?>
<div class="alert alert-danger mb-3">
There are <?= (int)count($overItems) ?> product(s) at or above <?= number_format($over,2) ?> kg.
</div>
<div class="table-responsive">
<table class="table table-sm table-striped align-middle mb-0">
<thead class="table-dark">
<tr>
<th>Product</th>
<th class="text-end">Sack Size</th>
<th class="text-end">Stock (kg)</th>
<th>Status</th>
</tr>
</thead>
<tbody>
<?php foreach($overItems as $oi): ?>
<tr>
<td class="fw-semibold"><?= h($oi['product']) ?></td>
<td class="text-end"><?= number_format((float)$oi['sack'],0) ?> kg</td>
<td class="text-end fw-bold"><?= number_format((float)$oi['stock'],2) ?></td>
<td><span class="badge bg-danger">OVER</span></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<?php endif; ?>
</div>
<div class="modal-footer">
<button class="btn btn-outline-dark" data-bs-dismiss="modal">Close</button>
<a class="btn btn-dark" href="#stockTable">Go to table</a>
</div>
</div>
</div>
</div>

<!-- AGING MODAL -->
<div class="modal fade" id="agingStockModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog modal-lg modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title fw-bold">Aging Stock Alert</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<?php if(count($agingItems) === 0): ?>
<div class="alert alert-success mb-0">No aging stock found for current threshold.</div>
<?php else: ?>
<div class="alert alert-secondary mb-3">
There are <?= (int)count($agingItems) ?> product(s) aged at least <?= (int)$AGE_LIMIT_DAYS ?> day(s) since last stock-in.
</div>
<div class="table-responsive">
<table class="table table-sm table-striped align-middle mb-0">
<thead class="table-dark">
<tr>
<th>Product</th>
<th class="text-end">Sack Size</th>
<th class="text-end">Stock (kg)</th>
<th class="text-end">Age</th>
<th>Last Stock-in</th>
<th>Status</th>
</tr>
</thead>
<tbody>
<?php foreach($agingItems as $ai): ?>
<tr>
<td class="fw-semibold"><?= h($ai['product']) ?></td>
<td class="text-end"><?= number_format((float)$ai['sack'],0) ?> kg</td>
<td class="text-end fw-bold"><?= number_format((float)$ai['stock'],2) ?></td>
<td class="text-end fw-bold"><?= (int)$ai['age_days'] ?></td>
<td>
<?php if(!empty($ai['last_in_date'])): ?>
<?= h(date("M d, Y", strtotime($ai['last_in_date']))) ?>
<?php else: ?>—<?php endif; ?>
</td>
<td><span class="badge bg-secondary">AGING</span></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<?php endif; ?>
</div>
<div class="modal-footer">
<button class="btn btn-outline-dark" data-bs-dismiss="modal">Close</button>
<a class="btn btn-dark" href="#stockTable">Go to table</a>
</div>
</div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Collect all unique product names once from the page
const allProducts = [
  <?php 
  $unique = [];
  foreach ($productsRows as $p) {
    $label = $p['variety'].' - '.$p['grade'];
    if (!in_array($label, $unique)) $unique[] = $label;
  }
  echo "'" . implode("','", array_map(fn($s) => addslashes($s), $unique)) . "'";
  ?>
];

const searchInput = document.getElementById('searchInput');
const suggestionsBox = document.getElementById('searchSuggestions');
const searchWrapper = document.querySelector('.search-wrapper');
let selectedIndex = -1;

// Render suggestions
function renderSuggestions(list, query) {
  suggestionsBox.innerHTML = '';
  if (list.length === 0 || query.trim() === '') {
    suggestionsBox.classList.add('d-none');
    return;
  }
  suggestionsBox.classList.remove('d-none');
  selectedIndex = -1;

  list.forEach((name, idx) => {
    const regex = new RegExp(`(${escapeRegex(query)})`, 'gi');
    const highlighted = name.replace(regex, '<span class="suggestion-match">$1</span>');
    const item = document.createElement('button');
    item.type = 'button';
    item.className = 'list-group-item list-group-item-action';
    item.dataset.value = name;
    item.innerHTML = highlighted;
    item.addEventListener('click', () => {
      searchInput.value = name;
      suggestionsBox.classList.add('d-none');
      searchInput.form.submit(); // Auto-submit on click
    });
    suggestionsBox.appendChild(item);
  });
}

function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// As-you-type filtering
searchInput.addEventListener('input', () => {
  const q = searchInput.value.trim().toLowerCase();
  if (q.length < 1) {
    suggestionsBox.classList.add('d-none');
    return;
  }
  const matches = allProducts.filter(name => name.toLowerCase().includes(q)).slice(0, 8);
  renderSuggestions(matches, q);
});

// Keyboard navigation
searchInput.addEventListener('keydown', e => {
  const items = suggestionsBox.querySelectorAll('.list-group-item');
  if (e.key === 'ArrowDown') {
    e.preventDefault();
    selectedIndex = Math.min(selectedIndex + 1, items.length - 1);
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    selectedIndex = Math.max(selectedIndex - 1, 0);
  } else if (e.key === 'Enter') {
    if (selectedIndex >= 0 && items[selectedIndex]) {
      e.preventDefault();
      searchInput.value = items[selectedIndex].dataset.value;
      suggestionsBox.classList.add('d-none');
      searchInput.form.submit();
    }
    return;
  } else if (e.key === 'Escape') {
    suggestionsBox.classList.add('d-none');
    searchInput.blur();
    return;
  }

  items.forEach((el, i) => {
    el.classList.toggle('active', i === selectedIndex);
  });
});

// ✅ Close suggestions on OUTSIDE click
document.addEventListener('click', e => {
  if (!searchWrapper.contains(e.target)) {
    suggestionsBox.classList.add('d-none');
  }
});

// Keep open when clicking inside the dropdown
suggestionsBox.addEventListener('click', e => {
  e.stopPropagation();
});

<?php if($autoModal): ?>

document.addEventListener("DOMContentLoaded", function () {
const modalEl = document.getElementById("<?= $autoModal ?>");
if(modalEl){
const modal = new bootstrap.Modal(modalEl);
modal.show();
}
});
</script>
<?php endif; ?>

</body>
</html>
