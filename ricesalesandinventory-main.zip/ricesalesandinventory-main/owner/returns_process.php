<?php
session_start();
if(!isset($_SESSION['user_id'])){ header("Location: ../login.php"); exit; }
if(strtolower($_SESSION['role'] ?? '') !== 'owner'){ header("Location: ../login.php"); exit; }

$username = $_SESSION['username'] ?? 'Owner';
include '../config/db.php';

if(empty($_SESSION['csrf_token'])){
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = (string)$_SESSION['csrf_token'];

function require_csrf_or_redirect(string $target): void {
  $posted = (string)($_POST['csrf_token'] ?? '');
  $stored = (string)($_SESSION['csrf_token'] ?? '');
  if($posted === '' || $stored === '' || !hash_equals($stored, $posted)){
    header("Location: {$target}?error=" . urlencode("Invalid request token. Please refresh and try again."));
    exit;
  }
}

if(isset($_POST['return_id'], $_POST['action'])){
  require_csrf_or_redirect('returns_process.php');
  $return_id = (int)$_POST['return_id'];
  $action = strtolower((string)$_POST['action']);

  $stmt = $conn->prepare("SELECT product_id, qty_returned, status FROM returns WHERE return_id = ?");
  $stmt->bind_param("i", $return_id);
  $stmt->execute();
  $ret = $stmt->get_result()->fetch_assoc();
  $stmt->close();

  if($ret && strtolower((string)$ret['status']) === 'pending'){
    if($action === 'approve'){
      $stmt = $conn->prepare("UPDATE returns SET status='APPROVED' WHERE return_id=?");
      $stmt->bind_param("i", $return_id);
      $stmt->execute();
      $stmt->close();

      $note = "Approved return #{$return_id}";
      $stmt = $conn->prepare("
        INSERT INTO inventory_transactions
        (product_id, qty_kg, reference_id, reference_type, type, note, created_at)
        VALUES (?, ?, ?, 'return', 'in', ?, NOW())
      ");
      $stmt->bind_param("idis", $ret['product_id'], $ret['qty_returned'], $return_id, $note);
      $stmt->execute();
      $stmt->close();
    }

    if($action === 'reject'){
      $stmt = $conn->prepare("UPDATE returns SET status='REJECTED' WHERE return_id=?");
      $stmt->bind_param("i", $return_id);
      $stmt->execute();
      $stmt->close();
    }

    $type = ($action === 'approve') ? 'RETURN_APPROVED' : 'RETURN_REJECTED';
    $desc = strtoupper($type) . " for Return #{$return_id}";
    $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, activity_type, description, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("iss", $_SESSION['user_id'], $type, $desc);
    $stmt->execute();
    $stmt->close();
  }

  header("Location: returns_process.php");
  exit;
}

$status = trim($_GET['status'] ?? 'pending');
$allowed = ['all','pending','approved','rejected','completed','refunded'];
if(!in_array(strtolower($status), $allowed, true)) $status = 'pending';

$where = "";
if(strtolower($status) !== 'all'){
  $s = $conn->real_escape_string($status);
  $where = " WHERE LOWER(r.status) = '$s' ";
}

$summary = $conn->query("
  SELECT
    SUM(CASE WHEN LOWER(status)='pending' THEN 1 ELSE 0 END) AS pending_cnt,
    SUM(CASE WHEN LOWER(status)='approved' THEN 1 ELSE 0 END) AS approved_cnt,
    SUM(CASE WHEN LOWER(status)='rejected' THEN 1 ELSE 0 END) AS rejected_cnt
  FROM returns
")->fetch_assoc();

$res = $conn->query("
  SELECT r.return_id, r.sale_id, r.qty_returned, r.reason, r.return_date, r.status,
         p.variety, p.grade,
         CONCAT(c.first_name,' ',c.last_name) AS customer
  FROM returns r
  LEFT JOIN products p ON p.product_id=r.product_id
  LEFT JOIN sales s ON s.sale_id=r.sale_id
  LEFT JOIN customers c ON c.customer_id=s.customer_id
  $where
  ORDER BY r.return_date DESC, r.return_id DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Process Returns | DE ORO HIYS</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="../css/layout.css" rel="stylesheet">
<link href="../css/owner-returns-report.css" rel="stylesheet">
<link href="../css/owner-mobile.css" rel="stylesheet">
</head>
<body>
<?php
$profileLink = 'profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>
<div class="container-fluid">
<div class="row">
<?php include '../includes/owner_sidebar.php'; ?>
<main class="col-lg-10 ms-sm-auto px-4 main-content">
<div class="py-4">
  <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
    <div>
      <h3 class="fw-bold mb-1">Process Returns</h3>
      <div class="text-muted">Approve or reject pending returns.</div>
    </div>
    <a class="btn btn-outline-dark" href="returns_report.php"><i class="fa-solid fa-chart-column me-1"></i> Open Report</a>
  </div>

  <div class="row g-3 mb-3">
    <div class="col-12 col-md-4"><div class="card modern-card card-kpi h-100"><div class="card-body"><div class="kpi-label">Pending</div><div class="kpi-value"><?= (int)($summary['pending_cnt'] ?? 0) ?></div></div></div></div>
    <div class="col-12 col-md-4"><div class="card modern-card card-kpi h-100"><div class="card-body"><div class="kpi-label">Approved</div><div class="kpi-value"><?= (int)($summary['approved_cnt'] ?? 0) ?></div></div></div></div>
    <div class="col-12 col-md-4"><div class="card modern-card card-kpi h-100"><div class="card-body"><div class="kpi-label">Rejected</div><div class="kpi-value"><?= (int)($summary['rejected_cnt'] ?? 0) ?></div></div></div></div>
  </div>

  <div class="card modern-card">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-striped align-middle mb-0">
          <thead class="table-dark">
            <tr>
              <th>Date</th><th>Return ID</th><th>Sale ID</th><th>Customer</th><th>Product</th><th class="text-end">Qty (kg)</th><th>Status</th><th>Reason</th><th>Action</th>
            </tr>
          </thead>
          <tbody>
          <?php if($res && $res->num_rows>0): ?>
            <?php while($r=$res->fetch_assoc()): ?>
              <?php $st = strtolower(trim($r['status'] ?? 'pending')); ?>
              <tr>
                <td><?= $r['return_date'] ? htmlspecialchars(date("M d, Y", strtotime($r['return_date']))) : '—' ?></td>
                <td class="fw-semibold">#<?= (int)$r['return_id'] ?></td>
                <td>#<?= (int)$r['sale_id'] ?></td>
                <td><?= htmlspecialchars($r['customer'] ?: '—') ?></td>
                <td><?= htmlspecialchars(trim(($r['variety'] ?? 'N/A')." - ".($r['grade'] ?? ''))) ?></td>
                <td class="text-end fw-bold"><?= number_format((float)$r['qty_returned'],2) ?></td>
                <td><span class="badge <?= $st==='pending' ? 'bg-warning text-dark' : ($st==='approved' ? 'bg-success' : 'bg-danger') ?>"><?= strtoupper($st) ?></span></td>
                <td><?= htmlspecialchars($r['reason'] ?? '') ?></td>
                <td>
                  <?php if($st === 'pending'): ?>
                  <form method="POST" class="d-flex gap-1">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
                    <input type="hidden" name="return_id" value="<?= (int)$r['return_id'] ?>">
                    <button type="submit" name="action" value="approve" class="btn btn-sm btn-success">Approve</button>
                    <button type="submit" name="action" value="reject" class="btn btn-sm btn-danger">Reject</button>
                  </form>
                  <?php else: ?>
                  —
                  <?php endif; ?>
                </td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr><td colspan="9" class="text-center text-muted">No returns found.</td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</main>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
