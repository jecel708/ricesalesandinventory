<?php

session_start();
if(!isset($_SESSION['user_id'])){ header("Location: ../login.php"); exit; }
if(strtolower($_SESSION['role'] ?? '') !== 'owner'){ header("Location: ../login.php"); exit; }

include "../config/db.php";

$username = $_SESSION['username'] ?? 'Owner';
$owner_id = (int)$_SESSION['user_id'];

$success = "";
$error   = "";

if(empty($_SESSION['csrf_token'])){
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = (string)$_SESSION['csrf_token'];

function csrf_ok(): bool {
  $posted = (string)($_POST['csrf_token'] ?? '');
  $stored = (string)($_SESSION['csrf_token'] ?? '');
  return ($posted !== '' && $stored !== '' && hash_equals($stored, $posted));
}

function tableExists(mysqli $conn, string $table): bool {
  $tableEsc = $conn->real_escape_string($table);
  $dbRes = $conn->query("SELECT DATABASE() AS dbname");
  $db = $dbRes ? ($dbRes->fetch_assoc()['dbname'] ?? '') : '';
  $dbEsc = $conn->real_escape_string($db);
  $q = $conn->query("
    SELECT 1 FROM information_schema.TABLES
    WHERE TABLE_SCHEMA = '$dbEsc' AND TABLE_NAME = '$tableEsc' LIMIT 1
  ");
  return $q && $q->num_rows > 0;
}

function columnExists(mysqli $conn, string $table, string $column): bool {
  $tableEsc = $conn->real_escape_string($table);
  $colEsc = $conn->real_escape_string($column);
  $dbRes = $conn->query("SELECT DATABASE() AS dbname");
  $db = $dbRes ? ($dbRes->fetch_assoc()['dbname'] ?? '') : '';
  $dbEsc = $conn->real_escape_string($db);
  $q = $conn->query("
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = '$dbEsc' AND TABLE_NAME = '$tableEsc' AND COLUMN_NAME = '$colEsc' LIMIT 1
  ");
  return $q && $q->num_rows > 0;
}

function f($v): float { return (float)($v ?? 0); }

// ✅ CHECK COLUMNS FIRST
$hasApproved = columnExists($conn, "account_payable", "approved");
$hasApprovedBy = columnExists($conn, "account_payable", "approved_by");
$hasApprovedAt = columnExists($conn, "account_payable", "approved_at");
$hasRejected = columnExists($conn, "account_payable", "rejected");
$hasRejectedBy = columnExists($conn, "account_payable", "rejected_by");
$hasRejectedAt = columnExists($conn, "account_payable", "rejected_at");

$hasSupplierPayments = tableExists($conn, "supplier_payments");


if($_SERVER['REQUEST_METHOD'] === 'POST'){
  if(isset($_POST['approve_ap']) || isset($_POST['reject_ap']) || isset($_POST['pay_ap'])){
    if(!csrf_ok()){
      $error = "Invalid request token. Please refresh the page and try again.";
    }
  }

  if($error === "" && isset($_POST['approve_ap'])){
    if(!$hasApproved){
      $error = "Approval feature not available yet (missing 'approved' column). Run the SQL setup first.";
    } else {
      $ap_id = (int)($_POST['ap_id'] ?? 0);
      if($ap_id <= 0){
        $error = "Invalid request (AP ID).";
      } else {
        $sql = "UPDATE account_payable
                SET approved=1,
                    balance=GREATEST(COALESCE(total_amount,0)-COALESCE(amount_paid,0),0),
                    status=CASE
                      WHEN GREATEST(COALESCE(total_amount,0)-COALESCE(amount_paid,0),0) <= 0 THEN 'paid'
                      WHEN COALESCE(amount_paid,0) > 0 THEN 'partial'
                      ELSE 'unpaid'
                    END";
        if($hasApprovedBy) $sql .= ", approved_by=?";
        if($hasApprovedAt) $sql .= ", approved_at=NOW()";
        if($hasRejected) $sql .= ", rejected=0";
        if($hasRejectedBy) $sql .= ", rejected_by=NULL";
        if($hasRejectedAt) $sql .= ", rejected_at=NULL";
        $sql .= " WHERE ap_id=?";

        $stmt = $conn->prepare($sql);
        if(!$stmt){
          $error = "DB Error: ".$conn->error;
        } else {
          if($hasApprovedBy){
            $stmt->bind_param("ii", $owner_id, $ap_id);
          } else {
            $stmt->bind_param("i", $ap_id);
          }
          if($stmt->execute()){
            $success = "✅ Payable Approved Successfully.";
          } else {
            $error = "❌ Failed to approve payable.";
          }
          $stmt->close();
        }
      }
    }
  }

  if($error === "" && isset($_POST['reject_ap'])){
    if(!$hasRejected){
      $error = "Reject feature not available yet (missing 'rejected' column). Run the SQL setup first.";
    } else {
      $ap_id = (int)($_POST['ap_id'] ?? 0);
      $reason = trim($_POST['reject_reason'] ?? '');
      if($ap_id <= 0){
        $error = "Invalid request (AP ID).";
      } else {
        $sql = "UPDATE account_payable SET rejected=1, balance=0, status='pending'";
        if($hasRejectedBy) $sql .= ", rejected_by=?";
        if($hasRejectedAt) $sql .= ", rejected_at=NOW()";
        if($hasApproved) $sql .= ", approved=0";
        if($hasApprovedBy) $sql .= ", approved_by=NULL";
        if($hasApprovedAt) $sql .= ", approved_at=NULL";
        $sql .= " WHERE ap_id=?";

        $stmt = $conn->prepare($sql);
        if(!$stmt){
          $error = "DB Error: ".$conn->error;
        } else {
          if($hasRejectedBy){
            $stmt->bind_param("ii", $owner_id, $ap_id);
          } else {
            $stmt->bind_param("i", $ap_id);
          }
          if($stmt->execute()){
            $success = "❌ Payable Rejected." . ($reason ? " Reason: {$reason}" : "");
          } else {
            $error = "❌ Failed to reject payable.";
          }
          $stmt->close();
        }
      }
    }
  }
  if($error === "" && isset($_POST['pay_ap'])){
    $ap_id       = (int)($_POST['ap_id'] ?? 0);
    $amount       = (float)($_POST['amount'] ?? 0);
    $method       = strtolower(trim($_POST['method'] ?? 'cash'));
    $reference_no = trim($_POST['reference_no'] ?? '');
    $note         = trim($_POST['note'] ?? '');

    if($ap_id <= 0){
      $error = "Please select a payable.";
    } elseif($amount <= 0){
      $error = "Payment amount must be greater than 0.";
    } elseif(!in_array($method, ['cash','gcash','bank'])){
      $error = "Invalid payment method.";
    } else {
      $select = "SELECT ap_id, purchase_id, supplier_id, total_amount, amount_paid, balance, due_date, status";
      if($hasApproved) $select .= ", approved";
      if($hasRejected) $select .= ", rejected";
      $select .= " FROM account_payable WHERE ap_id=? LIMIT 1";

      $stmt = $conn->prepare($select);
      if(!$stmt){
        $error = "DB Error: ".$conn->error;
      } else {
        $stmt->bind_param("i", $ap_id);
        $stmt->execute();
        $ap = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if(!$ap){
          $error = "Payable not found.";
        } else {
          $isApproved = !$hasApproved || (int)($ap['approved'] ?? 0) === 1;
          $isRejected = $hasRejected && (int)($ap['rejected'] ?? 0) === 1;

          if($isRejected){
            $error = "❌ Cannot pay — this payable has been REJECTED.";
          } elseif(!$isApproved){
            $error = "⚠️ This payable is not approved yet.";
          } else {
            $balance = f($ap['balance']);
            if($amount > $balance){
              $error = "⚠️ Payment cannot exceed balance (₱".number_format($balance,2).").";
            } else {
              $conn->begin_transaction();
              try {
                // Log payment
                if($hasSupplierPayments){
                  $purchase_id = (int)($ap['purchase_id'] ?? 0);
                  $supplier_id = (int)($ap['supplier_id'] ?? 0);

                  $stmtPay = $conn->prepare("
                    INSERT INTO supplier_payments
                      (ap_id, purchase_id, supplier_id, amount, method, reference_no, paid_at, paid_by, note, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, NOW(), ?, ?, NOW())
                  ");
                  if(!$stmtPay) throw new Exception("Prepare failed: ".$conn->error);
                  $stmtPay->bind_param("iiidssis", $ap_id, $purchase_id, $supplier_id, $amount, $method, $reference_no, $owner_id, $note);
                  if(!$stmtPay->execute()) throw new Exception("Insert payment failed.");
                  $stmtPay->close();
                }

                // Update AP balances
                $new_paid    = f($ap['amount_paid']) + $amount;
                $new_balance = f($ap['balance']) - $amount;
                $new_status  = ($new_balance <= 0.00001) ? 'paid' : (($new_paid > 0) ? 'partial' : 'unpaid');
                if($new_balance <= 0) $new_balance = 0;

                $stmtUp = $conn->prepare("
                  UPDATE account_payable SET amount_paid=?, balance=?, status=? WHERE ap_id=?
                ");
                if(!$stmtUp) throw new Exception("Prepare failed: ".$conn->error);
                $stmtUp->bind_param("ddsi", $new_paid, $new_balance, $new_status, $ap_id);
                if(!$stmtUp->execute()) throw new Exception("Update payable failed.");
                $stmtUp->close();

                $conn->commit();
                $success = "✅ Payment Recorded. New Balance: ₱".number_format($new_balance,2)
                          .(!$hasSupplierPayments ? " (Note: Payment log skipped — table not found.)" : "");
              } catch(Exception $e){
                $conn->rollback();
                $error = "❌ Failed: ".$e->getMessage();
              }
            }
          }
        }
      }
    }
  }
}

// ==========================================
// FILTERS & SEARCH
// ==========================================
$filter = strtolower(trim($_GET['filter'] ?? 'open'));
$allowedFilters = ['open','to_pay','unapproved','overdue','paid','all','rejected'];
if(!in_array($filter, $allowedFilters, true)) $filter = 'open';

$search = trim($_GET['q'] ?? '');
$searchLike = '%'.$conn->real_escape_string($search).'%';

$page = (int)($_GET['page'] ?? 1);
if($page < 1) $page = 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

$where = "1=1";
if($filter === 'open'){
  $where .= " AND ap.status IN ('unpaid','partial','overdue')";
  if($hasRejected) $where .= " AND (ap.rejected=0 OR ap.rejected IS NULL)";
} elseif($filter === 'to_pay'){
  if($hasApproved) $where .= " AND ap.approved=1";
  if($hasRejected) $where .= " AND (ap.rejected=0 OR ap.rejected IS NULL)";
  $where .= " AND ap.balance > 0 AND ap.status <> 'paid'
              AND ap.status <> 'overdue'
              AND (ap.due_date IS NULL OR ap.due_date >= CURDATE())";
} elseif($filter === 'unapproved'){
  if($hasApproved){
    $where .= " AND ap.approved = 0 AND ap.status <> 'paid'";
    if($hasRejected) $where .= " AND (ap.rejected=0 OR ap.rejected IS NULL)";
  }
} elseif($filter === 'overdue'){
  $where .= " AND (ap.status='overdue' OR (ap.due_date IS NOT NULL AND ap.due_date < CURDATE() AND ap.status <> 'paid'))";
  if($hasRejected) $where .= " AND (ap.rejected=0 OR ap.rejected IS NULL)";
  if($hasApproved) $where .= " AND ap.approved=1";
} elseif($filter === 'paid'){
  $where .= " AND ap.status='paid'";
} elseif($filter === 'rejected' && $hasRejected){
  $where .= " AND ap.rejected = 1";
}

if($search !== ''){
  $where .= " AND (sup.name LIKE '$searchLike' OR ap.ap_id LIKE '$searchLike' OR ap.purchase_id LIKE '$searchLike')";
}

// ==========================================
// ✅ FIXED: SUMMARY STATS
// ==========================================
$approvedPayableCondition = $hasApproved ? "ap.approved=1" : "1=1";
if($hasRejected){
  $approvedPayableCondition .= " AND (ap.rejected=0 OR ap.rejected IS NULL)";
}

$sumSelect = "
  SELECT
    IFNULL(SUM(CASE WHEN {$approvedPayableCondition} THEN ap.total_amount ELSE 0 END),0) AS total_ap,
    IFNULL(SUM(CASE WHEN {$approvedPayableCondition} THEN ap.balance ELSE 0 END),0) AS balance_ap,
    SUM(CASE WHEN {$approvedPayableCondition} AND ap.status='unpaid' THEN 1 ELSE 0 END) AS cnt_unpaid,
    SUM(CASE WHEN {$approvedPayableCondition} AND ap.status='partial' THEN 1 ELSE 0 END) AS cnt_partial,
    SUM(CASE WHEN {$approvedPayableCondition} AND ap.status='paid' THEN 1 ELSE 0 END) AS cnt_paid,
    SUM(CASE WHEN {$approvedPayableCondition} AND (ap.status='overdue' OR (ap.due_date IS NOT NULL AND ap.due_date < CURDATE() AND ap.status <> 'paid')) THEN 1 ELSE 0 END) AS cnt_overdue
";
if($hasApproved){
  if($hasRejected){
    $sumSelect .= ", SUM(CASE WHEN ap.approved=0 AND ap.status <> 'paid' AND (ap.rejected=0 OR ap.rejected IS NULL) THEN 1 ELSE 0 END) AS cnt_unapproved";
  } else {
    $sumSelect .= ", SUM(CASE WHEN ap.approved=0 AND ap.status <> 'paid' THEN 1 ELSE 0 END) AS cnt_unapproved";
  }
} else {
  $sumSelect .= ", 0 AS cnt_unapproved";
}
if($hasRejected){
  $sumSelect .= ", SUM(CASE WHEN ap.rejected=1 THEN 1 ELSE 0 END) AS cnt_rejected";
} else {
  $sumSelect .= ", 0 AS cnt_rejected";
}

$summary = $conn->query("$sumSelect FROM account_payable ap LEFT JOIN suppliers sup ON ap.supplier_id = sup.supplier_id")->fetch_assoc() ?? [];
$total_ap = f($summary['total_ap']);
$bal_ap   = f($summary['balance_ap']);

// ==========================================
// ✅ GET PAYABLES LIST
// ==========================================
$listSelect = "
  SELECT ap.ap_id, ap.purchase_id, ap.supplier_id, ap.total_amount, ap.amount_paid, ap.balance, ap.due_date, ap.status, ap.created_at, sup.name AS supplier_name
";
if($hasApproved) $listSelect .= ", ap.approved";
if($hasRejected) $listSelect .= ", ap.rejected";

$listSql = "$listSelect FROM account_payable ap LEFT JOIN suppliers sup ON ap.supplier_id = sup.supplier_id WHERE $where ORDER BY ap.created_at DESC LIMIT $perPage OFFSET $offset";
$payables = $conn->query($listSql);

// Pagination
$countRes = $conn->query("SELECT COUNT(*) AS cnt FROM account_payable ap LEFT JOIN suppliers sup ON ap.supplier_id = sup.supplier_id WHERE $where")->fetch_assoc();
$totalRows = (int)($countRes['cnt'] ?? 0);
$totalPages = (int)ceil($totalRows / $perPage);

// ==========================================
// ✅ AJAX LIVE UPDATE
// ==========================================
if (isset($_GET['ajax']) && $_GET['ajax'] === 'live') {
  header('Content-Type: application/json; charset=utf-8');
  $payableRows = [];
  if ($payables) {
    while ($row = $payables->fetch_assoc()) {
      $status = strtolower((string)($row['status'] ?? 'unpaid'));
      $due = (string)($row['due_date'] ?? '');
      $approved = $hasApproved ? ((int)($row['approved'] ?? 0) === 1) : true;
      $rejected = $hasRejected ? ((int)($row['rejected'] ?? 0) === 1) : false;
      $balance = (!$approved || $rejected) ? 0.0 : f($row['balance']);
      if (!$approved && !$rejected) {
        $status = 'pending';
      }
      $isDuePast = ($approved && !$rejected && $due !== '' && $status !== 'paid')
        ? (strtotime($due) < strtotime(date('Y-m-d')))
        : false;

      $payableRows[] = [
        'ap_id' => (int)($row['ap_id'] ?? 0),
        'supplier_name' => (string)($row['supplier_name'] ?? 'N/A'),
        'purchase_id' => (int)($row['purchase_id'] ?? 0),
        'total_amount' => f($row['total_amount']),
        'amount_paid' => f($row['amount_paid']),
        'balance' => $balance,
        'due_date' => $due,
        'status' => $status,
        'is_due_past' => $isDuePast,
        'approved' => $approved,
        'rejected' => $rejected,
      ];
    }
  }
  echo json_encode([
    'ok' => true,
    'summary' => [
      'total_ap' => $total_ap, 'bal_ap' => $bal_ap,
      'cnt_unpaid' => (int)($summary['cnt_unpaid'] ?? 0),
      'cnt_partial' => (int)($summary['cnt_partial'] ?? 0),
      'cnt_paid' => (int)($summary['cnt_paid'] ?? 0),
      'cnt_overdue' => (int)($summary['cnt_overdue'] ?? 0),
      'cnt_unapproved' => (int)($summary['cnt_unapproved'] ?? 0),
      'cnt_rejected' => (int)($summary['cnt_rejected'] ?? 0),
    ],
    'rows' => $payableRows,
    'pagination' => ['total_rows' => $totalRows, 'page' => $page, 'per_page' => $perPage, 'total_pages' => $totalPages, 'filter' => $filter, 'search' => $search],
  ]);
  exit;
}

// ==========================================
// VIEW PAYMENT HISTORY
// ==========================================
$view_ap_id = (int)($_GET['view'] ?? 0);
$viewAP = $viewPayments = null;
if($view_ap_id > 0){
  $sel = "SELECT ap.*, sup.name AS supplier_name FROM account_payable ap LEFT JOIN suppliers sup ON ap.supplier_id=sup.supplier_id WHERE ap.ap_id=? LIMIT 1";
  $stmtV = $conn->prepare($sel);
  if($stmtV){
    $stmtV->bind_param("i", $view_ap_id);
    $stmtV->execute();
    $viewAP = $stmtV->get_result()->fetch_assoc();
    $stmtV->close();
  }
  if($hasSupplierPayments && $viewAP){
    $stmtP = $conn->prepare("SELECT sp.* FROM supplier_payments sp WHERE sp.ap_id=? ORDER BY sp.paid_at DESC LIMIT 50");
    if($stmtP){
      $stmtP->bind_param("i", $view_ap_id);
      $stmtP->execute();
      $viewPayments = $stmtP->get_result();
      $stmtP->close();
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Supplier Payables | Owner</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

<link href="../css/layout.css" rel="stylesheet">
<link href="../css/owner-supplier-payables.css" rel="stylesheet">
<link href="../css/owner-mobile.css" rel="stylesheet">

<style>
.table { border-radius: 0.5rem; overflow: hidden; }
.table th { border-top: none !important; white-space: nowrap; }
.table td { vertical-align: middle; padding: 0.75rem 0.5rem !important; }
.table-striped tbody tr:nth-of-type(odd) { background-color: rgba(0,0,0,0.015); }
.table-hover tbody tr:hover { background-color: rgba(13,110,253,0.04); }
.badge { font-weight: 500; padding: 0.35em 0.65em; font-size: 0.78rem; }
.badge-unpaid { background-color: #dc3545; color: #fff; }
.badge-partial { background-color: #ffc107; color: #000; }
.badge-paid { background-color: #198754; color: #fff; }
.badge-pending { background-color: #fd7e14; color: #fff; }
.badge-overdue { background-color: #b02a37; color: #fff; }
.badge-approved { background-color: #198754; color: #fff; }
.badge-unapproved { background-color: #fd7e14; color: #fff; }
.badge-rejected { background-color: #212529; color: #fff; }
.btn-sm { padding: 0.2rem 0.45rem; font-size: 0.8rem; }
tr.table-secondary td { background-color: #f8f9fa !important; color: #6c757d; }
.setup-alert { background: #fff3cd; border-left: 4px solid #ffc107; }
.modal-payment .modal-header { background: #0d6efd; color: #fff; }
.modal-payment .btn-primary { background: #0d6efd; border-color: #0d6efd; }
</style>
</head>
<body>

<?php
$profileLink = 'profile.php';
$logoutLink = '../logout.php';
include '../includes/topnav.php';
?>

<div class="container-fluid">
<div class="row">

<?php include '../includes/owner_sidebar.php'; ?>

<main class="col-lg-10 ms-sm-auto px-4 main-content">
<div class="py-4">

  <?php if($success): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <i class="fa-solid fa-circle-check me-2"></i><?= htmlspecialchars($success) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>
  <?php if($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <i class="fa-solid fa-circle-exclamation me-2"></i><?= htmlspecialchars($error) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <?php if(!$hasApproved || !$hasRejected): ?>
    <div class="alert setup-alert mb-4">
      <i class="fa-solid fa-triangle-exclamation me-2"></i>
      <strong>Setup Needed:</strong>
      <?php if(!$hasApproved): ?> Approval columns missing. <?php endif; ?>
      <?php if(!$hasRejected): ?> Reject columns missing. <?php endif; ?>
      Run the SQL query provided in the file comments to enable Approve/Reject features.
    </div>
  <?php endif; ?>

  <!-- KPI CARDS -->
  <div class="row g-3 mb-4" id="apSummaryRow">
    <div class="col-12 col-md-6 col-xl-3">
      <div class="card modern-card card-kpi h-100 border-0 shadow-sm">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-start gap-3">
            <div class="flex-grow-1 min-w-0">
              <div class="kpi-label text-muted small">Total Payables</div>
              <div class="kpi-value fs-4 fw-bold">₱<?= number_format($total_ap,2) ?></div>
              <div class="kpi-sub small text-muted">Approved supplier purchases</div>
            </div>
            <span class="kpi-icon text-primary fs-4"><i class="fa-solid fa-coins"></i></span>
          </div>
        </div>
      </div>
    </div>
    <div class="col-12 col-md-6 col-xl-3">
      <div class="card modern-card card-kpi h-100 border-0 shadow-sm">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-start gap-3">
            <div class="flex-grow-1 min-w-0">
              <div class="kpi-label text-muted small">Outstanding Balance</div>
              <div class="kpi-value fs-4 fw-bold text-danger">₱<?= number_format($bal_ap,2) ?></div>
              <div class="kpi-sub small text-muted">Unpaid + Partial</div>
            </div>
            <span class="kpi-icon text-danger fs-4"><i class="fa-solid fa-hand-holding-dollar"></i></span>
          </div>
        </div>
      </div>
    </div>
    <div class="col-12 col-md-6 col-xl-3">
      <div class="card modern-card card-kpi h-100 border-0 shadow-sm">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-start gap-3">
            <div class="flex-grow-1 min-w-0">
              <div class="kpi-label text-muted small">Overdue</div>
              <div class="kpi-value fs-4 fw-bold text-danger"><?= (int)($summary['cnt_overdue'] ?? 0) ?></div>
              <div class="kpi-sub small text-muted">Needs attention</div>
            </div>
            <span class="kpi-icon text-danger fs-4"><i class="fa-solid fa-triangle-exclamation"></i></span>
          </div>
        </div>
      </div>
    </div>
    <div class="col-12 col-md-6 col-xl-3">
      <div class="card modern-card card-kpi h-100 border-0 shadow-sm">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-start gap-3">
            <div class="flex-grow-1 min-w-0">
              <div class="kpi-label text-muted small">Pending Approval</div>
              <div class="kpi-value fs-4 fw-bold text-warning"><?= (int)($summary['cnt_unapproved'] ?? 0) ?></div>
              <div class="kpi-sub small text-muted">Requires review</div>
            </div>
            <span class="kpi-icon text-warning fs-4"><i class="fa-solid fa-clock"></i></span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- FILTERS & SEARCH -->
  <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
    <div>
      <h4 class="fw-bold mb-0">Accounts Payable List</h4>
      <div class="small-muted">Workflow: <b>Approve</b> → <b>Pay</b> OR <b>Reject</b> to decline.</div>
    </div>
    <form method="GET" class="d-flex flex-wrap gap-2 align-items-center">
      <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
      <div class="input-group">
        <span class="input-group-text bg-white"><i class="fa-solid fa-magnifying-glass"></i></span>
        <input type="text" name="q" class="form-control" placeholder="Search supplier / AP #" value="<?= htmlspecialchars($search) ?>">
      </div>
      <button class="btn btn-dark" type="submit"><i class="fa-solid fa-search me-1"></i>Search</button>
      <a class="btn btn-outline-secondary" href="supplier_payables.php"><i class="fa-solid fa-rotate-left me-1"></i>Reset</a>
    </form>
  </div>

  <!-- FILTER PILLS -->
  <div class="mb-3">
    <div class="nav nav-pills gap-2 flex-wrap">
      <a class="nav-link <?= $filter==='unapproved'?'active':'' ?>" href="?filter=unapproved&q=<?= urlencode($search) ?>">Pending Approval</a>
      <a class="nav-link <?= $filter==='to_pay'?'active':'' ?>" href="?filter=to_pay&q=<?= urlencode($search) ?>">Approved / To Pay</a>
      <a class="nav-link <?= $filter==='overdue'?'active':'' ?>" href="?filter=overdue&q=<?= urlencode($search) ?>">Overdue</a>
      <?php if($hasRejected): ?>
      <a class="nav-link <?= $filter==='rejected'?'active':'' ?>" href="?filter=rejected&q=<?= urlencode($search) ?>">Rejected</a>
      <?php endif; ?>
      <a class="nav-link <?= $filter==='paid'?'active':'' ?>" href="?filter=paid&q=<?= urlencode($search) ?>">Paid</a>
    </div>
  </div>

  <!-- MAIN TABLE -->
  <div class="card modern-card border-0 shadow-sm" id="apTableCard">
    <div class="card-body p-0 table-responsive ap-table-scroll">
      <table class="table table-striped table-hover mb-0 align-middle">
        <thead class="table-dark">
          <tr>
            <th class="text-center" style="width:70px;">AP #</th>
            <th>Supplier</th>
            <th class="text-center" style="width:110px;">Purchase #</th>
            <th class="text-end" style="width:130px;">Total</th>
            <th class="text-end" style="width:130px;">Paid</th>
            <th class="text-end" style="width:130px;">Balance</th>
            <th class="text-center" style="width:110px;">Due Date</th>
            <th class="text-center" style="width:100px;">Status</th>
            <?php if($hasApproved || $hasRejected): ?>
            <th class="text-center" style="width:110px;">Approval</th>
            <?php endif; ?>
            <th class="text-center" style="width:240px;">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if($payables && $payables->num_rows > 0): ?>
            <?php while($row = $payables->fetch_assoc()): ?>
              <?php
                $ap_id = (int)$row['ap_id'];
                $supplierName = $row['supplier_name'] ?? 'N/A';
                $status = strtolower($row['status'] ?? 'unpaid');
                $due = $row['due_date'] ?? '';

                // Determine approval before calculating the payable balance.
                $approved = $hasApproved ? ((int)($row['approved'] ?? 0) === 1) : true;
                $rejected = $hasRejected ? ((int)($row['rejected'] ?? 0) === 1) : false;
                $balance = (!$approved || $rejected) ? 0.0 : f($row['balance']);
                if (!$approved && !$rejected) {
                  $status = 'pending';
                }
                $isDuePast = ($approved && !$rejected && $due && $status !== 'paid')
                  ? (strtotime($due) < strtotime(date('Y-m-d')))
                  : false;

                $statusBadge = 'badge-unpaid';
                if($status === 'pending') $statusBadge = 'badge-pending';
                elseif($status === 'paid') $statusBadge = 'badge-paid';
                elseif($status === 'partial') $statusBadge = 'badge-partial';
                elseif($isDuePast) $statusBadge = 'badge-overdue';

                if($rejected){
                  $approvalBadge = "badge-rejected";
                  $approvalText  = "REJECTED";
                } elseif($approved){
                  $approvalBadge = "badge-approved";
                  $approvalText  = "APPROVED";
                } else {
                  $approvalBadge = "badge-unapproved";
                  $approvalText  = "PENDING";
                }
              ?>
              <tr class="<?= $rejected ? 'table-secondary opacity-75' : '' ?>">
                <td class="fw-bold text-center"><?= $ap_id ?></td>
                <td><?= htmlspecialchars($supplierName) ?></td>
                <td class="text-center"><?= (int)($row['purchase_id'] ?? 0) ?></td>
                <td class="text-end">₱<?= number_format(f($row['total_amount']),2) ?></td>
                <td class="text-end">₱<?= number_format(f($row['amount_paid']),2) ?></td>
                <td class="text-end fw-bold <?= $balance>0?'text-danger':'text-success' ?>">₱<?= number_format($balance,2) ?></td>
                <td class="text-center"><?= $due ? htmlspecialchars(date('M d, Y', strtotime($due))) : '-' ?></td>
                <td class="text-center">
                  <span class="badge <?= $statusBadge ?>">
                    <?= strtoupper($isDuePast && $status!=='paid' ? 'overdue' : $status) ?>
                  </span>
                </td>
                <?php if($hasApproved || $hasRejected): ?>
                <td class="text-center">
                  <span class="badge <?= $approvalBadge ?>"><?= $approvalText ?></span>
                </td>
                <?php endif; ?>
                <td class="text-center">
                  <div class="d-flex flex-wrap gap-1 justify-content-center">
                    <!-- History Button -->
                    <a class="btn btn-sm btn-outline-dark" title="View History"
                       href="?filter=<?= urlencode($filter) ?>&q=<?= urlencode($search) ?>&page=<?= (int)$page ?>&view=<?= $ap_id ?>">
                      <i class="fa-solid fa-clock-rotate-left"></i>
                    </a>

                    <!-- APPROVE + REJECT BUTTONS -->
                    <?php if(!$rejected && !$approved && $status !== 'paid' && $hasApproved): ?>
                      <form method="POST" class="d-inline" onsubmit="return confirm('Approve this payable?');">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
                        <input type="hidden" name="ap_id" value="<?= $ap_id ?>">
                        <button class="btn btn-sm btn-success" type="submit" name="approve_ap" title="Approve">
                          <i class="fa-solid fa-check"></i> Approve
                        </button>
                      </form>

                      <?php if($hasRejected): ?>
                        <button class="btn btn-sm btn-danger" type="button" title="Reject"
                                data-bs-toggle="modal" data-bs-target="#rejectModal<?= $ap_id ?>">
                          <i class="fa-solid fa-xmark"></i> Reject
                        </button>
                      <?php endif; ?>
                    <?php endif; ?>

                    <!-- 💳 PAY BUTTON — OPENS MODAL NOW -->
                    <?php if($approved && !$rejected && $status !== 'paid' && $balance > 0): ?>
                      <button class="btn btn-sm btn-primary" type="button" title="Record Payment"
                              data-bs-toggle="modal" data-bs-target="#payModal<?= $ap_id ?>">
                        <i class="fa-solid fa-money-bill-wave"></i> Pay
                      </button>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>

            <?php endwhile; ?>
          <?php else: ?>
            <tr><td colspan="<?= ($hasApproved || $hasRejected) ? 10 : 9 ?>" class="text-center text-muted py-5">
              <i class="fa-solid fa-inbox fa-2x mb-2 d-block"></i>No payables found.
            </td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <!-- PAGINATION -->
    <div class="card-footer bg-white border-top d-flex flex-wrap justify-content-between align-items-center gap-2">
      <div class="small text-muted">
        Showing <?= min($totalRows, $offset + 1) ?>–<?= min($totalRows, $offset + $perPage) ?> of <?= $totalRows ?> results
      </div>
      <nav>
        <ul class="pagination pagination-sm mb-0">
          <?php $base = "supplier_payables.php?filter=".urlencode($filter)."&q=".urlencode($search); ?>
          <li class="page-item <?= $page<=1?'disabled':'' ?>"><a class="page-link" href="<?= $base ?>&page=<?= max(1,$page-1) ?>">Prev</a></li>
          <?php
            $start = max(1, $page - 2);
            $end = min($totalPages, $page + 2);
            for($i=$start; $i<=$end; $i++):
          ?>
            <li class="page-item <?= $i===$page?'active':'' ?>"><a class="page-link" href="<?= $base ?>&page=<?= $i ?>"><?= $i ?></a></li>
          <?php endfor; ?>
          <li class="page-item <?= $page>=$totalPages?'disabled':'' ?>"><a class="page-link" href="<?= $base ?>&page=<?= min($totalPages,$page+1) ?>">Next</a></li>
        </ul>
      </nav>
    </div>
  </div>
  <!-- PAYMENT/REJECT MODALS: outside the table to keep Bootstrap DOM valid -->
  <?php
  $modalRows = $conn->query("
    $listSelect
    FROM account_payable ap
    LEFT JOIN suppliers sup ON ap.supplier_id = sup.supplier_id
    WHERE $where
    ORDER BY ap.created_at DESC
    LIMIT $perPage OFFSET $offset
  ");
  ?>
  <?php if($modalRows): ?>
    <?php while($mrow = $modalRows->fetch_assoc()): ?>
      <?php
        $m_ap_id = (int)$mrow['ap_id'];
        $m_supplierName = $mrow['supplier_name'] ?? 'N/A';
        $m_status = strtolower($mrow['status'] ?? 'unpaid');
        $m_approved = $hasApproved ? ((int)($mrow['approved'] ?? 0) === 1) : true;
        $m_rejected = $hasRejected ? ((int)($mrow['rejected'] ?? 0) === 1) : false;
        $m_balance = (!$m_approved || $m_rejected) ? 0.0 : f($mrow['balance']);
      ?>
              <!-- ❌ REJECT MODAL -->
              <?php if(!$m_rejected && !$m_approved && $m_status !== 'paid' && $hasApproved && $hasRejected): ?>
                <div class="modal fade" id="rejectModal<?= $m_ap_id ?>" tabindex="-1">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
                        <input type="hidden" name="ap_id" value="<?= $m_ap_id ?>">
                        <div class="modal-header bg-danger text-white">
                          <h5 class="modal-title"><i class="fa-solid fa-triangle-exclamation me-2"></i>Reject Payable #<?= $m_ap_id ?></h5>
                          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                          <p>Are you sure you want to <strong>REJECT</strong> this payable?</p>
                          <p class="text-muted small">Supplier: <strong><?= htmlspecialchars($m_supplierName) ?></strong> — ₱<?= number_format(f($mrow['total_amount']),2) ?></p>
                          <div class="mb-3">
                            <label class="form-label fw-semibold">Reason (Optional)</label>
                            <textarea name="reject_reason" class="form-control" rows="3" placeholder="Enter reason..."></textarea>
                          </div>
                          <div class="alert alert-warning small mb-0">
                            <i class="fa-solid fa-info-circle me-1"></i> Rejected items cannot be paid until re-approved.
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                          <button type="submit" name="reject_ap" class="btn btn-danger">
                            <i class="fa-solid fa-xmark me-1"></i>Confirm Reject
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              <?php endif; ?>

              <!-- 💳 PAYMENT MODAL — NEW! -->
              <?php if($m_approved && !$m_rejected && $m_status !== 'paid' && $m_balance > 0): ?>
                <div class="modal fade modal-payment" id="payModal<?= $m_ap_id ?>" tabindex="-1" aria-labelledby="payModalLabel<?= $m_ap_id ?>" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                    <div class="modal-content">
                      <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
                        <input type="hidden" name="ap_id" value="<?= $m_ap_id ?>">
                        <div class="modal-header">
                          <h5 class="modal-title" id="payModalLabel<?= $m_ap_id ?>">
                            <i class="fa-solid fa-money-bill-wave me-2"></i>Record Payment — AP #<?= $m_ap_id ?>
                          </h5>
                          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                          <div class="mb-3">
                            <label class="form-label fw-semibold">Supplier</label>
                            <input type="text" class="form-control" value="<?= htmlspecialchars($m_supplierName) ?>" readonly>
                          </div>
                          <div class="mb-3">
                            <label class="form-label fw-semibold">Amount to Pay</label>
                            <input type="number" step="0.01" min="0.01" max="<?= htmlspecialchars($m_balance) ?>"
                                   name="amount" class="form-control payment-amount-input" required autofocus>
                            <div class="d-flex gap-2 mt-2">
                              <button type="button" class="btn btn-sm btn-outline-primary payment-amount-preset" data-payment-preset="half">
                                Half Balance
                              </button>
                              <button type="button" class="btn btn-sm btn-outline-primary payment-amount-preset" data-payment-preset="full">
                                Full Balance
                              </button>
                            </div>
                            <div class="form-text text-muted">Max payable: <strong>₱<?= number_format($m_balance,2) ?></strong></div>
                          </div>
                          <div class="mb-3">
                            <label class="form-label fw-semibold">Payment Method</label>
                            <select name="method" class="form-select">
                              <option value="cash">Cash</option>
                              <option value="gcash">GCash</option>
                              <option value="bank">Bank Transfer</option>
                            </select>
                          </div>
                          <div class="mb-3">
                            <label class="form-label fw-semibold">Reference Number</label>
                            <input type="text" name="reference_no" class="form-control" placeholder="Optional — e.g. receipt or transaction ID">
                          </div>
                          <div class="mb-0">
                            <label class="form-label fw-semibold">Notes / Remarks</label>
                            <textarea name="note" class="form-control" rows="2" placeholder="Optional remarks"></textarea>
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="fa-solid fa-xmark me-1"></i>Cancel
                          </button>
                          <button type="submit" name="pay_ap" class="btn btn-primary">
                            <i class="fa-solid fa-floppy-disk me-1"></i>Record Payment
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              <?php endif; ?>
    <?php endwhile; ?>
  <?php endif; ?>


</div>

<!-- PAYMENT HISTORY MODAL -->
<?php if($viewAP): ?>
<div class="modal fade show" id="historyModal" tabindex="-1" style="display:block;" aria-modal="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header bg-dark text-white">
        <h5 class="modal-title fw-bold">
          <i class="fa-solid fa-clock-rotate-left me-2"></i>
          Payment History — AP #<?= (int)$viewAP['ap_id'] ?> • <?= htmlspecialchars($viewAP['supplier_name'] ?? 'N/A') ?>
        </h5>
        <a class="btn-close btn-close-white" href="<?= htmlspecialchars("supplier_payables.php?filter=$filter&q=".urlencode($search)."&page=$page") ?>"></a>
      </div>
      <div class="modal-body">
        <div class="row g-3 mb-4">
          <div class="col-md-4"><div class="border rounded p-3 bg-light text-center"><div class="small text-muted">Total</div><div class="fw-bold fs-5">₱<?= number_format(f($viewAP['total_amount']),2) ?></div></div></div>
          <div class="col-md-4"><div class="border rounded p-3 bg-light text-center"><div class="small text-muted">Paid</div><div class="fw-bold fs-5 text-success">₱<?= number_format(f($viewAP['amount_paid']),2) ?></div></div></div>
          <div class="col-md-4"><div class="border rounded p-3 bg-light text-center"><div class="small text-muted">Balance</div><div class="fw-bold fs-5 text-danger">₱<?= number_format(f($viewAP['balance']),2) ?></div></div></div>
        </div>
        <?php if(!$hasSupplierPayments): ?>
          <div class="alert alert-warning"><i class="fa-solid fa-triangle-exclamation me-2"></i>supplier_payments table not found — history unavailable.</div>
        <?php else: ?>
          <table class="table table-striped table-bordered">
            <thead class="table-dark"><tr><th>Date</th><th class="text-end">Amount</th><th>Method</th><th>Reference</th><th>Note</th></tr></thead>
            <tbody>
              <?php if($viewPayments && $viewPayments->num_rows > 0): ?>
                <?php while($p = $viewPayments->fetch_assoc()): ?>
                  <tr>
                    <td><?= htmlspecialchars(date("M d, Y h:i A", strtotime($p['paid_at']))) ?></td>
                    <td class="fw-bold text-end">₱<?= number_format(f($p['amount']),2) ?></td>
                    <td><span class="badge bg-secondary"><?= htmlspecialchars(strtoupper($p['method'] ?? '')) ?></span></td>
                    <td><?= htmlspecialchars($p['reference_no'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($p['note'] ?? '-') ?></td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="5" class="text-center text-muted py-4"><i class="fa-solid fa-file-circle-xmark fa-2x mb-2 d-block"></i>No payments yet.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
      <div class="modal-footer">
        <a class="btn btn-outline-secondary" href="<?= htmlspecialchars("supplier_payables.php?filter=$filter&q=".urlencode($search)."&page=$page") ?>"><i class="fa-solid fa-xmark me-1"></i>Close</a>
      </div>
    </div>
  </div>
</div>
<div class="modal-backdrop fade show"></div>
<?php endif; ?>

</div>
</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
  document.addEventListener('click', function(event){
    const button = event.target.closest('.payment-amount-preset');
    if(!button) return;

    const form = button.closest('form');
    const amountInput = form?.querySelector('.payment-amount-input');
    if(!amountInput) return;

    const maxAmount = Number(amountInput.max || 0);
    const preset = button.dataset.paymentPreset;
    const amount = preset === 'half' ? Math.round(maxAmount * 50) / 100 : maxAmount;
    amountInput.value = amount.toFixed(2);
    amountInput.dispatchEvent(new Event('input', { bubbles: true }));
    amountInput.dispatchEvent(new Event('change', { bubbles: true }));
  });
})();
</script>
<script>
(function(){
  const pollIntervalMs = 4000;
  let pollingInFlight = false;
  let pollTimer = null;

  async function pollSupplierPayables() {
    // Never poll while a modal is open.
    if (pollingInFlight || document.querySelector('.modal.show')) return;

    pollingInFlight = true;
    let controller = null;
    let timeoutId = null;

    try {
      const url = new URL(window.location.href);
      url.searchParams.set('ajax', 'live');

      controller = new AbortController();
      timeoutId = setTimeout(() => controller.abort(), 8000);

      const res = await fetch(url.toString(), {
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        cache: 'no-store',
        signal: controller.signal
      });

      if (!res.ok) return;

      const data = await res.json();
      if (!data || !data.ok) return;

      // Do not replace the table/modal DOM here.
      // This keeps a payment form stable while the user is filling it out.
    } catch (e) {
      if (e.name !== 'AbortError') console.error('Poll failed:', e);
    } finally {
      if (timeoutId) clearTimeout(timeoutId);
      pollingInFlight = false;
    }
  }

  function startPolling() {
    if (!pollTimer) pollTimer = setInterval(pollSupplierPayables, pollIntervalMs);
  }

  document.addEventListener('show.bs.modal', function () {
    if (pollTimer) {
      clearInterval(pollTimer);
      pollTimer = null;
    }
  });

  document.addEventListener('hidden.bs.modal', function () {
    startPolling();
  });

  startPolling();
</script>
</body>
</html>
