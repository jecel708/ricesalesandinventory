<?php
$conn=new mysqli("localhost","root","","rice_inventory");
if($conn->connect_error){ echo "DBFAIL ". $conn->connect_error; exit(1); }
$sql="SELECT DATE_FORMAT(s.sale_date, '%b %Y') AS month_label, SUM(si.qty_kg) AS total_kg FROM sales_items si JOIN sales s ON si.sale_id=s.sale_id WHERE LOWER(s.status) IN ('paid','unpaid') GROUP BY YEAR(s.sale_date), MONTH(s.sale_date) ORDER BY YEAR(s.sale_date), MONTH(s.sale_date)";
$res=$conn->query($sql);
if(!$res){ echo 'ERR '. $conn->error; exit(1); }
while($row=$res->fetch_assoc()){
    echo $row['month_label'].':'.(float)$row['total_kg']."\n";
}
?>
