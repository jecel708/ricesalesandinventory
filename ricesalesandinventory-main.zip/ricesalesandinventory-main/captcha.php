<?php
declare(strict_types=1);

ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');

$secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

session_set_cookie_params([
  'lifetime' => 0,
  'path' => '/',
  'secure' => $secure,
  'httponly' => true,
  'samesite' => 'Lax',
]);

session_start();

function issue_captcha_code(): string {
  $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  $captcha = '';
  $maxIndex = strlen($alphabet) - 1;

  for ($index = 0; $index < 6; $index++) {
    $captcha .= $alphabet[random_int(0, $maxIndex)];
  }

  $_SESSION['captcha_code'] = $captcha;
  $_SESSION['captcha_generated_at'] = time();

  return $captcha;
}

$refresh = isset($_GET['refresh']) && $_GET['refresh'] === '1';
$captcha = strtoupper((string)($_SESSION['captcha_code'] ?? ''));
$issuedAt = (int)($_SESSION['captcha_generated_at'] ?? 0);

if ($refresh || $captcha === '' || (time() - $issuedAt) > 300) {
  $captcha = issue_captcha_code();
}

header('Content-Type: image/svg+xml; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
header('X-Content-Type-Options: nosniff');

$width = 220;
$height = 64;
$chars = preg_split('//u', $captcha, -1, PREG_SPLIT_NO_EMPTY) ?: [];
$fontSize = 30;
$x = 22;
$yBase = 42;

function svg_escape(string $value): string {
  return htmlspecialchars($value, ENT_QUOTES | ENT_XML1, 'UTF-8');
}

echo '<?xml version="1.0" encoding="UTF-8"?>';
?>
<svg xmlns="http://www.w3.org/2000/svg" width="<?= $width ?>" height="<?= $height ?>" viewBox="0 0 <?= $width ?> <?= $height ?>" role="img" aria-label="Captcha image">
  <rect width="100%" height="100%" rx="12" fill="#f8fafc" />
  <rect x="1.5" y="1.5" width="<?= $width - 3 ?>" height="<?= $height - 3 ?>" rx="10" fill="none" stroke="#cbd5e1" stroke-width="2" />
<?php for ($line = 0; $line < 6; $line++): ?>
  <path
    d="M <?= random_int(0, 40) ?> <?= random_int(8, $height - 8) ?> C <?= random_int(40, 90) ?> <?= random_int(0, $height) ?>, <?= random_int(120, 170) ?> <?= random_int(0, $height) ?>, <?= random_int(180, $width) ?> <?= random_int(8, $height - 8) ?>"
    fill="none"
    stroke="rgba(148, 163, 184, 0.55)"
    stroke-width="<?= random_int(1, 2) ?>"
  />
<?php endfor; ?>
<?php foreach ($chars as $char): ?>
  <text
    x="<?= $x ?>"
    y="<?= $yBase + random_int(-4, 4) ?>"
    font-family="Verdana, Arial, sans-serif"
    font-size="<?= $fontSize + random_int(-2, 3) ?>"
    font-weight="700"
    fill="#1e293b"
    transform="rotate(<?= random_int(-16, 16) ?> <?= $x ?> <?= $yBase ?>)"
  ><?= svg_escape($char) ?></text>
<?php $x += 30; endforeach; ?>
<?php for ($dot = 0; $dot < 20; $dot++): ?>
  <circle cx="<?= random_int(10, $width - 10) ?>" cy="<?= random_int(10, $height - 10) ?>" r="<?= random_int(1, 2) ?>" fill="rgba(71, 85, 105, 0.45)" />
<?php endfor; ?>
</svg>
