<?php
declare(strict_types=1);

header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');

$secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
session_set_cookie_params([
  'lifetime' => 0,
  'path' => '/',
  'secure' => $secure,
  'httponly' => true,
  'samesite' => 'Lax',
]);

session_start();
require_once 'config/db.php';

function h(string $v): string {
  return htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
}

function redirect_login(string $message): void {
  $_SESSION['flash_success'] = $message;
  header('Location: login.php');
  exit;
}

if (empty($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$token = trim((string)($_GET['token'] ?? $_POST['token'] ?? ''));
if ($token === '' || !preg_match('/^[a-f0-9]{64}$/i', $token)) {
  redirect_login('Invalid or expired password reset link.');
}

$tokenHash = hash('sha256', $token);
$user = null;

$stmt = $conn->prepare('SELECT user_id, reset_token_expires_at FROM users WHERE reset_token = ? LIMIT 1');
if ($stmt) {
  $stmt->bind_param('s', $tokenHash);
  $stmt->execute();
  $user = $stmt->get_result()->fetch_assoc();
  $stmt->close();
}

if (!$user || empty($user['reset_token_expires_at']) || strtotime((string)$user['reset_token_expires_at']) < time()) {
  redirect_login('Invalid or expired password reset link.');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $csrfPost = (string)($_POST['csrf_token'] ?? '');
  $csrfSess = (string)($_SESSION['csrf_token'] ?? '');
  if ($csrfPost === '' || $csrfSess === '' || !hash_equals($csrfSess, $csrfPost)) {
    $error = 'Invalid request. Please refresh and try again.';
  } else {
    $password = (string)($_POST['password'] ?? '');
    $confirm = (string)($_POST['confirm_password'] ?? '');

    if ($password === '' || $confirm === '') {
      $error = 'Please fill in both password fields.';
    } elseif ($password !== $confirm) {
      $error = 'Passwords do not match.';
    } elseif (strlen($password) < 8) {
      $error = 'Password must be at least 8 characters long.';
    } else {
      $hashed = password_hash($password, PASSWORD_DEFAULT);
      if ($hashed === false) {
        $error = 'Unable to update password right now.';
      } else {
        $update = $conn->prepare('UPDATE users SET password = ?, reset_token = NULL, reset_token_expires_at = NULL WHERE user_id = ? AND reset_token = ?');
        if ($update) {
          $userId = (int)$user['user_id'];
          $update->bind_param('sis', $hashed, $userId, $tokenHash);
          $update->execute();

          if ($update->affected_rows > 0) {
            $update->close();
            redirect_login('Your password has been reset successfully. Please log in with your new password.');
          }

          $update->close();
        }

        $error = 'Invalid or expired password reset link.';
      }
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reset Password | Rice Control System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="css/login.css?v=5" rel="stylesheet">
</head>
<body>
<div class="container-fluid">
<div class="row min-vh-100">
  <div class="col-md-6 d-flex align-items-center login-column">
    <div class="w-100 px-3 px-md-5 panel-wrap">
      <div class="login-panel">
        <div class="brand-row mb-3">
          <img src="assets/logo.jpg" alt="Logo" class="brand-logo">
          <div class="brand-text">
            <strong>Rice Control</strong>
            <span>System</span>
          </div>
        </div>

        <h2 class="fw-bold mb-1">Create a new password</h2>
        <p class="text-muted mb-4">Choose a strong password for your account.</p>

        <?php if ($error): ?>
          <div class="alert alert-danger"><?= h($error) ?></div>
        <?php endif; ?>

        <form method="POST" action="reset_password.php" class="needs-validation" novalidate>
          <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">
          <input type="hidden" name="token" value="<?= h($token) ?>">

          <div class="mb-3">
            <label class="form-label">New Password</label>
            <input type="password" class="form-control" name="password" required autocomplete="new-password">
            <div class="invalid-feedback">Please enter a new password.</div>
          </div>

          <div class="mb-3">
            <label class="form-label">Confirm New Password</label>
            <input type="password" class="form-control" name="confirm_password" required autocomplete="new-password">
            <div class="invalid-feedback">Please confirm your new password.</div>
          </div>

          <button type="submit" class="btn btn-dark w-100">Update Password</button>
        </form>

        <div class="text-center mt-3">
          <a href="login.php" class="small text-decoration-none">Back to Login</a>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-6 hero-image d-none d-md-block"></div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
