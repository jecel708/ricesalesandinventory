-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 02, 2026 at 04:21 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rice_inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_payable`
--

CREATE TABLE `account_payable` (
  `ap_id` int(11) NOT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `amount_paid` decimal(10,2) DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('paid','unpaid','partial','overdue','pending') DEFAULT 'pending',
  `approved` tinyint(1) NOT NULL DEFAULT 0,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `accrued_interest` decimal(10,2) NOT NULL DEFAULT 0.00,
  `accrued_penalty` decimal(10,2) NOT NULL DEFAULT 0.00,
  `last_charge_date` date DEFAULT NULL,
  `rejected` tinyint(1) NOT NULL DEFAULT 0,
  `rejected_by` int(11) DEFAULT NULL,
  `rejected_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account_payable`
--

INSERT INTO `account_payable` (`ap_id`, `purchase_id`, `supplier_id`, `total_amount`, `amount_paid`, `balance`, `due_date`, `status`, `approved`, `approved_by`, `approved_at`, `created_at`, `accrued_interest`, `accrued_penalty`, `last_charge_date`, `rejected`, `rejected_by`, `rejected_at`) VALUES
(1, 2, 1, 4000.00, 4000.00, 0.00, '2026-02-06', 'paid', 1, 5, '2026-01-28 07:14:37', '2026-01-28 06:48:30', 0.00, 0.00, NULL, 0, NULL, NULL),
(2, 3, 1, 10000.00, 10000.00, 0.00, '2026-02-06', 'paid', 1, 5, '2026-01-28 07:55:29', '2026-01-28 07:54:07', 0.00, 0.00, NULL, 0, NULL, NULL),
(3, 4, 1, 0.00, 0.00, 0.00, '2026-02-08', 'unpaid', 1, 5, '2026-01-28 08:40:35', '2026-01-28 08:38:18', 0.00, 0.00, NULL, 0, NULL, NULL),
(4, 6, 1, 11200.00, 11200.00, 0.00, '2026-02-15', 'paid', 1, 5, '2026-01-28 08:55:26', '2026-01-28 08:53:54', 0.00, 0.00, NULL, 0, NULL, NULL),
(5, 9, 3, 3360.00, 3360.00, 0.00, '2026-01-28', 'paid', 1, 5, '2026-01-29 02:23:39', '2026-01-29 02:22:32', 0.00, 0.00, NULL, 0, NULL, NULL),
(6, 10, 3, 4300.00, 4300.00, 0.00, '2026-02-06', 'paid', 1, 5, '2026-01-29 11:53:22', '2026-01-29 11:52:47', 0.00, 0.00, NULL, 0, NULL, NULL),
(7, 16, 3, 400.00, 400.00, 0.00, '2026-02-21', 'paid', 1, 5, '2026-02-05 09:12:19', '2026-02-05 09:11:51', 0.00, 0.00, NULL, 0, NULL, NULL),
(8, 17, 2, 440.00, 440.00, 0.00, '2026-03-06', 'paid', 1, 5, '2026-02-27 05:47:40', '2026-02-06 06:03:06', 0.00, 0.00, NULL, 0, NULL, NULL),
(9, 18, 1, 6327.73, 0.00, 6327.73, '2026-03-02', 'overdue', 0, NULL, NULL, '2026-02-22 03:21:16', 227.73, 0.00, '2026-09-01', 0, NULL, NULL),
(10, 19, 2, 20954.15, 0.00, 20954.15, '2026-03-01', 'overdue', 0, NULL, NULL, '2026-02-22 03:34:51', 754.15, 0.00, '2026-09-01', 0, NULL, NULL),
(11, 20, 1, 11410.71, 0.00, 11410.71, '2026-03-02', 'overdue', 0, NULL, NULL, '2026-02-22 04:29:41', 410.71, 0.00, '2026-09-01', 0, NULL, NULL),
(12, 21, 2, 20850.42, 0.00, 20850.42, '2026-03-01', 'overdue', 0, NULL, NULL, '2026-02-22 12:51:15', 750.42, 0.00, '2026-09-01', 0, NULL, NULL),
(13, 22, 3, 10150.00, 10150.00, 0.00, '2026-02-28', 'paid', 1, 5, '2026-02-23 04:27:00', '2026-02-23 04:24:54', 0.00, 0.00, NULL, 0, NULL, NULL),
(14, 23, 3, 24983.09, 0.00, 24983.09, '2026-03-04', 'overdue', 0, NULL, NULL, '2026-02-25 14:15:51', 883.09, 0.00, '2026-09-01', 0, NULL, NULL),
(15, 24, 1, 27970.72, 0.00, 27970.72, '2026-03-07', 'overdue', 0, NULL, NULL, '2026-02-27 05:37:05', 970.72, 0.00, '2026-09-01', 1, 5, '2026-08-20 22:58:33'),
(16, 25, 1, 5589.88, 3000.00, 2589.88, '2026-03-07', 'overdue', 1, 5, '2026-02-27 07:51:05', '2026-02-27 07:30:49', 89.88, 0.00, '2026-09-01', 0, NULL, NULL),
(17, 26, 3, 49932.92, 0.00, 49932.92, '2026-03-07', 'overdue', 1, 5, '2026-06-02 03:14:26', '2026-02-27 10:59:04', 1732.92, 0.00, '2026-09-01', 0, NULL, NULL),
(18, 27, 3, 46737.31, 46276.40, 460.91, '2026-03-07', 'overdue', 1, 5, '2026-04-17 12:06:17', '2026-02-27 11:16:54', 537.31, 0.00, '2026-09-01', 0, NULL, NULL),
(19, 28, 1, 50000.00, 50000.00, 0.00, '2026-03-30', 'paid', 1, 5, '2026-03-28 05:25:49', '2026-03-23 05:35:32', 0.00, 0.00, NULL, 0, NULL, NULL),
(20, 29, 1, 25000.00, 25000.00, 0.00, '2026-03-31', 'paid', 1, 5, '2026-03-28 05:23:55', '2026-03-24 04:01:55', 0.00, 0.00, NULL, 0, NULL, NULL),
(21, 30, 2, 23000.00, 23000.00, 0.00, '2026-03-31', 'paid', 1, 5, '2026-03-24 04:40:40', '2026-03-24 04:39:02', 0.00, 0.00, NULL, 0, NULL, NULL),
(22, 31, 1, 10000.00, 10000.00, 0.00, '2026-03-30', 'paid', 1, 5, '2026-03-28 05:18:52', '2026-03-25 03:35:04', 0.00, 0.00, NULL, 0, NULL, NULL),
(23, 32, 1, 23000.00, 23000.00, 0.00, '2026-03-30', 'paid', 1, 5, '2026-03-25 03:42:13', '2026-03-25 03:39:07', 0.00, 0.00, NULL, 0, NULL, NULL),
(24, 33, 2, 5000.00, 5000.00, 0.00, '2026-03-30', 'paid', 1, 5, '2026-03-25 03:46:15', '2026-03-25 03:45:17', 0.00, 0.00, NULL, 0, NULL, NULL),
(25, 34, 1, 76667.72, 0.00, 76667.72, '2026-05-03', 'overdue', 1, 5, '2026-06-02 03:14:24', '2026-04-26 12:51:24', 1667.72, 0.00, '2026-09-01', 0, NULL, NULL),
(26, 35, 2, 23480.01, 0.00, 23480.01, '2026-05-11', 'overdue', 1, 5, '2026-06-02 03:14:22', '2026-05-04 02:46:34', 480.11, 0.00, '2026-09-01', 0, NULL, NULL),
(27, 36, 2, 8166.99, 0.00, 8166.99, '2026-05-11', 'overdue', 1, 5, '2026-06-02 03:14:20', '2026-05-04 02:47:30', 166.99, 0.00, '2026-09-01', 0, NULL, NULL),
(28, 39, 3, 39000.00, 39000.00, 0.00, '2026-06-09', 'paid', 1, 5, '2026-06-02 03:14:19', '2026-06-02 02:58:59', 0.00, 0.00, NULL, 0, NULL, NULL),
(29, 50, 1, 7025.28, 0.00, 7025.28, '2026-06-09', 'overdue', 1, 5, '2026-08-02 07:43:19', '2026-06-02 06:35:36', 125.28, 0.00, '2026-09-01', 0, NULL, NULL),
(30, 52, 3, 2440.77, 2100.01, 340.76, '2026-06-09', 'overdue', 1, 5, '2026-08-02 07:43:14', '2026-06-02 06:42:35', 40.77, 0.00, '2026-09-01', 0, NULL, NULL),
(31, 54, 4, 11669.84, 11669.84, 0.00, '2026-06-17', 'paid', 1, 5, '2026-08-02 07:41:55', '2026-06-10 02:16:42', 169.84, 0.00, '2026-08-20', 0, NULL, NULL),
(32, 85, 4, 3500.00, 3500.00, 0.00, '2026-08-25', 'paid', 1, 5, '2026-08-18 07:26:52', '2026-08-18 07:23:48', 0.00, 0.00, NULL, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `account_receivable`
--

CREATE TABLE `account_receivable` (
  `ar_id` int(11) NOT NULL,
  `sales_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `amount_paid` decimal(10,2) DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('paid','unpaid','partial','overdue') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `accrued_interest` decimal(10,2) NOT NULL DEFAULT 0.00,
  `accrued_penalty` decimal(10,2) NOT NULL DEFAULT 0.00,
  `last_charge_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account_receivable`
--

INSERT INTO `account_receivable` (`ar_id`, `sales_id`, `customer_id`, `total_amount`, `amount_paid`, `balance`, `due_date`, `status`, `created_at`, `accrued_interest`, `accrued_penalty`, `last_charge_date`) VALUES
(1, 16, 2, 1815.00, 1815.00, 0.00, '2026-03-22', 'paid', '2026-01-26 09:26:19', 0.00, 0.00, NULL),
(2, 17, 1, 680.00, 680.00, 0.00, '2026-02-05', 'paid', '2026-01-26 10:42:27', 0.00, 0.00, NULL),
(3, 19, 2, 550.00, 550.00, 0.00, '2026-02-12', 'paid', '2026-01-26 11:02:37', 0.00, 0.00, NULL),
(4, 20, 3, 1375.00, 1375.00, 0.00, '2026-02-12', 'paid', '2026-01-27 03:02:10', 0.00, 0.00, NULL),
(5, 21, 4, 1375.00, 1375.00, 0.00, '2026-01-30', 'paid', '2026-01-27 06:10:04', 0.00, 0.00, NULL),
(6, 22, 5, 1375.00, 1375.00, 0.00, '2026-02-04', 'paid', '2026-01-27 07:24:29', 0.00, 0.00, NULL),
(7, 26, 5, 680.00, 680.00, 0.00, '2026-02-14', 'paid', '2026-01-27 07:34:22', 0.00, 0.00, NULL),
(8, 31, 3, 55.00, 55.00, 0.00, '2026-01-30', 'paid', '2026-01-28 08:15:42', 0.00, 0.00, NULL),
(9, 34, 2, 265.00, 265.00, 0.00, '2026-01-30', 'paid', '2026-01-29 11:09:44', 0.00, 0.00, NULL),
(10, 35, 1, 60.00, 60.00, 0.00, '2026-01-30', 'paid', '2026-01-29 11:14:46', 0.00, 0.00, NULL),
(11, 38, 2, 265.00, 265.00, 0.00, '2026-01-30', 'paid', '2026-01-29 11:27:25', 0.00, 0.00, NULL),
(12, 41, 2, 300.00, 300.00, 0.00, '2026-01-30', 'paid', '2026-01-29 11:46:45', 0.00, 0.00, NULL),
(13, 42, 2, 110.00, 110.00, 0.00, '2026-01-30', 'paid', '2026-01-29 11:47:41', 0.00, 0.00, NULL),
(14, 47, 7, 550.00, 550.00, 0.00, '2026-01-30', 'paid', '2026-01-30 12:21:52', 0.00, 0.00, NULL),
(15, 50, 4, 720.00, 720.00, 0.00, '2026-02-02', 'paid', '2026-01-30 13:28:47', 0.00, 0.00, NULL),
(16, 53, 2, 75.00, 75.00, 0.00, '2026-02-02', 'paid', '2026-01-31 05:39:38', 0.00, 0.00, NULL),
(17, 55, 3, 550.00, 550.00, 0.00, '2026-02-15', 'paid', '2026-02-03 04:22:36', 0.00, 0.00, NULL),
(18, 57, 6, 470.00, 470.00, 0.00, '2026-02-15', 'paid', '2026-02-03 09:09:18', 0.00, 0.00, NULL),
(19, 60, 3, 800.00, 800.00, 0.00, '2026-02-15', 'paid', '2026-02-05 09:07:13', 0.00, 0.00, NULL),
(20, 61, 2, 300.00, 300.00, 0.00, '2026-02-15', 'paid', '2026-02-06 06:01:36', 0.00, 0.00, NULL),
(21, 65, 5, 550.00, 550.00, 0.00, '2026-02-15', 'paid', '2026-02-06 06:15:59', 0.00, 0.00, NULL),
(22, 70, 4, 242.00, 242.00, 0.00, '2026-02-25', 'paid', '2026-02-22 06:26:19', 0.00, 0.00, NULL),
(23, 76, 7, 2550.00, 2550.00, 0.00, '2026-02-25', 'paid', '2026-02-23 04:18:12', 0.00, 0.00, NULL),
(24, 80, 6, 245.00, 245.00, 0.00, '2026-02-28', 'paid', '2026-02-25 15:59:13', 0.00, 0.00, NULL),
(25, 83, 8, 600.00, 600.00, 0.00, '2026-02-28', 'paid', '2026-02-27 07:42:39', 0.00, 0.00, NULL),
(26, 86, 3, 1960.00, 1960.00, 0.00, '2026-02-28', 'paid', '2026-02-27 08:03:54', 0.00, 0.00, NULL),
(27, 88, 8, 4640.00, 4640.00, 0.00, '2026-03-14', 'paid', '2026-02-27 11:45:16', 0.00, 0.00, NULL),
(28, 90, 7, 2350.00, 2350.00, 0.00, '2026-03-18', 'paid', '2026-03-03 10:23:04', 0.00, 0.00, NULL),
(29, 95, 9, 411.88, 0.00, 411.88, '2026-03-22', 'overdue', '2026-03-22 08:38:53', 11.88, 0.00, '2026-09-01'),
(30, 97, 10, 2543.69, 2543.69, 0.00, '2026-04-08', 'paid', '2026-03-24 04:44:10', 43.69, 0.00, '2026-08-03'),
(31, 98, 6, 81.85, 0.00, 81.85, '2026-04-08', 'overdue', '2026-03-24 04:44:48', 1.85, 0.00, '2026-09-01'),
(32, 99, 7, 63.25, 63.25, 0.00, '2026-04-09', 'paid', '2026-03-25 03:20:17', 0.00, 0.00, NULL),
(33, 100, 7, 506.00, 506.00, 0.00, '2026-04-24', 'paid', '2026-03-25 03:22:14', 0.00, 0.00, NULL),
(34, 101, 5, 2300.00, 2300.00, 0.00, '2026-04-24', 'paid', '2026-03-25 03:55:09', 0.00, 0.00, NULL),
(35, 103, 3, 2000.00, 2000.00, 0.00, '2026-04-12', 'paid', '2026-03-28 04:43:56', 0.00, 0.00, NULL),
(36, 104, 4, 2100.00, 2100.00, 0.00, '2026-04-12', 'paid', '2026-03-28 04:52:23', 0.00, 0.00, NULL),
(37, 105, 8, 2015.00, 2015.00, 0.00, '2026-04-12', 'paid', '2026-03-28 04:55:20', 0.00, 0.00, NULL),
(38, 106, 8, 450.00, 450.00, 0.00, '2026-04-12', 'paid', '2026-03-28 04:59:26', 0.00, 0.00, NULL),
(39, 107, 1, 2500.00, 2500.00, 0.00, '2026-04-12', 'paid', '2026-03-28 05:05:14', 0.00, 0.00, NULL),
(40, 109, 8, 46.00, 46.00, 0.00, '2026-05-12', 'paid', '2026-04-27 01:29:59', 0.00, 0.00, NULL),
(41, 112, 7, 506.72, 506.72, 0.00, '2026-05-19', 'paid', '2026-05-04 03:15:16', 6.72, 0.00, '2026-08-03'),
(42, 115, 4, 3050.00, 3050.00, 0.00, '2026-06-08', 'paid', '2026-05-24 08:52:40', 0.00, 0.00, NULL),
(43, 116, 5, 3150.00, 3150.00, 0.00, '2026-06-08', 'paid', '2026-05-24 08:54:15', 0.00, 0.00, NULL),
(44, 118, 3, 3050.00, 3050.00, 0.00, '2026-06-16', 'paid', '2026-06-01 13:46:21', 0.00, 0.00, NULL),
(45, 124, 2, 1000.00, 1000.00, 0.00, '2026-07-31', 'paid', '2026-07-16 06:15:08', 0.00, 0.00, NULL),
(46, 126, 10, 4000.00, 4000.00, 0.00, '2026-07-31', 'paid', '2026-07-16 08:48:51', 0.00, 0.00, NULL),
(47, 159, 1, 27000.00, 14398.00, 12602.00, '2026-09-01', 'partial', '2026-08-17 17:16:08', 0.00, 0.00, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `activity_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `activity_type` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`activity_id`, `user_id`, `activity_type`, `description`, `created_at`) VALUES
(1, 1, 'USER_CREATE', 'Created new user (owner): sydney', '2026-01-25 06:32:10'),
(2, 1, 'USER_STATUS', 'Changed user_id 4 status to inactive', '2026-01-25 06:58:27'),
(3, 1, 'USER_STATUS', 'Changed user_id 3 status to inactive', '2026-01-25 06:58:32'),
(4, 1, 'USER_CREATE', 'Created new user (owner): kriz', '2026-01-25 07:26:32'),
(5, 2, 'SALE_CREATED', 'Created sale #3 total ₱10,000,000.00', '2026-01-25 09:12:56'),
(6, 2, 'DELIVERY_UPDATE', 'Updated delivery receipt for sale #3 (status: pending)', '2026-01-25 09:13:47'),
(7, 2, 'PAYMENT_REQUEST', 'Sent payment request for sale #3 to 09859958194', '2026-01-25 09:14:09'),
(8, 2, 'SALE_CREATED', 'Created sale #4 total ₱18,000.00', '2026-01-25 09:37:37'),
(9, 2, 'SALE_CREATED', 'Created sale #0 total ₱20,000.00', '2026-01-25 10:45:38'),
(10, 2, 'SALE_CREATED', 'Created sale #0 total ₱18,000.00', '2026-01-25 10:45:55'),
(11, 2, 'SALE_CREATE', 'Created sale #8 (CASH) total: 340', '2026-01-25 11:17:36'),
(12, 2, 'SALE_CREATE', 'Created sale #18 (paid) total ₱1,700.00', '2026-01-26 11:01:43'),
(13, 2, 'SALE_CREATE', 'Created sale #19 (unpaid) total ₱550.00', '2026-01-26 11:02:37'),
(14, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #19 amount ₱250.00', '2026-01-26 11:03:08'),
(15, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #17 amount ₱680.00', '2026-01-26 11:03:49'),
(16, 5, 'RETURN_APPROVED', 'RETURN_APPROVED for Return #2', '2026-01-26 11:09:40'),
(17, 1, 'USER_CREATE', 'Created new user (owner): johndoe', '2026-01-26 11:22:01'),
(18, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #19 amount ₱300.00', '2026-01-27 03:01:22'),
(19, 2, 'SALE_CREATE', 'Created sale #20 (unpaid) total ₱1,375.00', '2026-01-27 03:02:10'),
(20, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #20 amount ₱500.00', '2026-01-27 03:03:29'),
(21, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #20 amount ₱375.00', '2026-01-27 03:03:50'),
(22, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #20 amount ₱500.00', '2026-01-27 03:04:03'),
(23, 5, 'RETURN_APPROVED', 'RETURN_APPROVED for Return #3', '2026-01-27 03:11:14'),
(24, 2, 'SALE_CREATE', 'Created sale #21 (unpaid) total ₱1,375.00', '2026-01-27 06:10:04'),
(25, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #21 amount ₱375.00', '2026-01-27 06:59:34'),
(26, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #21 amount ₱1,000.00', '2026-01-27 06:59:53'),
(27, 2, 'SALE_CREATE', 'Created sale #22 (unpaid) total ₱1,375.00', '2026-01-27 07:24:29'),
(28, 2, 'SALE_CREATE', 'Created sale #24 (paid) total ₱40,715.00', '2026-01-27 07:28:03'),
(29, 2, 'SALE_CREATE', 'Created sale #26 (unpaid) total ₱680.00', '2026-01-27 07:34:22'),
(30, 1, 'PRODUCT', 'Added product: Princess Sydney - B (SKU: PS123)', '2026-01-27 07:41:54'),
(31, 1, 'PRODUCT', 'Edited product #9: Princess Sydney - B (SKU: PS123)', '2026-01-27 07:42:23'),
(32, 1, 'PRODUCT', 'Added product: Super Sydney - A (SKU: SS11)', '2026-01-27 07:47:48'),
(33, 1, 'USER_STATUS', 'Changed user_id 6 status to inactive', '2026-01-27 07:53:27'),
(34, 1, 'USER_STATUS', 'Changed user_id 6 status to active', '2026-01-27 07:53:37'),
(35, 5, 'RETURN_REJECTED', 'RETURN_REJECTED for Return #4', '2026-01-27 07:57:59'),
(36, 5, 'PROFILE_UPDATE', 'Updated profile username to \'kriezyl\'', '2026-01-27 10:31:23'),
(38, 2, 'SALE_CREATE', 'Created sale #28 (paid) total ₱550.00', '2026-01-27 13:00:24'),
(39, 1, 'USER_STATUS', 'Changed user_id 4 status to active', '2026-01-28 05:22:17'),
(40, 1, 'USER_STATUS', 'Changed user_id 4 status to inactive', '2026-01-28 05:22:20'),
(41, 1, 'PRODUCT', 'Added product: Premium Rice - A (SKU: PR345)', '2026-01-28 05:48:37'),
(42, 2, 'SALE_CREATE', 'Created sale #30 (paid) total ₱1,500.00', '2026-01-28 07:45:35'),
(43, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #26 amount ₱680.00', '2026-01-28 07:45:48'),
(44, 2, 'SALE_CREATE', 'Created sale #31 (unpaid) total ₱55.00', '2026-01-28 08:15:42'),
(45, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #22 amount ₱1,375.00', '2026-01-28 08:17:30'),
(46, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #31 amount ₱55.00', '2026-01-28 08:18:01'),
(47, 1, 'PRODUCT', 'Added product: Sakura - B (SKU: SAK342)', '2026-01-28 08:37:44'),
(48, 1, 'PRODUCT', 'Added product: Malagkit Rice - B (SKU: MAL903)', '2026-01-28 08:56:35'),
(49, 2, 'SALE_CREATE', 'Created sale #32 (paid) total ₱385.00', '2026-01-29 11:01:46'),
(50, 2, 'SALE_CREATE', 'Created sale #33 (paid) total ₱275.00', '2026-01-29 11:03:19'),
(51, 2, 'SALE_CREATE', 'Created sale #34 (unpaid) total ₱265.00', '2026-01-29 11:09:44'),
(52, 2, 'SALE_CREATE', 'Created sale #35 (unpaid) total ₱60.00', '2026-01-29 11:14:46'),
(53, 2, 'SALE_CREATE', 'Created sale #36 (paid) total ₱85.00', '2026-01-29 11:15:22'),
(54, 2, 'SALE_CREATE', 'Created sale #37 (paid) total ₱250.00', '2026-01-29 11:26:51'),
(55, 2, 'SALE_CREATE', 'Created sale #38 (unpaid) total ₱265.00', '2026-01-29 11:27:25'),
(56, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #38 amount ₱265.00', '2026-01-29 11:28:10'),
(57, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #35 amount ₱60.00', '2026-01-29 11:36:17'),
(58, 2, 'SALE_CREATE', 'Created sale #39 (paid) total ₱240.00', '2026-01-29 11:36:58'),
(59, 2, 'SALE_CREATE', 'Created sale #40 (paid) total ₱125.00', '2026-01-29 11:46:15'),
(60, 2, 'SALE_CREATE', 'Created sale #41 (unpaid) total ₱300.00', '2026-01-29 11:46:45'),
(61, 2, 'SALE_CREATE', 'Created sale #42 (unpaid) total ₱110.00', '2026-01-29 11:47:41'),
(62, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #34 amount ₱265.00', '2026-01-29 11:48:04'),
(63, 1, 'PRODUCT', 'Added product: Black Rice - A (SKU: BLA972)', '2026-01-30 11:02:37'),
(64, 2, 'SALE_CREATE', 'Created sale #43 (paid) total ₱550.00', '2026-01-30 11:09:46'),
(65, 2, 'SALE_CREATE', 'Created sale #44 (paid) total ₱120.00', '2026-01-30 11:21:24'),
(66, 2, 'SALE_CREATE', 'Created sale #45 (paid) total ₱50.00', '2026-01-30 12:17:36'),
(67, 2, 'SALE_CREATE', 'Created sale #46 (paid) total ₱180.00', '2026-01-30 12:21:06'),
(68, 2, 'SALE_CREATE', 'Created sale #47 (unpaid) total ₱550.00', '2026-01-30 12:21:52'),
(69, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #41 amount ₱300.00', '2026-01-30 12:25:41'),
(70, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #42 amount ₱110.00', '2026-01-30 12:29:12'),
(71, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #47 amount ₱250.00', '2026-01-30 12:31:01'),
(72, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #47 amount ₱150.00', '2026-01-30 12:31:41'),
(73, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #47 amount ₱150.00', '2026-01-30 12:32:29'),
(74, 2, 'SALE_CREATE', 'Created sale #50 (unpaid) total ₱720.00', '2026-01-30 13:28:47'),
(75, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #50 amount ₱720.00', '2026-01-30 13:29:08'),
(76, 2, 'SALE_CREATE', 'Created sale #51 (paid) total ₱1,200.00', '2026-01-30 13:29:24'),
(77, 2, 'SALE_CREATE', 'Created sale #52 (paid) total ₱530.00', '2026-01-31 05:38:59'),
(78, 2, 'SALE_CREATE', 'Created sale #53 (unpaid) total ₱75.00', '2026-01-31 05:39:38'),
(79, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #53 amount ₱75.00', '2026-01-31 05:43:47'),
(80, 1, 'USER_STATUS', 'Changed user_id 6 status to inactive', '2026-02-03 01:44:30'),
(81, 2, 'SALE_CREATE', 'Created sale #54 (paid) total ₱250.00', '2026-02-03 04:22:06'),
(82, 2, 'SALE_CREATE', 'Created sale #55 (unpaid) total ₱550.00', '2026-02-03 04:22:36'),
(83, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #55 amount ₱550.00', '2026-02-03 04:24:18'),
(84, 2, 'SALE_CREATE', 'Created sale #57 (unpaid) total ₱470.00', '2026-02-03 09:09:18'),
(85, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #57 amount ₱470.00', '2026-02-03 09:09:50'),
(86, 2, 'SALE_CREATE', 'Created sale #58 (paid) total ₱300.00', '2026-02-05 03:37:54'),
(87, 2, 'SALE_CREATE', 'Created sale #59 (paid) total ₱530.00', '2026-02-05 09:06:29'),
(88, 2, 'SALE_CREATE', 'Created sale #60 (unpaid) total ₱800.00', '2026-02-05 09:07:13'),
(89, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #60 amount ₱800.00', '2026-02-05 09:07:28'),
(90, 5, 'RETURN_APPROVED', 'RETURN_APPROVED for Return #6', '2026-02-05 09:14:42'),
(91, 5, 'RETURN_APPROVED', 'RETURN_APPROVED for Return #7', '2026-02-06 04:32:49'),
(92, 2, 'SALE_CREATE', 'Created sale #61 (unpaid) total ₱300.00', '2026-02-06 06:01:36'),
(93, 2, 'SALE_CREATE', 'Created sale #63 (paid) total ₱500.00', '2026-02-06 06:10:56'),
(94, 2, 'SALE_CREATE', 'Created sale #64 (paid) total ₱600.00', '2026-02-06 06:14:01'),
(95, 2, 'SALE_CREATE', 'Created sale #65 (unpaid) total ₱550.00', '2026-02-06 06:15:59'),
(96, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #65 amount ₱100.00', '2026-02-06 06:18:32'),
(97, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #65 amount ₱450.00', '2026-02-06 06:19:05'),
(98, 2, 'SALE_CREATE', 'Created sale #66 (paid) gross ₱750.00 disc ₱150.00 net ₱600.00', '2026-02-06 06:27:53'),
(99, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #61 amount ₱100.00', '2026-02-06 06:35:25'),
(100, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #61 amount ₱200.00', '2026-02-06 06:35:57'),
(101, 2, 'SALE_CREATE', 'Created sale #67 (paid) gross ₱540.00 disc ₱0.00 net ₱540.00', '2026-02-08 04:08:53'),
(102, 1, 'PRODUCT', 'Added product: Sakura - A (15kg sack)', '2026-02-22 03:19:47'),
(103, 1, 'PRODUCT', 'Added product: Japonesa - A (50kg sack)', '2026-02-22 03:25:35'),
(104, 1, 'PRODUCT', 'Edited product #14: Black Rice - A (10kg sack)', '2026-02-22 04:37:53'),
(105, 1, 'PRODUCT', 'Edited product #13: Young Chow - B (50kg sack)', '2026-02-22 04:39:46'),
(106, 1, 'PRODUCT', 'Edited product #12: Jasmine Rice (Local) - B (50kg sack)', '2026-02-22 04:39:53'),
(107, 1, 'PRODUCT', 'Edited product #10: Mang Bigas - A (10kg sack)', '2026-02-22 04:40:09'),
(108, 1, 'PRODUCT', 'Edited product #2: Valencia Rice (Special) - B (50kg sack)', '2026-02-22 04:40:56'),
(109, 1, 'SECURITY', 'Updated stock thresholds (LOW=50, OVER=1000) after password confirmation', '2026-02-22 05:25:25'),
(110, 1, 'PRODUCT', 'Edited product #13: Young Chow - B (50kg/sack)', '2026-02-22 06:03:58'),
(111, 1, 'PRODUCT', 'Edited product #12: Jasmine Rice (Local) - B (50kg/sack)', '2026-02-22 06:04:05'),
(112, 1, 'PRODUCT', 'Edited product #11: Japonika - A (10kg/sack)', '2026-02-22 06:04:13'),
(113, 1, 'PRODUCT', 'Edited product #10: Mang Bigas - A (10kg/sack)', '2026-02-22 06:04:24'),
(114, 1, 'PRODUCT', 'Edited product #9: Square Line - B (10kg/sack)', '2026-02-22 06:04:30'),
(115, 1, 'PRODUCT', 'Edited product #5: Valencia Red Rice - B (50kg/sack)', '2026-02-22 06:04:36'),
(116, 1, 'PRODUCT', 'Edited product #4: Red Rice - A (50kg/sack)', '2026-02-22 06:04:42'),
(117, 1, 'PRODUCT', 'Edited product #7: Masipag Valencia - A (25kg/sack)', '2026-02-22 06:04:48'),
(118, 1, 'PRODUCT', 'Edited product #6: Angelica Rice - A (25kg/sack)', '2026-02-22 06:04:56'),
(119, 1, 'PRODUCT', 'Edited product #2: Valencia Rice (Special) - B (50kg/sack)', '2026-02-22 06:05:05'),
(120, 1, 'PRODUCT', 'Edited product #1: Valencia Rice - B (50kg/sack)', '2026-02-22 06:05:12'),
(121, 2, 'SALE_CREATE', 'Created sale #68 (paid) gross ₱89.34 disc ₱0.00 net ₱89.34', '2026-02-22 06:09:53'),
(122, 2, 'SALE_CREATE', 'Created sale #69 (paid) gross ₱500.00 disc ₱0.00 net ₱500.00', '2026-02-22 06:18:13'),
(123, 2, 'SALE_CREATE', 'Created sale #70 (unpaid) gross ₱242.00 disc ₱0.00 net ₱242.00', '2026-02-22 06:26:19'),
(124, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #70 amount ₱200.00', '2026-02-22 06:27:08'),
(125, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #70 amount ₱42.00', '2026-02-22 06:30:12'),
(126, 2, 'SALE_CREATE', 'Created sale #71 (paid) gross ₱400.00 disc ₱80.00 net ₱320.00', '2026-02-22 09:01:30'),
(127, 2, 'SALE_CREATE', 'Created sale #73 (paid) gross ₱4,800.00 disc ₱960.00 net ₱3,840.00', '2026-02-22 09:02:31'),
(128, 2, 'SALE_CREATE', 'Created sale #74 (paid) gross ₱720.00 disc ₱0.00 net ₱720.00', '2026-02-22 09:05:58'),
(129, 1, 'PRODUCT', 'Added product: Princess Sydney - B (15kg/sack)', '2026-02-22 12:50:43'),
(130, 1, 'PRODUCT', 'Edited product #17: Princess Sydney - B (15kg/sack)', '2026-02-22 12:55:21'),
(131, 1, 'SECURITY', 'Updated stock thresholds (LOW=50, OVER=2000) after password confirmation', '2026-02-23 02:07:14'),
(132, 1, 'SECURITY', 'Updated stock thresholds (LOW=50, OVER=1000) after password confirmation', '2026-02-23 02:08:54'),
(133, 1, 'SECURITY', 'Updated stock thresholds (LOW=50, OVER=1000) after password confirmation', '2026-02-23 02:17:26'),
(134, 1, 'SECURITY', 'Updated stock thresholds (LOW=50, OVER=1000)', '2026-02-23 02:19:39'),
(135, 1, 'SECURITY', 'Updated stock thresholds (LOW=70, OVER=1000)', '2026-02-23 03:21:11'),
(136, 5, 'PASSWORD_CHANGE', 'Changed account password', '2026-02-23 04:10:58'),
(137, 2, 'SALE_CREATE', 'Created sale #75 (paid) gross ₱240.00 disc ₱0.00 net ₱240.00', '2026-02-23 04:17:03'),
(138, 2, 'SALE_CREATE', 'Created sale #76 (unpaid) gross ₱2,550.00 disc ₱0.00 net ₱2,550.00', '2026-02-23 04:18:12'),
(139, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #76 amount ₱2,000.00', '2026-02-23 04:19:14'),
(140, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #76 amount ₱550.00', '2026-02-23 04:19:24'),
(141, 2, 'SALE_CREATE', 'Created sale #77 (paid) gross ₱1,000.00 disc ₱200.00 net ₱800.00', '2026-02-23 04:20:00'),
(142, 2, 'SALE_CREATE', 'Created sale #78 (paid) gross ₱54.00 disc ₱10.80 net ₱43.20', '2026-02-23 04:20:33'),
(143, 1, 'PRODUCT', 'Edited product #12: Jasmine Rice (Local) - B (50kg/sack)', '2026-02-23 04:25:24'),
(144, 5, 'RETURN_APPROVED', 'RETURN_APPROVED for Return #8', '2026-02-23 04:29:49'),
(145, 1, 'SECURITY', 'Updated stock thresholds (LOW=80, OVER=1000)', '2026-02-23 14:38:20'),
(146, 1, 'PRODUCT', 'Edited product #17: Princess Sydney - Regular (15kg/sack)', '2026-02-25 11:55:58'),
(147, 1, 'PRODUCT', 'Edited product #16: Japonesa - Premium (50kg/sack)', '2026-02-25 11:56:08'),
(148, 2, 'SALE_CREATE', 'Created sale #79 (paid) gross ₱2,550.00 disc ₱0.00 net ₱2,550.00', '2026-02-25 15:08:17'),
(149, 2, 'SALE_CREATE', 'Created sale #80 (unpaid) gross ₱245.00 disc ₱0.00 net ₱245.00', '2026-02-25 15:59:13'),
(150, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #80 amount ₱245.00', '2026-02-25 15:59:25'),
(151, 1, 'PRODUCT', 'Added product: Sinandomeng - Regular (50kg/sack)', '2026-02-27 05:33:15'),
(152, 1, 'PRODUCT', 'Edited product #18: Sinandomeng - Regular (50kg/sack)', '2026-02-27 05:38:07'),
(153, 2, 'SALE_CREATE', 'Created sale #81 (paid) gross ₱1,300.00 disc ₱260.00 net ₱1,040.00', '2026-02-27 05:42:59'),
(154, 1, 'SECURITY', 'Updated stock thresholds (LOW=80.16, OVER=500)', '2026-02-27 06:54:46'),
(155, 1, 'SECURITY', 'Updated stock thresholds (LOW=80.16, OVER=5000)', '2026-02-27 06:57:00'),
(156, 1, 'PRODUCT', 'Edited product #17: Princess Sydney - Regular (25kg/sack)', '2026-02-27 07:07:32'),
(157, 1, 'PRODUCT', 'Edited product #17: Princess Sydney - Regular (50kg/sack)', '2026-02-27 07:07:52'),
(158, 1, 'PRODUCT', 'Edited product #17: Molawin - Regular (50kg/sack)', '2026-02-27 07:10:45'),
(159, 1, 'PRODUCT', 'Archived product #18', '2026-02-27 07:11:36'),
(160, 1, 'USER_STATUS', 'Changed user_id 4 status to active', '2026-02-27 07:34:07'),
(161, 1, 'USER_STATUS', 'Changed user_id 4 status to inactive', '2026-02-27 07:34:13'),
(162, 1, 'USER_STATUS', 'Changed user_id 3 status to active', '2026-02-27 07:35:34'),
(163, 2, 'SALE_CREATE', 'Created sale #82 (paid) gross ₱600.00 disc ₱120.00 net ₱480.00', '2026-02-27 07:39:28'),
(164, 2, 'SALE_CREATE', 'Created sale #83 (unpaid) gross ₱600.00 disc ₱0.00 net ₱600.00', '2026-02-27 07:42:39'),
(165, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #83 amount ₱600.00', '2026-02-27 07:45:07'),
(166, 5, 'RETURN_APPROVED', 'RETURN_APPROVED for Return #9', '2026-02-27 07:56:09'),
(167, 2, 'SALE_CREATE', 'Created sale #84 (paid) gross ₱1,000.00 disc ₱0.00 net ₱1,000.00', '2026-02-27 08:00:57'),
(168, 2, 'SALE_CREATE', 'Created sale #85 (paid) gross ₱1,000.00 disc ₱0.00 net ₱1,000.00', '2026-02-27 08:01:33'),
(169, 2, 'SALE_CREATE', 'Created sale #86 (unpaid) gross ₱2,450.00 disc ₱490.00 net ₱1,960.00', '2026-02-27 08:03:54'),
(170, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #86 amount ₱500.00', '2026-02-27 08:04:37'),
(171, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #86 amount ₱1,460.00', '2026-02-27 08:05:37'),
(172, 1, 'PRODUCT', 'Added product: Dinorado - Regular (50kg/sack)', '2026-02-27 10:33:16'),
(173, 1, 'PRODUCT', 'Duplicated product #19 as #20 (Dinorado - Regular, 10kg/sack)', '2026-02-27 10:45:28'),
(174, 1, 'PRODUCT', 'Archived product #20', '2026-02-27 10:57:20'),
(175, 1, 'PRODUCT', 'Archived product #19', '2026-02-27 10:57:24'),
(176, 1, 'PRODUCT', 'Added product: Dinorado - Regular (50kg/sack)', '2026-02-27 10:57:46'),
(177, 1, 'PRODUCT', 'Added product: Coco Pandan - Premium (50kg/sack)', '2026-02-27 11:14:05'),
(178, 1, 'PRODUCT', 'Added product: Jasponica - Regular (50kg/sack)', '2026-02-27 11:26:12'),
(179, 2, 'SALE_CREATE', 'Created sale #87 (paid) gross ₱96.00 disc ₱19.20 net ₱76.80', '2026-02-27 11:38:38'),
(180, 1, 'PRODUCT', 'Edited product #14: Black Rice - Premium (10kg/sack)', '2026-02-27 11:44:07'),
(181, 2, 'SALE_CREATE', 'Created sale #88 (unpaid) gross ₱4,640.00 disc ₱0.00 net ₱4,640.00', '2026-02-27 11:45:16'),
(182, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #88 amount ₱4,640.00', '2026-02-27 11:48:04'),
(183, 2, 'PASSWORD_CHANGE', 'Changed cashier password with OTP verification and revoked trusted devices', '2026-03-03 08:03:20'),
(184, 2, 'SALE_CREATE', 'Created sale #89 (paid) gross ₱1,000.00 disc ₱0.00 net ₱1,000.00', '2026-03-03 10:22:37'),
(185, 2, 'SALE_CREATE', 'Created sale #90 (unpaid) gross ₱2,350.00 disc ₱0.00 net ₱2,350.00', '2026-03-03 10:23:04'),
(186, 2, 'SALE_CREATE', 'Created sale #91 (paid) gross ₱7,050.00 disc ₱1,410.00 net ₱5,640.00', '2026-03-03 10:39:40'),
(187, 2, 'SALE_CREATE', 'Created sale #92 (paid) gross ₱3,000.00 disc ₱0.00 net ₱3,000.00', '2026-03-04 07:28:45'),
(188, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #90 amount ₱2,350.00', '2026-03-04 07:30:06'),
(189, 2, 'SALE_CREATE', 'Created sale #93 (paid) gross ₱12,000.00 disc ₱0.00 net ₱12,000.00', '2026-03-04 07:34:56'),
(190, 2, 'SALE_CREATE', 'Created sale #94 (paid) gross ₱2,400.00 disc ₱480.00 net ₱1,920.00', '2026-03-10 12:14:21'),
(191, 5, 'PASSWORD_CHANGE', 'Changed account password with OTP verification and revoked trusted devices', '2026-03-20 14:41:16'),
(192, 2, 'SALE_CREATE', 'Created sale #95 (unpaid) gross ₱500.00 disc ₱100.00 net ₱400.00', '2026-03-22 08:38:53'),
(193, 1, 'PRODUCT', 'Added product: Sophia - Premium (50kg/sack)', '2026-03-23 05:34:36'),
(194, 1, 'PO', 'Updated PO #28 to status pending', '2026-03-23 05:35:59'),
(195, 1, 'SUPPLIER', 'Updated supplier #1: ABC Ride Trading (active)', '2026-03-23 05:41:38'),
(196, 1, 'PRODUCT', 'Added product: Dona Maria - Premium (50kg/sack)', '2026-03-24 03:10:22'),
(197, 1, 'PRODUCT', 'Edited product #25: Dona Maria - Premium (50kg/sack)', '2026-03-24 04:09:25'),
(198, 1, 'PO', 'Updated PO #28 to status received', '2026-03-24 04:29:26'),
(199, 2, 'SALE_CREATE', 'Created sale #96 (paid) gross ₱30.00 disc ₱0.00 net ₱30.00', '2026-03-24 04:32:48'),
(200, 2, 'SALE_CREATE', 'Created sale #97 (unpaid) gross ₱2,500.00 disc ₱0.00 net ₱2,500.00', '2026-03-24 04:44:10'),
(201, 2, 'SALE_CREATE', 'Created sale #98 (unpaid) gross ₱80.00 disc ₱0.00 net ₱80.00', '2026-03-24 04:44:48'),
(202, 2, 'SALE_CREATE', 'Created sale #99 (unpaid) gross ₱63.25 disc ₱0.00 net ₱63.25', '2026-03-25 03:20:17'),
(203, 2, 'SALE_CREATE', 'Created sale #100 (unpaid) gross ₱632.50 disc ₱126.50 net ₱506.00', '2026-03-25 03:22:14'),
(204, 2, 'SALE_CREATE', 'Created sale #101 (unpaid) gross ₱2,300.00 disc ₱0.00 net ₱2,300.00', '2026-03-25 03:55:09'),
(205, 2, 'SALE_CREATE', 'Created sale #102 (paid) gross ₱50.00 disc ₱10.00 net ₱40.00', '2026-03-28 04:43:15'),
(206, 2, 'SALE_CREATE', 'Created sale #103 (unpaid) gross ₱2,000.00 disc ₱0.00 net ₱2,000.00', '2026-03-28 04:43:56'),
(207, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #103 amount ₱2,000.00', '2026-03-28 04:44:32'),
(208, 2, 'SALE_CREATE', 'Created sale #104 (unpaid) gross ₱2,100.00 disc ₱0.00 net ₱2,100.00', '2026-03-28 04:52:23'),
(209, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #104 amount ₱2,100.00', '2026-03-28 04:53:07'),
(210, 2, 'SALE_CREATE', 'Created sale #105 (unpaid) gross ₱2,015.00 disc ₱0.00 net ₱2,015.00', '2026-03-28 04:55:20'),
(211, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #105 amount ₱2,015.00', '2026-03-28 04:56:09'),
(212, 2, 'SALE_CREATE', 'Created sale #106 (unpaid) gross ₱450.00 disc ₱0.00 net ₱450.00', '2026-03-28 04:59:26'),
(213, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #106 amount ₱450.00', '2026-03-28 05:00:10'),
(214, 2, 'SALE_CREATE', 'Created sale #107 (unpaid) gross ₱2,500.00 disc ₱0.00 net ₱2,500.00', '2026-03-28 05:05:14'),
(215, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #107 amount ₱2,500.00', '2026-03-28 05:08:17'),
(216, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #101 amount ₱2,300.00', '2026-03-28 05:10:20'),
(217, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #100 amount ₱506.00', '2026-03-28 05:11:43'),
(218, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #99 amount ₱63.25', '2026-03-28 05:12:45'),
(219, 1, 'PRODUCT', 'Archived product #25', '2026-04-01 07:47:04'),
(220, 1, 'PRODUCT', 'Archived product #24', '2026-04-07 02:27:30'),
(221, 1, 'PRODUCT', 'Edited product #22: Coco Pandan - Premium (50kg/sack)', '2026-04-07 02:30:12'),
(222, 1, 'PRODUCT', 'Edited product #22: Coco Pandan - Premium (50kg/sack)', '2026-04-07 02:30:31'),
(223, 1, 'SECURITY', 'Updated stock thresholds (LOW=80.16, OVER=5000, DYN=on, COVER=7, OVER_DAYS=30)', '2026-04-07 02:33:34'),
(224, 2, 'SALE_CREATE', 'Created sale #108 (paid) gross ₱40.30 disc ₱8.06 net ₱32.24', '2026-04-08 10:38:41'),
(225, 1, 'PRODUCT', 'Added product: Agriko - Regular (50kg/sack)', '2026-04-26 12:48:45'),
(226, 1, 'SECURITY', 'Updated stock thresholds (LOW=231, OVER=2000)', '2026-04-26 12:50:23'),
(227, 1, 'PRODUCT', 'Edited product #16: Japonesa - Premium (50kg/sack)', '2026-04-26 12:58:44'),
(228, 1, 'PRODUCT', 'Edited product #9: Square Line - Regular (10kg/sack)', '2026-04-26 12:59:27'),
(229, 1, 'PRODUCT', 'Edited product #15: Sakura - Premium (15kg/sack)', '2026-04-26 12:59:43'),
(230, 1, 'PRODUCT', 'Edited product #16: Japonesa - Premium (50kg/sack)', '2026-04-26 13:00:30'),
(231, 1, 'PRODUCT', 'Edited product #15: Sakura - Premium (15kg/sack)', '2026-04-26 13:00:41'),
(232, 1, 'PRODUCT', 'Edited product #14: Black Rice - Premium (10kg/sack)', '2026-04-26 13:01:06'),
(233, 1, 'PRODUCT', 'Edited product #14: Black Rice - Premium (10kg/sack)', '2026-04-26 13:01:21'),
(234, 1, 'PRODUCT', 'Edited product #14: Black Rice - Premium (10kg/sack)', '2026-04-26 13:01:33'),
(235, 1, 'PRODUCT', 'Edited product #13: Young Chow - Regular (50kg/sack)', '2026-04-26 13:01:44'),
(236, 1, 'PRODUCT', 'Edited product #11: Japonika - Premium (10kg/sack)', '2026-04-26 13:01:54'),
(237, 1, 'PRODUCT', 'Edited product #9: Square Line - Regular (10kg/sack)', '2026-04-26 13:02:04'),
(238, 1, 'PRODUCT', 'Edited product #8: NFA Rice - Premium (50kg/sack)', '2026-04-26 13:02:26'),
(239, 1, 'PRODUCT', 'Edited product #2: Valencia Rice (Special) - Regular (50kg/sack)', '2026-04-26 13:02:57'),
(240, 1, 'PRODUCT', 'Edited product #1: Valencia Rice - Regular (50kg/sack)', '2026-04-26 13:03:09'),
(241, 1, 'PRODUCT', 'Edited product #26: Agriko - Regular (50kg/sack)', '2026-04-26 13:03:19'),
(242, 1, 'PRODUCT', 'Edited product #23: Jasponica - Regular (50kg/sack)', '2026-04-26 13:03:29'),
(243, 1, 'PRODUCT', 'Edited product #22: Coco Pandan - Premium (50kg/sack)', '2026-04-26 13:03:40'),
(244, 1, 'PRODUCT', 'Edited product #17: Molawin - Regular (50kg/sack)', '2026-04-26 13:03:50'),
(245, 1, 'PRODUCT', 'Edited product #10: Mang Bigas - Premium (10kg/sack)', '2026-04-26 13:04:15'),
(246, 1, 'PRODUCT', 'Edited product #7: Masipag Valencia - Premium (25kg/sack)', '2026-04-26 13:04:31'),
(247, 1, 'PRODUCT', 'Edited product #5: Valencia Red Rice - Regular (50kg/sack)', '2026-04-26 13:04:43'),
(248, 1, 'SUPPLIER', 'Added supplier #4: Rice Granaries', '2026-04-26 13:07:37'),
(249, 1, 'Penalty Waiver', 'Waived penalty for AR #31. Reason: unable to pay', '2026-04-26 13:09:27'),
(250, 2, 'SALE_CREATE', 'Created sale #109 (unpaid) gross ₱46.00 disc ₱0.00 net ₱46.00', '2026-04-27 01:29:59'),
(251, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #109 amount ₱46.00', '2026-04-27 01:30:25'),
(252, 2, 'SALE_CREATE', 'Created sale #110 (paid) gross ₱3,080.00 disc ₱0.00 net ₱3,080.00', '2026-05-04 02:53:05'),
(253, 2, 'SALE_CREATE', 'Created sale #111 (paid) gross ₱90.00 disc ₱0.00 net ₱90.00', '2026-05-04 02:56:20'),
(254, 2, 'SALE_CREATE', 'Created sale #112 (unpaid) gross ₱500.00 disc ₱0.00 net ₱500.00', '2026-05-04 03:15:16'),
(255, 1, 'PO', 'Submitted purchase request #37 for supplier #3 (Grace Rice Trading), amount=25,000.00', '2026-05-11 04:27:43'),
(256, 5, 'PO_APPROVAL', 'Approved purchase request #37', '2026-05-11 04:30:35'),
(257, 1, 'PO', 'Updated PO #37 to status pending', '2026-05-11 04:30:48'),
(258, 2, 'SALE_CREATE', 'Created sale #113 (paid) gross ₱2,500.00 disc ₱0.00 net ₱2,500.00', '2026-05-11 04:34:46'),
(259, 1, 'PO', 'Submitted purchase request #38 for supplier #3 (Grace Rice Trading), amount=50,000.00', '2026-05-24 08:11:30'),
(260, 1, 'PO', 'Updated PO #37 to status pending', '2026-05-24 08:11:46'),
(261, 1, 'PO', 'Updated PO #37 to status pending', '2026-05-24 08:11:50'),
(262, 1, 'PO', 'Updated PO #37 to status pending', '2026-05-24 08:11:50'),
(263, 1, 'PO', 'Updated PO #37 to status pending', '2026-05-24 08:11:50'),
(264, 1, 'PO', 'Updated PO #37 to status received', '2026-05-24 08:12:02'),
(265, 2, 'SALE_CREATE', 'Created sale #114 (paid) gross ₱3,150.00 disc ₱0.00 net ₱3,150.00', '2026-05-24 08:41:24'),
(266, 2, 'SALE_CREATE', 'Created sale #115 (unpaid) gross ₱3,050.00 disc ₱0.00 net ₱3,050.00', '2026-05-24 08:52:40'),
(267, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #115 amount ₱1,525.00', '2026-05-24 08:53:19'),
(268, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #115 amount ₱1,525.00', '2026-05-24 08:53:33'),
(269, 2, 'SALE_CREATE', 'Created sale #116 (unpaid) gross ₱3,150.00 disc ₱0.00 net ₱3,150.00', '2026-05-24 08:54:15'),
(270, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #116 amount ₱3,150.00', '2026-05-24 08:54:36'),
(271, 2, 'SALE_CREATE', 'Created sale #117 (paid) gross ₱3,000.00 disc ₱600.00 net ₱2,400.00', '2026-06-01 13:45:26'),
(272, 2, 'SALE_CREATE', 'Created sale #118 (unpaid) gross ₱3,050.00 disc ₱0.00 net ₱3,050.00', '2026-06-01 13:46:21'),
(273, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #118 amount ₱3,050.00', '2026-06-01 13:46:47'),
(274, 2, 'SALE_CREATE', 'Created sale #119 (paid) gross ₱1,800.00 disc ₱0.00 net ₱1,800.00', '2026-06-02 03:05:09'),
(275, 5, 'RETURN_REJECTED', 'RETURN_REJECTED for Return #10', '2026-06-02 03:07:27'),
(276, 1, 'PO', 'Updated PO #39 to status received', '2026-06-02 04:11:07'),
(277, 1, 'PO', 'Updated PO #39 to status ordered', '2026-06-02 04:13:38'),
(278, 1, 'PO', 'Submitted purchase request #40 for supplier #3 (Grace Rice Trading), amount=12,000.00', '2026-06-02 04:26:55'),
(279, 1, 'PO', 'Submitted purchase request #41 for supplier #1 (ABC Ride Trading), amount=15,000.00', '2026-06-02 04:42:26'),
(280, 5, 'PO_APPROVAL', 'Approved purchase request #41', '2026-06-02 04:43:24'),
(281, 1, 'PO', 'Updated PO #41 to status ordered', '2026-06-02 04:48:46'),
(282, 1, 'PO', 'Submitted purchase request #42 for supplier #4 (Rice Granaries), amount=0.00', '2026-06-02 05:02:48'),
(283, 5, 'PO_APPROVAL', 'Approved purchase request #42', '2026-06-02 05:18:40'),
(284, 1, 'PO', 'Submitted purchase request #43 for supplier #1 (ABC Ride Trading), amount=5,600.00', '2026-06-02 05:29:55'),
(285, 5, 'PO_APPROVAL', 'Approved purchase request #43', '2026-06-02 05:30:13'),
(286, 1, 'PO', 'Updated PO #43 to status received', '2026-06-02 05:31:16'),
(287, 1, 'PO', 'Submitted purchase request #44 for supplier #3 (Grace Rice Trading), amount=1,600.00', '2026-06-02 05:33:26'),
(288, 5, 'PO_APPROVAL', 'Approved purchase request #44', '2026-06-02 05:33:39'),
(289, 1, 'PO', 'Submitted purchase request #45 for supplier #4 (Rice Granaries), amount=1,600.00', '2026-06-02 05:38:15'),
(290, 5, 'PO_APPROVAL', 'Approved purchase request #45', '2026-06-02 05:38:21'),
(291, 1, 'PO', 'Updated PO #44 to status pending', '2026-06-02 05:38:39'),
(292, 1, 'PO', 'Updated PO #45 to status received', '2026-06-02 05:38:44'),
(293, 1, 'PO', 'Submitted purchase request #46 for supplier #3 (Grace Rice Trading), amount=1,600.00', '2026-06-02 05:43:53'),
(294, 5, 'PO_APPROVAL', 'Approved purchase request #46', '2026-06-02 05:44:01'),
(295, 1, 'PO', 'Updated PO #46 to status received', '2026-06-02 05:44:13'),
(296, 1, 'PO', 'Submitted purchase request #47 for supplier #3 (Grace Rice Trading), amount=2,400.00', '2026-06-02 06:07:01'),
(297, 5, 'PO_APPROVAL', 'Approved purchase request #47', '2026-06-02 06:07:18'),
(298, 1, 'PO', 'Updated PO #47 to status received', '2026-06-02 06:07:31'),
(299, 1, 'PO', 'Updated PO #44 to status ordered', '2026-06-02 06:08:39'),
(300, 1, 'PO', 'Updated PO #44 to status received', '2026-06-02 06:08:54'),
(301, 1, 'PRODUCT', 'Added product: Jamaica - Regular (50kg/sack)', '2026-06-02 06:22:04'),
(302, 1, 'PO', 'Submitted purchase request #48 for supplier #2 (Agri Oro), amount=0.00', '2026-06-02 06:22:29'),
(303, 1, 'PO', 'Submitted purchase request #49 for supplier #2 (Agri Oro), amount=6,900.00', '2026-06-02 06:30:34'),
(304, 5, 'PO_APPROVAL', 'Approved purchase request #49', '2026-06-02 06:31:21'),
(305, 1, 'PO', 'Updated PO #49 to status received', '2026-06-02 06:31:39'),
(306, 1, 'PO', 'Submitted purchase request #51 for supplier #3 (Grace Rice Trading), amount=2,400.00', '2026-06-02 06:41:28'),
(307, 5, 'PO_APPROVAL', 'Approved purchase request #51', '2026-06-02 06:41:43'),
(308, 1, 'PO', 'Updated PO #51 to status ordered', '2026-06-02 06:41:57'),
(309, 1, 'PO', 'Updated PO #51 to status received', '2026-06-02 06:42:09'),
(310, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:29'),
(311, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:29'),
(312, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:29'),
(313, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:29'),
(314, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:29'),
(315, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:30'),
(316, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:30'),
(317, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:30'),
(318, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:30'),
(319, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:30'),
(320, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:30'),
(321, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:31'),
(322, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:31'),
(323, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:31'),
(324, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:31'),
(325, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:31'),
(326, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:32'),
(327, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:32'),
(328, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:32'),
(329, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:32'),
(330, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:33'),
(331, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:34'),
(332, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:34'),
(333, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:34'),
(334, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:34'),
(335, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:34'),
(336, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:34'),
(337, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:35'),
(338, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:35'),
(339, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:35'),
(340, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:35'),
(341, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:35'),
(342, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:35'),
(343, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:36'),
(344, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:36'),
(345, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:36'),
(346, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:36'),
(347, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:36'),
(348, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:36'),
(349, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:37'),
(350, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:41'),
(351, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:41'),
(352, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:41'),
(353, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:41'),
(354, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:42'),
(355, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:42'),
(356, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:42'),
(357, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:42'),
(358, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:42'),
(359, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:43'),
(360, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:43'),
(361, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:43'),
(362, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:43'),
(363, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:43'),
(364, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:43'),
(365, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:44'),
(366, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:44'),
(367, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:44'),
(368, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:44'),
(369, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:47'),
(370, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:47'),
(371, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:47'),
(372, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:47'),
(373, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:48'),
(374, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:48'),
(375, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:48'),
(376, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:48'),
(377, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:48'),
(378, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:49'),
(379, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:49'),
(380, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:49'),
(381, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:49'),
(382, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:49'),
(383, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:49'),
(384, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:50'),
(385, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:50'),
(386, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:50'),
(387, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:50'),
(388, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:50'),
(389, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:52'),
(390, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:52'),
(391, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:52'),
(392, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:52'),
(393, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:52'),
(394, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:53'),
(395, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:53'),
(396, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:53'),
(397, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:53'),
(398, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:53'),
(399, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:53'),
(400, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:54'),
(401, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:54'),
(402, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:54'),
(403, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:54'),
(404, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:54'),
(405, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:54'),
(406, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:55'),
(407, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:55'),
(408, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:03:55'),
(409, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:10'),
(410, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:10'),
(411, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:10'),
(412, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:10'),
(413, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:10'),
(414, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:11'),
(415, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:11'),
(416, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:11'),
(417, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:11'),
(418, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:12'),
(419, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:12'),
(420, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:12'),
(421, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:12'),
(422, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:12'),
(423, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:13'),
(424, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:13'),
(425, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:13'),
(426, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:13'),
(427, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:13'),
(428, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:13'),
(429, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:15'),
(430, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:15'),
(431, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:15'),
(432, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:15'),
(433, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:15'),
(434, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:16'),
(435, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:16'),
(436, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:16'),
(437, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:16'),
(438, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:16'),
(439, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:17'),
(440, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:17'),
(441, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:17'),
(442, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:17'),
(443, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:17'),
(444, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:17'),
(445, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:18'),
(446, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:18'),
(447, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:18'),
(448, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:18'),
(449, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:23'),
(450, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:24'),
(451, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:24'),
(452, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:24'),
(453, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:24'),
(454, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:25'),
(455, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:25'),
(456, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:25'),
(457, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:25'),
(458, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:25'),
(459, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:26'),
(460, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:26'),
(461, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:26'),
(462, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:26'),
(463, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:27'),
(464, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:27'),
(465, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:27'),
(466, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:27'),
(467, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:27'),
(468, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:27'),
(469, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:58'),
(470, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:58'),
(471, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:58'),
(472, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:58'),
(473, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:59'),
(474, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:59'),
(475, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:59'),
(476, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:59'),
(477, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:04:59'),
(478, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:00'),
(479, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:00'),
(480, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:00'),
(481, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:00'),
(482, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:00'),
(483, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:01'),
(484, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:01'),
(485, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:01'),
(486, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:01'),
(487, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:01'),
(488, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:01'),
(489, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:48'),
(490, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:48'),
(491, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:48'),
(492, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:49'),
(493, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:49'),
(494, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:49'),
(495, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:49'),
(496, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:49'),
(497, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:49'),
(498, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:50'),
(499, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:50'),
(500, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:50'),
(501, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:50'),
(502, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:50'),
(503, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:50'),
(504, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:51'),
(505, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:51'),
(506, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:51'),
(507, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:52'),
(508, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:52'),
(509, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:53'),
(510, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:53'),
(511, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:53'),
(512, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:53'),
(513, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:53'),
(514, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:54'),
(515, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:54'),
(516, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:54'),
(517, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:54'),
(518, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:54'),
(519, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:54'),
(520, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:55'),
(521, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:55'),
(522, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:55'),
(523, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:55'),
(524, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:55'),
(525, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:56'),
(526, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:56'),
(527, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:57'),
(528, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:57'),
(529, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:05:58'),
(530, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:43'),
(531, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:43'),
(532, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:43'),
(533, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:44'),
(534, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:44'),
(535, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:44'),
(536, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:44'),
(537, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:44'),
(538, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:45'),
(539, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:45'),
(540, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:45'),
(541, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:45'),
(542, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:45'),
(543, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:45'),
(544, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:46'),
(545, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:46'),
(546, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:46'),
(547, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:46'),
(548, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:46'),
(549, 1, 'SALE_CANCEL', 'Cancelled sale #. Reason: ', '2026-06-09 08:06:47'),
(550, 2, 'SALE_CREATE', 'Created sale #120 (paid) gross ₱2,464.00 disc ₱0.00 net ₱2,464.00', '2026-06-09 08:20:16'),
(551, 1, 'USER_CREATE', 'Created new user (cashier): genesis', '2026-06-10 01:54:56'),
(552, 1, 'USER_STATUS', 'Changed user_id 7 status to inactive', '2026-06-10 01:58:11'),
(553, 1, 'PO', 'Submitted purchase request #53 for supplier #3 (Grace Rice Trading), amount=11,500.00', '2026-06-10 02:09:27'),
(554, 5, 'PO_APPROVAL', 'Approved purchase request #53', '2026-06-10 02:09:55'),
(555, 2, 'SALE_CREATE', 'Created sale #121 (paid) gross ₱14,000.00 disc ₱0.00 net ₱14,000.00', '2026-06-10 02:22:16'),
(556, 2, 'SALE_CREATE', 'Created sale #122 (paid) gross ₱918.75 disc ₱0.00 net ₱918.75', '2026-06-10 02:26:06'),
(557, 1, 'USER_CREATE', 'Created new user (cashier): ctwo', '2026-06-11 01:18:26'),
(558, 1, 'USER_CREATE', 'Created new user (cashier): dani', '2026-06-11 01:24:17'),
(559, 1, 'PO', 'Submitted purchase request #55 for supplier #3 (Grace Rice Trading), amount=0.00', '2026-06-11 04:04:14'),
(560, 5, 'PO_APPROVAL', 'Approved purchase request #55', '2026-06-11 04:08:13'),
(561, 1, 'PO', 'Updated PO #55 to status ordered', '2026-06-11 04:09:27'),
(562, 1, 'PO', 'Submitted purchase request #56 for supplier #3 (Grace Rice Trading), amount=0.00', '2026-06-12 03:12:00'),
(563, 5, 'PO_APPROVAL', 'Approved purchase request #56', '2026-06-12 03:12:56'),
(564, 1, 'PO', 'Submitted purchase request #57 for supplier #3 (Grace Rice Trading), amount=0.00', '2026-06-12 03:41:54'),
(565, 5, 'PO_APPROVAL', 'Approved purchase request #57', '2026-06-12 03:42:07'),
(566, 1, 'PO', 'Submitted purchase request #58 for supplier #3 (Grace Rice Trading), amount=4,600.00', '2026-07-08 13:13:48'),
(567, 5, 'PO_EDIT', 'Edited purchase request #58 before approval. New total: 4,600.00', '2026-07-08 13:17:09'),
(568, 5, 'PO_APPROVAL', 'Approved purchase request #58', '2026-07-08 13:17:13'),
(569, 2, 'SALE_CREATE', 'Created sale #123 (paid) gross ₱2,300.00 disc ₱0.00 net ₱2,300.00', '2026-07-08 13:19:50');
INSERT INTO `activity_logs` (`activity_id`, `user_id`, `activity_type`, `description`, `created_at`) VALUES
(570, 1, 'PO', 'Submitted purchase request #59 for supplier #3 (Grace Rice Trading), amount=9,000.00', '2026-07-08 13:32:19'),
(571, 5, 'PO_APPROVAL', 'Approved purchase request #59', '2026-07-08 13:34:31'),
(572, 1, 'PO', 'Submitted purchase request #60 for supplier #4 (Rice Granaries), amount=9,200.00', '2026-07-16 06:06:28'),
(573, 5, 'PO_EDIT', 'Edited purchase request #60 before approval. New total: 12,500.00', '2026-07-16 06:08:17'),
(574, 5, 'PO_APPROVAL', 'Approved purchase request #60', '2026-07-16 06:08:33'),
(575, 2, 'SALE_CREATE', 'Created sale #124 (unpaid) gross ₱1,000.00 disc ₱0.00 net ₱1,000.00', '2026-07-16 06:15:08'),
(576, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #124 amount ₱1,000.00', '2026-07-16 06:16:49'),
(577, 1, 'PO', 'Submitted purchase request #61 for supplier #2 (Agri Oro), amount=2,300.00', '2026-07-16 06:21:19'),
(578, 5, 'PO_APPROVAL', 'Approved purchase request #61', '2026-07-16 06:22:31'),
(579, 1, 'PO', 'Submitted purchase request #62 for supplier #2 (Agri Oro), amount=4,600.00', '2026-07-16 06:28:28'),
(580, 5, 'PO_APPROVAL', 'Approved purchase request #62', '2026-07-16 06:29:08'),
(581, 1, 'PO', 'Submitted purchase request #63 for supplier #1 (ABC Ride Trading), amount=800.00', '2026-07-16 07:38:58'),
(582, 5, 'PO_APPROVAL', 'Approved purchase request #63', '2026-07-16 07:39:12'),
(583, 1, 'PO', 'Submitted purchase request #64 for supplier #3 (Grace Rice Trading), amount=8,000.00', '2026-07-16 08:03:13'),
(584, 1, 'PO', 'Submitted purchase request #65 for supplier #1 (ABC Ride Trading), amount=10,000.00', '2026-07-16 08:03:32'),
(585, 5, 'PO_EDIT', 'Edited purchase request #64 before approval. New total: 8,800.00', '2026-07-16 08:05:02'),
(586, 5, 'PO_APPROVAL', 'Approved purchase request #65', '2026-07-16 08:05:05'),
(587, 5, 'PO_APPROVAL', 'Approved purchase request #64', '2026-07-16 08:05:07'),
(588, 2, 'SALE_CREATE', 'Created sale #125 (paid) gross ₱3,625.00 disc ₱725.00 net ₱2,900.00', '2026-07-16 08:45:21'),
(589, 2, 'SALE_CREATE', 'Created sale #126 (unpaid) gross ₱5,000.00 disc ₱1,000.00 net ₱4,000.00', '2026-07-16 08:48:51'),
(590, 1, 'Penalty Waiver', 'Waived penalty for AR #30. Reason: SS', '2026-07-16 08:50:20'),
(591, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #126 amount ₱4,000.00', '2026-07-16 08:52:00'),
(592, 1, 'PO', 'Submitted purchase request #66 for supplier #3 (Grace Rice Trading), amount=2,450.00', '2026-07-19 12:52:13'),
(593, 5, 'PO_APPROVAL', 'Approved purchase request #66', '2026-07-19 13:06:36'),
(594, 2, 'SALE_CREATE', 'Created sale #127 (paid) gross ₱632.50 disc ₱126.50 net ₱506.00', '2026-07-19 15:11:05'),
(595, 2, 'SALE_CREATE', 'Created sale #128 (paid) gross ₱3,080.00 disc ₱154.00 net ₱2,926.00', '2026-07-19 15:31:20'),
(596, 2, 'SALE_CREATE', 'Created sale #129 (paid) gross ₱632.50 disc ₱0.00 net ₱632.50', '2026-07-19 15:37:14'),
(597, 2, 'SALE_CREATE', 'Created sale #130 (paid) gross ₱632.50 disc ₱316.25 net ₱316.25', '2026-07-21 05:00:37'),
(598, 2, 'SALE_CREATE', 'Created sale #131 (paid) gross ₱2,500.00 disc ₱250.00 net ₱2,250.00', '2026-07-21 05:19:41'),
(599, 2, 'SALE_CREATE', 'Created sale #132 (paid) gross ₱2,500.00 disc ₱250.00 net ₱2,250.00', '2026-07-21 05:41:01'),
(600, 2, 'SALE_CREATE', 'Created sale #133 (paid) gross ₱2,950.00 disc ₱295.00 net ₱2,655.00', '2026-07-21 06:35:47'),
(601, 2, 'SALE_CREATE', 'Created sale #134 (paid) gross ₱45.00 disc ₱0.00 net ₱45.00', '2026-07-21 06:39:41'),
(602, 1, 'PRODUCT', 'Added product: Maharlika - Premium (50kg/sack)', '2026-07-22 01:02:11'),
(603, 1, 'SUPPLIER', 'Added supplier #5: GoodForce Trading, Inc.', '2026-07-22 01:06:24'),
(604, 1, 'SUPPLIER', 'Added supplier #6: BK Basic Rice Trading, Inc.', '2026-07-22 01:07:30'),
(605, 1, 'PO', 'Submitted purchase request #67 for supplier #6 (BK Basic Rice Trading, Inc.), amount=0.00', '2026-07-22 01:09:30'),
(606, 5, 'PO_EDIT', 'Edited purchase request #67 before approval. New total: 6,900.00', '2026-07-22 01:10:08'),
(607, 5, 'PO_APPROVAL', 'Approved purchase request #67', '2026-07-22 01:10:12'),
(608, 1, 'SECURITY', 'Updated stock thresholds (LOW=300, OVER=2500)', '2026-07-22 01:20:39'),
(609, 2, 'SALE_CREATE', 'Created sale #135 (paid) gross ₱632.50 disc ₱0.00 net ₱632.50', '2026-07-22 01:27:05'),
(610, 2, 'SALE_CREATE', 'Created sale #136 (paid) gross ₱2,500.00 disc ₱0.00 net ₱2,500.00', '2026-07-23 07:17:59'),
(611, 1, 'PO', 'Submitted purchase request #68 for supplier #5 (GoodForce Trading, Inc.), amount=49,000.00', '2026-07-27 07:02:15'),
(612, 5, 'PO_EDIT', 'Edited purchase request #68 before approval. New total: 49,000.00', '2026-07-27 07:06:53'),
(613, 5, 'PO_APPROVAL', 'Approved purchase request #68', '2026-07-27 07:06:55'),
(614, 1, 'PO', 'Submitted purchase request #69 for supplier #1 (ABC Ride Trading), amount=69,000.00', '2026-07-27 07:33:01'),
(615, 5, 'PO_APPROVAL', 'Approved purchase request #69', '2026-07-27 07:33:28'),
(616, 2, 'SALE_CREATE', 'Created sale #137 (paid) gross ₱4,900.00 disc ₱245.00 net ₱4,655.00', '2026-07-27 08:04:57'),
(617, 2, 'SALE_CREATE', 'Created sale #138 (paid) gross ₱2,200.00 disc ₱0.00 net ₱2,200.00', '2026-07-27 08:08:43'),
(618, 2, 'SALE_CREATE', 'Created sale #139 (paid) gross ₱2,950.00 disc ₱0.00 net ₱2,950.00', '2026-07-28 10:54:36'),
(619, 2, 'SALE_CREATE', 'Created sale #140 (paid) gross ₱45.00 disc ₱0.00 net ₱45.00', '2026-07-28 10:55:32'),
(620, 1, 'PO', 'Submitted purchase request #70 for supplier #5 (GoodForce Trading, Inc.), amount=4,600.00', '2026-07-29 00:49:04'),
(621, 5, 'PO_APPROVAL', 'Approved purchase request #70', '2026-07-29 00:49:13'),
(622, 1, 'PO', 'Submitted purchase request #71 for supplier #4 (Rice Granaries), amount=4,600.00', '2026-07-29 04:28:38'),
(623, 5, 'PO_APPROVAL', 'Approved purchase request #71', '2026-07-29 04:28:49'),
(624, 1, 'PO', 'Submitted purchase request #72 for supplier #4 (Rice Granaries), amount=4,600.00', '2026-07-29 10:07:26'),
(625, 5, 'PO_APPROVAL', 'Approved purchase request #72', '2026-07-29 10:07:42'),
(626, 5, 'PO_EDIT_APPROVED', 'Edited approved purchase request #72 by Owner. Reason: add more stocks. Changes: Item #29: quantity 2 -> 5. New total: 11,500.00', '2026-07-29 10:15:18'),
(627, 1, 'PO', 'Submitted purchase request #73 for supplier #5 (GoodForce Trading, Inc.), amount=4,600.00', '2026-07-29 11:31:27'),
(628, 5, 'PO_APPROVAL', 'Approved purchase request #73', '2026-07-29 11:31:36'),
(629, 1, 'PO', 'Submitted purchase request #74 for supplier #4 (Rice Granaries), amount=2,600.00', '2026-07-29 11:37:23'),
(630, 5, 'PO_APPROVAL', 'Approved purchase request #74', '2026-07-29 11:38:19'),
(631, 2, 'SALE_CREATE', 'Created sale #141 (paid) gross ₱6,030.00 disc ₱1,206.00 net ₱4,824.00', '2026-07-29 11:44:11'),
(632, 1, 'PO', 'Submitted purchase request #75 for supplier #5 (GoodForce Trading, Inc.), amount=2,000.00', '2026-07-31 02:15:34'),
(633, 5, 'PO_EDIT', 'Edited purchase request #48 before approval. New total: 11,500.00', '2026-07-31 02:16:01'),
(634, 5, 'PO_APPROVAL', 'Approved purchase request #75', '2026-07-31 02:16:08'),
(635, 5, 'PO_APPROVAL', 'Approved purchase request #48', '2026-07-31 02:16:25'),
(636, 5, 'PO_APPROVAL', 'Approved purchase request #40', '2026-07-31 02:16:27'),
(637, 5, 'PO_APPROVAL', 'Approved purchase request #38', '2026-07-31 02:16:28'),
(638, 1, 'PO', 'Submitted purchase request #76 for supplier #3 (Grace Rice Trading), amount=1,800.00', '2026-07-31 02:23:40'),
(639, 5, 'PO_APPROVAL', 'Approved purchase request #76', '2026-07-31 02:23:47'),
(640, 2, 'SALE_CREATE', 'Created sale #142 (paid) gross ₱2,040.00 disc ₱0.00 net ₱2,040.00', '2026-07-31 03:28:46'),
(641, 5, 'RETURN_APPROVED', 'RETURN_APPROVED for Return #11', '2026-07-31 03:38:19'),
(642, 1, 'PRODUCT', 'Added product: MagRice - Premium (50kg/sack)', '2026-08-02 06:46:44'),
(643, 1, 'PO', 'Submitted purchase request #77 for supplier #5 (GoodForce Trading, Inc.), amount=0.00', '2026-08-02 06:48:08'),
(644, 5, 'PO_EDIT', 'Edited purchase request #77 before approval. New total: 11,000.00', '2026-08-02 06:50:36'),
(645, 5, 'PO_APPROVAL', 'Approved purchase request #77', '2026-08-02 06:50:47'),
(646, 5, 'PROFILE_UPDATE', 'Updated profile username to \'owner\'', '2026-08-02 07:51:53'),
(647, 1, 'PRODUCT', 'Added product: Thai Jasmine - Special (50kg/sack)', '2026-08-02 13:24:36'),
(648, 1, 'PO', 'Submitted purchase request #78 for supplier #3 (Grace Rice Trading), amount=0.00', '2026-08-02 13:25:46'),
(649, 5, 'PO_EDIT', 'Edited purchase request #78 before approval. New total: 23,000.00', '2026-08-02 13:26:00'),
(650, 5, 'PO_APPROVAL', 'Approved purchase request #78', '2026-08-02 13:26:09'),
(651, 1, 'PO', 'Submitted purchase request #79 for supplier #1 (ABC Ride Trading), amount=2,300.00', '2026-08-02 13:27:21'),
(652, 5, 'PO_EDIT', 'Edited purchase request #79 before approval. New total: 2,300.00', '2026-08-02 13:27:31'),
(653, 5, 'PO_APPROVAL', 'Approved purchase request #79', '2026-08-02 13:27:32'),
(654, 2, 'SALE_CREATE', 'Created sale #143 (paid) gross ₱2,800.00 disc ₱560.00 net ₱2,240.00', '2026-08-02 13:31:25'),
(655, 5, 'RETURN_APPROVED', 'RETURN_APPROVED for Return #12', '2026-08-02 13:32:29'),
(656, 1, 'USER_CREATE', 'Created new user (cashier): justinia', '2026-08-03 05:12:46'),
(657, 1, 'USER_STATUS_CHANGE', 'Changed user status for justinia (#10) to inactive', '2026-08-03 05:12:50'),
(658, 1, 'USER_STATUS_CHANGE', 'Changed user status for justinia (#10) to active', '2026-08-03 05:13:36'),
(659, 10, 'SALE_CREATE', 'Created sale #144 (paid) gross ₱2,250.00 disc ₱0.00 net ₱2,250.00', '2026-08-03 05:14:39'),
(660, 1, 'PO', 'Submitted purchase request #80 for supplier #5 (GoodForce Trading, Inc.), amount=11,000.00', '2026-08-03 06:03:15'),
(661, 5, 'PO_EDIT', 'Edited purchase request #80 before approval. New total: 11,000.00', '2026-08-03 06:03:27'),
(662, 5, 'PO_APPROVAL', 'Approved purchase request #80', '2026-08-03 06:03:31'),
(663, 2, 'SALE_CREATE', 'Created sale #145 (paid) gross ₱13,500.00 disc ₱2,700.00 net ₱10,800.00', '2026-08-03 06:06:02'),
(664, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #112 amount ₱506.72', '2026-08-03 06:06:13'),
(665, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #97 amount ₱2,543.69', '2026-08-03 06:06:41'),
(666, 2, 'SALE_CREATE', 'Created sale #146 (paid) gross ₱13,500.00 disc ₱2,700.00 net ₱10,800.00', '2026-08-03 06:08:03'),
(667, 2, 'SALE_CREATE', 'Created sale #147 (paid) gross ₱5,000.00 disc ₱1,000.00 net ₱4,000.00', '2026-08-03 06:12:09'),
(668, 1, 'PO', 'Submitted purchase request #81 for supplier #4 (Rice Granaries), amount=2,200.00', '2026-08-10 06:03:32'),
(669, 5, 'PO_APPROVAL', 'Approved purchase request #81', '2026-08-10 06:03:51'),
(670, 2, 'SALE_CREATE', 'Created sale #148 (paid) gross ₱1,834.25 disc ₱0.00 net ₱1,834.25', '2026-08-10 06:08:28'),
(671, 2, 'SALE_CREATE', 'Created sale #149 (paid) gross ₱45.00 disc ₱0.00 net ₱45.00', '2026-08-10 06:13:59'),
(672, 1, 'PRODUCT', 'Archived product #30', '2026-08-10 06:32:41'),
(673, 2, 'SALE_CREATE', 'Created sale #150 (paid) gross ₱25,000.00 disc ₱0.00 net ₱25,000.00', '2026-08-10 06:37:32'),
(674, 2, 'SALE_CREATE', 'Created sale #151 (paid) gross ₱20,000.00 disc ₱0.00 net ₱20,000.00', '2026-08-10 06:43:58'),
(675, 1, 'PRODUCT', 'Edited product #29: MagRice - Premium (50kg/sack)', '2026-08-11 04:00:18'),
(676, 1, 'SETTING', 'Added new rice grade: First Class', '2026-08-12 02:15:31'),
(677, 1, 'PO', 'Submitted PO #82 for supplier #4 (Rice Granaries), amount=2,500.00', '2026-08-12 02:41:44'),
(678, 5, 'PO_APPROVAL', 'Approved purchase request #82', '2026-08-12 02:47:31'),
(679, 2, 'SALE_CREATE', 'Created sale #152 (paid) gross ₱45.00 disc ₱0.00 net ₱45.00', '2026-08-17 05:56:43'),
(680, 2, 'SALE_CREATE', 'Created sale #153 (paid) gross ₱54.00 disc ₱0.00 net ₱54.00', '2026-08-17 06:03:32'),
(681, 2, 'SALE_CREATE', 'Created sale #154 (paid) gross ₱2,700.00 disc ₱0.00 net ₱2,700.00', '2026-08-17 06:05:24'),
(682, 2, 'SALE_CREATE', 'Created sale #155 (paid) gross ₱13,500.00 disc ₱0.00 net ₱13,500.00', '2026-08-17 06:07:02'),
(683, 2, 'SALE_CREATE', 'Created sale #156 (paid) gross ₱2,450.00 disc ₱0.00 net ₱2,450.00', '2026-08-17 06:07:23'),
(684, 2, 'SALE_CREATE', 'Created sale #157 (paid) gross ₱66.00 disc ₱0.00 net ₱66.00', '2026-08-17 08:45:38'),
(685, 2, 'SALE_CREATE', 'Created sale #158 (paid) gross ₱45.00 disc ₱0.00 net ₱45.00', '2026-08-17 13:17:30'),
(686, 5, 'PASSWORD_CHANGE', 'Changed account password with OTP verification and revoked trusted devices', '2026-08-17 13:58:45'),
(687, 1, 'PRODUCT', 'Edited product #8: NFA Rice - Broken (50kg/sack)', '2026-08-17 15:12:14'),
(688, 1, 'PO', 'Submitted PO #83 for supplier #4 (Rice Granaries), amount=2,500.00', '2026-08-17 16:45:02'),
(689, 5, 'PO_APPROVAL', 'Approved purchase request #83', '2026-08-17 16:45:17'),
(690, 1, 'PRODUCT', 'Added product: Planters Rice - First Class (50kg/sack)', '2026-08-17 16:52:00'),
(691, 1, 'SUPPLIER', 'Added supplier #7: Suy Sing CDO', '2026-08-17 16:54:37'),
(692, 2, 'SALE_CREATE', 'Created sale #159 (unpaid) gross ₱27,000.00 disc ₱0.00 net ₱27,000.00', '2026-08-17 17:16:08'),
(693, 2, 'PAYMENT_RECEIVED', 'Payment received for Sale #159 amount ₱13,500.00', '2026-08-17 17:16:25'),
(694, 1, 'PO', 'Submitted PO #84 for supplier #7 (Suy Sing CDO), amount=2,500.00', '2026-08-17 17:20:08'),
(695, 5, 'PO_APPROVAL', 'Approved purchase request #84', '2026-08-17 17:20:20'),
(696, 1, 'PO', 'Submitted PO #85 for supplier #4 (Rice Granaries), amount=3,500.00', '2026-08-18 07:22:21'),
(697, 5, 'PO_APPROVAL', 'Approved purchase request #85', '2026-08-18 07:22:30'),
(698, 1, 'USER_CREATE', 'Created new user (cashier): jayson', '2026-08-20 01:37:52'),
(699, 1, 'PO', 'Submitted PO #86 for supplier #5 (GoodForce Trading, Inc.), amount=11,500.00', '2026-08-20 03:12:07'),
(700, 1, 'PO', 'Submitted PO #87 for supplier #6 (BK Basic Rice Trading, Inc.), amount=10,500.00', '2026-08-20 03:13:46'),
(701, 1, 'PRODUCT', 'Edited product #31: Planters Rice - First Class (50kg/sack)', '2026-08-20 03:14:31'),
(702, 1, 'PRODUCT', 'Edited product #31: Planters Rice - First Class (50kg/sack)', '2026-08-20 03:16:21'),
(703, 1, 'PRODUCT', 'Archived product #31', '2026-08-20 03:16:45'),
(704, 5, 'PO_APPROVAL', 'Approved purchase request #87', '2026-08-20 03:25:36'),
(705, 5, 'PAYMENT_RECEIVED', 'Payment received for Sale #159 amount ₱898.00', '2026-08-20 03:28:45'),
(706, 1, 'PO', 'Submitted PO #88 for supplier #7 (Suy Sing CDO), amount=21,000.00', '2026-09-01 15:31:56'),
(707, 5, 'PO_APPROVAL', 'Approved purchase request #86', '2026-09-01 15:32:07'),
(708, 5, 'PO_APPROVAL', 'Approved purchase request #88', '2026-09-01 15:32:09'),
(709, 2, 'SALE_CREATE', 'Created sale #331 (paid) gross ₱15,600.00 disc ₱3,120.00 net ₱12,480.00', '2026-09-01 15:37:18');

-- --------------------------------------------------------

--
-- Table structure for table `adjust_logs`
--

CREATE TABLE `adjust_logs` (
  `adjust_log_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `adjust_type` enum('add','damaged','unsellable','discounted','in','out') NOT NULL,
  `reference_no` varchar(30) DEFAULT NULL,
  `qty_sacks` decimal(12,2) NOT NULL DEFAULT 0.00,
  `qty_kg` decimal(12,2) NOT NULL DEFAULT 0.00,
  `before_stock_kg` decimal(12,2) NOT NULL DEFAULT 0.00,
  `after_stock_kg` decimal(12,2) NOT NULL DEFAULT 0.00,
  `value_change` decimal(14,2) DEFAULT 0.00,
  `note` varchar(255) DEFAULT NULL,
  `adjusted_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adjust_logs`
--

INSERT INTO `adjust_logs` (`adjust_log_id`, `product_id`, `batch_id`, `adjust_type`, `reference_no`, `qty_sacks`, `qty_kg`, `before_stock_kg`, `after_stock_kg`, `value_change`, `note`, `adjusted_by`, `created_at`) VALUES
(1, 6, NULL, 'out', NULL, 1.00, 25.00, 48.00, 23.00, 0.00, 'test', 1, '2026-03-18 21:30:00'),
(2, 21, NULL, 'out', NULL, 3.00, 150.00, 950.00, 800.00, 0.00, 'Quality downgrade - testtt', 1, '2026-03-22 18:02:54'),
(3, 22, NULL, 'out', NULL, 5.00, 250.00, 1000.00, 750.00, 0.00, 'Wet stock - test', 1, '2026-03-22 18:03:37'),
(4, 11, NULL, 'out', NULL, 4.00, 40.00, 580.00, 580.00, 0.00, 'Discounted @ ₱50.60/kg - test', 1, '2026-03-22 18:42:27'),
(5, 25, NULL, 'out', NULL, 3.00, 150.00, 500.00, 500.00, 0.00, 'Discounted @ ₱30.00/kg - test', 1, '2026-03-24 12:10:04'),
(6, 8, NULL, 'out', NULL, 2.00, 100.00, 630.00, 530.00, 0.00, 'Pest contamination - test', 1, '2026-03-24 12:28:31'),
(7, 14, NULL, '', NULL, 1.00, 10.00, 680.00, 670.00, 0.00, 'Torn sack - sada', 1, '2026-04-07 10:58:43'),
(8, 14, NULL, '', NULL, 1.00, 10.00, 670.00, 680.00, 0.00, 'basa', 1, '2026-04-08 19:03:47'),
(9, 23, NULL, '', NULL, 1.00, 50.00, 450.00, 400.00, 0.00, 'Pest contamination - pest', 1, '2026-04-08 19:05:07'),
(10, 26, NULL, '', NULL, 1.00, 50.00, 1500.00, 1550.00, 0.00, 'Manual stock addition', 1, '2026-04-26 21:05:14'),
(11, 26, NULL, '', NULL, 3.00, 150.00, 1550.00, 1400.00, 0.00, 'Torn sack - done', 1, '2026-04-26 21:06:09'),
(12, 22, 19, 'discounted', NULL, 2.00, 100.00, 700.00, 700.00, 0.00, 'Discounted @ ₱49.28/kg - DISCOUNTED', 1, '2026-06-09 16:15:27'),
(13, 6, 24, 'damaged', NULL, 1.00, 25.00, 748.00, 723.00, 0.00, 'Quality downgrade - QUALITY IS NOT GOOD', 1, '2026-07-27 15:42:13'),
(14, 6, 24, 'discounted', NULL, 1.00, 25.00, 723.00, 723.00, 0.00, 'Discounted @ ₱57.00/kg - DISCOUNTED', 1, '2026-07-27 15:50:04'),
(15, 22, 19, 'discounted', NULL, 1.00, 50.00, 600.00, 600.00, 0.00, 'Discounted @ ₱49.00/kg - DISCOUNTED', 1, '2026-07-27 15:53:31'),
(16, 12, 11, 'discounted', NULL, 1.00, 50.00, 1018.00, 1018.00, 0.00, 'Discounted @ ₱44.00/kg - DISCOUNTED', 1, '2026-07-27 16:06:25'),
(17, 15, 36, 'discounted', NULL, 1.00, 15.00, 388.00, 388.00, 0.00, 'Discounted @ ₱46.66/kg - DISCOUNTED BECASUE OF QUALITY', 1, '2026-07-29 18:39:40'),
(18, 28, 39, 'discounted', NULL, 1.00, 50.00, 2150.00, 2150.00, 0.00, 'Discounted @ ₱40.80/kg - discounted for quality downgrade', 1, '2026-07-31 11:25:07'),
(19, 28, 39, 'damaged', NULL, 1.00, 50.00, 2100.00, 2050.00, 0.00, 'Torn sack', 1, '2026-08-11 15:52:53'),
(20, 22, 19, 'damaged', NULL, 7.00, 350.00, 450.00, 100.00, 0.00, 'Manual recount correction - DFDF', 1, '2026-08-20 11:20:17');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `archived_at` datetime DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `first_name`, `last_name`, `phone`, `email`, `archived_at`, `address`, `created_at`) VALUES
(1, 'Kriezyl', 'Villlalobos', '09129823923', NULL, NULL, 'Zone 7 Block 6 Kabina Kauswagan Cagayan de Oro City', '2026-01-24 10:59:49'),
(2, 'Sydney', 'Magsalay', '0972838634', NULL, NULL, 'Carmen', '2026-01-25 11:54:27'),
(3, 'Kirk', 'Maxilom', '09138326434', NULL, NULL, 'COC', '2026-01-25 12:59:46'),
(4, 'Kristina Cass', 'Merida', '091234567897', NULL, NULL, 'Carmen', '2026-01-26 10:59:43'),
(5, 'Jayson', 'Belmes', '091234567895', NULL, NULL, 'carmen', '2026-01-27 07:22:51'),
(6, 'Britt', 'Jaramillo', '09526347981', NULL, NULL, 'cdo', '2026-01-29 02:17:19'),
(7, 'Jecel', 'Cabasag', '093745637456', NULL, NULL, 'coc carmen', '2026-01-30 11:09:23'),
(8, 'mika', 'garol', '1234567798', NULL, NULL, 'coc', '2026-02-27 07:40:53'),
(9, 'joana', 'saliling', '098764554', 'joanasaliling@gmail.com', NULL, 'Balulang', '2026-02-27 07:59:43'),
(10, 'Yoonchae', 'Jeung', '09718734672', 'yooncahe@gmail.com', NULL, 'carmen', '2026-03-20 14:07:04'),
(11, 'Jayson', 'Belmes', '09234791299', NULL, NULL, 'carmen', '2026-08-20 03:59:36'),
(12, 'Jayson', 'Belmes', '09234791299', NULL, '2026-08-31 13:00:13', 'carmen', '2026-08-20 03:59:54');

-- --------------------------------------------------------

--
-- Table structure for table `demo_seed_runs`
--

CREATE TABLE `demo_seed_runs` (
  `seed_key` varchar(100) NOT NULL,
  `inserted_sales` int(11) NOT NULL DEFAULT 0,
  `inserted_items` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `demo_seed_runs`
--

INSERT INTO `demo_seed_runs` (`seed_key`, `inserted_sales`, `inserted_items`, `created_at`) VALUES
('demo_sales_2022_2026_v1', 171, 513, '2026-09-01 22:19:42');

-- --------------------------------------------------------

--
-- Table structure for table `discounts`
--

CREATE TABLE `discounts` (
  `discount_id` int(11) NOT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `discount_amount` decimal(10,2) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `finance_charge_logs`
--

CREATE TABLE `finance_charge_logs` (
  `charge_id` int(11) NOT NULL,
  `account_type` enum('AP','AR') NOT NULL,
  `account_id` int(11) NOT NULL,
  `charge_date` date NOT NULL,
  `interest_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `penalty_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_charge` decimal(10,2) NOT NULL DEFAULT 0.00,
  `balance_before` decimal(10,2) NOT NULL DEFAULT 0.00,
  `balance_after` decimal(10,2) NOT NULL DEFAULT 0.00,
  `note` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `finance_charge_logs`
--

INSERT INTO `finance_charge_logs` (`charge_id`, `account_type`, `account_id`, `charge_date`, `interest_amount`, `penalty_amount`, `total_charge`, `balance_before`, `balance_after`, `note`, `created_at`) VALUES
(1, 'AP', 9, '2026-04-27', 4.12, 0.00, 4.12, 6185.97, 6190.09, 'Auto overdue charge', '2026-04-27 09:23:41'),
(2, 'AP', 10, '2026-04-27', 13.66, 0.00, 13.66, 20484.69, 20498.35, 'Auto overdue charge', '2026-04-27 09:23:41'),
(3, 'AP', 11, '2026-04-27', 7.44, 0.00, 7.44, 11155.03, 11162.47, 'Auto overdue charge', '2026-04-27 09:23:41'),
(4, 'AP', 12, '2026-04-27', 13.59, 0.00, 13.59, 20383.28, 20396.87, 'Auto overdue charge', '2026-04-27 09:23:41'),
(5, 'AP', 14, '2026-04-27', 16.28, 0.00, 16.28, 24423.38, 24439.66, 'Auto overdue charge', '2026-04-27 09:23:41'),
(6, 'AP', 15, '2026-04-27', 18.23, 0.00, 18.23, 27344.06, 27362.29, 'Auto overdue charge', '2026-04-27 09:23:41'),
(7, 'AP', 16, '2026-04-27', 1.69, 0.00, 1.69, 2531.86, 2533.55, 'Auto overdue charge', '2026-04-27 09:23:41'),
(8, 'AP', 17, '2026-04-27', 32.54, 0.00, 32.54, 48814.21, 48846.75, 'Auto overdue charge', '2026-04-27 09:23:41'),
(9, 'AP', 18, '2026-04-27', 0.30, 0.00, 0.30, 450.60, 450.90, 'Auto overdue charge', '2026-04-27 09:23:41'),
(10, 'AR', 29, '2026-04-27', 0.27, 0.00, 0.27, 402.70, 402.97, 'Auto overdue charge', '2026-04-27 09:23:41'),
(11, 'AR', 30, '2026-04-27', 1.67, 0.00, 1.67, 2505.01, 2506.68, 'Auto overdue charge', '2026-04-27 09:23:41'),
(12, 'AR', 31, '2026-04-27', 0.05, 0.00, 0.05, 80.15, 80.20, 'Auto overdue charge', '2026-04-27 09:23:41'),
(13, 'AP', 9, '2026-05-04', 4.13, 0.00, 4.13, 6190.09, 6194.22, 'Auto overdue charge', '2026-05-04 10:25:01'),
(14, 'AP', 10, '2026-05-04', 13.67, 0.00, 13.67, 20498.35, 20512.02, 'Auto overdue charge', '2026-05-04 10:25:01'),
(15, 'AP', 11, '2026-05-04', 7.44, 0.00, 7.44, 11162.47, 11169.91, 'Auto overdue charge', '2026-05-04 10:25:01'),
(16, 'AP', 12, '2026-05-04', 13.60, 0.00, 13.60, 20396.87, 20410.47, 'Auto overdue charge', '2026-05-04 10:25:01'),
(17, 'AP', 14, '2026-05-04', 16.29, 0.00, 16.29, 24439.66, 24455.95, 'Auto overdue charge', '2026-05-04 10:25:01'),
(18, 'AP', 15, '2026-05-04', 18.24, 0.00, 18.24, 27362.29, 27380.53, 'Auto overdue charge', '2026-05-04 10:25:01'),
(19, 'AP', 16, '2026-05-04', 1.69, 0.00, 1.69, 2533.55, 2535.24, 'Auto overdue charge', '2026-05-04 10:25:01'),
(20, 'AP', 17, '2026-05-04', 32.56, 0.00, 32.56, 48846.75, 48879.31, 'Auto overdue charge', '2026-05-04 10:25:01'),
(21, 'AP', 18, '2026-05-04', 0.30, 0.00, 0.30, 450.90, 451.20, 'Auto overdue charge', '2026-05-04 10:25:01'),
(22, 'AP', 25, '2026-05-04', 50.00, 0.00, 50.00, 75000.00, 75050.00, 'Auto overdue charge', '2026-05-04 10:25:01'),
(23, 'AR', 29, '2026-05-04', 0.27, 0.00, 0.27, 402.97, 403.24, 'Auto overdue charge', '2026-05-04 10:25:01'),
(24, 'AR', 30, '2026-05-04', 1.67, 0.00, 1.67, 2506.68, 2508.35, 'Auto overdue charge', '2026-05-04 10:25:01'),
(25, 'AR', 31, '2026-05-04', 0.05, 0.00, 0.05, 80.20, 80.25, 'Auto overdue charge', '2026-05-04 10:25:01'),
(26, 'AP', 9, '2026-05-11', 4.13, 0.00, 4.13, 6194.22, 6198.35, 'Auto overdue charge', '2026-05-11 12:25:40'),
(27, 'AP', 10, '2026-05-11', 13.67, 0.00, 13.67, 20512.02, 20525.69, 'Auto overdue charge', '2026-05-11 12:25:40'),
(28, 'AP', 11, '2026-05-11', 7.45, 0.00, 7.45, 11169.91, 11177.36, 'Auto overdue charge', '2026-05-11 12:25:40'),
(29, 'AP', 12, '2026-05-11', 13.61, 0.00, 13.61, 20410.47, 20424.08, 'Auto overdue charge', '2026-05-11 12:25:40'),
(30, 'AP', 14, '2026-05-11', 16.30, 0.00, 16.30, 24455.95, 24472.25, 'Auto overdue charge', '2026-05-11 12:25:40'),
(31, 'AP', 15, '2026-05-11', 18.25, 0.00, 18.25, 27380.53, 27398.78, 'Auto overdue charge', '2026-05-11 12:25:40'),
(32, 'AP', 16, '2026-05-11', 1.69, 0.00, 1.69, 2535.24, 2536.93, 'Auto overdue charge', '2026-05-11 12:25:40'),
(33, 'AP', 17, '2026-05-11', 32.59, 0.00, 32.59, 48879.31, 48911.90, 'Auto overdue charge', '2026-05-11 12:25:40'),
(34, 'AP', 18, '2026-05-11', 0.30, 0.00, 0.30, 451.20, 451.50, 'Auto overdue charge', '2026-05-11 12:25:40'),
(35, 'AP', 25, '2026-05-11', 50.03, 0.00, 50.03, 75050.00, 75100.03, 'Auto overdue charge', '2026-05-11 12:25:40'),
(36, 'AR', 29, '2026-05-11', 0.27, 0.00, 0.27, 403.24, 403.51, 'Auto overdue charge', '2026-05-11 12:25:40'),
(37, 'AR', 30, '2026-05-11', 1.67, 0.00, 1.67, 2508.35, 2510.02, 'Auto overdue charge', '2026-05-11 12:25:40'),
(38, 'AR', 31, '2026-05-11', 0.05, 0.00, 0.05, 80.25, 80.30, 'Auto overdue charge', '2026-05-11 12:25:40'),
(39, 'AP', 9, '2026-05-24', 4.13, 0.00, 4.13, 6198.35, 6202.48, 'Auto overdue charge', '2026-05-24 16:03:36'),
(40, 'AP', 10, '2026-05-24', 13.68, 0.00, 13.68, 20525.69, 20539.37, 'Auto overdue charge', '2026-05-24 16:03:36'),
(41, 'AP', 11, '2026-05-24', 7.45, 0.00, 7.45, 11177.36, 11184.81, 'Auto overdue charge', '2026-05-24 16:03:36'),
(42, 'AP', 12, '2026-05-24', 13.62, 0.00, 13.62, 20424.08, 20437.70, 'Auto overdue charge', '2026-05-24 16:03:36'),
(43, 'AP', 14, '2026-05-24', 16.31, 0.00, 16.31, 24472.25, 24488.56, 'Auto overdue charge', '2026-05-24 16:03:36'),
(44, 'AP', 15, '2026-05-24', 18.27, 0.00, 18.27, 27398.78, 27417.05, 'Auto overdue charge', '2026-05-24 16:03:36'),
(45, 'AP', 16, '2026-05-24', 1.69, 0.00, 1.69, 2536.93, 2538.62, 'Auto overdue charge', '2026-05-24 16:03:36'),
(46, 'AP', 17, '2026-05-24', 32.61, 0.00, 32.61, 48911.90, 48944.51, 'Auto overdue charge', '2026-05-24 16:03:36'),
(47, 'AP', 18, '2026-05-24', 0.30, 0.00, 0.30, 451.50, 451.80, 'Auto overdue charge', '2026-05-24 16:03:36'),
(48, 'AP', 25, '2026-05-24', 50.07, 0.00, 50.07, 75100.03, 75150.10, 'Auto overdue charge', '2026-05-24 16:03:36'),
(49, 'AP', 26, '2026-05-24', 15.33, 0.00, 15.33, 22999.90, 23015.23, 'Auto overdue charge', '2026-05-24 16:03:36'),
(50, 'AP', 27, '2026-05-24', 5.33, 0.00, 5.33, 8000.00, 8005.33, 'Auto overdue charge', '2026-05-24 16:03:36'),
(51, 'AR', 29, '2026-05-24', 0.27, 0.00, 0.27, 403.51, 403.78, 'Auto overdue charge', '2026-05-24 16:03:36'),
(52, 'AR', 30, '2026-05-24', 1.67, 0.00, 1.67, 2510.02, 2511.69, 'Auto overdue charge', '2026-05-24 16:03:36'),
(53, 'AR', 31, '2026-05-24', 0.05, 0.00, 0.05, 80.30, 80.35, 'Auto overdue charge', '2026-05-24 16:03:36'),
(54, 'AR', 41, '2026-05-24', 0.33, 0.00, 0.33, 500.00, 500.33, 'Auto overdue charge', '2026-05-24 16:03:36'),
(55, 'AP', 9, '2026-06-01', 4.13, 0.00, 4.13, 6202.48, 6206.61, 'Auto overdue charge', '2026-06-01 20:28:12'),
(56, 'AP', 10, '2026-06-01', 13.69, 0.00, 13.69, 20539.37, 20553.06, 'Auto overdue charge', '2026-06-01 20:28:12'),
(57, 'AP', 11, '2026-06-01', 7.46, 0.00, 7.46, 11184.81, 11192.27, 'Auto overdue charge', '2026-06-01 20:28:12'),
(58, 'AP', 12, '2026-06-01', 13.63, 0.00, 13.63, 20437.70, 20451.33, 'Auto overdue charge', '2026-06-01 20:28:12'),
(59, 'AP', 14, '2026-06-01', 16.33, 0.00, 16.33, 24488.56, 24504.89, 'Auto overdue charge', '2026-06-01 20:28:13'),
(60, 'AP', 15, '2026-06-01', 18.28, 0.00, 18.28, 27417.05, 27435.33, 'Auto overdue charge', '2026-06-01 20:28:13'),
(61, 'AP', 16, '2026-06-01', 1.69, 0.00, 1.69, 2538.62, 2540.31, 'Auto overdue charge', '2026-06-01 20:28:13'),
(62, 'AP', 17, '2026-06-01', 32.63, 0.00, 32.63, 48944.51, 48977.14, 'Auto overdue charge', '2026-06-01 20:28:13'),
(63, 'AP', 18, '2026-06-01', 0.30, 0.00, 0.30, 451.80, 452.10, 'Auto overdue charge', '2026-06-01 20:28:13'),
(64, 'AP', 25, '2026-06-01', 50.10, 0.00, 50.10, 75150.10, 75200.20, 'Auto overdue charge', '2026-06-01 20:28:13'),
(65, 'AP', 26, '2026-06-01', 15.34, 0.00, 15.34, 23015.23, 23030.57, 'Auto overdue charge', '2026-06-01 20:28:13'),
(66, 'AP', 27, '2026-06-01', 5.34, 0.00, 5.34, 8005.33, 8010.67, 'Auto overdue charge', '2026-06-01 20:28:13'),
(67, 'AR', 29, '2026-06-01', 0.27, 0.00, 0.27, 403.78, 404.05, 'Auto overdue charge', '2026-06-01 20:28:13'),
(68, 'AR', 30, '2026-06-01', 1.67, 0.00, 1.67, 2511.69, 2513.36, 'Auto overdue charge', '2026-06-01 20:28:13'),
(69, 'AR', 31, '2026-06-01', 0.05, 0.00, 0.05, 80.35, 80.40, 'Auto overdue charge', '2026-06-01 20:28:13'),
(70, 'AR', 41, '2026-06-01', 0.33, 0.00, 0.33, 500.33, 500.66, 'Auto overdue charge', '2026-06-01 20:28:13'),
(71, 'AP', 9, '2026-06-02', 4.14, 0.00, 4.14, 6206.61, 6210.75, 'Auto overdue charge', '2026-06-02 10:51:13'),
(72, 'AP', 10, '2026-06-02', 13.70, 0.00, 13.70, 20553.06, 20566.76, 'Auto overdue charge', '2026-06-02 10:51:13'),
(73, 'AP', 11, '2026-06-02', 7.46, 0.00, 7.46, 11192.27, 11199.73, 'Auto overdue charge', '2026-06-02 10:51:13'),
(74, 'AP', 12, '2026-06-02', 13.63, 0.00, 13.63, 20451.33, 20464.96, 'Auto overdue charge', '2026-06-02 10:51:13'),
(75, 'AP', 14, '2026-06-02', 16.34, 0.00, 16.34, 24504.89, 24521.23, 'Auto overdue charge', '2026-06-02 10:51:13'),
(76, 'AP', 15, '2026-06-02', 18.29, 0.00, 18.29, 27435.33, 27453.62, 'Auto overdue charge', '2026-06-02 10:51:13'),
(77, 'AP', 16, '2026-06-02', 1.69, 0.00, 1.69, 2540.31, 2542.00, 'Auto overdue charge', '2026-06-02 10:51:13'),
(78, 'AP', 17, '2026-06-02', 32.65, 0.00, 32.65, 48977.14, 49009.79, 'Auto overdue charge', '2026-06-02 10:51:13'),
(79, 'AP', 18, '2026-06-02', 0.30, 0.00, 0.30, 452.10, 452.40, 'Auto overdue charge', '2026-06-02 10:51:13'),
(80, 'AP', 25, '2026-06-02', 50.13, 0.00, 50.13, 75200.20, 75250.33, 'Auto overdue charge', '2026-06-02 10:51:13'),
(81, 'AP', 26, '2026-06-02', 15.35, 0.00, 15.35, 23030.57, 23045.92, 'Auto overdue charge', '2026-06-02 10:51:13'),
(82, 'AP', 27, '2026-06-02', 5.34, 0.00, 5.34, 8010.67, 8016.01, 'Auto overdue charge', '2026-06-02 10:51:13'),
(83, 'AR', 29, '2026-06-02', 0.27, 0.00, 0.27, 404.05, 404.32, 'Auto overdue charge', '2026-06-02 10:51:13'),
(84, 'AR', 30, '2026-06-02', 1.68, 0.00, 1.68, 2513.36, 2515.04, 'Auto overdue charge', '2026-06-02 10:51:13'),
(85, 'AR', 31, '2026-06-02', 0.05, 0.00, 0.05, 80.40, 80.45, 'Auto overdue charge', '2026-06-02 10:51:13'),
(86, 'AR', 41, '2026-06-02', 0.33, 0.00, 0.33, 500.66, 500.99, 'Auto overdue charge', '2026-06-02 10:51:13'),
(87, 'AP', 9, '2026-06-09', 4.14, 0.00, 4.14, 6210.75, 6214.89, 'Auto overdue charge', '2026-06-09 15:51:19'),
(88, 'AP', 10, '2026-06-09', 13.71, 0.00, 13.71, 20566.76, 20580.47, 'Auto overdue charge', '2026-06-09 15:51:19'),
(89, 'AP', 11, '2026-06-09', 7.47, 0.00, 7.47, 11199.73, 11207.20, 'Auto overdue charge', '2026-06-09 15:51:19'),
(90, 'AP', 12, '2026-06-09', 13.64, 0.00, 13.64, 20464.96, 20478.60, 'Auto overdue charge', '2026-06-09 15:51:19'),
(91, 'AP', 14, '2026-06-09', 16.35, 0.00, 16.35, 24521.23, 24537.58, 'Auto overdue charge', '2026-06-09 15:51:19'),
(92, 'AP', 15, '2026-06-09', 18.30, 0.00, 18.30, 27453.62, 27471.92, 'Auto overdue charge', '2026-06-09 15:51:19'),
(93, 'AP', 16, '2026-06-09', 1.69, 0.00, 1.69, 2542.00, 2543.69, 'Auto overdue charge', '2026-06-09 15:51:19'),
(94, 'AP', 17, '2026-06-09', 32.67, 0.00, 32.67, 49009.79, 49042.46, 'Auto overdue charge', '2026-06-09 15:51:19'),
(95, 'AP', 18, '2026-06-09', 0.30, 0.00, 0.30, 452.40, 452.70, 'Auto overdue charge', '2026-06-09 15:51:19'),
(96, 'AP', 25, '2026-06-09', 50.17, 0.00, 50.17, 75250.33, 75300.50, 'Auto overdue charge', '2026-06-09 15:51:19'),
(97, 'AP', 26, '2026-06-09', 15.36, 0.00, 15.36, 23045.92, 23061.28, 'Auto overdue charge', '2026-06-09 15:51:19'),
(98, 'AP', 27, '2026-06-09', 5.34, 0.00, 5.34, 8016.01, 8021.35, 'Auto overdue charge', '2026-06-09 15:51:19'),
(99, 'AR', 29, '2026-06-09', 0.27, 0.00, 0.27, 404.32, 404.59, 'Auto overdue charge', '2026-06-09 15:51:19'),
(100, 'AR', 30, '2026-06-09', 1.68, 0.00, 1.68, 2515.04, 2516.72, 'Auto overdue charge', '2026-06-09 15:51:19'),
(101, 'AR', 31, '2026-06-09', 0.05, 0.00, 0.05, 80.45, 80.50, 'Auto overdue charge', '2026-06-09 15:51:19'),
(102, 'AR', 41, '2026-06-09', 0.33, 0.00, 0.33, 500.99, 501.32, 'Auto overdue charge', '2026-06-09 15:51:19'),
(103, 'AP', 9, '2026-06-10', 4.14, 0.00, 4.14, 6214.89, 6219.03, 'Auto overdue charge', '2026-06-10 09:42:38'),
(104, 'AP', 10, '2026-06-10', 13.72, 0.00, 13.72, 20580.47, 20594.19, 'Auto overdue charge', '2026-06-10 09:42:38'),
(105, 'AP', 11, '2026-06-10', 7.47, 0.00, 7.47, 11207.20, 11214.67, 'Auto overdue charge', '2026-06-10 09:42:38'),
(106, 'AP', 12, '2026-06-10', 13.65, 0.00, 13.65, 20478.60, 20492.25, 'Auto overdue charge', '2026-06-10 09:42:38'),
(107, 'AP', 14, '2026-06-10', 16.36, 0.00, 16.36, 24537.58, 24553.94, 'Auto overdue charge', '2026-06-10 09:42:38'),
(108, 'AP', 15, '2026-06-10', 18.31, 0.00, 18.31, 27471.92, 27490.23, 'Auto overdue charge', '2026-06-10 09:42:38'),
(109, 'AP', 16, '2026-06-10', 1.70, 0.00, 1.70, 2543.69, 2545.39, 'Auto overdue charge', '2026-06-10 09:42:38'),
(110, 'AP', 17, '2026-06-10', 32.69, 0.00, 32.69, 49042.46, 49075.15, 'Auto overdue charge', '2026-06-10 09:42:38'),
(111, 'AP', 18, '2026-06-10', 0.30, 0.00, 0.30, 452.70, 453.00, 'Auto overdue charge', '2026-06-10 09:42:38'),
(112, 'AP', 25, '2026-06-10', 50.20, 0.00, 50.20, 75300.50, 75350.70, 'Auto overdue charge', '2026-06-10 09:42:38'),
(113, 'AP', 26, '2026-06-10', 15.37, 0.00, 15.37, 23061.28, 23076.65, 'Auto overdue charge', '2026-06-10 09:42:38'),
(114, 'AP', 27, '2026-06-10', 5.35, 0.00, 5.35, 8021.35, 8026.70, 'Auto overdue charge', '2026-06-10 09:42:39'),
(115, 'AP', 29, '2026-06-10', 4.60, 0.00, 4.60, 6900.00, 6904.60, 'Auto overdue charge', '2026-06-10 09:42:39'),
(116, 'AP', 30, '2026-06-10', 1.60, 0.00, 1.60, 2400.00, 2401.60, 'Auto overdue charge', '2026-06-10 09:42:39'),
(117, 'AR', 29, '2026-06-10', 0.27, 0.00, 0.27, 404.59, 404.86, 'Auto overdue charge', '2026-06-10 09:42:39'),
(118, 'AR', 30, '2026-06-10', 1.68, 0.00, 1.68, 2516.72, 2518.40, 'Auto overdue charge', '2026-06-10 09:42:39'),
(119, 'AR', 31, '2026-06-10', 0.05, 0.00, 0.05, 80.50, 80.55, 'Auto overdue charge', '2026-06-10 09:42:39'),
(120, 'AR', 41, '2026-06-10', 0.33, 0.00, 0.33, 501.32, 501.65, 'Auto overdue charge', '2026-06-10 09:42:39'),
(121, 'AP', 9, '2026-06-11', 4.15, 0.00, 4.15, 6219.03, 6223.18, 'Auto overdue charge', '2026-06-11 08:18:38'),
(122, 'AP', 10, '2026-06-11', 13.73, 0.00, 13.73, 20594.19, 20607.92, 'Auto overdue charge', '2026-06-11 08:18:38'),
(123, 'AP', 11, '2026-06-11', 7.48, 0.00, 7.48, 11214.67, 11222.15, 'Auto overdue charge', '2026-06-11 08:18:38'),
(124, 'AP', 12, '2026-06-11', 13.66, 0.00, 13.66, 20492.25, 20505.91, 'Auto overdue charge', '2026-06-11 08:18:38'),
(125, 'AP', 14, '2026-06-11', 16.37, 0.00, 16.37, 24553.94, 24570.31, 'Auto overdue charge', '2026-06-11 08:18:38'),
(126, 'AP', 15, '2026-06-11', 18.33, 0.00, 18.33, 27490.23, 27508.56, 'Auto overdue charge', '2026-06-11 08:18:38'),
(127, 'AP', 16, '2026-06-11', 1.70, 0.00, 1.70, 2545.39, 2547.09, 'Auto overdue charge', '2026-06-11 08:18:38'),
(128, 'AP', 17, '2026-06-11', 32.72, 0.00, 32.72, 49075.15, 49107.87, 'Auto overdue charge', '2026-06-11 08:18:38'),
(129, 'AP', 18, '2026-06-11', 0.30, 0.00, 0.30, 453.00, 453.30, 'Auto overdue charge', '2026-06-11 08:18:38'),
(130, 'AP', 25, '2026-06-11', 50.23, 0.00, 50.23, 75350.70, 75400.93, 'Auto overdue charge', '2026-06-11 08:18:38'),
(131, 'AP', 26, '2026-06-11', 15.38, 0.00, 15.38, 23076.65, 23092.03, 'Auto overdue charge', '2026-06-11 08:18:38'),
(132, 'AP', 27, '2026-06-11', 5.35, 0.00, 5.35, 8026.70, 8032.05, 'Auto overdue charge', '2026-06-11 08:18:38'),
(133, 'AP', 29, '2026-06-11', 4.60, 0.00, 4.60, 6904.60, 6909.20, 'Auto overdue charge', '2026-06-11 08:18:38'),
(134, 'AP', 30, '2026-06-11', 1.60, 0.00, 1.60, 2401.60, 2403.20, 'Auto overdue charge', '2026-06-11 08:18:38'),
(135, 'AR', 29, '2026-06-11', 0.27, 0.00, 0.27, 404.86, 405.13, 'Auto overdue charge', '2026-06-11 08:18:38'),
(136, 'AR', 30, '2026-06-11', 1.68, 0.00, 1.68, 2518.40, 2520.08, 'Auto overdue charge', '2026-06-11 08:18:38'),
(137, 'AR', 31, '2026-06-11', 0.05, 0.00, 0.05, 80.55, 80.60, 'Auto overdue charge', '2026-06-11 08:18:38'),
(138, 'AR', 41, '2026-06-11', 0.33, 0.00, 0.33, 501.65, 501.98, 'Auto overdue charge', '2026-06-11 08:18:38'),
(139, 'AP', 9, '2026-06-12', 4.15, 0.00, 4.15, 6223.18, 6227.33, 'Auto overdue charge', '2026-06-12 10:21:21'),
(140, 'AP', 10, '2026-06-12', 13.74, 0.00, 13.74, 20607.92, 20621.66, 'Auto overdue charge', '2026-06-12 10:21:21'),
(141, 'AP', 11, '2026-06-12', 7.48, 0.00, 7.48, 11222.15, 11229.63, 'Auto overdue charge', '2026-06-12 10:21:21'),
(142, 'AP', 12, '2026-06-12', 13.67, 0.00, 13.67, 20505.91, 20519.58, 'Auto overdue charge', '2026-06-12 10:21:21'),
(143, 'AP', 14, '2026-06-12', 16.38, 0.00, 16.38, 24570.31, 24586.69, 'Auto overdue charge', '2026-06-12 10:21:21'),
(144, 'AP', 15, '2026-06-12', 18.34, 0.00, 18.34, 27508.56, 27526.90, 'Auto overdue charge', '2026-06-12 10:21:21'),
(145, 'AP', 16, '2026-06-12', 1.70, 0.00, 1.70, 2547.09, 2548.79, 'Auto overdue charge', '2026-06-12 10:21:21'),
(146, 'AP', 17, '2026-06-12', 32.74, 0.00, 32.74, 49107.87, 49140.61, 'Auto overdue charge', '2026-06-12 10:21:21'),
(147, 'AP', 18, '2026-06-12', 0.30, 0.00, 0.30, 453.30, 453.60, 'Auto overdue charge', '2026-06-12 10:21:21'),
(148, 'AP', 25, '2026-06-12', 50.27, 0.00, 50.27, 75400.93, 75451.20, 'Auto overdue charge', '2026-06-12 10:21:21'),
(149, 'AP', 26, '2026-06-12', 15.39, 0.00, 15.39, 23092.03, 23107.42, 'Auto overdue charge', '2026-06-12 10:21:21'),
(150, 'AP', 27, '2026-06-12', 5.35, 0.00, 5.35, 8032.05, 8037.40, 'Auto overdue charge', '2026-06-12 10:21:21'),
(151, 'AP', 29, '2026-06-12', 4.61, 0.00, 4.61, 6909.20, 6913.81, 'Auto overdue charge', '2026-06-12 10:21:21'),
(152, 'AP', 30, '2026-06-12', 1.60, 0.00, 1.60, 2403.20, 2404.80, 'Auto overdue charge', '2026-06-12 10:21:21'),
(153, 'AR', 29, '2026-06-12', 0.27, 0.00, 0.27, 405.13, 405.40, 'Auto overdue charge', '2026-06-12 10:21:21'),
(154, 'AR', 30, '2026-06-12', 1.68, 0.00, 1.68, 2520.08, 2521.76, 'Auto overdue charge', '2026-06-12 10:21:21'),
(155, 'AR', 31, '2026-06-12', 0.05, 0.00, 0.05, 80.60, 80.65, 'Auto overdue charge', '2026-06-12 10:21:21'),
(156, 'AR', 41, '2026-06-12', 0.33, 0.00, 0.33, 501.98, 502.31, 'Auto overdue charge', '2026-06-12 10:21:21'),
(157, 'AP', 9, '2026-07-07', 4.15, 0.00, 4.15, 6227.33, 6231.48, 'Auto overdue charge', '2026-07-07 11:07:02'),
(158, 'AP', 10, '2026-07-07', 13.75, 0.00, 13.75, 20621.66, 20635.41, 'Auto overdue charge', '2026-07-07 11:07:02'),
(159, 'AP', 11, '2026-07-07', 7.49, 0.00, 7.49, 11229.63, 11237.12, 'Auto overdue charge', '2026-07-07 11:07:02'),
(160, 'AP', 12, '2026-07-07', 13.68, 0.00, 13.68, 20519.58, 20533.26, 'Auto overdue charge', '2026-07-07 11:07:02'),
(161, 'AP', 14, '2026-07-07', 16.39, 0.00, 16.39, 24586.69, 24603.08, 'Auto overdue charge', '2026-07-07 11:07:02'),
(162, 'AP', 15, '2026-07-07', 18.35, 0.00, 18.35, 27526.90, 27545.25, 'Auto overdue charge', '2026-07-07 11:07:02'),
(163, 'AP', 16, '2026-07-07', 1.70, 0.00, 1.70, 2548.79, 2550.49, 'Auto overdue charge', '2026-07-07 11:07:02'),
(164, 'AP', 17, '2026-07-07', 32.76, 0.00, 32.76, 49140.61, 49173.37, 'Auto overdue charge', '2026-07-07 11:07:02'),
(165, 'AP', 18, '2026-07-07', 0.30, 0.00, 0.30, 453.60, 453.90, 'Auto overdue charge', '2026-07-07 11:07:02'),
(166, 'AP', 25, '2026-07-07', 50.30, 0.00, 50.30, 75451.20, 75501.50, 'Auto overdue charge', '2026-07-07 11:07:02'),
(167, 'AP', 26, '2026-07-07', 15.40, 0.00, 15.40, 23107.42, 23122.82, 'Auto overdue charge', '2026-07-07 11:07:02'),
(168, 'AP', 27, '2026-07-07', 5.36, 0.00, 5.36, 8037.40, 8042.76, 'Auto overdue charge', '2026-07-07 11:07:02'),
(169, 'AP', 29, '2026-07-07', 4.61, 0.00, 4.61, 6913.81, 6918.42, 'Auto overdue charge', '2026-07-07 11:07:02'),
(170, 'AP', 30, '2026-07-07', 1.60, 0.00, 1.60, 2404.80, 2406.40, 'Auto overdue charge', '2026-07-07 11:07:02'),
(171, 'AP', 31, '2026-07-07', 7.67, 0.00, 7.67, 11500.00, 11507.67, 'Auto overdue charge', '2026-07-07 11:07:02'),
(172, 'AR', 29, '2026-07-07', 0.27, 0.00, 0.27, 405.40, 405.67, 'Auto overdue charge', '2026-07-07 11:07:02'),
(173, 'AR', 30, '2026-07-07', 1.68, 0.00, 1.68, 2521.76, 2523.44, 'Auto overdue charge', '2026-07-07 11:07:03'),
(174, 'AR', 31, '2026-07-07', 0.05, 0.00, 0.05, 80.65, 80.70, 'Auto overdue charge', '2026-07-07 11:07:03'),
(175, 'AR', 41, '2026-07-07', 0.33, 0.00, 0.33, 502.31, 502.64, 'Auto overdue charge', '2026-07-07 11:07:03'),
(176, 'AP', 9, '2026-07-08', 4.15, 0.00, 4.15, 6231.48, 6235.63, 'Auto overdue charge', '2026-07-08 20:14:07'),
(177, 'AP', 10, '2026-07-08', 13.76, 0.00, 13.76, 20635.41, 20649.17, 'Auto overdue charge', '2026-07-08 20:14:07'),
(178, 'AP', 11, '2026-07-08', 7.49, 0.00, 7.49, 11237.12, 11244.61, 'Auto overdue charge', '2026-07-08 20:14:07'),
(179, 'AP', 12, '2026-07-08', 13.69, 0.00, 13.69, 20533.26, 20546.95, 'Auto overdue charge', '2026-07-08 20:14:07'),
(180, 'AP', 14, '2026-07-08', 16.40, 0.00, 16.40, 24603.08, 24619.48, 'Auto overdue charge', '2026-07-08 20:14:07'),
(181, 'AP', 15, '2026-07-08', 18.36, 0.00, 18.36, 27545.25, 27563.61, 'Auto overdue charge', '2026-07-08 20:14:07'),
(182, 'AP', 16, '2026-07-08', 1.70, 0.00, 1.70, 2550.49, 2552.19, 'Auto overdue charge', '2026-07-08 20:14:07'),
(183, 'AP', 17, '2026-07-08', 32.78, 0.00, 32.78, 49173.37, 49206.15, 'Auto overdue charge', '2026-07-08 20:14:07'),
(184, 'AP', 18, '2026-07-08', 0.30, 0.00, 0.30, 453.90, 454.20, 'Auto overdue charge', '2026-07-08 20:14:07'),
(185, 'AP', 25, '2026-07-08', 50.33, 0.00, 50.33, 75501.50, 75551.83, 'Auto overdue charge', '2026-07-08 20:14:07'),
(186, 'AP', 26, '2026-07-08', 15.42, 0.00, 15.42, 23122.82, 23138.24, 'Auto overdue charge', '2026-07-08 20:14:07'),
(187, 'AP', 27, '2026-07-08', 5.36, 0.00, 5.36, 8042.76, 8048.12, 'Auto overdue charge', '2026-07-08 20:14:07'),
(188, 'AP', 29, '2026-07-08', 4.61, 0.00, 4.61, 6918.42, 6923.03, 'Auto overdue charge', '2026-07-08 20:14:07'),
(189, 'AP', 30, '2026-07-08', 1.60, 0.00, 1.60, 2406.40, 2408.00, 'Auto overdue charge', '2026-07-08 20:14:07'),
(190, 'AP', 31, '2026-07-08', 7.67, 0.00, 7.67, 11507.67, 11515.34, 'Auto overdue charge', '2026-07-08 20:14:07'),
(191, 'AR', 29, '2026-07-08', 0.27, 0.00, 0.27, 405.67, 405.94, 'Auto overdue charge', '2026-07-08 20:14:08'),
(192, 'AR', 30, '2026-07-08', 1.68, 0.00, 1.68, 2523.44, 2525.12, 'Auto overdue charge', '2026-07-08 20:14:08'),
(193, 'AR', 31, '2026-07-08', 0.05, 0.00, 0.05, 80.70, 80.75, 'Auto overdue charge', '2026-07-08 20:14:08'),
(194, 'AR', 41, '2026-07-08', 0.34, 0.00, 0.34, 502.64, 502.98, 'Auto overdue charge', '2026-07-08 20:14:08'),
(195, 'AP', 9, '2026-07-16', 4.16, 0.00, 4.16, 6235.63, 6239.79, 'Auto overdue charge', '2026-07-16 13:47:11'),
(196, 'AP', 10, '2026-07-16', 13.77, 0.00, 13.77, 20649.17, 20662.94, 'Auto overdue charge', '2026-07-16 13:47:11'),
(197, 'AP', 11, '2026-07-16', 7.50, 0.00, 7.50, 11244.61, 11252.11, 'Auto overdue charge', '2026-07-16 13:47:11'),
(198, 'AP', 12, '2026-07-16', 13.70, 0.00, 13.70, 20546.95, 20560.65, 'Auto overdue charge', '2026-07-16 13:47:11'),
(199, 'AP', 14, '2026-07-16', 16.41, 0.00, 16.41, 24619.48, 24635.89, 'Auto overdue charge', '2026-07-16 13:47:11'),
(200, 'AP', 15, '2026-07-16', 18.38, 0.00, 18.38, 27563.61, 27581.99, 'Auto overdue charge', '2026-07-16 13:47:11'),
(201, 'AP', 16, '2026-07-16', 1.70, 0.00, 1.70, 2552.19, 2553.89, 'Auto overdue charge', '2026-07-16 13:47:11'),
(202, 'AP', 17, '2026-07-16', 32.80, 0.00, 32.80, 49206.15, 49238.95, 'Auto overdue charge', '2026-07-16 13:47:11'),
(203, 'AP', 18, '2026-07-16', 0.30, 0.00, 0.30, 454.20, 454.50, 'Auto overdue charge', '2026-07-16 13:47:11'),
(204, 'AP', 25, '2026-07-16', 50.37, 0.00, 50.37, 75551.83, 75602.20, 'Auto overdue charge', '2026-07-16 13:47:11'),
(205, 'AP', 26, '2026-07-16', 15.43, 0.00, 15.43, 23138.24, 23153.67, 'Auto overdue charge', '2026-07-16 13:47:11'),
(206, 'AP', 27, '2026-07-16', 5.37, 0.00, 5.37, 8048.12, 8053.49, 'Auto overdue charge', '2026-07-16 13:47:11'),
(207, 'AP', 29, '2026-07-16', 4.62, 0.00, 4.62, 6923.03, 6927.65, 'Auto overdue charge', '2026-07-16 13:47:11'),
(208, 'AP', 30, '2026-07-16', 1.61, 0.00, 1.61, 2408.00, 2409.61, 'Auto overdue charge', '2026-07-16 13:47:11'),
(209, 'AP', 31, '2026-07-16', 7.68, 0.00, 7.68, 11515.34, 11523.02, 'Auto overdue charge', '2026-07-16 13:47:11'),
(210, 'AR', 29, '2026-07-16', 0.27, 0.00, 0.27, 405.94, 406.21, 'Auto overdue charge', '2026-07-16 13:47:11'),
(211, 'AR', 30, '2026-07-16', 1.68, 0.00, 1.68, 2525.12, 2526.80, 'Auto overdue charge', '2026-07-16 13:47:11'),
(212, 'AR', 31, '2026-07-16', 0.05, 0.00, 0.05, 80.75, 80.80, 'Auto overdue charge', '2026-07-16 13:47:11'),
(213, 'AR', 41, '2026-07-16', 0.34, 0.00, 0.34, 502.98, 503.32, 'Auto overdue charge', '2026-07-16 13:47:11'),
(214, 'AP', 9, '2026-07-19', 4.16, 0.00, 4.16, 6239.79, 6243.95, 'Auto overdue charge', '2026-07-19 20:47:39'),
(215, 'AP', 10, '2026-07-19', 13.78, 0.00, 13.78, 20662.94, 20676.72, 'Auto overdue charge', '2026-07-19 20:47:40'),
(216, 'AP', 11, '2026-07-19', 7.50, 0.00, 7.50, 11252.11, 11259.61, 'Auto overdue charge', '2026-07-19 20:47:40'),
(217, 'AP', 12, '2026-07-19', 13.71, 0.00, 13.71, 20560.65, 20574.36, 'Auto overdue charge', '2026-07-19 20:47:40'),
(218, 'AP', 14, '2026-07-19', 16.42, 0.00, 16.42, 24635.89, 24652.31, 'Auto overdue charge', '2026-07-19 20:47:40'),
(219, 'AP', 15, '2026-07-19', 18.39, 0.00, 18.39, 27581.99, 27600.38, 'Auto overdue charge', '2026-07-19 20:47:40'),
(220, 'AP', 16, '2026-07-19', 1.70, 0.00, 1.70, 2553.89, 2555.59, 'Auto overdue charge', '2026-07-19 20:47:40'),
(221, 'AP', 17, '2026-07-19', 32.83, 0.00, 32.83, 49238.95, 49271.78, 'Auto overdue charge', '2026-07-19 20:47:40'),
(222, 'AP', 18, '2026-07-19', 0.30, 0.00, 0.30, 454.50, 454.80, 'Auto overdue charge', '2026-07-19 20:47:40'),
(223, 'AP', 25, '2026-07-19', 50.40, 0.00, 50.40, 75602.20, 75652.60, 'Auto overdue charge', '2026-07-19 20:47:40'),
(224, 'AP', 26, '2026-07-19', 15.44, 0.00, 15.44, 23153.67, 23169.11, 'Auto overdue charge', '2026-07-19 20:47:40'),
(225, 'AP', 27, '2026-07-19', 5.37, 0.00, 5.37, 8053.49, 8058.86, 'Auto overdue charge', '2026-07-19 20:47:40'),
(226, 'AP', 29, '2026-07-19', 4.62, 0.00, 4.62, 6927.65, 6932.27, 'Auto overdue charge', '2026-07-19 20:47:40'),
(227, 'AP', 30, '2026-07-19', 1.61, 0.00, 1.61, 2409.61, 2411.22, 'Auto overdue charge', '2026-07-19 20:47:40'),
(228, 'AP', 31, '2026-07-19', 7.68, 0.00, 7.68, 11523.02, 11530.70, 'Auto overdue charge', '2026-07-19 20:47:40'),
(229, 'AR', 29, '2026-07-19', 0.27, 0.00, 0.27, 406.21, 406.48, 'Auto overdue charge', '2026-07-19 20:47:40'),
(230, 'AR', 30, '2026-07-19', 1.68, 0.00, 1.68, 2526.80, 2528.48, 'Auto overdue charge', '2026-07-19 20:47:40'),
(231, 'AR', 31, '2026-07-19', 0.05, 0.00, 0.05, 80.80, 80.85, 'Auto overdue charge', '2026-07-19 20:47:40'),
(232, 'AR', 41, '2026-07-19', 0.34, 0.00, 0.34, 503.32, 503.66, 'Auto overdue charge', '2026-07-19 20:47:40'),
(233, 'AP', 9, '2026-07-21', 4.16, 0.00, 4.16, 6243.95, 6248.11, 'Auto overdue charge', '2026-07-21 12:33:16'),
(234, 'AP', 10, '2026-07-21', 13.78, 0.00, 13.78, 20676.72, 20690.50, 'Auto overdue charge', '2026-07-21 12:33:16'),
(235, 'AP', 11, '2026-07-21', 7.51, 0.00, 7.51, 11259.61, 11267.12, 'Auto overdue charge', '2026-07-21 12:33:16'),
(236, 'AP', 12, '2026-07-21', 13.72, 0.00, 13.72, 20574.36, 20588.08, 'Auto overdue charge', '2026-07-21 12:33:16'),
(237, 'AP', 14, '2026-07-21', 16.43, 0.00, 16.43, 24652.31, 24668.74, 'Auto overdue charge', '2026-07-21 12:33:16'),
(238, 'AP', 15, '2026-07-21', 18.40, 0.00, 18.40, 27600.38, 27618.78, 'Auto overdue charge', '2026-07-21 12:33:16'),
(239, 'AP', 16, '2026-07-21', 1.70, 0.00, 1.70, 2555.59, 2557.29, 'Auto overdue charge', '2026-07-21 12:33:16'),
(240, 'AP', 17, '2026-07-21', 32.85, 0.00, 32.85, 49271.78, 49304.63, 'Auto overdue charge', '2026-07-21 12:33:16'),
(241, 'AP', 18, '2026-07-21', 0.30, 0.00, 0.30, 454.80, 455.10, 'Auto overdue charge', '2026-07-21 12:33:16'),
(242, 'AP', 25, '2026-07-21', 50.44, 0.00, 50.44, 75652.60, 75703.04, 'Auto overdue charge', '2026-07-21 12:33:16'),
(243, 'AP', 26, '2026-07-21', 15.45, 0.00, 15.45, 23169.11, 23184.56, 'Auto overdue charge', '2026-07-21 12:33:16'),
(244, 'AP', 27, '2026-07-21', 5.37, 0.00, 5.37, 8058.86, 8064.23, 'Auto overdue charge', '2026-07-21 12:33:16'),
(245, 'AP', 29, '2026-07-21', 4.62, 0.00, 4.62, 6932.27, 6936.89, 'Auto overdue charge', '2026-07-21 12:33:16'),
(246, 'AP', 30, '2026-07-21', 1.61, 0.00, 1.61, 2411.22, 2412.83, 'Auto overdue charge', '2026-07-21 12:33:16'),
(247, 'AP', 31, '2026-07-21', 7.69, 0.00, 7.69, 11530.70, 11538.39, 'Auto overdue charge', '2026-07-21 12:33:16'),
(248, 'AR', 29, '2026-07-21', 0.27, 0.00, 0.27, 406.48, 406.75, 'Auto overdue charge', '2026-07-21 12:33:16'),
(249, 'AR', 30, '2026-07-21', 1.69, 0.00, 1.69, 2528.48, 2530.17, 'Auto overdue charge', '2026-07-21 12:33:16'),
(250, 'AR', 31, '2026-07-21', 0.05, 0.00, 0.05, 80.85, 80.90, 'Auto overdue charge', '2026-07-21 12:33:16'),
(251, 'AR', 41, '2026-07-21', 0.34, 0.00, 0.34, 503.66, 504.00, 'Auto overdue charge', '2026-07-21 12:33:16'),
(252, 'AP', 9, '2026-07-22', 4.17, 0.00, 4.17, 6248.11, 6252.28, 'Auto overdue charge', '2026-07-22 08:58:53'),
(253, 'AP', 10, '2026-07-22', 13.79, 0.00, 13.79, 20690.50, 20704.29, 'Auto overdue charge', '2026-07-22 08:58:53'),
(254, 'AP', 11, '2026-07-22', 7.51, 0.00, 7.51, 11267.12, 11274.63, 'Auto overdue charge', '2026-07-22 08:58:53'),
(255, 'AP', 12, '2026-07-22', 13.73, 0.00, 13.73, 20588.08, 20601.81, 'Auto overdue charge', '2026-07-22 08:58:53'),
(256, 'AP', 14, '2026-07-22', 16.45, 0.00, 16.45, 24668.74, 24685.19, 'Auto overdue charge', '2026-07-22 08:58:53'),
(257, 'AP', 15, '2026-07-22', 18.41, 0.00, 18.41, 27618.78, 27637.19, 'Auto overdue charge', '2026-07-22 08:58:53'),
(258, 'AP', 16, '2026-07-22', 1.70, 0.00, 1.70, 2557.29, 2558.99, 'Auto overdue charge', '2026-07-22 08:58:53'),
(259, 'AP', 17, '2026-07-22', 32.87, 0.00, 32.87, 49304.63, 49337.50, 'Auto overdue charge', '2026-07-22 08:58:53'),
(260, 'AP', 18, '2026-07-22', 0.30, 0.00, 0.30, 455.10, 455.40, 'Auto overdue charge', '2026-07-22 08:58:53'),
(261, 'AP', 25, '2026-07-22', 50.47, 0.00, 50.47, 75703.04, 75753.51, 'Auto overdue charge', '2026-07-22 08:58:53'),
(262, 'AP', 26, '2026-07-22', 15.46, 0.00, 15.46, 23184.56, 23200.02, 'Auto overdue charge', '2026-07-22 08:58:53'),
(263, 'AP', 27, '2026-07-22', 5.38, 0.00, 5.38, 8064.23, 8069.61, 'Auto overdue charge', '2026-07-22 08:58:53'),
(264, 'AP', 29, '2026-07-22', 4.62, 0.00, 4.62, 6936.89, 6941.51, 'Auto overdue charge', '2026-07-22 08:58:53'),
(265, 'AP', 30, '2026-07-22', 1.61, 0.00, 1.61, 2412.83, 2414.44, 'Auto overdue charge', '2026-07-22 08:58:53'),
(266, 'AP', 31, '2026-07-22', 7.69, 0.00, 7.69, 11538.39, 11546.08, 'Auto overdue charge', '2026-07-22 08:58:53'),
(267, 'AR', 29, '2026-07-22', 0.27, 0.00, 0.27, 406.75, 407.02, 'Auto overdue charge', '2026-07-22 08:58:53'),
(268, 'AR', 30, '2026-07-22', 1.69, 0.00, 1.69, 2530.17, 2531.86, 'Auto overdue charge', '2026-07-22 08:58:53'),
(269, 'AR', 31, '2026-07-22', 0.05, 0.00, 0.05, 80.90, 80.95, 'Auto overdue charge', '2026-07-22 08:58:53'),
(270, 'AR', 41, '2026-07-22', 0.34, 0.00, 0.34, 504.00, 504.34, 'Auto overdue charge', '2026-07-22 08:58:53'),
(271, 'AP', 9, '2026-07-23', 4.17, 0.00, 4.17, 6252.28, 6256.45, 'Auto overdue charge', '2026-07-23 15:07:16'),
(272, 'AP', 10, '2026-07-23', 13.80, 0.00, 13.80, 20704.29, 20718.09, 'Auto overdue charge', '2026-07-23 15:07:16'),
(273, 'AP', 11, '2026-07-23', 7.52, 0.00, 7.52, 11274.63, 11282.15, 'Auto overdue charge', '2026-07-23 15:07:16'),
(274, 'AP', 12, '2026-07-23', 13.73, 0.00, 13.73, 20601.81, 20615.54, 'Auto overdue charge', '2026-07-23 15:07:16'),
(275, 'AP', 14, '2026-07-23', 16.46, 0.00, 16.46, 24685.19, 24701.65, 'Auto overdue charge', '2026-07-23 15:07:16'),
(276, 'AP', 15, '2026-07-23', 18.42, 0.00, 18.42, 27637.19, 27655.61, 'Auto overdue charge', '2026-07-23 15:07:16'),
(277, 'AP', 16, '2026-07-23', 1.71, 0.00, 1.71, 2558.99, 2560.70, 'Auto overdue charge', '2026-07-23 15:07:16'),
(278, 'AP', 17, '2026-07-23', 32.89, 0.00, 32.89, 49337.50, 49370.39, 'Auto overdue charge', '2026-07-23 15:07:16'),
(279, 'AP', 18, '2026-07-23', 0.30, 0.00, 0.30, 455.40, 455.70, 'Auto overdue charge', '2026-07-23 15:07:16'),
(280, 'AP', 25, '2026-07-23', 50.50, 0.00, 50.50, 75753.51, 75804.01, 'Auto overdue charge', '2026-07-23 15:07:16'),
(281, 'AP', 26, '2026-07-23', 15.47, 0.00, 15.47, 23200.02, 23215.49, 'Auto overdue charge', '2026-07-23 15:07:16'),
(282, 'AP', 27, '2026-07-23', 5.38, 0.00, 5.38, 8069.61, 8074.99, 'Auto overdue charge', '2026-07-23 15:07:16'),
(283, 'AP', 29, '2026-07-23', 4.63, 0.00, 4.63, 6941.51, 6946.14, 'Auto overdue charge', '2026-07-23 15:07:16'),
(284, 'AP', 30, '2026-07-23', 1.61, 0.00, 1.61, 2414.44, 2416.05, 'Auto overdue charge', '2026-07-23 15:07:16'),
(285, 'AP', 31, '2026-07-23', 7.70, 0.00, 7.70, 11546.08, 11553.78, 'Auto overdue charge', '2026-07-23 15:07:16'),
(286, 'AR', 29, '2026-07-23', 0.27, 0.00, 0.27, 407.02, 407.29, 'Auto overdue charge', '2026-07-23 15:07:16'),
(287, 'AR', 30, '2026-07-23', 1.69, 0.00, 1.69, 2531.86, 2533.55, 'Auto overdue charge', '2026-07-23 15:07:16'),
(288, 'AR', 31, '2026-07-23', 0.05, 0.00, 0.05, 80.95, 81.00, 'Auto overdue charge', '2026-07-23 15:07:16'),
(289, 'AR', 41, '2026-07-23', 0.34, 0.00, 0.34, 504.34, 504.68, 'Auto overdue charge', '2026-07-23 15:07:16'),
(290, 'AP', 9, '2026-07-27', 4.17, 0.00, 4.17, 6256.45, 6260.62, 'Auto overdue charge', '2026-07-27 14:47:47'),
(291, 'AP', 10, '2026-07-27', 13.81, 0.00, 13.81, 20718.09, 20731.90, 'Auto overdue charge', '2026-07-27 14:47:47'),
(292, 'AP', 11, '2026-07-27', 7.52, 0.00, 7.52, 11282.15, 11289.67, 'Auto overdue charge', '2026-07-27 14:47:47'),
(293, 'AP', 12, '2026-07-27', 13.74, 0.00, 13.74, 20615.54, 20629.28, 'Auto overdue charge', '2026-07-27 14:47:47'),
(294, 'AP', 14, '2026-07-27', 16.47, 0.00, 16.47, 24701.65, 24718.12, 'Auto overdue charge', '2026-07-27 14:47:47'),
(295, 'AP', 15, '2026-07-27', 18.44, 0.00, 18.44, 27655.61, 27674.05, 'Auto overdue charge', '2026-07-27 14:47:47'),
(296, 'AP', 16, '2026-07-27', 1.71, 0.00, 1.71, 2560.70, 2562.41, 'Auto overdue charge', '2026-07-27 14:47:47'),
(297, 'AP', 17, '2026-07-27', 32.91, 0.00, 32.91, 49370.39, 49403.30, 'Auto overdue charge', '2026-07-27 14:47:47'),
(298, 'AP', 18, '2026-07-27', 0.30, 0.00, 0.30, 455.70, 456.00, 'Auto overdue charge', '2026-07-27 14:47:47'),
(299, 'AP', 25, '2026-07-27', 50.54, 0.00, 50.54, 75804.01, 75854.55, 'Auto overdue charge', '2026-07-27 14:47:47'),
(300, 'AP', 26, '2026-07-27', 15.48, 0.00, 15.48, 23215.49, 23230.97, 'Auto overdue charge', '2026-07-27 14:47:47'),
(301, 'AP', 27, '2026-07-27', 5.38, 0.00, 5.38, 8074.99, 8080.37, 'Auto overdue charge', '2026-07-27 14:47:47'),
(302, 'AP', 29, '2026-07-27', 4.63, 0.00, 4.63, 6946.14, 6950.77, 'Auto overdue charge', '2026-07-27 14:47:47'),
(303, 'AP', 30, '2026-07-27', 1.61, 0.00, 1.61, 2416.05, 2417.66, 'Auto overdue charge', '2026-07-27 14:47:47'),
(304, 'AP', 31, '2026-07-27', 7.70, 0.00, 7.70, 11553.78, 11561.48, 'Auto overdue charge', '2026-07-27 14:47:47'),
(305, 'AR', 29, '2026-07-27', 0.27, 0.00, 0.27, 407.29, 407.56, 'Auto overdue charge', '2026-07-27 14:47:47'),
(306, 'AR', 30, '2026-07-27', 1.69, 0.00, 1.69, 2533.55, 2535.24, 'Auto overdue charge', '2026-07-27 14:47:47'),
(307, 'AR', 31, '2026-07-27', 0.05, 0.00, 0.05, 81.00, 81.05, 'Auto overdue charge', '2026-07-27 14:47:47'),
(308, 'AR', 41, '2026-07-27', 0.34, 0.00, 0.34, 504.68, 505.02, 'Auto overdue charge', '2026-07-27 14:47:47'),
(309, 'AP', 9, '2026-07-28', 4.17, 0.00, 4.17, 6260.62, 6264.79, 'Auto overdue charge', '2026-07-28 18:35:37'),
(310, 'AP', 10, '2026-07-28', 13.82, 0.00, 13.82, 20731.90, 20745.72, 'Auto overdue charge', '2026-07-28 18:35:37'),
(311, 'AP', 11, '2026-07-28', 7.53, 0.00, 7.53, 11289.67, 11297.20, 'Auto overdue charge', '2026-07-28 18:35:37'),
(312, 'AP', 12, '2026-07-28', 13.75, 0.00, 13.75, 20629.28, 20643.03, 'Auto overdue charge', '2026-07-28 18:35:37'),
(313, 'AP', 14, '2026-07-28', 16.48, 0.00, 16.48, 24718.12, 24734.60, 'Auto overdue charge', '2026-07-28 18:35:37'),
(314, 'AP', 15, '2026-07-28', 18.45, 0.00, 18.45, 27674.05, 27692.50, 'Auto overdue charge', '2026-07-28 18:35:37'),
(315, 'AP', 16, '2026-07-28', 1.71, 0.00, 1.71, 2562.41, 2564.12, 'Auto overdue charge', '2026-07-28 18:35:37'),
(316, 'AP', 17, '2026-07-28', 32.94, 0.00, 32.94, 49403.30, 49436.24, 'Auto overdue charge', '2026-07-28 18:35:37'),
(317, 'AP', 18, '2026-07-28', 0.30, 0.00, 0.30, 456.00, 456.30, 'Auto overdue charge', '2026-07-28 18:35:37'),
(318, 'AP', 25, '2026-07-28', 50.57, 0.00, 50.57, 75854.55, 75905.12, 'Auto overdue charge', '2026-07-28 18:35:37'),
(319, 'AP', 26, '2026-07-28', 15.49, 0.00, 15.49, 23230.97, 23246.46, 'Auto overdue charge', '2026-07-28 18:35:37'),
(320, 'AP', 27, '2026-07-28', 5.39, 0.00, 5.39, 8080.37, 8085.76, 'Auto overdue charge', '2026-07-28 18:35:37'),
(321, 'AP', 29, '2026-07-28', 4.63, 0.00, 4.63, 6950.77, 6955.40, 'Auto overdue charge', '2026-07-28 18:35:37'),
(322, 'AP', 30, '2026-07-28', 1.61, 0.00, 1.61, 2417.66, 2419.27, 'Auto overdue charge', '2026-07-28 18:35:37'),
(323, 'AP', 31, '2026-07-28', 7.71, 0.00, 7.71, 11561.48, 11569.19, 'Auto overdue charge', '2026-07-28 18:35:37'),
(324, 'AR', 29, '2026-07-28', 0.27, 0.00, 0.27, 407.56, 407.83, 'Auto overdue charge', '2026-07-28 18:35:37'),
(325, 'AR', 30, '2026-07-28', 1.69, 0.00, 1.69, 2535.24, 2536.93, 'Auto overdue charge', '2026-07-28 18:35:37'),
(326, 'AR', 31, '2026-07-28', 0.05, 0.00, 0.05, 81.05, 81.10, 'Auto overdue charge', '2026-07-28 18:35:37'),
(327, 'AR', 41, '2026-07-28', 0.34, 0.00, 0.34, 505.02, 505.36, 'Auto overdue charge', '2026-07-28 18:35:37'),
(328, 'AP', 9, '2026-07-29', 4.18, 0.00, 4.18, 6264.79, 6268.97, 'Auto overdue charge', '2026-07-29 08:46:08'),
(329, 'AP', 10, '2026-07-29', 13.83, 0.00, 13.83, 20745.72, 20759.55, 'Auto overdue charge', '2026-07-29 08:46:08'),
(330, 'AP', 11, '2026-07-29', 7.53, 0.00, 7.53, 11297.20, 11304.73, 'Auto overdue charge', '2026-07-29 08:46:08'),
(331, 'AP', 12, '2026-07-29', 13.76, 0.00, 13.76, 20643.03, 20656.79, 'Auto overdue charge', '2026-07-29 08:46:08'),
(332, 'AP', 14, '2026-07-29', 16.49, 0.00, 16.49, 24734.60, 24751.09, 'Auto overdue charge', '2026-07-29 08:46:08'),
(333, 'AP', 15, '2026-07-29', 18.46, 0.00, 18.46, 27692.50, 27710.96, 'Auto overdue charge', '2026-07-29 08:46:08'),
(334, 'AP', 16, '2026-07-29', 1.71, 0.00, 1.71, 2564.12, 2565.83, 'Auto overdue charge', '2026-07-29 08:46:08'),
(335, 'AP', 17, '2026-07-29', 32.96, 0.00, 32.96, 49436.24, 49469.20, 'Auto overdue charge', '2026-07-29 08:46:08'),
(336, 'AP', 18, '2026-07-29', 0.30, 0.00, 0.30, 456.30, 456.60, 'Auto overdue charge', '2026-07-29 08:46:08'),
(337, 'AP', 25, '2026-07-29', 50.60, 0.00, 50.60, 75905.12, 75955.72, 'Auto overdue charge', '2026-07-29 08:46:08'),
(338, 'AP', 26, '2026-07-29', 15.50, 0.00, 15.50, 23246.46, 23261.96, 'Auto overdue charge', '2026-07-29 08:46:08'),
(339, 'AP', 27, '2026-07-29', 5.39, 0.00, 5.39, 8085.76, 8091.15, 'Auto overdue charge', '2026-07-29 08:46:08'),
(340, 'AP', 29, '2026-07-29', 4.64, 0.00, 4.64, 6955.40, 6960.04, 'Auto overdue charge', '2026-07-29 08:46:08'),
(341, 'AP', 30, '2026-07-29', 1.61, 0.00, 1.61, 2419.27, 2420.88, 'Auto overdue charge', '2026-07-29 08:46:08'),
(342, 'AP', 31, '2026-07-29', 7.71, 0.00, 7.71, 11569.19, 11576.90, 'Auto overdue charge', '2026-07-29 08:46:08'),
(343, 'AR', 29, '2026-07-29', 0.27, 0.00, 0.27, 407.83, 408.10, 'Auto overdue charge', '2026-07-29 08:46:08'),
(344, 'AR', 30, '2026-07-29', 1.69, 0.00, 1.69, 2536.93, 2538.62, 'Auto overdue charge', '2026-07-29 08:46:08'),
(345, 'AR', 31, '2026-07-29', 0.05, 0.00, 0.05, 81.10, 81.15, 'Auto overdue charge', '2026-07-29 08:46:08'),
(346, 'AR', 41, '2026-07-29', 0.34, 0.00, 0.34, 505.36, 505.70, 'Auto overdue charge', '2026-07-29 08:46:08'),
(347, 'AP', 9, '2026-07-31', 4.18, 0.00, 4.18, 6268.97, 6273.15, 'Auto overdue charge', '2026-07-31 09:53:27'),
(348, 'AP', 10, '2026-07-31', 13.84, 0.00, 13.84, 20759.55, 20773.39, 'Auto overdue charge', '2026-07-31 09:53:27'),
(349, 'AP', 11, '2026-07-31', 7.54, 0.00, 7.54, 11304.73, 11312.27, 'Auto overdue charge', '2026-07-31 09:53:27'),
(350, 'AP', 12, '2026-07-31', 13.77, 0.00, 13.77, 20656.79, 20670.56, 'Auto overdue charge', '2026-07-31 09:53:27'),
(351, 'AP', 14, '2026-07-31', 16.50, 0.00, 16.50, 24751.09, 24767.59, 'Auto overdue charge', '2026-07-31 09:53:27'),
(352, 'AP', 15, '2026-07-31', 18.47, 0.00, 18.47, 27710.96, 27729.43, 'Auto overdue charge', '2026-07-31 09:53:27'),
(353, 'AP', 16, '2026-07-31', 1.71, 0.00, 1.71, 2565.83, 2567.54, 'Auto overdue charge', '2026-07-31 09:53:27'),
(354, 'AP', 17, '2026-07-31', 32.98, 0.00, 32.98, 49469.20, 49502.18, 'Auto overdue charge', '2026-07-31 09:53:27'),
(355, 'AP', 18, '2026-07-31', 0.30, 0.00, 0.30, 456.60, 456.90, 'Auto overdue charge', '2026-07-31 09:53:27'),
(356, 'AP', 25, '2026-07-31', 50.64, 0.00, 50.64, 75955.72, 76006.36, 'Auto overdue charge', '2026-07-31 09:53:27'),
(357, 'AP', 26, '2026-07-31', 15.51, 0.00, 15.51, 23261.96, 23277.47, 'Auto overdue charge', '2026-07-31 09:53:27'),
(358, 'AP', 27, '2026-07-31', 5.39, 0.00, 5.39, 8091.15, 8096.54, 'Auto overdue charge', '2026-07-31 09:53:27'),
(359, 'AP', 29, '2026-07-31', 4.64, 0.00, 4.64, 6960.04, 6964.68, 'Auto overdue charge', '2026-07-31 09:53:27'),
(360, 'AP', 30, '2026-07-31', 1.61, 0.00, 1.61, 2420.88, 2422.49, 'Auto overdue charge', '2026-07-31 09:53:27'),
(361, 'AP', 31, '2026-07-31', 7.72, 0.00, 7.72, 11576.90, 11584.62, 'Auto overdue charge', '2026-07-31 09:53:27'),
(362, 'AR', 29, '2026-07-31', 0.27, 0.00, 0.27, 408.10, 408.37, 'Auto overdue charge', '2026-07-31 09:53:27'),
(363, 'AR', 30, '2026-07-31', 1.69, 0.00, 1.69, 2538.62, 2540.31, 'Auto overdue charge', '2026-07-31 09:53:27'),
(364, 'AR', 31, '2026-07-31', 0.05, 0.00, 0.05, 81.15, 81.20, 'Auto overdue charge', '2026-07-31 09:53:27'),
(365, 'AR', 41, '2026-07-31', 0.34, 0.00, 0.34, 505.70, 506.04, 'Auto overdue charge', '2026-07-31 09:53:27'),
(366, 'AP', 9, '2026-08-02', 4.18, 0.00, 4.18, 6273.15, 6277.33, 'Auto overdue charge', '2026-08-02 14:38:50'),
(367, 'AP', 10, '2026-08-02', 13.85, 0.00, 13.85, 20773.39, 20787.24, 'Auto overdue charge', '2026-08-02 14:38:50'),
(368, 'AP', 11, '2026-08-02', 7.54, 0.00, 7.54, 11312.27, 11319.81, 'Auto overdue charge', '2026-08-02 14:38:50'),
(369, 'AP', 12, '2026-08-02', 13.78, 0.00, 13.78, 20670.56, 20684.34, 'Auto overdue charge', '2026-08-02 14:38:50'),
(370, 'AP', 14, '2026-08-02', 16.51, 0.00, 16.51, 24767.59, 24784.10, 'Auto overdue charge', '2026-08-02 14:38:50'),
(371, 'AP', 15, '2026-08-02', 18.49, 0.00, 18.49, 27729.43, 27747.92, 'Auto overdue charge', '2026-08-02 14:38:50'),
(372, 'AP', 16, '2026-08-02', 1.71, 0.00, 1.71, 2567.54, 2569.25, 'Auto overdue charge', '2026-08-02 14:38:50'),
(373, 'AP', 17, '2026-08-02', 33.00, 0.00, 33.00, 49502.18, 49535.18, 'Auto overdue charge', '2026-08-02 14:38:50'),
(374, 'AP', 18, '2026-08-02', 0.30, 0.00, 0.30, 456.90, 457.20, 'Auto overdue charge', '2026-08-02 14:38:50'),
(375, 'AP', 25, '2026-08-02', 50.67, 0.00, 50.67, 76006.36, 76057.03, 'Auto overdue charge', '2026-08-02 14:38:50'),
(376, 'AP', 26, '2026-08-02', 15.52, 0.00, 15.52, 23277.47, 23292.99, 'Auto overdue charge', '2026-08-02 14:38:50'),
(377, 'AP', 27, '2026-08-02', 5.40, 0.00, 5.40, 8096.54, 8101.94, 'Auto overdue charge', '2026-08-02 14:38:50'),
(378, 'AP', 29, '2026-08-02', 4.64, 0.00, 4.64, 6964.68, 6969.32, 'Auto overdue charge', '2026-08-02 14:38:50'),
(379, 'AP', 30, '2026-08-02', 1.61, 0.00, 1.61, 2422.49, 2424.10, 'Auto overdue charge', '2026-08-02 14:38:50'),
(380, 'AP', 31, '2026-08-02', 7.72, 0.00, 7.72, 11584.62, 11592.34, 'Auto overdue charge', '2026-08-02 14:38:50'),
(381, 'AR', 29, '2026-08-02', 0.27, 0.00, 0.27, 408.37, 408.64, 'Auto overdue charge', '2026-08-02 14:38:50'),
(382, 'AR', 30, '2026-08-02', 1.69, 0.00, 1.69, 2540.31, 2542.00, 'Auto overdue charge', '2026-08-02 14:38:50'),
(383, 'AR', 31, '2026-08-02', 0.05, 0.00, 0.05, 81.20, 81.25, 'Auto overdue charge', '2026-08-02 14:38:50'),
(384, 'AR', 41, '2026-08-02', 0.34, 0.00, 0.34, 506.04, 506.38, 'Auto overdue charge', '2026-08-02 14:38:50'),
(385, 'AP', 9, '2026-08-03', 4.18, 0.00, 4.18, 6277.33, 6281.51, 'Auto overdue charge', '2026-08-03 11:02:09'),
(386, 'AP', 10, '2026-08-03', 13.86, 0.00, 13.86, 20787.24, 20801.10, 'Auto overdue charge', '2026-08-03 11:02:10'),
(387, 'AP', 11, '2026-08-03', 7.55, 0.00, 7.55, 11319.81, 11327.36, 'Auto overdue charge', '2026-08-03 11:02:10'),
(388, 'AP', 12, '2026-08-03', 13.79, 0.00, 13.79, 20684.34, 20698.13, 'Auto overdue charge', '2026-08-03 11:02:10'),
(389, 'AP', 14, '2026-08-03', 16.52, 0.00, 16.52, 24784.10, 24800.62, 'Auto overdue charge', '2026-08-03 11:02:10'),
(390, 'AP', 15, '2026-08-03', 18.50, 0.00, 18.50, 27747.92, 27766.42, 'Auto overdue charge', '2026-08-03 11:02:10'),
(391, 'AP', 16, '2026-08-03', 1.71, 0.00, 1.71, 2569.25, 2570.96, 'Auto overdue charge', '2026-08-03 11:02:10'),
(392, 'AP', 17, '2026-08-03', 33.02, 0.00, 33.02, 49535.18, 49568.20, 'Auto overdue charge', '2026-08-03 11:02:10'),
(393, 'AP', 18, '2026-08-03', 0.30, 0.00, 0.30, 457.20, 457.50, 'Auto overdue charge', '2026-08-03 11:02:10'),
(394, 'AP', 25, '2026-08-03', 50.70, 0.00, 50.70, 76057.03, 76107.73, 'Auto overdue charge', '2026-08-03 11:02:10'),
(395, 'AP', 26, '2026-08-03', 15.53, 0.00, 15.53, 23292.99, 23308.52, 'Auto overdue charge', '2026-08-03 11:02:10'),
(396, 'AP', 27, '2026-08-03', 5.40, 0.00, 5.40, 8101.94, 8107.34, 'Auto overdue charge', '2026-08-03 11:02:10'),
(397, 'AP', 29, '2026-08-03', 4.65, 0.00, 4.65, 6969.32, 6973.97, 'Auto overdue charge', '2026-08-03 11:02:10'),
(398, 'AP', 30, '2026-08-03', 1.62, 0.00, 1.62, 2424.10, 2425.72, 'Auto overdue charge', '2026-08-03 11:02:10'),
(399, 'AP', 31, '2026-08-03', 7.73, 0.00, 7.73, 11592.34, 11600.07, 'Auto overdue charge', '2026-08-03 11:02:10'),
(400, 'AR', 29, '2026-08-03', 0.27, 0.00, 0.27, 408.64, 408.91, 'Auto overdue charge', '2026-08-03 11:02:10'),
(401, 'AR', 30, '2026-08-03', 1.69, 0.00, 1.69, 2542.00, 2543.69, 'Auto overdue charge', '2026-08-03 11:02:10'),
(402, 'AR', 31, '2026-08-03', 0.05, 0.00, 0.05, 81.25, 81.30, 'Auto overdue charge', '2026-08-03 11:02:10'),
(403, 'AR', 41, '2026-08-03', 0.34, 0.00, 0.34, 506.38, 506.72, 'Auto overdue charge', '2026-08-03 11:02:10'),
(404, 'AP', 9, '2026-08-05', 4.19, 0.00, 4.19, 6281.51, 6285.70, 'Auto overdue charge', '2026-08-05 10:28:58'),
(405, 'AP', 10, '2026-08-05', 13.87, 0.00, 13.87, 20801.10, 20814.97, 'Auto overdue charge', '2026-08-05 10:28:58'),
(406, 'AP', 11, '2026-08-05', 7.55, 0.00, 7.55, 11327.36, 11334.91, 'Auto overdue charge', '2026-08-05 10:28:58'),
(407, 'AP', 12, '2026-08-05', 13.80, 0.00, 13.80, 20698.13, 20711.93, 'Auto overdue charge', '2026-08-05 10:28:58'),
(408, 'AP', 14, '2026-08-05', 16.53, 0.00, 16.53, 24800.62, 24817.15, 'Auto overdue charge', '2026-08-05 10:28:58'),
(409, 'AP', 15, '2026-08-05', 18.51, 0.00, 18.51, 27766.42, 27784.93, 'Auto overdue charge', '2026-08-05 10:28:58'),
(410, 'AP', 16, '2026-08-05', 1.71, 0.00, 1.71, 2570.96, 2572.67, 'Auto overdue charge', '2026-08-05 10:28:58'),
(411, 'AP', 17, '2026-08-05', 33.05, 0.00, 33.05, 49568.20, 49601.25, 'Auto overdue charge', '2026-08-05 10:28:58'),
(412, 'AP', 18, '2026-08-05', 0.31, 0.00, 0.31, 457.50, 457.81, 'Auto overdue charge', '2026-08-05 10:28:58'),
(413, 'AP', 25, '2026-08-05', 50.74, 0.00, 50.74, 76107.73, 76158.47, 'Auto overdue charge', '2026-08-05 10:28:58'),
(414, 'AP', 26, '2026-08-05', 15.54, 0.00, 15.54, 23308.52, 23324.06, 'Auto overdue charge', '2026-08-05 10:28:58'),
(415, 'AP', 27, '2026-08-05', 5.40, 0.00, 5.40, 8107.34, 8112.74, 'Auto overdue charge', '2026-08-05 10:28:58'),
(416, 'AP', 29, '2026-08-05', 4.65, 0.00, 4.65, 6973.97, 6978.62, 'Auto overdue charge', '2026-08-05 10:28:59'),
(417, 'AP', 30, '2026-08-05', 1.62, 0.00, 1.62, 2425.72, 2427.34, 'Auto overdue charge', '2026-08-05 10:28:59'),
(418, 'AP', 31, '2026-08-05', 7.73, 0.00, 7.73, 11600.07, 11607.80, 'Auto overdue charge', '2026-08-05 10:28:59'),
(419, 'AR', 29, '2026-08-05', 0.27, 0.00, 0.27, 408.91, 409.18, 'Auto overdue charge', '2026-08-05 10:28:59'),
(420, 'AR', 31, '2026-08-05', 0.05, 0.00, 0.05, 81.30, 81.35, 'Auto overdue charge', '2026-08-05 10:28:59'),
(421, 'AP', 9, '2026-08-06', 4.19, 0.00, 4.19, 6285.70, 6289.89, 'Auto overdue charge', '2026-08-06 09:25:47'),
(422, 'AP', 10, '2026-08-06', 13.88, 0.00, 13.88, 20814.97, 20828.85, 'Auto overdue charge', '2026-08-06 09:25:47'),
(423, 'AP', 11, '2026-08-06', 7.56, 0.00, 7.56, 11334.91, 11342.47, 'Auto overdue charge', '2026-08-06 09:25:47'),
(424, 'AP', 12, '2026-08-06', 13.81, 0.00, 13.81, 20711.93, 20725.74, 'Auto overdue charge', '2026-08-06 09:25:47'),
(425, 'AP', 14, '2026-08-06', 16.54, 0.00, 16.54, 24817.15, 24833.69, 'Auto overdue charge', '2026-08-06 09:25:47'),
(426, 'AP', 15, '2026-08-06', 18.52, 0.00, 18.52, 27784.93, 27803.45, 'Auto overdue charge', '2026-08-06 09:25:47'),
(427, 'AP', 16, '2026-08-06', 1.72, 0.00, 1.72, 2572.67, 2574.39, 'Auto overdue charge', '2026-08-06 09:25:47'),
(428, 'AP', 17, '2026-08-06', 33.07, 0.00, 33.07, 49601.25, 49634.32, 'Auto overdue charge', '2026-08-06 09:25:47'),
(429, 'AP', 18, '2026-08-06', 0.31, 0.00, 0.31, 457.81, 458.12, 'Auto overdue charge', '2026-08-06 09:25:47'),
(430, 'AP', 25, '2026-08-06', 50.77, 0.00, 50.77, 76158.47, 76209.24, 'Auto overdue charge', '2026-08-06 09:25:47'),
(431, 'AP', 26, '2026-08-06', 15.55, 0.00, 15.55, 23324.06, 23339.61, 'Auto overdue charge', '2026-08-06 09:25:47'),
(432, 'AP', 27, '2026-08-06', 5.41, 0.00, 5.41, 8112.74, 8118.15, 'Auto overdue charge', '2026-08-06 09:25:47'),
(433, 'AP', 29, '2026-08-06', 4.65, 0.00, 4.65, 6978.62, 6983.27, 'Auto overdue charge', '2026-08-06 09:25:47'),
(434, 'AP', 30, '2026-08-06', 1.62, 0.00, 1.62, 2427.34, 2428.96, 'Auto overdue charge', '2026-08-06 09:25:47'),
(435, 'AP', 31, '2026-08-06', 7.74, 0.00, 7.74, 11607.80, 11615.54, 'Auto overdue charge', '2026-08-06 09:25:47'),
(436, 'AR', 29, '2026-08-06', 0.27, 0.00, 0.27, 409.18, 409.45, 'Auto overdue charge', '2026-08-06 09:25:47'),
(437, 'AR', 31, '2026-08-06', 0.05, 0.00, 0.05, 81.35, 81.40, 'Auto overdue charge', '2026-08-06 09:25:47'),
(438, 'AP', 9, '2026-08-10', 4.19, 0.00, 4.19, 6289.89, 6294.08, 'Auto overdue charge', '2026-08-10 13:17:30'),
(439, 'AP', 10, '2026-08-10', 13.89, 0.00, 13.89, 20828.85, 20842.74, 'Auto overdue charge', '2026-08-10 13:17:30'),
(440, 'AP', 11, '2026-08-10', 7.56, 0.00, 7.56, 11342.47, 11350.03, 'Auto overdue charge', '2026-08-10 13:17:30'),
(441, 'AP', 12, '2026-08-10', 13.82, 0.00, 13.82, 20725.74, 20739.56, 'Auto overdue charge', '2026-08-10 13:17:30'),
(442, 'AP', 14, '2026-08-10', 16.56, 0.00, 16.56, 24833.69, 24850.25, 'Auto overdue charge', '2026-08-10 13:17:30'),
(443, 'AP', 15, '2026-08-10', 18.54, 0.00, 18.54, 27803.45, 27821.99, 'Auto overdue charge', '2026-08-10 13:17:30'),
(444, 'AP', 16, '2026-08-10', 1.72, 0.00, 1.72, 2574.39, 2576.11, 'Auto overdue charge', '2026-08-10 13:17:30');
INSERT INTO `finance_charge_logs` (`charge_id`, `account_type`, `account_id`, `charge_date`, `interest_amount`, `penalty_amount`, `total_charge`, `balance_before`, `balance_after`, `note`, `created_at`) VALUES
(445, 'AP', 17, '2026-08-10', 33.09, 0.00, 33.09, 49634.32, 49667.41, 'Auto overdue charge', '2026-08-10 13:17:30'),
(446, 'AP', 18, '2026-08-10', 0.31, 0.00, 0.31, 458.12, 458.43, 'Auto overdue charge', '2026-08-10 13:17:30'),
(447, 'AP', 25, '2026-08-10', 50.81, 0.00, 50.81, 76209.24, 76260.05, 'Auto overdue charge', '2026-08-10 13:17:30'),
(448, 'AP', 26, '2026-08-10', 15.56, 0.00, 15.56, 23339.61, 23355.17, 'Auto overdue charge', '2026-08-10 13:17:30'),
(449, 'AP', 27, '2026-08-10', 5.41, 0.00, 5.41, 8118.15, 8123.56, 'Auto overdue charge', '2026-08-10 13:17:30'),
(450, 'AP', 29, '2026-08-10', 4.66, 0.00, 4.66, 6983.27, 6987.93, 'Auto overdue charge', '2026-08-10 13:17:30'),
(451, 'AP', 30, '2026-08-10', 1.62, 0.00, 1.62, 2428.96, 2430.58, 'Auto overdue charge', '2026-08-10 13:17:30'),
(452, 'AP', 31, '2026-08-10', 7.74, 0.00, 7.74, 11615.54, 11623.28, 'Auto overdue charge', '2026-08-10 13:17:30'),
(453, 'AR', 29, '2026-08-10', 0.27, 0.00, 0.27, 409.45, 409.72, 'Auto overdue charge', '2026-08-10 13:17:30'),
(454, 'AR', 31, '2026-08-10', 0.05, 0.00, 0.05, 81.40, 81.45, 'Auto overdue charge', '2026-08-10 13:17:30'),
(455, 'AP', 9, '2026-08-11', 4.20, 0.00, 4.20, 6294.08, 6298.28, 'Auto overdue charge', '2026-08-11 11:32:47'),
(456, 'AP', 10, '2026-08-11', 13.90, 0.00, 13.90, 20842.74, 20856.64, 'Auto overdue charge', '2026-08-11 11:32:47'),
(457, 'AP', 11, '2026-08-11', 7.57, 0.00, 7.57, 11350.03, 11357.60, 'Auto overdue charge', '2026-08-11 11:32:47'),
(458, 'AP', 12, '2026-08-11', 13.83, 0.00, 13.83, 20739.56, 20753.39, 'Auto overdue charge', '2026-08-11 11:32:47'),
(459, 'AP', 14, '2026-08-11', 16.57, 0.00, 16.57, 24850.25, 24866.82, 'Auto overdue charge', '2026-08-11 11:32:47'),
(460, 'AP', 15, '2026-08-11', 18.55, 0.00, 18.55, 27821.99, 27840.54, 'Auto overdue charge', '2026-08-11 11:32:47'),
(461, 'AP', 16, '2026-08-11', 1.72, 0.00, 1.72, 2576.11, 2577.83, 'Auto overdue charge', '2026-08-11 11:32:47'),
(462, 'AP', 17, '2026-08-11', 33.11, 0.00, 33.11, 49667.41, 49700.52, 'Auto overdue charge', '2026-08-11 11:32:47'),
(463, 'AP', 18, '2026-08-11', 0.31, 0.00, 0.31, 458.43, 458.74, 'Auto overdue charge', '2026-08-11 11:32:47'),
(464, 'AP', 25, '2026-08-11', 50.84, 0.00, 50.84, 76260.05, 76310.89, 'Auto overdue charge', '2026-08-11 11:32:47'),
(465, 'AP', 26, '2026-08-11', 15.57, 0.00, 15.57, 23355.17, 23370.74, 'Auto overdue charge', '2026-08-11 11:32:47'),
(466, 'AP', 27, '2026-08-11', 5.42, 0.00, 5.42, 8123.56, 8128.98, 'Auto overdue charge', '2026-08-11 11:32:47'),
(467, 'AP', 29, '2026-08-11', 4.66, 0.00, 4.66, 6987.93, 6992.59, 'Auto overdue charge', '2026-08-11 11:32:47'),
(468, 'AP', 30, '2026-08-11', 1.62, 0.00, 1.62, 2430.58, 2432.20, 'Auto overdue charge', '2026-08-11 11:32:47'),
(469, 'AP', 31, '2026-08-11', 7.75, 0.00, 7.75, 11623.28, 11631.03, 'Auto overdue charge', '2026-08-11 11:32:47'),
(470, 'AR', 29, '2026-08-11', 0.27, 0.00, 0.27, 409.72, 409.99, 'Auto overdue charge', '2026-08-11 11:32:47'),
(471, 'AR', 31, '2026-08-11', 0.05, 0.00, 0.05, 81.45, 81.50, 'Auto overdue charge', '2026-08-11 11:32:47'),
(472, 'AP', 9, '2026-08-12', 4.20, 0.00, 4.20, 6298.28, 6302.48, 'Auto overdue charge', '2026-08-12 09:50:06'),
(473, 'AP', 10, '2026-08-12', 13.90, 0.00, 13.90, 20856.64, 20870.54, 'Auto overdue charge', '2026-08-12 09:50:06'),
(474, 'AP', 11, '2026-08-12', 7.57, 0.00, 7.57, 11357.60, 11365.17, 'Auto overdue charge', '2026-08-12 09:50:06'),
(475, 'AP', 12, '2026-08-12', 13.84, 0.00, 13.84, 20753.39, 20767.23, 'Auto overdue charge', '2026-08-12 09:50:06'),
(476, 'AP', 14, '2026-08-12', 16.58, 0.00, 16.58, 24866.82, 24883.40, 'Auto overdue charge', '2026-08-12 09:50:06'),
(477, 'AP', 15, '2026-08-12', 18.56, 0.00, 18.56, 27840.54, 27859.10, 'Auto overdue charge', '2026-08-12 09:50:06'),
(478, 'AP', 16, '2026-08-12', 1.72, 0.00, 1.72, 2577.83, 2579.55, 'Auto overdue charge', '2026-08-12 09:50:06'),
(479, 'AP', 17, '2026-08-12', 33.13, 0.00, 33.13, 49700.52, 49733.65, 'Auto overdue charge', '2026-08-12 09:50:06'),
(480, 'AP', 18, '2026-08-12', 0.31, 0.00, 0.31, 458.74, 459.05, 'Auto overdue charge', '2026-08-12 09:50:06'),
(481, 'AP', 25, '2026-08-12', 50.87, 0.00, 50.87, 76310.89, 76361.76, 'Auto overdue charge', '2026-08-12 09:50:06'),
(482, 'AP', 26, '2026-08-12', 15.58, 0.00, 15.58, 23370.74, 23386.32, 'Auto overdue charge', '2026-08-12 09:50:06'),
(483, 'AP', 27, '2026-08-12', 5.42, 0.00, 5.42, 8128.98, 8134.40, 'Auto overdue charge', '2026-08-12 09:50:06'),
(484, 'AP', 29, '2026-08-12', 4.66, 0.00, 4.66, 6992.59, 6997.25, 'Auto overdue charge', '2026-08-12 09:50:06'),
(485, 'AP', 30, '2026-08-12', 1.62, 0.00, 1.62, 2432.20, 2433.82, 'Auto overdue charge', '2026-08-12 09:50:06'),
(486, 'AP', 31, '2026-08-12', 7.75, 0.00, 7.75, 11631.03, 11638.78, 'Auto overdue charge', '2026-08-12 09:50:06'),
(487, 'AR', 29, '2026-08-12', 0.27, 0.00, 0.27, 409.99, 410.26, 'Auto overdue charge', '2026-08-12 09:50:06'),
(488, 'AR', 31, '2026-08-12', 0.05, 0.00, 0.05, 81.50, 81.55, 'Auto overdue charge', '2026-08-12 09:50:06'),
(489, 'AP', 9, '2026-08-15', 4.20, 0.00, 4.20, 6302.48, 6306.68, 'Auto overdue charge', '2026-08-15 15:31:04'),
(490, 'AP', 10, '2026-08-15', 13.91, 0.00, 13.91, 20870.54, 20884.45, 'Auto overdue charge', '2026-08-15 15:31:04'),
(491, 'AP', 11, '2026-08-15', 7.58, 0.00, 7.58, 11365.17, 11372.75, 'Auto overdue charge', '2026-08-15 15:31:04'),
(492, 'AP', 12, '2026-08-15', 13.84, 0.00, 13.84, 20767.23, 20781.07, 'Auto overdue charge', '2026-08-15 15:31:04'),
(493, 'AP', 14, '2026-08-15', 16.59, 0.00, 16.59, 24883.40, 24899.99, 'Auto overdue charge', '2026-08-15 15:31:04'),
(494, 'AP', 15, '2026-08-15', 18.57, 0.00, 18.57, 27859.10, 27877.67, 'Auto overdue charge', '2026-08-15 15:31:04'),
(495, 'AP', 16, '2026-08-15', 1.72, 0.00, 1.72, 2579.55, 2581.27, 'Auto overdue charge', '2026-08-15 15:31:04'),
(496, 'AP', 17, '2026-08-15', 33.16, 0.00, 33.16, 49733.65, 49766.81, 'Auto overdue charge', '2026-08-15 15:31:04'),
(497, 'AP', 18, '2026-08-15', 0.31, 0.00, 0.31, 459.05, 459.36, 'Auto overdue charge', '2026-08-15 15:31:04'),
(498, 'AP', 25, '2026-08-15', 50.91, 0.00, 50.91, 76361.76, 76412.67, 'Auto overdue charge', '2026-08-15 15:31:04'),
(499, 'AP', 26, '2026-08-15', 15.59, 0.00, 15.59, 23386.32, 23401.91, 'Auto overdue charge', '2026-08-15 15:31:04'),
(500, 'AP', 27, '2026-08-15', 5.42, 0.00, 5.42, 8134.40, 8139.82, 'Auto overdue charge', '2026-08-15 15:31:04'),
(501, 'AP', 29, '2026-08-15', 4.66, 0.00, 4.66, 6997.25, 7001.91, 'Auto overdue charge', '2026-08-15 15:31:04'),
(502, 'AP', 30, '2026-08-15', 1.62, 0.00, 1.62, 2433.82, 2435.44, 'Auto overdue charge', '2026-08-15 15:31:04'),
(503, 'AP', 31, '2026-08-15', 7.76, 0.00, 7.76, 11638.78, 11646.54, 'Auto overdue charge', '2026-08-15 15:31:04'),
(504, 'AR', 29, '2026-08-15', 0.27, 0.00, 0.27, 410.26, 410.53, 'Auto overdue charge', '2026-08-15 15:31:04'),
(505, 'AR', 31, '2026-08-15', 0.05, 0.00, 0.05, 81.55, 81.60, 'Auto overdue charge', '2026-08-15 15:31:04'),
(506, 'AP', 9, '2026-08-17', 4.20, 0.00, 4.20, 6306.68, 6310.88, 'Auto overdue charge', '2026-08-17 13:44:53'),
(507, 'AP', 10, '2026-08-17', 13.92, 0.00, 13.92, 20884.45, 20898.37, 'Auto overdue charge', '2026-08-17 13:44:53'),
(508, 'AP', 11, '2026-08-17', 7.58, 0.00, 7.58, 11372.75, 11380.33, 'Auto overdue charge', '2026-08-17 13:44:53'),
(509, 'AP', 12, '2026-08-17', 13.85, 0.00, 13.85, 20781.07, 20794.92, 'Auto overdue charge', '2026-08-17 13:44:53'),
(510, 'AP', 14, '2026-08-17', 16.60, 0.00, 16.60, 24899.99, 24916.59, 'Auto overdue charge', '2026-08-17 13:44:53'),
(511, 'AP', 15, '2026-08-17', 18.59, 0.00, 18.59, 27877.67, 27896.26, 'Auto overdue charge', '2026-08-17 13:44:53'),
(512, 'AP', 16, '2026-08-17', 1.72, 0.00, 1.72, 2581.27, 2582.99, 'Auto overdue charge', '2026-08-17 13:44:53'),
(513, 'AP', 17, '2026-08-17', 33.18, 0.00, 33.18, 49766.81, 49799.99, 'Auto overdue charge', '2026-08-17 13:44:53'),
(514, 'AP', 18, '2026-08-17', 0.31, 0.00, 0.31, 459.36, 459.67, 'Auto overdue charge', '2026-08-17 13:44:53'),
(515, 'AP', 25, '2026-08-17', 50.94, 0.00, 50.94, 76412.67, 76463.61, 'Auto overdue charge', '2026-08-17 13:44:53'),
(516, 'AP', 26, '2026-08-17', 15.60, 0.00, 15.60, 23401.91, 23417.51, 'Auto overdue charge', '2026-08-17 13:44:53'),
(517, 'AP', 27, '2026-08-17', 5.43, 0.00, 5.43, 8139.82, 8145.25, 'Auto overdue charge', '2026-08-17 13:44:53'),
(518, 'AP', 29, '2026-08-17', 4.67, 0.00, 4.67, 7001.91, 7006.58, 'Auto overdue charge', '2026-08-17 13:44:53'),
(519, 'AP', 30, '2026-08-17', 1.62, 0.00, 1.62, 2435.44, 2437.06, 'Auto overdue charge', '2026-08-17 13:44:53'),
(520, 'AP', 31, '2026-08-17', 7.76, 0.00, 7.76, 11646.54, 11654.30, 'Auto overdue charge', '2026-08-17 13:44:53'),
(521, 'AR', 29, '2026-08-17', 0.27, 0.00, 0.27, 410.53, 410.80, 'Auto overdue charge', '2026-08-17 13:44:53'),
(522, 'AR', 31, '2026-08-17', 0.05, 0.00, 0.05, 81.60, 81.65, 'Auto overdue charge', '2026-08-17 13:44:53'),
(523, 'AP', 9, '2026-08-18', 4.21, 0.00, 4.21, 6310.88, 6315.09, 'Auto overdue charge', '2026-08-18 14:23:03'),
(524, 'AP', 10, '2026-08-18', 13.93, 0.00, 13.93, 20898.37, 20912.30, 'Auto overdue charge', '2026-08-18 14:23:03'),
(525, 'AP', 11, '2026-08-18', 7.59, 0.00, 7.59, 11380.33, 11387.92, 'Auto overdue charge', '2026-08-18 14:23:03'),
(526, 'AP', 12, '2026-08-18', 13.86, 0.00, 13.86, 20794.92, 20808.78, 'Auto overdue charge', '2026-08-18 14:23:03'),
(527, 'AP', 14, '2026-08-18', 16.61, 0.00, 16.61, 24916.59, 24933.20, 'Auto overdue charge', '2026-08-18 14:23:03'),
(528, 'AP', 15, '2026-08-18', 18.60, 0.00, 18.60, 27896.26, 27914.86, 'Auto overdue charge', '2026-08-18 14:23:03'),
(529, 'AP', 16, '2026-08-18', 1.72, 0.00, 1.72, 2582.99, 2584.71, 'Auto overdue charge', '2026-08-18 14:23:03'),
(530, 'AP', 17, '2026-08-18', 33.20, 0.00, 33.20, 49799.99, 49833.19, 'Auto overdue charge', '2026-08-18 14:23:03'),
(531, 'AP', 18, '2026-08-18', 0.31, 0.00, 0.31, 459.67, 459.98, 'Auto overdue charge', '2026-08-18 14:23:03'),
(532, 'AP', 25, '2026-08-18', 50.98, 0.00, 50.98, 76463.61, 76514.59, 'Auto overdue charge', '2026-08-18 14:23:03'),
(533, 'AP', 26, '2026-08-18', 15.61, 0.00, 15.61, 23417.51, 23433.12, 'Auto overdue charge', '2026-08-18 14:23:03'),
(534, 'AP', 27, '2026-08-18', 5.43, 0.00, 5.43, 8145.25, 8150.68, 'Auto overdue charge', '2026-08-18 14:23:03'),
(535, 'AP', 29, '2026-08-18', 4.67, 0.00, 4.67, 7006.58, 7011.25, 'Auto overdue charge', '2026-08-18 14:23:03'),
(536, 'AP', 30, '2026-08-18', 1.62, 0.00, 1.62, 2437.06, 2438.68, 'Auto overdue charge', '2026-08-18 14:23:03'),
(537, 'AP', 31, '2026-08-18', 7.77, 0.00, 7.77, 11654.30, 11662.07, 'Auto overdue charge', '2026-08-18 14:23:03'),
(538, 'AR', 29, '2026-08-18', 0.27, 0.00, 0.27, 410.80, 411.07, 'Auto overdue charge', '2026-08-18 14:23:03'),
(539, 'AR', 31, '2026-08-18', 0.05, 0.00, 0.05, 81.65, 81.70, 'Auto overdue charge', '2026-08-18 14:23:03'),
(540, 'AP', 9, '2026-08-20', 4.21, 0.00, 4.21, 6315.09, 6319.30, 'Auto overdue charge', '2026-08-20 09:08:00'),
(541, 'AP', 10, '2026-08-20', 13.94, 0.00, 13.94, 20912.30, 20926.24, 'Auto overdue charge', '2026-08-20 09:08:00'),
(542, 'AP', 11, '2026-08-20', 7.59, 0.00, 7.59, 11387.92, 11395.51, 'Auto overdue charge', '2026-08-20 09:08:00'),
(543, 'AP', 12, '2026-08-20', 13.87, 0.00, 13.87, 20808.78, 20822.65, 'Auto overdue charge', '2026-08-20 09:08:00'),
(544, 'AP', 14, '2026-08-20', 16.62, 0.00, 16.62, 24933.20, 24949.82, 'Auto overdue charge', '2026-08-20 09:08:00'),
(545, 'AP', 15, '2026-08-20', 18.61, 0.00, 18.61, 27914.86, 27933.47, 'Auto overdue charge', '2026-08-20 09:08:00'),
(546, 'AP', 16, '2026-08-20', 1.72, 0.00, 1.72, 2584.71, 2586.43, 'Auto overdue charge', '2026-08-20 09:08:00'),
(547, 'AP', 17, '2026-08-20', 33.22, 0.00, 33.22, 49833.19, 49866.41, 'Auto overdue charge', '2026-08-20 09:08:00'),
(548, 'AP', 18, '2026-08-20', 0.31, 0.00, 0.31, 459.98, 460.29, 'Auto overdue charge', '2026-08-20 09:08:00'),
(549, 'AP', 25, '2026-08-20', 51.01, 0.00, 51.01, 76514.59, 76565.60, 'Auto overdue charge', '2026-08-20 09:08:00'),
(550, 'AP', 26, '2026-08-20', 15.62, 0.00, 15.62, 23433.12, 23448.74, 'Auto overdue charge', '2026-08-20 09:08:00'),
(551, 'AP', 27, '2026-08-20', 5.43, 0.00, 5.43, 8150.68, 8156.11, 'Auto overdue charge', '2026-08-20 09:08:00'),
(552, 'AP', 29, '2026-08-20', 4.67, 0.00, 4.67, 7011.25, 7015.92, 'Auto overdue charge', '2026-08-20 09:08:00'),
(553, 'AP', 30, '2026-08-20', 1.63, 0.00, 1.63, 2438.68, 2440.31, 'Auto overdue charge', '2026-08-20 09:08:00'),
(554, 'AP', 31, '2026-08-20', 7.77, 0.00, 7.77, 11662.07, 11669.84, 'Auto overdue charge', '2026-08-20 09:08:00'),
(555, 'AR', 29, '2026-08-20', 0.27, 0.00, 0.27, 411.07, 411.34, 'Auto overdue charge', '2026-08-20 09:08:00'),
(556, 'AR', 31, '2026-08-20', 0.05, 0.00, 0.05, 81.70, 81.75, 'Auto overdue charge', '2026-08-20 09:08:00'),
(557, 'AP', 9, '2026-08-31', 4.21, 0.00, 4.21, 6319.30, 6323.51, 'Auto overdue charge', '2026-08-31 12:14:47'),
(558, 'AP', 10, '2026-08-31', 13.95, 0.00, 13.95, 20926.24, 20940.19, 'Auto overdue charge', '2026-08-31 12:14:47'),
(559, 'AP', 11, '2026-08-31', 7.60, 0.00, 7.60, 11395.51, 11403.11, 'Auto overdue charge', '2026-08-31 12:14:47'),
(560, 'AP', 12, '2026-08-31', 13.88, 0.00, 13.88, 20822.65, 20836.53, 'Auto overdue charge', '2026-08-31 12:14:47'),
(561, 'AP', 14, '2026-08-31', 16.63, 0.00, 16.63, 24949.82, 24966.45, 'Auto overdue charge', '2026-08-31 12:14:47'),
(562, 'AP', 15, '2026-08-31', 18.62, 0.00, 18.62, 27933.47, 27952.09, 'Auto overdue charge', '2026-08-31 12:14:47'),
(563, 'AP', 16, '2026-08-31', 1.72, 0.00, 1.72, 2586.43, 2588.15, 'Auto overdue charge', '2026-08-31 12:14:47'),
(564, 'AP', 17, '2026-08-31', 33.24, 0.00, 33.24, 49866.41, 49899.65, 'Auto overdue charge', '2026-08-31 12:14:47'),
(565, 'AP', 18, '2026-08-31', 0.31, 0.00, 0.31, 460.29, 460.60, 'Auto overdue charge', '2026-08-31 12:14:47'),
(566, 'AP', 25, '2026-08-31', 51.04, 0.00, 51.04, 76565.60, 76616.64, 'Auto overdue charge', '2026-08-31 12:14:47'),
(567, 'AP', 26, '2026-08-31', 15.63, 0.00, 15.63, 23448.74, 23464.37, 'Auto overdue charge', '2026-08-31 12:14:47'),
(568, 'AP', 27, '2026-08-31', 5.44, 0.00, 5.44, 8156.11, 8161.55, 'Auto overdue charge', '2026-08-31 12:14:47'),
(569, 'AP', 29, '2026-08-31', 4.68, 0.00, 4.68, 7015.92, 7020.60, 'Auto overdue charge', '2026-08-31 12:14:47'),
(570, 'AP', 30, '2026-08-31', 0.23, 0.00, 0.23, 340.30, 340.53, 'Auto overdue charge', '2026-08-31 12:14:47'),
(571, 'AR', 29, '2026-08-31', 0.27, 0.00, 0.27, 411.34, 411.61, 'Auto overdue charge', '2026-08-31 12:14:47'),
(572, 'AR', 31, '2026-08-31', 0.05, 0.00, 0.05, 81.75, 81.80, 'Auto overdue charge', '2026-08-31 12:14:47'),
(573, 'AP', 9, '2026-09-01', 4.22, 0.00, 4.22, 6323.51, 6327.73, 'Auto overdue charge', '2026-09-01 22:19:41'),
(574, 'AP', 10, '2026-09-01', 13.96, 0.00, 13.96, 20940.19, 20954.15, 'Auto overdue charge', '2026-09-01 22:19:41'),
(575, 'AP', 11, '2026-09-01', 7.60, 0.00, 7.60, 11403.11, 11410.71, 'Auto overdue charge', '2026-09-01 22:19:41'),
(576, 'AP', 12, '2026-09-01', 13.89, 0.00, 13.89, 20836.53, 20850.42, 'Auto overdue charge', '2026-09-01 22:19:41'),
(577, 'AP', 14, '2026-09-01', 16.64, 0.00, 16.64, 24966.45, 24983.09, 'Auto overdue charge', '2026-09-01 22:19:41'),
(578, 'AP', 15, '2026-09-01', 18.63, 0.00, 18.63, 27952.09, 27970.72, 'Auto overdue charge', '2026-09-01 22:19:41'),
(579, 'AP', 16, '2026-09-01', 1.73, 0.00, 1.73, 2588.15, 2589.88, 'Auto overdue charge', '2026-09-01 22:19:41'),
(580, 'AP', 17, '2026-09-01', 33.27, 0.00, 33.27, 49899.65, 49932.92, 'Auto overdue charge', '2026-09-01 22:19:41'),
(581, 'AP', 18, '2026-09-01', 0.31, 0.00, 0.31, 460.60, 460.91, 'Auto overdue charge', '2026-09-01 22:19:41'),
(582, 'AP', 25, '2026-09-01', 51.08, 0.00, 51.08, 76616.64, 76667.72, 'Auto overdue charge', '2026-09-01 22:19:41'),
(583, 'AP', 26, '2026-09-01', 15.64, 0.00, 15.64, 23464.37, 23480.01, 'Auto overdue charge', '2026-09-01 22:19:41'),
(584, 'AP', 27, '2026-09-01', 5.44, 0.00, 5.44, 8161.55, 8166.99, 'Auto overdue charge', '2026-09-01 22:19:41'),
(585, 'AP', 29, '2026-09-01', 4.68, 0.00, 4.68, 7020.60, 7025.28, 'Auto overdue charge', '2026-09-01 22:19:41'),
(586, 'AP', 30, '2026-09-01', 0.23, 0.00, 0.23, 340.53, 340.76, 'Auto overdue charge', '2026-09-01 22:19:41'),
(587, 'AR', 29, '2026-09-01', 0.27, 0.00, 0.27, 411.61, 411.88, 'Auto overdue charge', '2026-09-01 22:19:41'),
(588, 'AR', 31, '2026-09-01', 0.05, 0.00, 0.05, 81.80, 81.85, 'Auto overdue charge', '2026-09-01 22:19:41');

-- --------------------------------------------------------

--
-- Table structure for table `finance_settings`
--

CREATE TABLE `finance_settings` (
  `id` tinyint(4) NOT NULL,
  `auto_apply` tinyint(1) NOT NULL DEFAULT 1,
  `grace_days` int(11) NOT NULL DEFAULT 0,
  `ap_interest_monthly_pct` decimal(6,2) NOT NULL DEFAULT 2.00,
  `ap_penalty_flat` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ar_interest_monthly_pct` decimal(6,2) NOT NULL DEFAULT 2.00,
  `ar_penalty_flat` decimal(10,2) NOT NULL DEFAULT 0.00,
  `last_run_date` date DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `finance_settings`
--

INSERT INTO `finance_settings` (`id`, `auto_apply`, `grace_days`, `ap_interest_monthly_pct`, `ap_penalty_flat`, `ar_interest_monthly_pct`, `ar_penalty_flat`, `last_run_date`, `updated_at`) VALUES
(1, 1, 0, 2.00, 0.00, 2.00, 0.00, '2026-09-01', '2026-09-01 22:19:41');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_transactions`
--

CREATE TABLE `inventory_transactions` (
  `inventTrans_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `qty_kg` decimal(10,2) DEFAULT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `reference_type` enum('sale','purchase','return','delivery','adjust') DEFAULT NULL,
  `type` enum('in','out','adjust') DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory_transactions`
--

INSERT INTO `inventory_transactions` (`inventTrans_id`, `product_id`, `batch_id`, `qty_kg`, `reference_id`, `reference_type`, `type`, `note`, `created_at`) VALUES
(1, NULL, NULL, NULL, NULL, 'purchase', 'in', NULL, '2026-01-24 04:53:57'),
(2, NULL, NULL, NULL, NULL, 'purchase', 'in', NULL, '2026-01-24 04:53:59'),
(3, NULL, NULL, NULL, NULL, 'purchase', 'in', NULL, '2026-01-24 04:54:00'),
(4, NULL, NULL, NULL, NULL, 'sale', 'out', NULL, '2026-01-24 04:54:04'),
(5, NULL, NULL, NULL, NULL, 'sale', 'out', NULL, '2026-01-24 04:55:00'),
(6, NULL, NULL, NULL, NULL, 'sale', 'out', NULL, '2026-01-24 04:55:00'),
(7, NULL, NULL, NULL, NULL, 'sale', 'out', NULL, '2026-01-24 04:55:02'),
(8, NULL, NULL, NULL, NULL, 'purchase', 'in', NULL, '2026-01-24 04:55:10'),
(9, NULL, NULL, NULL, NULL, 'purchase', 'in', NULL, '2026-01-24 04:56:19'),
(10, NULL, NULL, NULL, NULL, 'sale', 'out', NULL, '2026-01-24 06:12:35'),
(11, NULL, NULL, NULL, NULL, 'sale', 'out', NULL, '2026-01-24 06:14:25'),
(12, NULL, NULL, NULL, NULL, 'sale', 'out', NULL, '2026-01-24 06:20:33'),
(13, NULL, NULL, NULL, NULL, 'sale', 'out', NULL, '2026-01-24 06:34:01'),
(16, 1, NULL, 200.00, 101, 'purchase', 'in', 'Initial stock', '2026-01-24 07:38:43'),
(17, 2, NULL, 150.00, 102, 'purchase', 'in', 'Initial stock', '2026-01-24 07:38:43'),
(18, 1, NULL, 1.00, 2147483647, NULL, 'out', 'wala lang', '2026-01-24 07:48:28'),
(19, 2, NULL, 2.00, NULL, NULL, 'out', 'padala sa imong mama', '2026-01-24 08:34:18'),
(20, 2, NULL, 1000.00, 2147483647, 'purchase', 'in', 'stock pa more', '2026-01-24 10:43:16'),
(21, 2, NULL, -100.00, NULL, NULL, 'adjust', 'change lang', '2026-01-24 11:51:56'),
(22, 1, NULL, -1.00, 2, 'sale', 'out', 'Sold via cashier', '2026-01-24 12:30:18'),
(23, 2, NULL, 100.00, NULL, NULL, 'adjust', 'stock add', '2026-01-25 05:00:49'),
(24, 1, NULL, 5.00, 8, 'sale', 'out', 'Sale deduction', '2026-01-25 11:17:36'),
(25, 2, NULL, 10.00, 9, 'sale', 'out', NULL, '2026-01-25 11:39:07'),
(26, 1, NULL, 1000.00, 2147483647, 'purchase', 'in', 'delivered by supplier', '2026-01-25 12:22:36'),
(27, 2, NULL, 5.00, 11, 'sale', 'out', 'Sale #11 - deducted stock', '2026-01-25 12:59:08'),
(31, 1, NULL, 5.00, 15, 'sale', 'out', 'Sale #15 - deducted stock', '2026-01-26 09:25:38'),
(32, 2, NULL, 33.00, 16, 'sale', 'out', 'Sale #16 - deducted stock', '2026-01-26 09:26:19'),
(33, 1, NULL, 10.00, 17, 'sale', 'out', 'Sale #17 - deducted stock', '2026-01-26 10:42:27'),
(34, 6, NULL, 500.00, 0, 'purchase', 'in', 'Dliverd by supplier', '2026-01-26 10:46:37'),
(35, 2, NULL, 100.00, 0, 'purchase', 'in', 'Delivered by supplier', '2026-01-26 10:47:11'),
(36, 6, NULL, 20.00, 18, 'sale', 'out', 'Sale #18 - deducted stock', '2026-01-26 11:01:43'),
(37, 2, NULL, 10.00, 19, 'sale', 'out', 'Sale #19 - deducted stock', '2026-01-26 11:02:37'),
(38, 2, NULL, 10.00, 2, 'return', 'in', 'Approved return #2', '2026-01-26 11:09:40'),
(39, 2, NULL, 25.00, 20, 'sale', 'out', 'Sale #20 - deducted stock', '2026-01-27 03:02:10'),
(40, 2, NULL, 25.00, 3, 'return', 'in', 'Approved return #3', '2026-01-27 03:11:14'),
(41, 2, NULL, 25.00, 21, 'sale', 'out', 'Sale #21 - deducted stock', '2026-01-27 06:10:04'),
(42, 2, NULL, 25.00, 22, 'sale', 'out', 'Sale #22 - deducted stock', '2026-01-27 07:24:29'),
(43, 6, NULL, 479.00, 24, 'sale', 'out', 'Sale #24 - deducted stock', '2026-01-27 07:28:03'),
(44, 1, NULL, 10.00, 26, 'sale', 'out', 'Sale #26 - deducted stock', '2026-01-27 07:34:22'),
(45, 9, NULL, 500.00, NULL, NULL, 'in', 'Manual stock adjustment', '2026-01-27 07:43:22'),
(46, 9, NULL, 50.00, NULL, NULL, 'in', 'Manual stock adjustment', '2026-01-27 07:46:07'),
(47, 10, NULL, 500.00, 134352345, 'purchase', 'in', 'Stock received (Add Stock)', '2026-01-27 07:50:32'),
(48, 2, NULL, 25.00, 5, 'return', 'in', 'Approved return #5', '2026-01-27 11:55:40'),
(49, 2, NULL, 10.00, 28, 'sale', 'out', 'Sale #28 - deducted stock', '2026-01-27 13:00:24'),
(50, 11, NULL, 10.00, 1, 'purchase', 'in', 'Delivered by the supplier', '2026-01-28 05:49:42'),
(51, 11, NULL, 100.00, 2, 'purchase', 'in', 'received by staff', '2026-01-28 06:48:30'),
(52, 10, NULL, 50.00, 30, 'sale', 'out', 'Sale #30 - deducted stock', '2026-01-28 07:45:35'),
(53, 6, NULL, 200.00, 3, 'purchase', 'in', 'delivered', '2026-01-28 07:54:07'),
(54, 2, NULL, 1.00, 31, 'sale', 'out', 'Sale #31 - deducted stock', '2026-01-28 08:15:42'),
(55, 12, NULL, 100.00, 4, 'purchase', 'in', 'received by staff', '2026-01-28 08:38:18'),
(56, 10, NULL, 20.00, 5, 'purchase', 'in', 'delivered by supplier', '2026-01-28 08:47:21'),
(57, 8, NULL, 200.00, 6, 'purchase', 'in', 'None', '2026-01-28 08:53:54'),
(58, 13, NULL, 50.00, 7, 'purchase', 'in', 'done', '2026-01-28 08:57:23'),
(59, 9, NULL, 60.00, 8, 'purchase', 'in', 'delivered to warehouse', '2026-01-29 02:13:55'),
(60, 4, NULL, 60.00, 9, 'purchase', 'in', 'received by staff', '2026-01-29 02:22:32'),
(61, 2, NULL, 7.00, 32, 'sale', 'out', 'Sale #32 - deducted stock', '2026-01-29 11:01:46'),
(62, 2, NULL, 5.00, 33, 'sale', 'out', 'Sale #33 - deducted stock', '2026-01-29 11:03:19'),
(63, 12, NULL, 5.00, 34, 'sale', 'out', 'Sale #34 - deducted stock', '2026-01-29 11:09:44'),
(64, 10, NULL, 2.00, 35, 'sale', 'out', 'Sale #35 - deducted stock', '2026-01-29 11:14:46'),
(65, 6, NULL, 1.00, 36, 'sale', 'out', 'Sale #36 - deducted stock', '2026-01-29 11:15:22'),
(66, 9, NULL, 10.00, 37, 'sale', 'out', 'Sale #37 - deducted stock', '2026-01-29 11:26:51'),
(67, 12, NULL, 5.00, 38, 'sale', 'out', 'Sale #38 - deducted stock', '2026-01-29 11:27:25'),
(68, 10, NULL, 8.00, 39, 'sale', 'out', 'Sale #39 - deducted stock', '2026-01-29 11:36:58'),
(69, 9, NULL, 5.00, 40, 'sale', 'out', 'Sale #40 - deducted stock', '2026-01-29 11:46:15'),
(70, 10, NULL, 10.00, 41, 'sale', 'out', 'Sale #41 - deducted stock', '2026-01-29 11:46:45'),
(71, 2, NULL, 2.00, 42, 'sale', 'out', 'Sale #42 - deducted stock', '2026-01-29 11:47:41'),
(72, 5, NULL, 100.00, 10, 'purchase', 'in', 'delivered', '2026-01-29 11:52:47'),
(73, 14, NULL, 20.00, 11, 'purchase', 'in', 'DELIVERED', '2026-01-30 11:03:12'),
(74, 2, NULL, 10.00, 43, 'sale', 'out', 'Sale #43 - deducted stock', '2026-01-30 11:09:46'),
(75, 10, NULL, 4.00, 44, 'sale', 'out', 'Sale #44 - deducted stock', '2026-01-30 11:21:24'),
(76, 11, NULL, 99.00, 12, 'purchase', 'in', 'test', '2026-01-30 12:00:12'),
(77, 14, NULL, 100.00, 13, 'purchase', 'in', 'test', '2026-01-30 12:01:01'),
(78, 7, NULL, 1.00, 14, 'purchase', 'in', 'test', '2026-01-30 12:02:22'),
(79, 9, NULL, 2.00, 45, 'sale', 'out', 'Sale #45 - deducted stock', '2026-01-30 12:17:36'),
(80, 10, NULL, 6.00, 46, 'sale', 'out', 'Sale #46 - deducted stock', '2026-01-30 12:21:06'),
(81, 2, NULL, 10.00, 47, 'sale', 'out', 'Sale #47 - deducted stock', '2026-01-30 12:21:52'),
(82, 11, NULL, 9.00, 50, 'sale', 'out', 'Sale #50 - deducted stock', '2026-01-30 13:28:47'),
(83, 10, NULL, 40.00, 51, 'sale', 'out', 'Sale #51 - deducted stock', '2026-01-30 13:29:24'),
(84, 12, NULL, 10.00, 52, 'sale', 'out', 'Sale #52 - deducted stock', '2026-01-31 05:38:59'),
(85, 9, NULL, 3.00, 53, 'sale', 'out', 'Sale #53 - deducted stock', '2026-01-31 05:39:38'),
(86, 9, NULL, 10.00, 54, 'sale', 'out', 'Sale #54 - deducted stock', '2026-02-03 04:22:06'),
(87, 2, NULL, 10.00, 55, 'sale', 'out', 'Sale #55 - deducted stock', '2026-02-03 04:22:36'),
(88, 13, NULL, 10.00, 57, 'sale', 'out', 'Sale #57 - deducted stock', '2026-02-03 09:09:18'),
(89, 10, NULL, 10.00, 58, 'sale', 'out', 'Sale #58 - deducted stock', '2026-02-05 03:37:54'),
(90, 12, NULL, 10.00, 59, 'sale', 'out', 'Sale #59 - deducted stock', '2026-02-05 09:06:29'),
(91, 11, NULL, 10.00, 60, 'sale', 'out', 'Sale #60 - deducted stock', '2026-02-05 09:07:13'),
(92, 8, NULL, 30.00, 15, 'purchase', 'in', 'delivered', '2026-02-05 09:09:34'),
(93, 14, NULL, 10.00, 16, 'purchase', 'in', 'test', '2026-02-05 09:11:51'),
(94, 11, NULL, 10.00, 6, 'return', 'in', 'Approved return #6', '2026-02-05 09:14:42'),
(95, 10, NULL, 40.00, 7, 'return', 'in', 'Approved return #7', '2026-02-06 04:32:49'),
(96, 10, NULL, 10.00, 61, 'sale', 'out', 'Sale #61 - deducted stock', '2026-02-06 06:01:36'),
(97, 4, NULL, 10.00, 17, 'purchase', 'in', 'test', '2026-02-06 06:03:06'),
(98, 9, NULL, 20.00, 63, 'sale', 'out', 'Sale #63 - deducted stock', '2026-02-06 06:10:56'),
(99, 10, NULL, 20.00, 64, 'sale', 'out', 'Sale #64 - deducted stock', '2026-02-06 06:14:01'),
(100, 2, NULL, 10.00, 65, 'sale', 'out', 'Sale #65 - deducted stock', '2026-02-06 06:15:59'),
(101, 4, NULL, 10.00, 66, 'sale', 'out', 'Sale #66 - deducted stock', '2026-02-06 06:27:53'),
(102, 11, NULL, 10.00, 67, 'sale', 'out', 'Sale #67 - deducted stock', '2026-02-08 04:08:53'),
(103, 15, NULL, 150.00, 18, 'purchase', 'in', 'delivered', '2026-02-22 03:21:16'),
(104, 16, NULL, 1000.00, 19, 'purchase', 'in', 'test', '2026-02-22 03:34:51'),
(105, 8, NULL, 500.00, 20, 'purchase', 'in', 'test | sacks=10 | sack_size=50kg | supplier/sack=₱1,000.00 | transport=₱1,000.00 | cost/kg=₱22.00 | markup/kg=₱20.00 | sell/kg=₱42.00', '2026-02-22 04:29:41'),
(106, 15, NULL, 2.00, 68, 'sale', 'out', 'Sale #68 - 2.00 kg deducted', '2026-02-22 06:09:53'),
(107, 5, NULL, 10.00, 69, 'sale', 'out', 'Sale #69 - 10.00 kg deducted', '2026-02-22 06:18:13'),
(108, 16, NULL, 10.00, 70, 'sale', 'out', 'Sale #70 - 10.00 kg deducted', '2026-02-22 06:26:19'),
(109, 1, NULL, 10.00, 71, 'sale', 'out', 'Sale #71 - 10.00 kg deducted', '2026-02-22 09:01:30'),
(110, 2, NULL, 100.00, 73, 'sale', 'out', 'Sale #73 - 2 sack(s) deducted', '2026-02-22 09:02:31'),
(111, 6, NULL, 15.00, 74, 'sale', 'out', 'Sale #74 - 15.00 kg deducted', '2026-02-22 09:05:58'),
(112, 17, NULL, 150.00, 21, 'purchase', 'in', 'test | sacks=10 | sack_size=15kg | supplier/sack=₱2,000.00 | transport=₱100.00 | cost/kg=₱134.00 | markup/kg=₱5.00 | sell/kg=₱139.00', '2026-02-22 12:51:15'),
(113, 17, NULL, 50.00, NULL, NULL, 'out', 'test', '2026-02-22 13:15:13'),
(114, 2, NULL, 10.00, NULL, NULL, 'out', 'TEST LUNGS', '2026-02-23 02:56:45'),
(115, 1, NULL, 60.00, NULL, 'adjust', 'out', 'test', '2026-02-23 03:13:46'),
(116, 6, NULL, 5.00, 75, 'sale', 'out', 'Sale #75 - 5.00 kg deducted', '2026-02-23 04:17:03'),
(117, 5, NULL, 50.00, 76, 'sale', 'out', 'Sale #76 - 1 sack(s) deducted', '2026-02-23 04:18:12'),
(118, 10, NULL, 20.00, 77, 'sale', 'out', 'Sale #77 - 2 sack(s) deducted', '2026-02-23 04:20:00'),
(119, 12, NULL, 1.00, 78, 'sale', 'out', 'Sale #78 - 1.00 kg deducted', '2026-02-23 04:20:33'),
(120, 12, NULL, 500.00, 22, 'purchase', 'in', 'test | sacks=10 | sack_size=50kg | supplier/sack=₱1,000.00 | transport=₱150.00 | cost/kg=₱20.30 | markup/kg=₱4.00 | sell/kg=₱24.30', '2026-02-23 04:24:54'),
(121, 5, NULL, 25.00, 8, 'return', 'in', 'Approved return #8', '2026-02-23 04:29:49'),
(122, 6, NULL, 30.00, NULL, 'adjust', 'out', 'test', '2026-02-25 05:45:40'),
(123, 13, NULL, 250.00, NULL, 'adjust', 'in', 'test', '2026-02-25 13:43:38'),
(124, 6, NULL, 100.00, NULL, 'adjust', 'out', 'test', '2026-02-25 13:45:25'),
(125, 10, NULL, 10.00, NULL, 'adjust', 'out', 'test', '2026-02-25 13:59:48'),
(126, 11, NULL, 400.00, 23, 'purchase', 'in', 'test | sacks=40 | sack_size=10kg | supplier/sack=₱600.00 | transport=₱100.00 | cost/kg=₱60.25 | markup/kg=₱3.00 | sell/kg=₱63.25', '2026-02-25 14:15:51'),
(127, 5, NULL, 50.00, 79, 'sale', 'out', 'Sale #79 - 1 sack(s) deducted', '2026-02-25 15:08:17'),
(128, 2, NULL, 5.00, 80, 'sale', 'out', 'Sale #80 - 5.00 kg deducted', '2026-02-25 15:59:13'),
(129, 18, NULL, 1000.00, 24, 'purchase', 'in', 'delivered | sacks=20 | sack_size=50kg | supplier/sack=₱1,300.00 | transport=₱1,000.00 | cost/kg=₱27.00 | markup/kg=₱5.00 | sell/kg=₱32.00', '2026-02-27 05:37:05'),
(130, 18, NULL, 50.00, NULL, 'adjust', 'out', 'daot 1 sack', '2026-02-27 05:39:07'),
(131, 18, NULL, 50.00, 81, 'sale', 'out', 'Sale #81 - 1 sack(s) deducted', '2026-02-27 05:42:59'),
(132, 14, NULL, 500.00, 25, 'purchase', 'in', 'Stock received (Receiving) | sacks=50 | sack_size=10kg | supplier/sack=₱100.00 | transport=₱500.00 | cost/kg=₱11.00 | markup/kg=₱10.00 | sell/kg=₱21.00', '2026-02-27 07:30:49'),
(133, 14, NULL, 70.00, NULL, 'adjust', 'in', 'Manual adjustment', '2026-02-27 07:32:04'),
(134, 11, NULL, 10.00, 82, 'sale', 'out', 'Sale #82 - 1 sack(s) deducted', '2026-02-27 07:39:28'),
(135, 4, NULL, 10.00, 83, 'sale', 'out', 'Sale #83 - 10.00 kg deducted', '2026-02-27 07:42:39'),
(136, 4, NULL, 10.00, 9, 'return', 'in', 'Approved return #9', '2026-02-27 07:56:09'),
(137, 8, NULL, 50.00, 84, 'sale', 'out', 'Sale #84 - 1 sack(s) deducted', '2026-02-27 08:00:57'),
(138, 8, NULL, 50.00, 85, 'sale', 'out', 'Sale #85 - 1 sack(s) deducted', '2026-02-27 08:01:33'),
(139, 13, NULL, 50.00, 86, 'sale', 'out', 'Sale #86 - 1 sack(s) deducted', '2026-02-27 08:03:54'),
(140, 21, NULL, 1000.00, 26, 'purchase', 'in', 'test | sacks=20 | sack_size=50kg | supplier/sack=₱2,400.00 | transport=₱200.00 | cost/kg=₱48.20 | markup/kg=₱6.00 | sell/kg=₱54.20', '2026-02-27 10:59:04'),
(141, 21, NULL, 50.00, NULL, 'adjust', 'out', 'damage', '2026-02-27 11:06:39'),
(142, 22, NULL, 1000.00, 27, 'purchase', 'in', 'delivered | sacks=20 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱200.00 | cost/kg=₱46.20 | markup/kg=₱5.00 | sell/kg=₱51.20', '2026-02-27 11:16:54'),
(143, 22, NULL, 7500.00, NULL, 'adjust', 'in', 'adjust', '2026-02-27 11:21:14'),
(144, 22, NULL, 7500.00, NULL, 'adjust', 'out', 'reduce', '2026-02-27 11:21:47'),
(145, 6, NULL, 2.00, 87, 'sale', 'out', 'Sale #87 - 2.00 kg deducted', '2026-02-27 11:38:38'),
(146, 14, NULL, 20.00, 88, 'sale', 'out', 'Sale #88 - 2 sack(s) deducted', '2026-02-27 11:45:16'),
(147, 16, NULL, 50.00, 89, 'sale', 'out', 'Sale #89 - 1 sack(s) deducted', '2026-03-03 10:22:37'),
(148, 9, NULL, 10.00, 90, 'sale', 'out', 'Sale #90 - 1 sack(s) deducted', '2026-03-03 10:23:04'),
(149, 9, NULL, 30.00, 91, 'sale', 'out', 'Sale #91 - 3 sack(s) deducted', '2026-03-03 10:39:40'),
(150, 15, NULL, 75.00, 92, 'sale', 'out', 'Sale #92 - 5 sack(s) deducted', '2026-03-04 07:28:45'),
(151, 2, NULL, 250.00, 93, 'sale', 'out', 'Sale #93 - 5 sack(s) deducted', '2026-03-04 07:34:56'),
(152, 15, NULL, 60.00, 94, 'sale', 'out', 'Sale #94 - 4 sack(s) deducted', '2026-03-10 12:14:21'),
(153, 6, NULL, -25.00, NULL, 'adjust', 'adjust', 'test', '2026-03-18 13:30:00'),
(154, 10, NULL, 10.00, 95, 'sale', 'out', 'Sale #95 - 1 sack(s) deducted', '2026-03-22 08:38:53'),
(155, 21, NULL, -150.00, NULL, 'adjust', 'adjust', 'Quality downgrade - testtt', '2026-03-22 10:02:54'),
(156, 22, NULL, -250.00, NULL, 'adjust', 'adjust', 'Wet stock - test', '2026-03-22 10:03:37'),
(157, 24, NULL, 1000.00, 28, 'purchase', 'in', 'test | sacks=20 | sack_size=50kg | supplier/sack=₱2,500.00 | transport=₱0.00 | cost/kg=₱50.00 | markup/kg=₱0.00 | sell/kg=₱50.00', '2026-03-23 05:35:32'),
(158, 25, NULL, 500.00, 29, 'purchase', 'in', 'Stock received (Receiving) | sacks=10 | sack_size=50kg | supplier/sack=₱2,500.00 | transport=₱0.00 | cost/kg=₱50.00 | markup/kg=₱0.00 | sell/kg=₱50.00 | sell/sack=₱2,500.00', '2026-03-24 04:01:55'),
(159, 8, NULL, -100.00, NULL, 'adjust', 'adjust', 'Pest contamination - test', '2026-03-24 04:28:31'),
(160, 25, NULL, 1.00, 96, 'sale', 'out', 'Sale #96 - 1.00 kg deducted from discounted stock', '2026-03-24 04:32:48'),
(161, 23, NULL, 500.00, 30, 'purchase', 'in', 'Stock received (Receiving) | sacks=10 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00', '2026-03-24 04:39:02'),
(162, 24, NULL, 50.00, 97, 'sale', 'out', 'Sale #97 - 1 sack(s) deducted from regular stock', '2026-03-24 04:44:10'),
(163, 1, NULL, 2.00, 98, 'sale', 'out', 'Sale #98 - 2.00 kg deducted from regular stock', '2026-03-24 04:44:48'),
(164, 11, NULL, 1.00, 99, 'sale', 'out', 'Sale #99 - 1.00 kg deducted from regular stock', '2026-03-25 03:20:17'),
(165, 11, NULL, 10.00, 100, 'sale', 'out', 'Sale #100 - 1 sack(s) deducted from regular stock', '2026-03-25 03:22:14'),
(166, 7, NULL, 250.00, 31, 'purchase', 'in', 'Stock received (Receiving) | sacks=10 | sack_size=25kg | supplier/sack=₱1,000.00 | transport=₱0.00 | cost/kg=₱40.00 | markup/kg=₱0.00 | sell/kg=₱40.00 | sell/sack=₱1,000.00', '2026-03-25 03:35:04'),
(167, 17, NULL, 500.00, 32, 'purchase', 'in', 'Stock received (Receiving) | sacks=10 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00', '2026-03-25 03:39:07'),
(168, 10, NULL, 100.00, 33, 'purchase', 'in', 'Stock received (Receiving) | sacks=10 | sack_size=10kg | supplier/sack=₱500.00 | transport=₱0.00 | cost/kg=₱50.00 | markup/kg=₱0.00 | sell/kg=₱50.00 | sell/sack=₱500.00', '2026-03-25 03:45:17'),
(169, 23, NULL, 50.00, 101, 'sale', 'out', 'Sale #101 - 1 sack(s) deducted from regular stock', '2026-03-25 03:55:09'),
(170, 24, NULL, 1.00, 102, 'sale', 'out', 'Sale #102 - 1.00 kg deducted from regular stock', '2026-03-28 04:43:15'),
(171, 1, NULL, 50.00, 103, 'sale', 'out', 'Sale #103 - 1 sack(s) deducted from regular stock', '2026-03-28 04:43:56'),
(172, 8, NULL, 50.00, 104, 'sale', 'out', 'Sale #104 - 1 sack(s) deducted from regular stock', '2026-03-28 04:52:23'),
(173, 12, NULL, 50.00, 105, 'sale', 'out', 'Sale #105 - 1 sack(s) deducted from regular stock', '2026-03-28 04:55:20'),
(174, 9, NULL, 10.00, 106, 'sale', 'out', 'Sale #106 - 1 sack(s) deducted from regular stock', '2026-03-28 04:59:26'),
(175, 24, NULL, 50.00, 107, 'sale', 'out', 'Sale #107 - 1 sack(s) deducted from regular stock', '2026-03-28 05:05:14'),
(176, 14, NULL, -10.00, NULL, 'adjust', 'adjust', 'Torn sack - sada', '2026-04-07 02:58:43'),
(177, 12, NULL, 1.00, 108, 'sale', 'out', 'Sale #108 - 1.00 kg deducted from regular stock', '2026-04-08 10:38:41'),
(178, 14, NULL, 10.00, NULL, 'adjust', 'adjust', 'basa', '2026-04-08 11:03:47'),
(179, 23, NULL, -50.00, NULL, 'adjust', 'adjust', 'Pest contamination - pest', '2026-04-08 11:05:07'),
(180, 26, NULL, 1500.00, 34, 'purchase', 'in', 'Stock received (Receiving) | sacks=30 | sack_size=50kg | supplier/sack=₱2,500.00 | transport=₱0.00 | cost/kg=₱50.00 | markup/kg=₱0.00 | sell/kg=₱50.00 | sell/sack=₱2,500.00', '2026-04-26 12:51:24'),
(181, 26, NULL, 50.00, NULL, 'adjust', 'adjust', 'Manual stock addition', '2026-04-26 13:05:14'),
(182, 26, NULL, -150.00, NULL, 'adjust', 'adjust', 'Torn sack - done', '2026-04-26 13:06:09'),
(183, 23, NULL, 1.00, 109, 'sale', 'out', 'Sale #109 - 1.00 kg deducted from regular stock', '2026-04-27 01:29:59'),
(184, 12, NULL, 500.00, 35, 'purchase', 'in', 'Stock received (Receiving) | sacks=10 | sack_size=50kg | supplier/sack=₱2,299.99 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱10.00 | sell/kg=₱56.00 | sell/sack=₱2,799.99', '2026-05-04 02:46:34'),
(185, 15, NULL, 150.00, 36, 'purchase', 'in', 'Stock received (Receiving) | sacks=10 | sack_size=15kg | supplier/sack=₱800.00 | transport=₱0.00 | cost/kg=₱53.33 | markup/kg=₱7.00 | sell/kg=₱60.33 | sell/sack=₱905.00', '2026-05-04 02:47:30'),
(186, 22, NULL, 50.00, 110, 'sale', 'out', 'Sale #110 - 1 sack(s) deducted from regular stock', '2026-05-04 02:53:05'),
(187, 9, NULL, 2.00, 111, 'sale', 'out', 'Sale #111 - 2.00 kg deducted from regular stock', '2026-05-04 02:56:20'),
(188, 14, NULL, 10.00, 112, 'sale', 'out', 'Sale #112 - 1 sack(s) deducted from regular stock', '2026-05-04 03:15:16'),
(189, 14, NULL, 50.00, 113, 'sale', 'out', 'Sale #113 - 5 sack(s) deducted from regular stock', '2026-05-11 04:34:46'),
(190, 2, 2, 50.00, 114, 'sale', 'out', 'Sale #114 - 1 sack(s) deducted from regular batch LEGACY-2', '2026-05-24 08:41:24'),
(191, 1, 1, 50.00, 115, 'sale', 'out', 'Sale #115 - 1 sack(s) deducted from regular batch LEGACY-1', '2026-05-24 08:52:40'),
(192, 2, 2, 50.00, 116, 'sale', 'out', 'Sale #116 - 1 sack(s) deducted from regular batch LEGACY-2', '2026-05-24 08:54:15'),
(193, 21, 18, 50.00, 117, 'sale', 'out', 'Sale #117 - 1 sack(s) deducted from regular batch LEGACY-21', '2026-06-01 13:45:26'),
(194, 1, 1, 50.00, 118, 'sale', 'out', 'Sale #118 - 1 sack(s) deducted from regular batch LEGACY-1', '2026-06-01 13:46:21'),
(195, 6, 24, 750.00, 39, 'purchase', 'in', 'Stock received (Receiving) | sacks=30 | sack_size=25kg | supplier/sack=₱1,300.00 | transport=₱0.00 | cost/kg=₱52.00 | markup/kg=₱20.00 | sell/kg=₱72.00 | sell/sack=₱1,800.00 | batch=B000024', '2026-06-02 02:58:59'),
(196, 6, 24, 25.00, 119, 'sale', 'out', 'Sale #119 - 1 sack(s) deducted from regular batch B000024', '2026-06-02 03:05:09'),
(197, 27, 25, 150.00, 50, 'purchase', 'in', 'Stock received (Receiving) | sacks=3 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱20.00 | sell/kg=₱66.00 | sell/sack=₱3,300.00 | batch=B000025', '2026-06-02 06:35:36'),
(198, 15, 26, 45.00, 52, 'purchase', 'in', 'Stock received (Receiving) | sacks=3 | sack_size=15kg | supplier/sack=₱800.00 | transport=₱0.00 | cost/kg=₱53.33 | markup/kg=₱13.00 | sell/kg=₱66.33 | sell/sack=₱995.00 | batch=B000026', '2026-06-02 06:42:35'),
(199, 22, 19, 50.00, 120, 'sale', 'out', 'Sale #120 - 1 sack(s) deducted from discounted batch LEGACY-22', '2026-06-09 08:20:16'),
(200, 5, 27, 250.00, 54, 'purchase', 'in', 'Stock received (Receiving) | sacks=5 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱10.00 | sell/kg=₱56.00 | sell/sack=₱2,800.00 | batch=B000027', '2026-06-10 02:16:42'),
(201, 5, 27, 250.00, 121, 'sale', 'out', 'Sale #121 - 5 sack(s) deducted from regular batch B000027', '2026-06-10 02:22:16'),
(202, 5, 4, 15.00, 122, 'sale', 'out', 'Sale #122 - 15.00 kg deducted from regular batch LEGACY-5', '2026-06-10 02:26:06'),
(203, 5, 28, 100.00, 58, 'purchase', 'in', 'Stock received (Receiving) | sacks=2 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00 | batch=B000028', '2026-07-08 13:17:43'),
(204, 5, 28, 50.00, 123, 'sale', 'out', 'Sale #123 - 1 sack(s) deducted from regular batch B000028', '2026-07-08 13:19:50'),
(205, 4, 29, 150.00, 59, 'purchase', 'in', 'Stock received (Receiving) | sacks=3 | sack_size=50kg | supplier/sack=₱3,000.00 | transport=₱0.00 | cost/kg=₱60.00 | markup/kg=₱0.00 | sell/kg=₱60.00 | sell/sack=₱3,000.00 | batch=B000029', '2026-07-08 13:34:52'),
(206, 4, 30, 150.00, 59, 'purchase', 'in', 'Stock received (Receiving) | sacks=3 | sack_size=50kg | supplier/sack=₱3,000.00 | transport=₱0.00 | cost/kg=₱60.00 | markup/kg=₱0.00 | sell/kg=₱60.00 | sell/sack=₱3,000.00 | batch=B000030', '2026-07-08 13:35:15'),
(207, 4, 31, 150.00, 59, 'purchase', 'in', 'Stock received (Receiving) | sacks=3 | sack_size=50kg | supplier/sack=₱3,000.00 | transport=₱0.00 | cost/kg=₱60.00 | markup/kg=₱0.00 | sell/kg=₱60.00 | sell/sack=₱3,000.00 | batch=B000031', '2026-07-08 13:41:43'),
(208, 5, 32, 250.00, 60, 'purchase', 'in', 'Stock received (Receiving) | sacks=5 | sack_size=50kg | supplier/sack=₱2,500.00 | transport=₱0.00 | cost/kg=₱50.00 | markup/kg=₱5.00 | sell/kg=₱55.00 | sell/sack=₱2,750.00 | batch=B000032', '2026-07-16 06:09:39'),
(209, 7, 6, 25.00, 124, 'sale', 'out', 'Sale #124 - 1 sack(s) deducted from regular batch LEGACY-7', '2026-07-16 06:15:08'),
(210, 27, 33, 50.00, 61, 'purchase', 'in', 'Stock received (Receiving) | sacks=1 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱9.99 | sell/kg=₱55.99 | sell/sack=₱2,799.50 | batch=B000033', '2026-07-16 06:26:21'),
(211, 27, 34, 100.00, 62, 'purchase', 'in', 'Stock received (Receiving) | sacks=2 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱4.99 | sell/kg=₱50.99 | sell/sack=₱2,549.50 | batch=B000034', '2026-07-16 06:31:59'),
(212, 15, 35, 15.00, 63, 'purchase', 'in', 'Stock received (Receiving) | sacks=1 | sack_size=15kg | supplier/sack=₱800.00 | transport=₱0.00 | cost/kg=₱53.33 | markup/kg=₱0.00 | sell/kg=₱53.33 | sell/sack=₱800.00 | batch=B000035', '2026-07-16 07:39:25'),
(213, 15, 36, 165.00, 64, 'purchase', 'in', 'Stock received (Receiving) | sacks=11 | sack_size=15kg | supplier/sack=₱800.00 | transport=₱0.00 | cost/kg=₱53.33 | markup/kg=₱5.00 | sell/kg=₱58.33 | sell/sack=₱875.00 | batch=B000036', '2026-07-16 08:10:36'),
(214, 7, 37, 250.00, 65, 'purchase', 'in', 'Stock received (Receiving) | sacks=10 | sack_size=25kg | supplier/sack=₱1,000.00 | transport=₱0.00 | cost/kg=₱40.00 | markup/kg=₱5.00 | sell/kg=₱45.00 | sell/sack=₱1,125.00 | batch=B000037', '2026-07-16 08:13:26'),
(215, 13, 12, 50.00, 125, 'sale', 'out', 'Sale #125 - 1 sack(s) deducted from regular batch LEGACY-13', '2026-07-16 08:45:21'),
(216, 7, 37, 25.00, 125, 'sale', 'out', 'Sale #125 - 1 sack(s) deducted from regular batch B000037', '2026-07-16 08:45:21'),
(217, 13, 12, 100.00, 126, 'sale', 'out', 'Sale #126 - 2 sack(s) deducted from regular batch LEGACY-13', '2026-07-16 08:48:51'),
(218, 13, 38, 50.00, 66, 'purchase', 'in', 'Stock in recorded | sacks=1 | sack_size=50kg | supplier/sack=₱2,450.00 | transport=₱0.00 | cost/kg=₱49.00 | markup/kg=₱0.00 | sell/kg=₱49.00 | sell/sack=₱2,450.00 | batch=B000038', '2026-07-19 13:37:09'),
(219, 11, 10, 10.00, 127, 'sale', 'out', 'Sale #127 - 1 sack(s) deducted from regular batch LEGACY-11', '2026-07-19 15:11:05'),
(220, 22, 19, 50.00, 128, 'sale', 'out', 'Sale #128 - 1 sack(s) deducted from regular batch LEGACY-22', '2026-07-19 15:31:20'),
(221, 11, 10, 10.00, 129, 'sale', 'out', 'Sale #129 - 1 sack(s) deducted from regular batch LEGACY-11', '2026-07-19 15:37:14'),
(222, 11, 10, 10.00, 130, 'sale', 'out', 'Sale #130 - 1 sack(s) deducted from regular batch LEGACY-11', '2026-07-21 05:00:37'),
(223, 26, 23, 50.00, 131, 'sale', 'out', 'Sale #131 - 1 sack(s) deducted from regular batch LEGACY-26', '2026-07-21 05:19:41'),
(224, 26, 23, 50.00, 132, 'sale', 'out', 'Sale #132 - 1 sack(s) deducted from regular batch LEGACY-26', '2026-07-21 05:41:01'),
(225, 9, 8, 10.00, 133, 'sale', 'out', 'Sale #133 - 1 sack(s) deducted from regular batch LEGACY-9', '2026-07-21 06:35:47'),
(226, 14, 13, 50.00, 133, 'sale', 'out', 'Sale #133 - 5 sack(s) deducted from regular batch LEGACY-14', '2026-07-21 06:35:47'),
(227, 9, 8, 1.00, 134, 'sale', 'out', 'Sale #134 - 1.00 kg deducted from regular batch LEGACY-9', '2026-07-21 06:39:41'),
(228, 28, 39, 150.00, 67, 'purchase', 'in', 'Stock in recorded | sacks=3 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱5.00 | sell/kg=₱51.00 | sell/sack=₱2,550.00 | batch=B000039', '2026-07-22 01:19:18'),
(229, 11, 10, 10.00, 135, 'sale', 'out', 'Sale #135 - 1 sack(s) deducted from regular batch LEGACY-11', '2026-07-22 01:27:05'),
(230, 13, 12, 50.00, 136, 'sale', 'out', 'Sale #136 - 1 sack(s) deducted from regular batch LEGACY-13', '2026-07-23 07:17:59'),
(231, 13, 40, 1000.00, 68, 'purchase', 'in', 'Stock in recorded | sacks=20 | sack_size=50kg | supplier/sack=₱2,450.00 | transport=₱0.00 | cost/kg=₱49.00 | markup/kg=₱10.00 | sell/kg=₱59.00 | sell/sack=₱2,950.00 | batch=B000040', '2026-07-27 07:22:07'),
(232, 6, 24, -25.00, NULL, 'adjust', 'adjust', 'Quality downgrade - QUALITY IS NOT GOOD', '2026-07-27 07:42:13'),
(233, 22, 19, 100.00, 137, 'sale', 'out', 'Sale #137 - 2 sack(s) deducted from discounted batch LEGACY-22', '2026-07-27 08:04:57'),
(234, 12, 11, 50.00, 138, 'sale', 'out', 'Sale #138 - 1 sack(s) deducted from discounted batch LEGACY-12', '2026-07-27 08:08:43'),
(235, 13, 40, 50.00, 139, 'sale', 'out', 'Sale #139 - 1 sack(s) deducted from regular batch B000040', '2026-07-28 10:54:36'),
(236, 9, 8, 1.00, 140, 'sale', 'out', 'Sale #140 - 1.00 kg deducted from regular batch LEGACY-9', '2026-07-28 10:55:32'),
(237, 6, 41, 50.00, 74, 'purchase', 'in', 'Stock in recorded | sacks=2 | sack_size=25kg | supplier/sack=₱1,300.00 | transport=₱0.00 | cost/kg=₱52.00 | markup/kg=₱0.00 | sell/kg=₱52.00 | sell/sack=₱1,300.00 | batch=B000041', '2026-07-29 11:39:06'),
(238, 28, 42, 100.00, 73, 'purchase', 'in', 'Stock in recorded | sacks=2 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00 | batch=B000042', '2026-07-29 11:39:15'),
(239, 28, 43, 250.00, 72, 'purchase', 'in', 'Stock in recorded | sacks=5 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00 | batch=B000043', '2026-07-29 11:39:20'),
(240, 27, 44, 100.00, 71, 'purchase', 'in', 'Stock in recorded | sacks=2 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00 | batch=B000044', '2026-07-29 11:39:24'),
(241, 28, 45, 100.00, 70, 'purchase', 'in', 'Stock in recorded | sacks=2 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00 | batch=B000045', '2026-07-29 11:39:28'),
(242, 28, 46, 1500.00, 69, 'purchase', 'in', 'Stock in recorded | sacks=30 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00 | batch=B000046', '2026-07-29 11:39:46'),
(243, 27, 47, 100.00, 62, 'purchase', 'in', 'Stock in recorded | sacks=2 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00 | batch=B000047', '2026-07-29 11:39:51'),
(244, 27, 48, 50.00, 61, 'purchase', 'in', 'Stock in recorded | sacks=1 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00 | batch=B000048', '2026-07-29 11:39:55'),
(245, 5, 49, 250.00, 60, 'purchase', 'in', 'Stock in recorded | sacks=5 | sack_size=50kg | supplier/sack=₱2,500.00 | transport=₱0.00 | cost/kg=₱50.00 | markup/kg=₱0.00 | sell/kg=₱50.00 | sell/sack=₱2,500.00 | batch=B000049', '2026-07-29 11:39:59'),
(246, 4, 50, 150.00, 59, 'purchase', 'in', 'Stock in recorded | sacks=3 | sack_size=50kg | supplier/sack=₱3,000.00 | transport=₱0.00 | cost/kg=₱60.00 | markup/kg=₱0.00 | sell/kg=₱60.00 | sell/sack=₱3,000.00 | batch=B000050', '2026-07-29 11:40:03'),
(247, 2, 51, 50.00, 57, 'purchase', 'in', 'Stock in recorded | sacks=1 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00 | batch=B000051', '2026-07-29 11:40:17'),
(248, 2, 52, 250.00, 56, 'purchase', 'in', 'Stock in recorded | sacks=5 | sack_size=50kg | supplier/sack=₱2,000.00 | transport=₱0.00 | cost/kg=₱40.00 | markup/kg=₱0.00 | sell/kg=₱40.00 | sell/sack=₱2,000.00 | batch=B000052', '2026-07-29 11:40:22'),
(249, 5, 53, 250.00, 55, 'purchase', 'in', 'Stock in recorded | sacks=5 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00 | batch=B000053', '2026-07-29 11:40:33'),
(250, 1, 54, 250.00, 53, 'purchase', 'in', 'Stock in recorded | sacks=5 | sack_size=50kg | supplier/sack=₱2,000.00 | transport=₱0.00 | cost/kg=₱40.00 | markup/kg=₱0.00 | sell/kg=₱40.00 | sell/sack=₱2,000.00 | batch=B000054', '2026-07-29 11:40:45'),
(251, 17, 55, 100.00, 42, 'purchase', 'in', 'Stock in recorded | sacks=2 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00 | batch=B000055', '2026-07-29 11:40:59'),
(252, 13, 40, 50.00, 141, 'sale', 'out', 'Sale #141 - 1 sack(s) deducted from regular batch B000040', '2026-07-29 11:44:11'),
(253, 22, 19, 50.00, 141, 'sale', 'out', 'Sale #141 - 1 sack(s) deducted from regular batch LEGACY-22', '2026-07-29 11:44:11'),
(254, 7, 56, 50.00, 75, 'purchase', 'in', 'Stock in recorded | sacks=2 | sack_size=25kg | supplier/sack=₱1,000.00 | transport=₱0.00 | cost/kg=₱40.00 | markup/kg=₱10.00 | sell/kg=₱50.00 | sell/sack=₱1,250.00 | batch=B000056', '2026-07-31 02:17:36'),
(255, 28, 57, 50.00, 75, 'purchase', 'in', 'Stock in recorded | sacks=1 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱4.00 | sell/kg=₱50.00 | sell/sack=₱2,500.00 | batch=B000057', '2026-07-31 02:18:33'),
(256, 14, 58, 20.00, 76, 'purchase', 'in', 'delivered by supplier | sacks=2 | sack_size=10kg | supplier/sack=₱500.00 | transport=₱0.00 | cost/kg=₱50.00 | markup/kg=₱5.00 | sell/kg=₱55.00 | sell/sack=₱550.00 | batch=B000058', '2026-07-31 02:24:55'),
(257, 28, 39, 50.00, 142, 'sale', 'out', 'Sale #142 - 1 sack(s) deducted from discounted batch B000039', '2026-07-31 03:28:46'),
(258, 28, NULL, 1.00, 11, 'return', 'in', 'Approved return #11', '2026-07-31 03:38:19'),
(259, 27, 59, 250.00, 48, 'purchase', 'in', 'Stock in recorded | sacks=5 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00 | batch=B000059', '2026-08-02 06:47:18'),
(260, 29, 60, 250.00, 77, 'purchase', 'in', 'Stock in recorded | sacks=5 | sack_size=50kg | supplier/sack=₱2,200.00 | transport=₱0.00 | cost/kg=₱44.00 | markup/kg=₱10.00 | sell/kg=₱54.00 | sell/sack=₱2,700.00 | batch=B000060', '2026-08-02 06:51:58'),
(261, 30, 61, 500.00, 78, 'purchase', 'in', 'Stock in recorded | sacks=10 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱10.00 | sell/kg=₱56.00 | sell/sack=₱2,800.00 | batch=B000061', '2026-08-02 13:26:36'),
(262, 8, 62, 50.00, 79, 'purchase', 'in', 'Stock in recorded | sacks=1 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱10.00 | sell/kg=₱56.00 | sell/sack=₱2,800.00 | batch=B000062', '2026-08-02 13:27:46'),
(263, 30, 61, 50.00, 143, 'sale', 'out', 'Sale #143 - 1 sack(s) deducted from regular batch B000061', '2026-08-02 13:31:25'),
(264, 30, NULL, 2.00, 12, 'return', 'in', 'Approved return #12', '2026-08-02 13:32:29'),
(265, 9, 8, 50.00, 144, 'sale', 'out', 'Sale #144 - 5 sack(s) deducted from regular batch LEGACY-9', '2026-08-03 05:14:39'),
(266, 29, 63, 250.00, 80, 'purchase', 'in', 'Stock in recorded | sacks=5 | sack_size=50kg | supplier/sack=₱2,200.00 | transport=₱0.00 | cost/kg=₱44.00 | markup/kg=₱10.00 | sell/kg=₱54.00 | sell/sack=₱2,700.00 | batch=B000063', '2026-08-03 06:04:05'),
(267, 29, 60, 250.00, 145, 'sale', 'out', 'Sale #145 - 5 sack(s) deducted from regular batch B000060', '2026-08-03 06:06:02'),
(268, 16, 15, 250.00, 146, 'sale', 'out', 'Sale #146 - 5 sack(s) deducted from regular batch LEGACY-16', '2026-08-03 06:08:03'),
(269, 7, 6, 125.00, 147, 'sale', 'out', 'Sale #147 - 5 sack(s) deducted from regular batch LEGACY-7', '2026-08-03 06:12:09'),
(270, 29, 64, 50.00, 81, 'purchase', 'in', 'Stock in recorded | sacks=1 | sack_size=50kg | supplier/sack=₱2,200.00 | transport=₱0.00 | cost/kg=₱44.00 | markup/kg=₱5.00 | sell/kg=₱49.00 | sell/sack=₱2,450.00 | batch=B000064', '2026-08-10 06:04:21'),
(271, 11, 10, 29.00, 148, 'sale', 'out', 'Sale #148 - 29.00 kg deducted from regular batch LEGACY-11', '2026-08-10 06:08:28'),
(272, 9, 8, 1.00, 149, 'sale', 'out', 'Sale #149 - 1.00 kg deducted from regular batch LEGACY-9', '2026-08-10 06:13:59'),
(273, 14, 13, 500.00, 150, 'sale', 'out', 'Sale #150 - 50 sack(s) deducted from regular batch LEGACY-14', '2026-08-10 06:37:32'),
(274, 10, 9, 400.00, 151, 'sale', 'out', 'Sale #151 - 40 sack(s) deducted from regular batch LEGACY-10', '2026-08-10 06:43:58'),
(275, 28, 39, -50.00, NULL, 'adjust', 'adjust', 'Torn sack', '2026-08-11 07:52:53'),
(276, 14, 65, 50.00, 82, 'purchase', 'in', 'Stock in recorded | sacks=5 | sack_size=10kg | supplier/sack=₱500.00 | transport=₱0.00 | cost/kg=₱50.00 | markup/kg=₱5.00 | sell/kg=₱55.00 | sell/sack=₱550.00 | batch=B000065', '2026-08-12 02:48:17'),
(277, 9, 8, 1.00, 152, 'sale', 'out', 'Sale #152 - 1.00 kg deducted from regular batch LEGACY-9', '2026-08-17 05:56:43'),
(278, 16, 15, 1.00, 153, 'sale', 'out', 'Sale #153 - 1.00 kg deducted from regular batch LEGACY-16', '2026-08-17 06:03:32'),
(279, 16, 15, 50.00, 154, 'sale', 'out', 'Sale #154 - 1 sack(s) deducted from regular batch LEGACY-16', '2026-08-17 06:05:24'),
(280, 29, 63, 250.00, 155, 'sale', 'out', 'Sale #155 - 5 sack(s) deducted from regular batch B000063', '2026-08-17 06:07:02'),
(281, 29, 64, 50.00, 156, 'sale', 'out', 'Sale #156 - 1 sack(s) deducted from regular batch B000064', '2026-08-17 06:07:23'),
(282, 27, 25, 1.00, 157, 'sale', 'out', 'Sale #157 - 1.00 kg deducted from regular batch B000025', '2026-08-17 08:45:38'),
(283, 9, 8, 1.00, 158, 'sale', 'out', 'Sale #158 - 1.00 kg deducted from regular batch LEGACY-9', '2026-08-17 13:17:30'),
(284, 14, 66, 50.00, 83, 'purchase', 'in', 'Stock in recorded | sacks=5 | sack_size=10kg | supplier/sack=₱500.00 | transport=₱0.00 | cost/kg=₱50.00 | markup/kg=₱7.00 | sell/kg=₱57.00 | sell/sack=₱570.00 | batch=B000066', '2026-08-17 16:46:20'),
(285, 8, 7, 450.00, 159, 'sale', 'out', 'Sale #159 - 9 sack(s) deducted from regular batch LEGACY-8', '2026-08-17 17:16:08'),
(286, 14, 67, 50.00, 84, 'purchase', 'in', 'Stock in recorded | sacks=5 | sack_size=10kg | supplier/sack=₱500.00 | transport=₱0.00 | cost/kg=₱50.00 | markup/kg=₱5.00 | sell/kg=₱55.00 | sell/sack=₱550.00 | batch=B000067', '2026-08-17 17:21:36'),
(287, 10, 68, 50.00, 85, 'purchase', 'in', 'Stock in recorded | sacks=5 | sack_size=10kg | supplier/sack=₱700.00 | transport=₱0.00 | cost/kg=₱70.00 | markup/kg=₱0.00 | sell/kg=₱70.00 | sell/sack=₱700.00 | payment=credit | batch=B000068', '2026-08-18 07:23:48'),
(288, 22, 19, -350.00, NULL, 'adjust', 'adjust', 'Manual recount correction - DFDF', '2026-08-20 03:20:17'),
(289, 29, 69, 500.00, 88, 'purchase', 'in', 'Stock in recorded | sacks=10 | sack_size=50kg | supplier/sack=₱2,100.00 | transport=₱0.00 | cost/kg=₱42.00 | markup/kg=₱10.00 | sell/kg=₱52.00 | sell/sack=₱2,600.00 | payment=cash | batch=B000069', '2026-09-01 15:32:35'),
(290, 29, 69, 300.00, 331, 'sale', 'out', 'Sale #331 - 6 sack(s) deducted from regular batch B000069', '2026-09-01 15:37:18');

-- --------------------------------------------------------

--
-- Table structure for table `login_logs`
--

CREATE TABLE `login_logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `login_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `device_info` varchar(255) DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_logs`
--

INSERT INTO `login_logs` (`log_id`, `user_id`, `login_time`, `device_info`, `ip_address`) VALUES
(1, 2, '2026-01-25 10:45:22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(2, 5, '2026-01-25 11:41:46', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(3, 2, '2026-01-25 11:42:18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(4, 1, '2026-01-25 11:53:07', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(5, 2, '2026-01-25 11:53:33', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(6, 2, '2026-01-25 12:14:16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(7, 2, '2026-01-25 12:14:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(8, 2, '2026-01-25 12:16:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(9, 1, '2026-01-25 12:21:51', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(10, 2, '2026-01-25 12:25:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(11, 1, '2026-01-25 13:02:34', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(12, 5, '2026-01-25 13:04:00', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(13, 1, '2026-01-26 04:14:58', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(14, 5, '2026-01-26 04:15:46', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(15, 5, '2026-01-26 05:09:37', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(16, 1, '2026-01-26 05:10:17', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(17, 5, '2026-01-26 05:11:19', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(18, 1, '2026-01-26 05:39:01', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(19, 2, '2026-01-26 08:43:09', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(20, 2, '2026-01-26 08:58:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(21, 5, '2026-01-26 09:29:08', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(22, 2, '2026-01-26 09:29:49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(23, 5, '2026-01-26 09:55:47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(24, 2, '2026-01-26 10:30:29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(25, 5, '2026-01-26 10:43:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(26, 1, '2026-01-26 10:45:55', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(27, 2, '2026-01-26 10:59:01', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(28, 5, '2026-01-26 11:06:54', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(29, 1, '2026-01-26 11:13:26', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(30, 1, '2026-01-26 11:16:58', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(31, 1, '2026-01-26 11:21:17', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(33, 2, '2026-01-27 02:35:20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(34, 5, '2026-01-27 03:09:47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(35, 2, '2026-01-27 03:11:59', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(36, 1, '2026-01-27 03:12:16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(37, 2, '2026-01-27 06:07:54', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(38, 1, '2026-01-27 06:10:30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(39, 5, '2026-01-27 06:12:17', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(40, 2, '2026-01-27 06:58:55', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(41, 1, '2026-01-27 07:01:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(42, 5, '2026-01-27 07:02:10', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(43, 1, '2026-01-27 07:06:00', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(44, 2, '2026-01-27 07:11:48', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(45, 5, '2026-01-27 07:12:44', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(46, 2, '2026-01-27 07:21:12', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(47, 1, '2026-01-27 07:38:13', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(48, 5, '2026-01-27 07:57:16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(49, 1, '2026-01-27 08:02:39', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(50, 2, '2026-01-27 08:06:19', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(51, 5, '2026-01-27 08:06:37', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(52, 2, '2026-01-27 08:07:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(53, 1, '2026-01-27 08:08:01', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(54, 1, '2026-01-27 09:02:31', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(55, 1, '2026-01-27 09:05:46', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(56, 2, '2026-01-27 09:20:11', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(57, 2, '2026-01-27 09:20:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(58, 5, '2026-01-27 09:25:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(59, 5, '2026-01-27 10:22:36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(60, 1, '2026-01-27 10:35:45', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(61, 2, '2026-01-27 11:06:05', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(63, 2, '2026-01-27 11:56:01', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(64, 1, '2026-01-27 12:26:01', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(65, 2, '2026-01-27 12:29:32', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(66, 2, '2026-01-28 01:09:47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(67, 1, '2026-01-28 01:10:56', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(68, 2, '2026-01-28 05:10:44', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(69, 1, '2026-01-28 05:19:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(70, 5, '2026-01-28 06:49:50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(71, 5, '2026-01-28 07:38:23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(72, 1, '2026-01-28 07:38:57', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(73, 2, '2026-01-28 07:45:20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(74, 1, '2026-01-28 07:46:07', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(75, 5, '2026-01-28 07:54:59', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(76, 1, '2026-01-28 07:56:47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(77, 2, '2026-01-28 08:00:39', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(78, 1, '2026-01-28 08:18:20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(79, 5, '2026-01-28 08:19:15', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(80, 5, '2026-01-28 08:26:29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(81, 1, '2026-01-28 08:26:49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(82, 2, '2026-01-28 08:28:07', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(83, 1, '2026-01-28 08:28:57', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(84, 5, '2026-01-28 08:40:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(85, 1, '2026-01-28 08:40:41', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(86, 5, '2026-01-28 08:54:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(87, 1, '2026-01-28 08:55:55', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(88, 5, '2026-01-28 08:57:49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(89, 1, '2026-01-29 02:12:53', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(90, 2, '2026-01-29 02:15:30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(91, 5, '2026-01-29 02:17:49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(92, 1, '2026-01-29 02:19:35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(93, 5, '2026-01-29 02:23:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(94, 1, '2026-01-29 07:34:05', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(95, 2, '2026-01-29 10:13:26', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(96, 5, '2026-01-29 10:42:33', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(97, 1, '2026-01-29 10:49:29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(98, 2, '2026-01-29 10:57:23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(99, 5, '2026-01-29 11:04:31', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(100, 2, '2026-01-29 11:08:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(101, 5, '2026-01-29 11:12:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(102, 1, '2026-01-29 11:12:54', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(103, 2, '2026-01-29 11:13:33', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(104, 5, '2026-01-29 11:37:50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(105, 2, '2026-01-29 11:39:32', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(106, 1, '2026-01-29 11:48:36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(107, 5, '2026-01-29 11:50:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(108, 1, '2026-01-29 11:52:03', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(109, 5, '2026-01-29 11:53:08', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(110, 5, '2026-01-30 10:05:03', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(111, 1, '2026-01-30 10:12:17', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(112, 5, '2026-01-30 10:24:09', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(113, 2, '2026-01-30 10:57:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(114, 1, '2026-01-30 10:57:51', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(115, 5, '2026-01-30 11:04:22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(116, 1, '2026-01-30 11:05:32', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(117, 2, '2026-01-30 11:08:48', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(118, 1, '2026-01-30 11:10:18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(119, 5, '2026-01-30 11:11:08', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(120, 2, '2026-01-30 11:21:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(121, 5, '2026-01-30 11:42:22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(122, 1, '2026-01-30 11:47:26', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(123, 5, '2026-01-30 11:52:18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(124, 1, '2026-01-30 11:53:05', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(125, 5, '2026-01-30 12:02:51', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(126, 1, '2026-01-30 12:04:11', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(127, 2, '2026-01-30 12:16:45', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(128, 5, '2026-01-30 12:29:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(129, 2, '2026-01-30 12:30:47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(130, 5, '2026-01-30 12:33:12', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(131, 2, '2026-01-30 12:41:19', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(132, 1, '2026-01-30 13:29:56', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(133, 5, '2026-01-30 13:31:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(134, 2, '2026-01-31 05:38:39', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(135, 1, '2026-01-31 08:08:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(136, 5, '2026-01-31 08:14:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(137, 1, '2026-01-31 08:28:32', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(138, 5, '2026-02-03 01:33:55', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(139, 2, '2026-02-03 01:37:27', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(140, 1, '2026-02-03 01:39:00', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(141, 1, '2026-02-03 01:43:57', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(142, 5, '2026-02-03 03:27:03', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(143, 2, '2026-02-03 04:21:33', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(144, 1, '2026-02-03 04:25:01', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(145, 1, '2026-02-03 05:29:01', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(146, 1, '2026-02-03 09:00:42', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.2 Mobile/15E148 Safari/604.1', '192.168.1.72'),
(147, 2, '2026-02-03 09:07:27', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.2 Mobile/15E148 Safari/604.1', '192.168.1.72'),
(148, 2, '2026-02-03 09:11:34', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Mobile Safari/537.36', '192.168.1.77'),
(149, 2, '2026-02-05 03:37:44', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(150, 1, '2026-02-05 05:57:50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(151, 1, '2026-02-05 06:13:20', 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_2_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/144.0.7559.95 Mobile/15E148 Safari/604.1', '192.168.1.72'),
(152, 5, '2026-02-05 06:36:48', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(153, 1, '2026-02-05 06:58:11', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(154, 2, '2026-02-05 07:34:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(155, 2, '2026-02-05 07:48:07', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(156, 5, '2026-02-05 08:03:36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(157, 1, '2026-02-05 08:28:00', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(158, 5, '2026-02-05 08:44:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(159, 1, '2026-02-05 08:57:19', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(160, 2, '2026-02-05 09:02:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(161, 5, '2026-02-05 09:02:18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(162, 1, '2026-02-05 09:03:16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(163, 1, '2026-02-05 09:05:36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(164, 2, '2026-02-05 09:05:45', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(165, 5, '2026-02-05 09:05:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(166, 2, '2026-02-05 09:06:16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(167, 5, '2026-02-05 09:08:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(168, 1, '2026-02-05 09:08:46', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(169, 5, '2026-02-05 09:10:19', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(170, 1, '2026-02-05 09:10:44', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(171, 5, '2026-02-05 09:12:09', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(172, 2, '2026-02-05 09:14:11', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(173, 5, '2026-02-05 09:14:37', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(174, 5, '2026-02-05 09:15:53', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(175, 1, '2026-02-05 09:29:29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(176, 1, '2026-02-05 09:58:27', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(177, 1, '2026-02-05 10:17:07', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(178, 5, '2026-02-05 10:17:29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(179, 2, '2026-02-05 10:17:38', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(180, 1, '2026-02-06 04:26:01', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(181, 2, '2026-02-06 04:31:40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(182, 5, '2026-02-06 04:32:44', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(183, 1, '2026-02-06 04:33:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(184, 5, '2026-02-06 04:55:46', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(185, 2, '2026-02-06 06:01:17', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(186, 5, '2026-02-06 06:01:50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(187, 1, '2026-02-06 06:02:32', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(188, 5, '2026-02-06 06:03:30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(189, 2, '2026-02-06 06:04:20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(190, 1, '2026-02-06 06:37:11', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(191, 5, '2026-02-06 06:37:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(192, 2, '2026-02-06 06:39:24', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(193, 5, '2026-02-06 07:06:59', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(194, 1, '2026-02-06 07:15:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(195, 2, '2026-02-06 13:19:35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(196, 1, '2026-02-08 03:47:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(197, 2, '2026-02-08 04:06:10', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(198, 5, '2026-02-08 04:09:26', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '::1'),
(199, 1, '2026-02-22 02:39:42', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '::1'),
(200, 2, '2026-02-22 03:14:37', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '::1'),
(201, 1, '2026-02-22 03:18:27', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '::1'),
(202, 1, '2026-02-22 04:51:47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(203, 2, '2026-02-22 05:40:15', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(204, 2, '2026-02-22 06:05:27', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '::1'),
(205, 1, '2026-02-22 06:05:55', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '::1'),
(206, 2, '2026-02-22 06:09:33', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '::1'),
(207, 1, '2026-02-22 06:25:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(208, 2, '2026-02-22 06:25:34', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(209, 1, '2026-02-22 06:26:35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(210, 2, '2026-02-22 06:26:59', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(211, 1, '2026-02-22 06:50:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(212, 5, '2026-02-22 07:04:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(213, 5, '2026-02-22 07:33:31', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '::1'),
(214, 1, '2026-02-22 08:19:01', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(215, 1, '2026-02-22 08:32:36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '::1'),
(216, 2, '2026-02-22 09:01:15', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(217, 1, '2026-02-22 09:03:05', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(218, 2, '2026-02-22 09:05:39', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(219, 1, '2026-02-22 09:06:11', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(220, 1, '2026-02-22 09:08:16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(221, 1, '2026-02-22 09:25:24', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(222, 5, '2026-02-22 09:45:37', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(223, 1, '2026-02-22 10:16:22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(224, 2, '2026-02-22 10:16:59', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(225, 1, '2026-02-22 10:17:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(226, 5, '2026-02-22 10:19:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(227, 1, '2026-02-22 10:39:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(228, 5, '2026-02-22 10:40:08', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(229, 5, '2026-02-22 11:49:16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(230, 1, '2026-02-22 11:51:11', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(231, 1, '2026-02-22 12:38:41', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(232, 5, '2026-02-22 13:15:57', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(233, 2, '2026-02-22 13:18:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(234, 1, '2026-02-23 01:58:40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(235, 5, '2026-02-23 02:02:56', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(236, 1, '2026-02-23 02:06:49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(237, 2, '2026-02-23 02:07:38', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(238, 5, '2026-02-23 02:08:08', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(239, 1, '2026-02-23 02:08:28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(240, 5, '2026-02-23 02:09:22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(241, 1, '2026-02-23 02:09:31', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(242, 1, '2026-02-23 02:17:51', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(243, 2, '2026-02-23 02:20:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(244, 1, '2026-02-23 02:24:49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(245, 2, '2026-02-23 02:26:19', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(246, 5, '2026-02-23 02:31:14', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(247, 1, '2026-02-23 02:31:41', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(248, 1, '2026-02-23 02:52:10', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '::1'),
(249, 2, '2026-02-23 03:14:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(250, 1, '2026-02-23 03:20:48', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(251, 2, '2026-02-23 03:21:28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(252, 5, '2026-02-23 03:21:40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(253, 1, '2026-02-23 03:22:27', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(254, 5, '2026-02-23 03:29:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(255, 1, '2026-02-23 03:44:30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(256, 1, '2026-02-23 04:02:15', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(257, 5, '2026-02-23 04:02:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(258, 5, '2026-02-23 04:11:36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(259, 2, '2026-02-23 04:11:45', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(260, 1, '2026-02-23 04:15:44', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(261, 2, '2026-02-23 04:16:47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(262, 1, '2026-02-23 04:20:58', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(263, 5, '2026-02-23 04:22:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(264, 1, '2026-02-23 04:24:02', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(265, 5, '2026-02-23 04:26:00', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(266, 2, '2026-02-23 04:28:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(267, 5, '2026-02-23 04:29:45', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(268, 1, '2026-02-23 04:30:38', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(269, 1, '2026-02-23 07:14:58', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(270, 1, '2026-02-23 14:25:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(271, 5, '2026-02-23 14:38:58', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(272, 1, '2026-02-23 17:05:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(273, 1, '2026-02-24 02:52:20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(274, 5, '2026-02-24 02:56:27', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(275, 2, '2026-02-24 02:58:13', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(276, 1, '2026-02-24 07:23:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '::1'),
(277, 5, '2026-02-24 08:01:30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '::1'),
(278, 5, '2026-02-24 08:06:38', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '::1'),
(279, 1, '2026-02-24 09:36:35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(280, 2, '2026-02-24 09:43:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(281, 5, '2026-02-24 09:46:12', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(282, 1, '2026-02-25 05:43:07', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(283, 2, '2026-02-25 05:48:18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(284, 5, '2026-02-25 05:50:20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(285, 1, '2026-02-25 08:53:37', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(286, 1, '2026-02-25 11:26:20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(287, 1, '2026-02-25 12:56:13', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(288, 5, '2026-02-25 14:37:08', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(289, 2, '2026-02-25 14:56:38', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(290, 1, '2026-02-25 15:17:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(291, 2, '2026-02-25 15:58:50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(292, 1, '2026-02-25 15:59:47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(293, 5, '2026-02-25 16:00:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(294, 1, '2026-02-25 16:16:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(295, 2, '2026-02-25 16:32:42', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(296, 5, '2026-02-25 16:40:51', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(297, 1, '2026-02-25 16:48:29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(298, 5, '2026-02-25 16:51:32', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(299, 5, '2026-02-26 03:44:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(300, 1, '2026-02-26 14:16:01', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(301, 5, '2026-02-26 14:34:55', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(302, 1, '2026-02-27 02:38:12', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(303, 2, '2026-02-27 02:45:07', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(304, 5, '2026-02-27 02:48:13', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(305, 5, '2026-02-27 03:12:23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(306, 1, '2026-02-27 05:27:33', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(307, 2, '2026-02-27 05:41:27', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(308, 5, '2026-02-27 05:45:36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(309, 1, '2026-02-27 06:49:54', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(310, 1, '2026-02-27 07:35:29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(311, 2, '2026-02-27 07:36:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(312, 5, '2026-02-27 07:48:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(313, 2, '2026-02-27 07:53:58', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '::1'),
(314, 1, '2026-02-27 08:10:15', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(315, 2, '2026-02-27 08:14:46', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(316, 1, '2026-02-27 10:13:32', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(317, 2, '2026-02-27 11:30:39', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(318, 1, '2026-02-27 11:42:05', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(319, 2, '2026-02-27 11:44:36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(320, 5, '2026-02-27 11:53:02', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(321, 2, '2026-02-27 11:54:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(322, 2, '2026-02-27 11:59:33', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(323, 1, '2026-02-27 12:15:40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(324, 2, '2026-02-27 12:16:40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(325, 5, '2026-02-27 12:18:55', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(326, 1, '2026-02-27 14:35:03', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1');
INSERT INTO `login_logs` (`log_id`, `user_id`, `login_time`, `device_info`, `ip_address`) VALUES
(327, 2, '2026-02-27 14:36:54', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(328, 5, '2026-02-27 14:38:11', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(329, 2, '2026-03-03 07:38:10', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(330, 2, '2026-03-03 08:03:51', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(331, 2, '2026-03-03 08:15:46', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G955U Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36', '::1'),
(332, 2, '2026-03-03 08:21:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(333, 2, '2026-03-03 10:10:57', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(334, 2, '2026-03-03 10:14:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(335, 2, '2026-03-03 10:15:57', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(336, 2, '2026-03-03 10:17:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(337, 2, '2026-03-03 10:21:31', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(338, 1, '2026-03-03 10:52:41', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(339, 2, '2026-03-04 03:42:30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(340, 2, '2026-03-04 05:32:32', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(341, 1, '2026-03-04 05:33:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(342, 2, '2026-03-04 07:28:23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(343, 1, '2026-03-04 07:29:09', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(344, 2, '2026-03-04 07:29:45', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(345, 1, '2026-03-04 07:30:18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(346, 2, '2026-03-04 07:34:37', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(347, 1, '2026-03-04 07:35:12', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(348, 5, '2026-03-04 07:38:33', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(349, 1, '2026-03-06 07:08:37', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(350, 1, '2026-03-09 04:46:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(351, 2, '2026-03-10 11:37:10', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(352, 1, '2026-03-14 05:55:00', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(353, 2, '2026-03-16 23:59:54', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(354, 2, '2026-03-17 00:36:20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1'),
(355, 1, '2026-03-18 13:02:03', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(356, 2, '2026-03-18 13:49:41', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(357, 1, '2026-03-18 14:01:24', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(358, 1, '2026-03-19 03:41:18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(359, 1, '2026-03-19 05:14:54', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '127.0.0.1'),
(360, 1, '2026-03-20 11:27:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(361, 1, '2026-03-20 11:49:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(362, 5, '2026-03-20 12:55:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(363, 1, '2026-03-20 12:57:40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(364, 2, '2026-03-20 12:58:48', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(365, 1, '2026-03-20 13:35:05', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(366, 2, '2026-03-20 14:01:27', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(367, 5, '2026-03-20 14:39:16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(368, 5, '2026-03-20 14:42:00', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(369, 1, '2026-03-20 14:44:44', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(370, 1, '2026-03-22 08:22:17', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(371, 5, '2026-03-22 08:29:20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(372, 2, '2026-03-22 08:30:13', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(373, 1, '2026-03-22 08:32:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(374, 2, '2026-03-22 08:36:24', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(375, 5, '2026-03-22 08:43:40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(376, 2, '2026-03-22 08:58:05', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(377, 5, '2026-03-22 09:00:55', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(378, 1, '2026-03-22 09:03:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(379, 2, '2026-03-22 09:11:56', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(380, 1, '2026-03-22 09:21:01', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(381, 1, '2026-03-22 09:21:41', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(382, 1, '2026-03-22 11:33:51', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(383, 2, '2026-03-23 02:32:09', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(384, 1, '2026-03-23 02:40:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(385, 5, '2026-03-23 03:48:10', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(386, 1, '2026-03-23 03:59:08', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(387, 5, '2026-03-23 04:03:45', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(388, 1, '2026-03-23 04:19:12', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(389, 5, '2026-03-23 04:47:36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(390, 5, '2026-03-23 05:30:48', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(391, 1, '2026-03-23 05:32:13', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(392, 1, '2026-03-23 11:47:32', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(393, 2, '2026-03-23 12:44:19', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(394, 1, '2026-03-24 03:09:41', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(395, 2, '2026-03-24 04:31:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(396, 5, '2026-03-24 04:35:40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(397, 1, '2026-03-24 04:37:57', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(398, 5, '2026-03-24 04:40:28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(399, 2, '2026-03-24 04:43:23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(400, 1, '2026-03-24 09:03:20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(401, 1, '2026-03-25 01:38:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(402, 2, '2026-03-25 02:39:58', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(403, 1, '2026-03-25 03:29:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(404, 5, '2026-03-25 03:40:37', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(405, 1, '2026-03-25 03:43:42', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(406, 5, '2026-03-25 03:45:48', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(407, 2, '2026-03-25 03:50:30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(408, 1, '2026-03-25 14:41:05', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(409, 1, '2026-03-26 03:43:31', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(410, 1, '2026-03-28 03:49:54', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(411, 2, '2026-03-28 04:41:47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(412, 5, '2026-03-28 05:17:16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(413, 1, '2026-04-01 07:04:19', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(414, 1, '2026-04-07 00:52:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(415, 2, '2026-04-07 03:59:23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(416, 5, '2026-04-07 04:20:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(417, 1, '2026-04-08 04:08:31', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(418, 2, '2026-04-08 04:26:07', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(419, 5, '2026-04-08 04:29:12', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(420, 5, '2026-04-08 08:32:05', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(421, 1, '2026-04-08 10:24:55', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(422, 2, '2026-04-08 10:26:46', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(423, 1, '2026-04-08 10:47:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(424, 2, '2026-04-08 11:11:10', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(425, 5, '2026-04-08 11:30:49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(426, 1, '2026-04-08 11:48:30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(427, 1, '2026-04-08 11:48:53', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(428, 1, '2026-04-08 11:49:30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(429, 2, '2026-04-08 12:10:32', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(430, 2, '2026-04-08 12:15:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(431, 5, '2026-04-08 12:15:57', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(432, 5, '2026-04-08 12:21:51', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(433, 1, '2026-04-08 12:50:01', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(434, 1, '2026-04-08 12:53:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(435, 2, '2026-04-08 12:54:05', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(436, 5, '2026-04-08 12:57:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(437, 5, '2026-04-08 12:57:39', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1'),
(438, 5, '2026-04-17 12:02:49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '::1'),
(439, 1, '2026-04-21 10:34:42', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '::1'),
(440, 1, '2026-04-21 10:38:55', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '::1'),
(441, 1, '2026-04-21 10:48:27', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '::1'),
(442, 1, '2026-04-21 11:17:58', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '::1'),
(443, 2, '2026-04-21 11:19:38', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '::1'),
(444, 5, '2026-04-21 11:21:02', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '::1'),
(445, 1, '2026-04-21 11:24:16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '::1'),
(446, 1, '2026-04-21 11:35:13', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '::1'),
(447, 1, '2026-04-21 11:35:34', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '::1'),
(448, 1, '2026-04-26 11:20:17', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(449, 2, '2026-04-26 13:17:28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(450, 5, '2026-04-26 13:18:36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(451, 5, '2026-04-26 13:19:45', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(452, 5, '2026-04-26 13:20:07', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(453, 2, '2026-04-26 13:20:40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(454, 2, '2026-04-26 13:20:57', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(455, 1, '2026-04-27 01:26:01', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(456, 2, '2026-04-27 01:27:49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(457, 1, '2026-04-27 10:42:07', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(458, 1, '2026-05-04 02:25:59', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(459, 2, '2026-05-04 02:49:30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(460, 5, '2026-05-04 03:01:24', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(461, 2, '2026-05-04 03:14:28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(462, 1, '2026-05-11 04:25:56', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(463, 5, '2026-05-11 04:29:11', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0', '::1'),
(464, 2, '2026-05-11 04:33:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0', '::1'),
(465, 1, '2026-05-24 08:03:37', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(466, 2, '2026-05-24 08:32:45', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(467, 5, '2026-05-24 09:01:56', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(468, 1, '2026-06-01 12:28:26', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 AVG/147.0.0.0', '::1'),
(469, 2, '2026-06-01 12:33:20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 AVG/147.0.0.0', '::1'),
(470, 5, '2026-06-01 12:35:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 AVG/147.0.0.0', '::1'),
(471, 1, '2026-06-01 12:37:31', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 AVG/147.0.0.0', '::1'),
(472, 2, '2026-06-01 13:02:57', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(473, 1, '2026-06-02 02:51:44', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(474, 2, '2026-06-02 03:01:34', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(475, 5, '2026-06-02 03:07:01', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0', '::1'),
(476, 1, '2026-06-02 03:20:42', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(477, 1, '2026-06-09 07:51:38', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(478, 1, '2026-06-09 08:05:44', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '::1'),
(479, 2, '2026-06-09 08:13:16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1'),
(480, 1, '2026-06-10 01:42:56', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1'),
(481, 2, '2026-06-10 01:43:41', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '::1'),
(482, 1, '2026-06-10 01:53:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1'),
(483, 1, '2026-06-10 01:57:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1'),
(484, 5, '2026-06-10 01:59:56', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1'),
(485, 1, '2026-06-10 02:04:15', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '::1'),
(486, 2, '2026-06-10 02:18:24', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '::1'),
(487, 1, '2026-06-10 09:21:31', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1'),
(488, 2, '2026-06-11 00:36:53', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1'),
(489, 5, '2026-06-11 00:43:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1'),
(490, 1, '2026-06-11 00:45:51', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1'),
(492, 1, '2026-06-11 01:30:14', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1'),
(493, 5, '2026-06-11 04:07:57', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1'),
(494, 1, '2026-06-11 04:09:14', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1'),
(495, 1, '2026-06-12 02:25:28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1'),
(496, 5, '2026-06-12 03:12:41', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '::1'),
(497, 1, '2026-07-07 03:07:22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1'),
(498, 1, '2026-07-08 12:14:58', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1'),
(499, 2, '2026-07-08 12:31:53', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '::1'),
(500, 5, '2026-07-08 13:15:08', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '::1'),
(501, 2, '2026-07-08 13:19:20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '::1'),
(502, 5, '2026-07-08 13:34:14', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '::1'),
(503, 1, '2026-07-16 06:03:47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 AVG/148.0.0.0', '::1'),
(504, 5, '2026-07-16 06:07:40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(505, 2, '2026-07-16 06:13:11', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '::1'),
(506, 2, '2026-07-16 06:47:23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '::1'),
(507, 2, '2026-07-16 07:17:31', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '::1'),
(508, 2, '2026-07-16 07:44:29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '::1'),
(509, 2, '2026-07-16 08:38:18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '::1'),
(510, 1, '2026-07-19 12:47:54', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(511, 5, '2026-07-19 13:06:26', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 AVG/148.0.0.0', '::1'),
(512, 2, '2026-07-19 13:14:53', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 AVG/148.0.0.0', '::1'),
(513, 2, '2026-07-19 14:31:41', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 AVG/148.0.0.0', '::1'),
(514, 2, '2026-07-19 15:40:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 AVG/148.0.0.0', '::1'),
(515, 2, '2026-07-21 04:34:07', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(516, 1, '2026-07-21 04:44:16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(517, 5, '2026-07-21 06:59:48', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(518, 1, '2026-07-22 00:59:10', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(519, 5, '2026-07-22 01:04:58', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '::1'),
(520, 2, '2026-07-22 01:23:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '::1'),
(521, 5, '2026-07-22 01:31:14', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '::1'),
(522, 1, '2026-07-23 07:07:39', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(523, 2, '2026-07-23 07:08:59', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(524, 5, '2026-07-23 07:13:19', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '::1'),
(525, 2, '2026-07-23 08:41:16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(526, 1, '2026-07-23 12:26:01', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(527, 5, '2026-07-23 13:20:57', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(528, 2, '2026-07-23 13:36:29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(529, 1, '2026-07-23 13:47:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(530, 5, '2026-07-23 13:48:45', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(531, 1, '2026-07-27 06:48:07', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(532, 5, '2026-07-27 06:48:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(533, 2, '2026-07-27 06:49:35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '::1'),
(534, 2, '2026-07-27 07:46:14', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '::1'),
(535, 2, '2026-07-28 10:36:10', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(536, 2, '2026-07-28 10:53:02', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(537, 1, '2026-07-28 10:53:54', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '::1'),
(538, 1, '2026-07-29 00:46:50', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(539, 5, '2026-07-29 00:48:16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '::1'),
(540, 1, '2026-07-29 08:38:03', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(541, 1, '2026-07-29 08:46:27', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(542, 5, '2026-07-29 08:57:36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(543, 2, '2026-07-29 10:16:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(544, 1, '2026-07-29 10:36:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(545, 1, '2026-07-29 11:01:32', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(546, 5, '2026-07-29 11:27:07', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(547, 2, '2026-07-29 11:43:09', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(548, 1, '2026-07-31 01:53:46', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(549, 5, '2026-07-31 02:06:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(550, 2, '2026-07-31 02:26:23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(551, 2, '2026-07-31 03:15:03', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(552, 5, '2026-07-31 03:34:36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(553, 1, '2026-08-02 06:39:03', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(554, 5, '2026-08-02 06:49:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(555, 2, '2026-08-02 07:52:24', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(556, 1, '2026-08-02 12:56:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(557, 5, '2026-08-02 13:25:15', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(558, 2, '2026-08-02 13:30:01', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(559, 1, '2026-08-02 13:33:09', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(560, 1, '2026-08-03 04:50:57', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(561, 5, '2026-08-03 05:06:51', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(562, 1, '2026-08-03 05:09:27', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(563, 10, '2026-08-03 05:14:17', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(564, 1, '2026-08-03 05:23:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(565, 2, '2026-08-03 05:34:28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(566, 5, '2026-08-03 05:37:11', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(567, 2, '2026-08-03 06:05:20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(568, 1, '2026-08-03 06:13:19', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(569, 2, '2026-08-03 06:35:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 AVG/149.0.0.0', '::1'),
(570, 1, '2026-08-03 06:36:39', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(571, 1, '2026-08-05 02:29:15', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(572, 5, '2026-08-05 02:30:37', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 AVG/150.0.0.0', '::1'),
(573, 2, '2026-08-05 02:31:42', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0', '::1'),
(574, 1, '2026-08-06 01:26:20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '::1'),
(575, 2, '2026-08-06 01:27:38', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0', '::1'),
(576, 1, '2026-08-10 05:17:54', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(577, 5, '2026-08-10 05:18:44', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 AVG/150.0.0.0', '::1'),
(578, 2, '2026-08-10 05:19:59', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0', '::1'),
(579, 2, '2026-08-10 06:00:28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0', '::1'),
(580, 2, '2026-08-10 06:36:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0', '::1'),
(581, 1, '2026-08-11 03:33:20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(582, 1, '2026-08-11 03:33:40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(583, 2, '2026-08-11 05:49:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(584, 1, '2026-08-11 06:07:03', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(585, 1, '2026-08-11 07:28:28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(586, 1, '2026-08-12 01:50:38', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(587, 5, '2026-08-12 02:42:28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 AVG/150.0.0.0', '::1'),
(588, 2, '2026-08-12 03:18:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(589, 1, '2026-08-12 03:49:10', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(590, 1, '2026-08-15 07:31:19', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(591, 5, '2026-08-15 07:43:48', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 AVG/150.0.0.0', '::1'),
(592, 1, '2026-08-17 05:45:12', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(593, 5, '2026-08-17 05:46:23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 AVG/150.0.0.0', '::1'),
(594, 2, '2026-08-17 05:47:29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0', '::1'),
(595, 2, '2026-08-17 07:42:08', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(596, 1, '2026-08-17 12:55:54', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(597, 2, '2026-08-17 12:59:17', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0', '::1'),
(598, 5, '2026-08-17 13:22:08', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 AVG/150.0.0.0', '::1'),
(599, 2, '2026-08-17 13:33:12', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0', '::1'),
(600, 2, '2026-08-17 16:44:20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0', '::1'),
(601, 5, '2026-08-18 06:23:59', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(602, 1, '2026-08-18 06:29:56', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(603, 2, '2026-08-18 06:31:23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 AVG/150.0.0.0', '::1'),
(604, 5, '2026-08-18 07:18:40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 AVG/150.0.0.0', '::1'),
(605, 1, '2026-08-20 01:10:03', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(606, 5, '2026-08-20 01:11:16', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0', '::1'),
(607, 2, '2026-08-20 01:12:38', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 AVG/150.0.0.0', '::1'),
(608, 11, '2026-08-20 01:40:58', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 AVG/150.0.0.0', '::1'),
(609, 11, '2026-08-20 01:43:42', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 AVG/150.0.0.0', '::1'),
(610, 2, '2026-08-20 01:48:48', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 AVG/150.0.0.0', '::1'),
(611, 1, '2026-08-20 03:07:39', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(612, 1, '2026-08-20 03:10:23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(613, 5, '2026-08-20 03:24:28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 AVG/150.0.0.0', '::1'),
(614, 2, '2026-08-20 03:50:09', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 AVG/150.0.0.0', '::1'),
(615, 1, '2026-08-20 12:20:33', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(616, 2, '2026-08-20 13:46:14', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(617, 5, '2026-08-20 14:03:18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(618, 2, '2026-08-20 15:49:10', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '::1'),
(619, 1, '2026-08-31 04:15:05', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '::1'),
(620, 2, '2026-08-31 04:16:17', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '::1'),
(621, 5, '2026-08-31 04:17:53', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 AVG/150.0.0.0', '::1'),
(622, 2, '2026-09-01 14:21:27', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '::1'),
(623, 1, '2026-09-01 14:26:45', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '::1'),
(624, 5, '2026-09-01 14:45:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '::1'),
(625, 1, '2026-09-01 14:47:08', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '::1'),
(626, 2, '2026-09-01 15:35:02', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '::1');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `method` enum('cash','gcash','bank') DEFAULT NULL,
  `status` enum('pending','paid','failed') DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `external_ref` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `sale_id`, `amount`, `method`, `status`, `paid_at`, `external_ref`) VALUES
(1, 8, 340.00, 'cash', 'paid', '2026-01-25 11:17:36', NULL),
(2, 9, 550.00, 'cash', 'paid', '2026-01-25 11:39:07', NULL),
(3, 16, 815.00, 'cash', 'paid', '2026-01-26 09:26:59', ''),
(4, 16, 1000.00, 'cash', 'paid', '2026-01-26 10:42:57', ''),
(5, 19, 250.00, 'cash', 'paid', '2026-01-26 11:03:08', ''),
(6, 17, 680.00, 'cash', 'paid', '2026-01-26 11:03:49', ''),
(7, 19, 300.00, 'cash', 'paid', '2026-01-27 03:01:22', ''),
(8, 20, 500.00, 'cash', 'paid', '2026-01-27 03:03:29', ''),
(9, 20, 375.00, 'cash', 'paid', '2026-01-27 03:03:50', ''),
(10, 20, 500.00, 'cash', 'paid', '2026-01-27 03:04:03', ''),
(11, 21, 375.00, 'cash', 'paid', '2026-01-27 06:59:34', ''),
(12, 21, 1000.00, 'cash', 'paid', '2026-01-27 06:59:53', ''),
(13, 26, 680.00, 'cash', 'paid', '2026-01-28 07:45:48', ''),
(14, 22, 1375.00, 'cash', 'paid', '2026-01-28 08:17:30', ''),
(15, 31, 55.00, 'cash', 'paid', '2026-01-28 08:18:01', ''),
(16, 38, 265.00, 'cash', 'paid', '2026-01-29 11:28:10', ''),
(17, 35, 60.00, 'cash', 'paid', '2026-01-29 11:36:17', ''),
(18, 34, 265.00, 'cash', 'paid', '2026-01-29 11:48:04', ''),
(19, 41, 300.00, 'cash', 'paid', '2026-01-30 12:25:41', ''),
(20, 42, 110.00, 'cash', 'paid', '2026-01-30 12:29:12', ''),
(21, 47, 250.00, 'cash', 'paid', '2026-01-30 12:31:01', ''),
(22, 47, 150.00, 'cash', 'paid', '2026-01-30 12:31:41', ''),
(23, 47, 150.00, 'cash', 'paid', '2026-01-30 12:32:29', ''),
(24, 50, 720.00, 'cash', 'paid', '2026-01-30 13:29:08', ''),
(25, 53, 75.00, 'cash', 'paid', '2026-01-31 05:43:47', ''),
(26, 55, 550.00, 'cash', 'paid', '2026-02-03 04:24:18', ''),
(27, 57, 470.00, 'cash', 'paid', '2026-02-03 09:09:50', ''),
(28, 60, 800.00, 'cash', 'paid', '2026-02-05 09:07:28', ''),
(29, 65, 100.00, 'cash', 'paid', '2026-02-06 06:18:32', ''),
(30, 65, 450.00, 'cash', 'paid', '2026-02-06 06:19:05', ''),
(31, 61, 100.00, 'cash', 'paid', '2026-02-06 06:35:25', ''),
(32, 61, 200.00, 'cash', 'paid', '2026-02-06 06:35:57', ''),
(33, 70, 200.00, 'cash', 'paid', '2026-02-22 06:27:08', ''),
(34, 70, 42.00, 'cash', 'paid', '2026-02-22 06:30:12', ''),
(35, 76, 2000.00, 'cash', 'paid', '2026-02-23 04:19:14', ''),
(36, 76, 550.00, 'cash', 'paid', '2026-02-23 04:19:24', ''),
(37, 80, 245.00, 'cash', 'paid', '2026-02-25 15:59:25', ''),
(38, 83, 600.00, 'cash', 'paid', '2026-02-27 07:45:07', ''),
(39, 86, 500.00, 'gcash', 'paid', '2026-02-27 08:04:37', '7865534'),
(40, 86, 1460.00, 'cash', 'paid', '2026-02-27 08:05:37', ''),
(41, 88, 4640.00, 'cash', 'paid', '2026-02-27 11:48:04', ''),
(42, 90, 2350.00, 'cash', 'paid', '2026-03-04 07:30:06', ''),
(43, 103, 2000.00, 'cash', 'paid', '2026-03-28 04:44:32', ''),
(44, 104, 2100.00, 'cash', 'paid', '2026-03-28 04:53:07', ''),
(45, 105, 2015.00, 'cash', 'paid', '2026-03-28 04:56:09', ''),
(46, 106, 450.00, 'cash', 'paid', '2026-03-28 05:00:10', ''),
(47, 107, 2500.00, 'cash', 'paid', '2026-03-28 05:08:17', ''),
(48, 101, 2300.00, 'cash', 'paid', '2026-03-28 05:10:20', ''),
(49, 100, 506.00, 'cash', 'paid', '2026-03-28 05:11:43', ''),
(50, 99, 63.25, 'cash', 'paid', '2026-03-28 05:12:45', ''),
(51, 109, 46.00, 'cash', 'paid', '2026-04-27 01:30:25', '---'),
(52, 110, 3080.00, 'cash', 'paid', '2026-05-04 02:53:05', ''),
(53, 111, 90.00, 'cash', 'paid', '2026-05-04 02:56:20', ''),
(54, 113, 2500.00, 'cash', 'paid', '2026-05-11 04:34:46', ''),
(55, 114, 3150.00, 'cash', 'paid', '2026-05-24 08:41:24', ''),
(56, 115, 1525.00, 'cash', 'paid', '2026-05-24 08:53:19', ''),
(57, 115, 1525.00, 'cash', 'paid', '2026-05-24 08:53:33', ''),
(58, 116, 3150.00, 'cash', 'paid', '2026-05-24 08:54:36', ''),
(59, 117, 2400.00, 'cash', 'paid', '2026-06-01 13:45:26', ''),
(60, 118, 3050.00, 'cash', 'paid', '2026-06-01 13:46:47', ''),
(61, 119, 1800.00, 'cash', 'paid', '2026-06-02 03:05:09', ''),
(62, 120, 2464.00, 'cash', 'paid', '2026-06-09 08:20:16', ''),
(63, 121, 14000.00, 'cash', 'paid', '2026-06-10 02:22:16', ''),
(64, 122, 918.75, 'cash', 'paid', '2026-06-10 02:26:06', ''),
(65, 123, 2300.00, 'cash', 'paid', '2026-07-08 13:19:50', ''),
(66, 124, 1000.00, 'cash', 'paid', '2026-07-16 06:16:49', ''),
(67, 125, 2900.00, 'cash', 'paid', '2026-07-16 08:45:21', ''),
(68, 126, 4000.00, 'cash', 'paid', '2026-07-16 08:52:00', ''),
(69, 127, 506.00, 'cash', 'paid', '2026-07-19 15:11:05', ''),
(70, 128, 2926.00, 'cash', 'paid', '2026-07-19 15:31:20', ''),
(71, 129, 632.50, 'cash', 'paid', '2026-07-19 15:37:14', ''),
(72, 130, 316.25, 'cash', 'paid', '2026-07-21 05:00:37', ''),
(73, 131, 2250.00, 'cash', 'paid', '2026-07-21 05:19:41', ''),
(74, 132, 2250.00, 'cash', 'paid', '2026-07-21 05:41:01', ''),
(75, 133, 2655.00, 'cash', 'paid', '2026-07-21 06:35:47', ''),
(76, 134, 45.00, 'cash', 'paid', '2026-07-21 06:39:41', ''),
(77, 135, 632.50, 'cash', 'paid', '2026-07-22 01:27:05', ''),
(78, 136, 2500.00, 'cash', 'paid', '2026-07-23 07:17:59', ''),
(79, 137, 4655.00, 'cash', 'paid', '2026-07-27 08:04:57', ''),
(80, 138, 2200.00, 'cash', 'paid', '2026-07-27 08:08:43', ''),
(81, 139, 2950.00, 'cash', 'paid', '2026-07-28 10:54:36', ''),
(82, 140, 45.00, 'cash', 'paid', '2026-07-28 10:55:32', ''),
(83, 141, 4824.00, 'cash', 'paid', '2026-07-29 11:44:11', ''),
(84, 142, 2040.00, 'cash', 'paid', '2026-07-31 03:28:46', ''),
(85, 143, 2240.00, 'cash', 'paid', '2026-08-02 13:31:25', ''),
(86, 144, 2250.00, 'cash', 'paid', '2026-08-03 05:14:39', ''),
(87, 145, 10800.00, 'cash', 'paid', '2026-08-03 06:06:02', ''),
(88, 112, 506.72, 'cash', 'paid', '2026-08-03 06:06:13', ''),
(89, 97, 2543.69, 'cash', 'paid', '2026-08-03 06:06:41', ''),
(90, 146, 10800.00, 'cash', 'paid', '2026-08-03 06:08:03', ''),
(91, 147, 4000.00, 'cash', 'paid', '2026-08-03 06:12:09', ''),
(92, 148, 1834.25, 'cash', 'paid', '2026-08-10 06:08:28', ''),
(93, 149, 45.00, 'cash', 'paid', '2026-08-10 06:13:59', ''),
(94, 150, 25000.00, 'cash', 'paid', '2026-08-10 06:37:32', ''),
(95, 151, 20000.00, 'cash', 'paid', '2026-08-10 06:43:58', ''),
(96, 152, 45.00, 'cash', 'paid', '2026-08-17 05:56:43', ''),
(97, 153, 54.00, 'cash', 'paid', '2026-08-17 06:03:32', ''),
(98, 154, 2700.00, 'cash', 'paid', '2026-08-17 06:05:24', ''),
(99, 155, 13500.00, 'cash', 'paid', '2026-08-17 06:07:02', ''),
(100, 156, 2450.00, 'cash', 'paid', '2026-08-17 06:07:23', ''),
(101, 157, 66.00, 'cash', 'paid', '2026-08-17 08:45:38', ''),
(102, 158, 45.00, 'cash', 'paid', '2026-08-17 13:17:30', ''),
(103, 159, 13500.00, 'cash', 'paid', '2026-08-17 17:16:25', ''),
(104, 159, 898.00, 'cash', 'paid', '2026-08-20 03:28:45', ''),
(105, 331, 12480.00, 'cash', 'paid', '2026-09-01 15:37:18', '');

-- --------------------------------------------------------

--
-- Table structure for table `payment_request`
--

CREATE TABLE `payment_request` (
  `pay_req_id` int(11) NOT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `requested_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('sent','paid','expired') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_request`
--

INSERT INTO `payment_request` (`pay_req_id`, `sale_id`, `phone`, `requested_at`, `status`) VALUES
(1, 3, '09859958194', '2026-01-25 09:14:09', 'sent');

-- --------------------------------------------------------

--
-- Table structure for table `penalties`
--

CREATE TABLE `penalties` (
  `penalty_id` int(11) NOT NULL,
  `reference_id` int(11) NOT NULL,
  `reference_type` enum('receivable','payable') NOT NULL DEFAULT 'receivable',
  `penalty_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `amount_paid` decimal(10,2) NOT NULL DEFAULT 0.00,
  `waived_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `days_late` int(11) NOT NULL DEFAULT 0,
  `last_calculated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penalties`
--

INSERT INTO `penalties` (`penalty_id`, `reference_id`, `reference_type`, `penalty_amount`, `days_late`, `last_calculated`, `created_at`) VALUES
(1, 31, 'receivable', 0.00, 0, '2026-04-26 13:09:27', '2026-04-26 13:09:27'),
(2, 30, 'receivable', 0.00, 0, '2026-07-16 08:50:20', '2026-07-16 08:50:20');

-- --------------------------------------------------------

--
-- Table structure for table `penalty_waivers`
--

CREATE TABLE `penalty_waivers` (
  `waiver_id` int(11) NOT NULL,
  `reference_id` int(11) NOT NULL,
  `reference_type` enum('receivable','payable') NOT NULL DEFAULT 'receivable',
  `waived_by` int(11) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `waived_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penalty_waivers`
--

INSERT INTO `penalty_waivers` (`waiver_id`, `reference_id`, `reference_type`, `waived_by`, `reason`, `waived_date`) VALUES
(1, 31, 'receivable', 1, 'unable to pay', '2026-04-26 13:09:27'),
(2, 30, 'receivable', 1, 'SS', '2026-07-16 08:50:20');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `variety` varchar(100) DEFAULT NULL,
  `grade` varchar(20) NOT NULL,
  `unit_weight_kg` decimal(10,2) DEFAULT NULL,
  `price_per_sack` decimal(10,2) NOT NULL,
  `sell_price_per_sack` decimal(10,2) NOT NULL DEFAULT 0.00,
  `price_per_kg` decimal(10,2) NOT NULL,
  `delivery_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `archived` tinyint(1) NOT NULL DEFAULT 0,
  `stock_kg` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `variety`, `grade`, `unit_weight_kg`, `price_per_sack`, `sell_price_per_sack`, `price_per_kg`, `delivery_date`, `created_at`, `archived`, `stock_kg`) VALUES
(1, 'Valencia Rice', 'Regular', 50.00, 2000.00, 2000.00, 40.00, '2026-07-29', '2026-01-24 07:38:02', 0, 1000.00),
(2, 'Valencia Rice (Special)', 'Regular', 50.00, 2000.00, 2000.00, 40.00, '2026-07-29', '2026-01-24 07:38:02', 0, 100.00),
(3, 'HR Jasmine', 'Premium', 50.00, 54.00, 0.00, 0.00, '2026-02-08', '2026-01-24 09:26:13', 1, 0.00),
(4, 'Red Rice', 'Premium', 50.00, 3000.00, 3000.00, 60.00, '2026-07-29', '2026-01-25 11:15:32', 0, 500.00),
(5, 'Valencia Red Rice', 'Regular', 50.00, 2300.00, 2300.00, 46.00, '2026-07-29', '2026-01-25 11:15:32', 0, 800.00),
(6, 'Angelica Rice', 'Premium', 25.00, 1300.00, 1300.00, 52.00, '2026-07-29', '2026-01-25 11:15:32', 0, 900.00),
(7, 'Masipag Valencia', 'Premium', 25.00, 1000.00, 1250.00, 50.00, '2026-07-31', '2026-01-25 11:15:32', 0, 150.00),
(8, 'NFA Rice', 'Broken', 50.00, 2300.00, 2800.00, 56.00, '2026-08-02', '2026-01-25 11:15:32', 0, 300.00),
(9, 'Square Line', 'Regular', 10.00, 600.00, 850.00, 45.00, '2026-02-17', '2026-01-27 07:41:54', 0, 550.00),
(10, 'Mang Bigas', 'Premium', 10.00, 700.00, 700.00, 70.00, '2026-08-18', '2026-01-27 07:47:48', 0, 500.00),
(11, 'Japonika', 'Premium', 10.00, 600.00, 800.00, 63.25, '2026-01-15', '2026-01-28 05:48:37', 0, 110.00),
(12, 'Jasmine Rice (Local)', 'Regular', 50.00, 2299.99, 2799.99, 56.00, '2026-05-04', '2026-01-28 08:37:44', 0, 100.00),
(13, 'Young Chow', 'Regular', 50.00, 2450.00, 2950.00, 59.00, '2026-07-27', '2026-01-28 08:56:35', 0, 0.00),
(14, 'Black Rice', 'Premium', 10.00, 500.00, 550.00, 55.00, '2026-08-17', '2026-01-30 11:02:37', 0, 0.00),
(15, 'Sakura', 'Premium', 15.00, 800.00, 875.00, 58.33, '2026-07-16', '2026-02-22 03:19:47', 0, 135.00),
(16, 'Japonesa', 'Premium', 50.00, 2500.00, 2750.00, 54.00, '2026-03-09', '2026-02-22 03:25:35', 0, 0.00),
(17, 'Molawin', 'Regular', 50.00, 2300.00, 2300.00, 46.00, '2026-07-29', '2026-02-22 12:50:43', 0, -50.00),
(18, 'Sinandomeng', 'Regular', 50.00, 1300.00, 0.00, 56.00, '2026-01-13', '2026-02-27 05:33:15', 1, 0.00),
(19, 'Dinorado', 'Regular', 50.00, 0.00, 0.00, 0.00, '2026-02-10', '2026-02-27 10:33:16', 1, 0.00),
(20, 'Dinorado', 'Regular', 10.00, 0.00, 0.00, 0.00, '2026-03-17', '2026-02-27 10:45:28', 1, 0.00),
(21, 'Dinorado', 'Regular', 50.00, 2710.00, 2981.00, 60.00, '2026-04-26', '2026-02-27 10:57:46', 0, 0.00),
(22, 'Coco Pandan', 'Premium', 50.00, 2300.00, 2500.00, 61.60, '2026-03-11', '2026-02-27 11:14:05', 0, 0.00),
(23, 'Jasponica', 'Regular', 50.00, 2300.00, 2600.00, 46.00, '2026-03-24', '2026-02-27 11:26:12', 0, 0.00),
(24, 'Sophia', 'Premium', 50.00, 2500.00, 0.00, 50.00, '2026-03-23', '2026-03-23 05:34:36', 1, 0.00),
(25, 'Dona Maria', 'Premium', 50.00, 2500.00, 2600.00, 50.00, '2026-03-24', '2026-03-24 03:10:22', 1, 0.00),
(26, 'Agriko', 'Regular', 50.00, 2500.00, 2700.00, 50.00, '2026-04-26', '2026-04-26 12:48:45', 0, 0.00),
(27, 'Jamaica', 'Regular', 50.00, 2300.00, 2300.00, 46.00, '2026-08-02', '2026-06-02 06:22:04', 0, 150.00),
(28, 'Maharlika', 'Premium', 50.00, 2300.00, 2500.00, 50.00, '2026-07-31', '2026-07-22 01:02:11', 0, 0.00),
(29, 'MagRice', 'Premium', 50.00, 2100.00, 2600.00, 52.00, '2026-09-01', '2026-08-02 06:46:44', 0, 0.00),
(30, 'Thai Jasmine', 'Special', 50.00, 2300.00, 2800.00, 56.00, '2026-08-02', '2026-08-02 13:24:36', 1, 0.00),
(31, 'Planters Rice', 'First Class', 50.00, 2300.00, 0.00, 0.00, '2026-08-30', '2026-08-17 16:52:00', 1, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `product_discount_stock`
--

CREATE TABLE `product_discount_stock` (
  `product_id` int(11) NOT NULL,
  `qty_kg` decimal(12,2) NOT NULL DEFAULT 0.00,
  `price_per_kg` decimal(10,2) NOT NULL DEFAULT 0.00,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_discount_stock`
--

INSERT INTO `product_discount_stock` (`product_id`, `qty_kg`, `price_per_kg`, `updated_at`) VALUES
(6, 25.00, 57.00, '2026-07-27 15:50:04'),
(11, 40.00, 50.60, '2026-03-22 18:42:27'),
(15, 15.00, 46.66, '2026-07-29 18:39:40'),
(25, 149.00, 30.00, '2026-03-24 12:32:48');

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `purchases_id` int(11) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `rice_variety` varchar(100) DEFAULT NULL,
  `milling_degree` varchar(50) DEFAULT NULL,
  `grain_quality` varchar(50) DEFAULT NULL,
  `packaging` varchar(50) DEFAULT NULL,
  `quantity_ordered` decimal(10,2) DEFAULT NULL,
  `locked_price` decimal(10,2) DEFAULT NULL,
  `payment_terms` varchar(50) DEFAULT NULL,
  `freight_cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `unloading_cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `actual_received_weight` decimal(10,2) NOT NULL DEFAULT 0.00,
  `weight_variance` decimal(10,2) NOT NULL DEFAULT 0.00,
  `rejected_sacks` int(11) NOT NULL DEFAULT 0,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `request_reason` text DEFAULT NULL,
  `delivery_receipt_no` varchar(100) DEFAULT NULL,
  `invoice_no` varchar(100) DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `received_by` varchar(120) DEFAULT NULL,
  `receiving_notes` text DEFAULT NULL,
  `received_at` datetime DEFAULT NULL,
  `status` enum('ordered','pending','partial','received','cancelled') DEFAULT 'pending',
  `po_approved` tinyint(1) NOT NULL DEFAULT 0,
  `po_approved_by` int(11) DEFAULT NULL,
  `po_approved_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`purchases_id`, `supplier_id`, `purchase_date`, `rice_variety`, `milling_degree`, `grain_quality`, `packaging`, `quantity_ordered`, `locked_price`, `payment_terms`, `freight_cost`, `unloading_cost`, `actual_received_weight`, `weight_variance`, `rejected_sacks`, `total_amount`, `request_reason`, `delivery_receipt_no`, `invoice_no`, `delivery_date`, `received_by`, `receiving_notes`, `received_at`, `status`, `po_approved`, `po_approved_by`, `po_approved_at`, `created_by`, `created_at`) VALUES
(1, 1, '2026-01-28', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-01-28 05:49:42'),
(2, 1, '2026-01-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 4000.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-01-28 06:48:30'),
(3, 1, '2026-01-30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 10000.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-01-28 07:54:07'),
(4, 1, '2026-02-01', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-01-28 08:38:18'),
(5, 1, '2026-02-05', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-01-28 08:47:21'),
(6, 1, '2026-02-05', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 11200.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-01-28 08:53:54'),
(7, 2, '2026-01-30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-01-28 08:57:23'),
(8, 2, '2026-01-31', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-01-29 02:13:55'),
(9, 3, '2026-01-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 3360.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-01-29 02:22:32'),
(10, 3, '2026-01-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 4300.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-01-29 11:52:47'),
(11, 2, '2026-02-28', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-01-30 11:03:12'),
(12, 1, '2026-01-30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-01-30 12:00:12'),
(13, 1, '2026-01-30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-01-30 12:01:01'),
(14, 3, '2026-01-30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-01-30 12:02:22'),
(15, 3, '2026-02-28', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-02-05 09:09:34'),
(16, 3, '2026-02-05', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 400.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-02-05 09:11:51'),
(17, 2, '2026-02-06', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 440.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-02-06 06:03:06'),
(18, 1, '2026-02-23', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 6100.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-02-22 03:21:16'),
(19, 2, '2026-02-22', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 20200.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-02-22 03:34:51'),
(20, 1, '2026-02-23', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 11000.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-02-22 04:29:41'),
(21, 2, '2026-02-22', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 20100.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-02-22 12:51:15'),
(22, 3, '2026-02-24', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 10150.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-02-23 04:24:54'),
(23, 3, '2026-02-25', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 24100.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-02-25 14:15:51'),
(24, 1, '2026-02-28', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 27000.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-02-27 05:37:05'),
(25, 1, '2026-02-28', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 5500.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-02-27 07:30:49'),
(26, 3, '2026-02-28', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 48200.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-02-27 10:59:04'),
(27, 3, '2026-02-28', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 46200.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-02-27 11:16:54'),
(28, 1, '2026-03-23', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 50000.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-03-23 05:35:32'),
(29, 1, '2026-03-24', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 25000.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-03-24 04:01:55'),
(30, 2, '2026-03-24', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 23000.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-03-24 04:39:02'),
(31, 1, '2026-03-25', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 10000.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-03-25 03:35:04'),
(32, 1, '2026-03-25', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 23000.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-03-25 03:39:07'),
(33, 2, '2026-03-25', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 5000.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-03-25 03:45:17'),
(34, 1, '2026-04-26', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 75000.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-04-26 12:51:24'),
(35, 2, '2026-05-04', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 22999.90, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-05-04 02:46:34'),
(36, 2, '2026-05-04', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 8000.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-05-04 02:47:30'),
(37, 3, '2026-05-11', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 25000.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, 5, '2026-05-11 12:30:35', 1, '2026-05-11 04:27:43'),
(38, 3, '2026-05-24', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 50000.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 1, 5, '2026-07-31 10:16:28', 1, '2026-05-24 08:11:30'),
(39, 3, '2026-06-02', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 39000.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ordered', 1, NULL, NULL, 1, '2026-06-02 02:58:59'),
(40, 3, '2026-06-02', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 12000.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 1, 5, '2026-07-31 10:16:27', 1, '2026-06-02 04:26:55'),
(41, 1, '2026-06-02', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 15000.00, 'low stock for jamaica rice', NULL, NULL, NULL, NULL, NULL, NULL, 'ordered', 1, 5, '2026-06-02 12:43:24', 1, '2026-06-02 04:42:26'),
(42, 4, '2026-07-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 4600.00, 'low stocks for molawin rice', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-29 19:40:59', 'received', 1, 5, '2026-06-02 13:18:40', 1, '2026-06-02 05:02:48'),
(43, 1, '2026-06-02', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 5600.00, 'low stocks for each', NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, 5, '2026-06-02 13:30:13', 1, '2026-06-02 05:29:55'),
(44, 3, '2026-06-02', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 1600.00, 'low stocks for sakura rice', NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, 5, '2026-06-02 13:33:39', 1, '2026-06-02 05:33:25'),
(45, 4, '2026-06-02', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 1600.00, 'low stock', NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, 5, '2026-06-02 13:38:21', 1, '2026-06-02 05:38:15'),
(46, 3, '2026-06-02', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 1600.00, 'low', NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, 5, '2026-06-02 13:44:01', 1, '2026-06-02 05:43:53'),
(47, 3, '2026-06-02', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 2400.00, 'low', NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, 5, '2026-06-02 14:07:18', 1, '2026-06-02 06:07:01'),
(48, 2, '2026-08-02', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 11500.00, 'order stock', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-08-02 14:47:18', 'received', 1, 5, '2026-07-31 10:16:25', 1, '2026-06-02 06:22:29'),
(49, 2, '2026-06-02', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 6900.00, 'order stocks for jamaica rice', NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, 5, '2026-06-02 14:31:21', 1, '2026-06-02 06:30:34'),
(50, 1, '2026-06-02', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 6900.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-06-02 06:35:36'),
(51, 3, '2026-06-02', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 2400.00, 'low stock reorder', NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, 5, '2026-06-02 14:41:43', 1, '2026-06-02 06:41:28'),
(52, 3, '2026-06-02', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 2400.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-06-02 06:42:35'),
(53, 3, '2026-07-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 10000.00, 'low stock', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-29 19:40:45', 'received', 1, 5, '2026-06-10 10:09:55', 1, '2026-06-10 02:09:27'),
(54, 4, '2026-06-10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 11500.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, NULL, NULL, 1, '2026-06-10 02:16:42'),
(55, 3, '2026-07-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 11500.00, 'low stocks', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-29 19:40:33', 'received', 1, 5, '2026-06-11 12:08:13', 1, '2026-06-11 04:04:14'),
(56, 3, '2026-07-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 10000.00, 'lowa stock', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-29 19:40:22', 'received', 1, 5, '2026-06-12 11:12:56', 1, '2026-06-12 03:12:00'),
(57, 3, '2026-07-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 2300.00, 'LOW', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-29 19:40:17', 'received', 1, 5, '2026-06-12 11:42:07', 1, '2026-06-12 03:41:54'),
(58, 3, '2026-07-08', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 4600.00, 'repurchase for adding stocks', NULL, NULL, NULL, NULL, NULL, NULL, 'received', 1, 5, '2026-07-08 21:17:13', 1, '2026-07-08 13:13:48'),
(59, 3, '2026-07-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 9000.00, 'purchase for restock', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-29 19:40:03', 'received', 1, 5, '2026-07-08 21:34:31', 1, '2026-07-08 13:32:19'),
(60, 4, '2026-07-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 12500.00, 'RESTOCK', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-29 19:39:59', 'received', 1, 5, '2026-07-16 14:08:33', 1, '2026-07-16 06:06:28'),
(61, 2, '2026-07-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 2300.00, 'LOW STOCK', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-29 19:39:55', 'received', 1, 5, '2026-07-16 14:22:31', 1, '2026-07-16 06:21:19'),
(62, 2, '2026-07-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 4600.00, 'LOW STOCK TO RESTOCK', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-29 19:39:51', 'received', 1, 5, '2026-07-16 14:29:08', 1, '2026-07-16 06:28:28'),
(63, 1, '2026-07-16', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 800.00, 'restock', NULL, NULL, NULL, 'admin', 'Stock received', '2026-07-16 15:39:25', 'received', 1, 5, '2026-07-16 15:39:12', 1, '2026-07-16 07:38:58'),
(64, 3, '2026-07-16', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 8800.00, 'RESTOCK', NULL, NULL, NULL, 'admin', 'Stock received', '2026-07-16 16:10:36', 'received', 1, 5, '2026-07-16 16:05:07', 1, '2026-07-16 08:03:13'),
(65, 1, '2026-07-16', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 10000.00, 'RESTOCK', NULL, NULL, NULL, 'admin', 'Stock received', '2026-07-16 16:13:26', 'received', 1, 5, '2026-07-16 16:05:05', 1, '2026-07-16 08:03:32'),
(66, 3, '2026-07-19', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 2450.00, 'restock for young chow', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-19 21:37:09', 'received', 1, 5, '2026-07-19 21:06:36', 1, '2026-07-19 12:52:13'),
(67, 6, '2026-07-22', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 6900.00, 'new stock for purchase', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-22 09:19:18', 'received', 1, 5, '2026-07-22 09:10:12', 1, '2026-07-22 01:09:30'),
(68, 5, '2026-07-27', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 49000.00, 'FOR RESTOCKING', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-27 15:22:07', 'received', 1, 5, '2026-07-27 15:06:55', 1, '2026-07-27 07:02:15'),
(69, 1, '2026-07-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 69000.00, 'RESTOCK', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-29 19:39:46', 'received', 1, 5, '2026-07-27 15:33:28', 1, '2026-07-27 07:33:01'),
(70, 5, '2026-07-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 4600.00, 'for restocking', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-29 19:39:28', 'received', 1, 5, '2026-07-29 08:49:13', 1, '2026-07-29 00:49:04'),
(71, 4, '2026-07-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 4600.00, 'restocking', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-29 19:39:24', 'received', 1, 5, '2026-07-29 12:28:49', 1, '2026-07-29 04:28:38'),
(72, 4, '2026-07-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 11500.00, 'for restocking', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-29 19:39:20', 'received', 1, 5, '2026-07-29 18:07:42', 1, '2026-07-29 10:07:26'),
(73, 5, '2026-07-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 4600.00, 'RESTOCK', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-29 19:39:15', 'received', 1, 5, '2026-07-29 19:31:36', 1, '2026-07-29 11:31:27'),
(74, 4, '2026-07-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 2600.00, 'restock', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-29 19:39:06', 'received', 1, 5, '2026-07-29 19:38:19', 1, '2026-07-29 11:37:23'),
(75, 5, '2026-07-31', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 4300.00, 'REPURCHASE FOR RESTOCKING', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-07-31 10:18:33', 'received', 1, 5, '2026-07-31 10:16:08', 1, '2026-07-31 02:15:34'),
(76, 3, '2026-07-31', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 1000.00, 'for restocking', NULL, NULL, NULL, 'admin', 'delivered by supplier', '2026-07-31 10:24:55', 'received', 1, 5, '2026-07-31 10:23:47', 1, '2026-07-31 02:23:40'),
(77, 5, '2026-08-02', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 11000.00, 'add stocks for new product', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-08-02 14:51:58', 'received', 1, 5, '2026-08-02 14:50:47', 1, '2026-08-02 06:48:08'),
(78, 3, '2026-08-02', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 23000.00, 'new stock for purchase', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-08-02 21:26:36', 'received', 1, 5, '2026-08-02 21:26:09', 1, '2026-08-02 13:25:46'),
(79, 1, '2026-08-02', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 2300.00, 'restock', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-08-02 21:27:46', 'received', 1, 5, '2026-08-02 21:27:32', 1, '2026-08-02 13:27:21'),
(80, 5, '2026-08-03', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 11000.00, 'restock', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-08-03 14:04:05', 'received', 1, 5, '2026-08-03 14:03:31', 1, '2026-08-03 06:03:15'),
(81, 4, '2026-08-10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 2200.00, 'RESTOCK', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-08-10 14:04:21', 'received', 1, 5, '2026-08-10 14:03:51', 1, '2026-08-10 06:03:32'),
(82, 4, '2026-08-12', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 2500.00, 'restock', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-08-12 10:48:17', 'received', 1, 5, '2026-08-12 10:47:31', 1, '2026-08-12 02:41:44'),
(83, 4, '2026-08-17', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 2500.00, 'REPURCHASE', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-08-18 00:46:20', 'received', 1, 5, '2026-08-18 00:45:17', 1, '2026-08-17 16:45:02'),
(84, 7, '2026-08-17', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 2500.00, 'repurchse', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-08-18 01:21:36', 'received', 1, 5, '2026-08-18 01:20:20', 1, '2026-08-17 17:20:08'),
(85, 4, '2026-08-18', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 3500.00, 'RESTOCK', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-08-18 15:23:48', 'received', 1, 5, '2026-08-18 15:22:30', 1, '2026-08-18 07:22:21'),
(86, 5, '2026-08-19', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 11500.00, 'RESTOCK', NULL, NULL, NULL, NULL, NULL, NULL, '', 1, 5, '2026-09-01 23:32:07', 1, '2026-08-20 03:12:07'),
(87, 6, '2026-08-20', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 10500.00, 'RESTOCK', NULL, NULL, NULL, NULL, NULL, NULL, '', 1, 5, '2026-08-20 11:25:36', 1, '2026-08-20 03:13:46'),
(88, 7, '2026-09-01', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00, 0.00, 0, 21000.00, 'REPURCHASE', NULL, NULL, NULL, 'admin', 'Stock in recorded', '2026-09-01 23:32:35', 'received', 1, 5, '2026-09-01 23:32:09', 1, '2026-09-01 15:31:56');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_items`
--

CREATE TABLE `purchase_items` (
  `purchase_item_id` int(11) NOT NULL,
  `purchases_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity_sacks` int(11) NOT NULL,
  `estimated_price` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `supplier_price` decimal(10,2) DEFAULT 0.00,
  `line_total` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase_items`
--

INSERT INTO `purchase_items` (`purchase_item_id`, `purchases_id`, `product_id`, `quantity_sacks`, `estimated_price`, `created_at`, `supplier_price`, `line_total`) VALUES
(1, 42, 17, 2, 2300.00, '2026-06-02 05:02:48', 2300.00, 4600.00),
(2, 43, 7, 1, 0.00, '2026-06-02 05:29:55', 0.00, 0.00),
(3, 43, 8, 2, 0.00, '2026-06-02 05:29:55', 0.00, 0.00),
(4, 44, 15, 2, 0.00, '2026-06-02 05:33:26', 0.00, 0.00),
(5, 45, 15, 2, 0.00, '2026-06-02 05:38:15', 0.00, 0.00),
(6, 46, 15, 2, 0.00, '2026-06-02 05:43:53', 0.00, 0.00),
(7, 47, 15, 3, 0.00, '2026-06-02 06:07:01', 0.00, 0.00),
(8, 48, 27, 5, 2300.00, '2026-06-02 06:22:29', 2300.00, 11500.00),
(9, 49, 27, 3, 2300.00, '2026-06-02 06:30:34', 0.00, 0.00),
(10, 51, 15, 3, 800.00, '2026-06-02 06:41:28', 0.00, 0.00),
(11, 53, 1, 5, 2000.00, '2026-06-10 02:09:27', 2000.00, 10000.00),
(12, 55, 5, 5, 2300.00, '2026-06-11 04:04:14', 2300.00, 11500.00),
(13, 56, 2, 5, 2000.00, '2026-06-12 03:12:00', 2000.00, 10000.00),
(14, 57, 2, 1, 2300.00, '2026-06-12 03:41:54', 2300.00, 2300.00),
(15, 58, 5, 2, 2300.00, '2026-07-08 13:13:48', 2300.00, 4600.00),
(16, 59, 4, 3, 3000.00, '2026-07-08 13:32:19', 3000.00, 9000.00),
(17, 60, 5, 5, 2500.00, '2026-07-16 06:06:28', 2500.00, 12500.00),
(18, 61, 27, 1, 2300.00, '2026-07-16 06:21:19', 2300.00, 2300.00),
(19, 62, 27, 2, 2300.00, '2026-07-16 06:28:28', 2300.00, 4600.00),
(20, 63, 15, 1, 800.00, '2026-07-16 07:38:58', 800.00, 800.00),
(21, 64, 15, 11, 800.00, '2026-07-16 08:03:13', 800.00, 8800.00),
(22, 65, 7, 10, 1000.00, '2026-07-16 08:03:32', 1000.00, 10000.00),
(23, 66, 13, 1, 2450.00, '2026-07-19 12:52:13', 2450.00, 2450.00),
(24, 67, 28, 3, 2300.00, '2026-07-22 01:09:30', 2300.00, 6900.00),
(25, 68, 13, 20, 2450.00, '2026-07-27 07:02:15', 2450.00, 49000.00),
(26, 69, 28, 30, 2300.00, '2026-07-27 07:33:01', 2300.00, 69000.00),
(27, 70, 28, 2, 2300.00, '2026-07-29 00:49:04', 2300.00, 4600.00),
(28, 71, 27, 2, 2300.00, '2026-07-29 04:28:38', 2300.00, 4600.00),
(29, 72, 28, 5, 2300.00, '2026-07-29 10:07:26', 2300.00, 11500.00),
(30, 73, 28, 2, 2300.00, '2026-07-29 11:31:27', 2300.00, 4600.00),
(31, 74, 6, 2, 1300.00, '2026-07-29 11:37:23', 1300.00, 2600.00),
(32, 75, 7, 2, 1000.00, '2026-07-31 02:15:34', 1000.00, 2000.00),
(33, 75, 28, 1, 2300.00, '2026-07-31 02:18:33', 2300.00, 2300.00),
(34, 76, 14, 2, 500.00, '2026-07-31 02:23:40', 500.00, 1000.00),
(35, 77, 29, 5, 2200.00, '2026-08-02 06:48:08', 2200.00, 11000.00),
(36, 78, 30, 10, 2300.00, '2026-08-02 13:25:46', 2300.00, 23000.00),
(37, 79, 8, 1, 2300.00, '2026-08-02 13:27:21', 2300.00, 2300.00),
(38, 80, 29, 5, 2200.00, '2026-08-03 06:03:15', 2200.00, 11000.00),
(39, 81, 29, 1, 2200.00, '2026-08-10 06:03:32', 2200.00, 2200.00),
(40, 82, 14, 5, 500.00, '2026-08-12 02:41:44', 500.00, 2500.00),
(41, 83, 14, 5, 500.00, '2026-08-17 16:45:02', 500.00, 2500.00),
(42, 84, 14, 5, 500.00, '2026-08-17 17:20:08', 500.00, 2500.00),
(43, 85, 10, 5, 700.00, '2026-08-18 07:22:21', 700.00, 3500.00),
(44, 86, 8, 5, 2300.00, '2026-08-20 03:12:07', 2300.00, 11500.00),
(45, 87, 29, 5, 2100.00, '2026-08-20 03:13:46', 2100.00, 10500.00),
(46, 88, 29, 10, 2100.00, '2026-09-01 15:31:56', 2100.00, 21000.00);

-- --------------------------------------------------------

--
-- Table structure for table `push_notif_logs`
--

CREATE TABLE `push_notif_logs` (
  `push_notif_id` int(11) NOT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('sent','failed') DEFAULT NULL,
  `device_token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `push_notif_logs`
--

INSERT INTO `push_notif_logs` (`push_notif_id`, `payment_id`, `customer_id`, `message`, `sent_at`, `status`, `device_token`) VALUES
(1, NULL, 1, 'Hi! You have an unpaid balance of ₱680.00 for Sale #17. Please settle it by 2026-02-05. Thank you!', '2026-01-26 10:42:27', 'sent', NULL),
(2, NULL, 2, 'Payment received for Sale #16: ₱1,000.00. Thank you!', '2026-01-26 10:42:57', 'sent', NULL),
(3, NULL, 2, 'Hi! You have an unpaid balance of ₱550.00 for Sale #19. Please settle it by 2026-02-12. Thank you!', '2026-01-26 11:02:37', 'sent', NULL),
(4, NULL, 2, 'Payment received for Sale #19: ₱250.00. Thank you!', '2026-01-26 11:03:08', 'sent', NULL),
(5, NULL, 1, 'Payment received for Sale #17: ₱680.00. Thank you!', '2026-01-26 11:03:49', 'sent', NULL),
(6, NULL, 2, 'Payment received for Sale #19: ₱300.00. Thank you!', '2026-01-27 03:01:22', 'sent', NULL),
(7, NULL, 3, 'Hi! You have an unpaid balance of ₱1,375.00 for Sale #20. Please settle it by 2026-02-12. Thank you!', '2026-01-27 03:02:10', 'sent', NULL),
(8, NULL, 3, 'Payment received for Sale #20: ₱500.00. Thank you!', '2026-01-27 03:03:29', 'sent', NULL),
(9, NULL, 3, 'Payment received for Sale #20: ₱375.00. Thank you!', '2026-01-27 03:03:50', 'sent', NULL),
(10, NULL, 3, 'Payment received for Sale #20: ₱500.00. Thank you!', '2026-01-27 03:04:03', 'sent', NULL),
(11, NULL, 4, 'Hi! You have an unpaid balance of ₱1,375.00 for Sale #21. Please settle it by 2026-01-30. Thank you!', '2026-01-27 06:10:04', 'sent', NULL),
(12, NULL, 4, 'Payment received for Sale #21: ₱375.00. Thank you!', '2026-01-27 06:59:34', 'sent', NULL),
(13, NULL, 4, 'Payment received for Sale #21: ₱1,000.00. Thank you!', '2026-01-27 06:59:53', 'sent', NULL),
(14, NULL, 5, 'Hi! You have an unpaid balance of ₱1,375.00 for Sale #22. Please settle it by 2026-02-04. Thank you!', '2026-01-27 07:24:29', 'sent', NULL),
(15, NULL, 5, 'Hi! You have an unpaid balance of ₱680.00 for Sale #26. Please settle it by 2026-02-14. Thank you!', '2026-01-27 07:34:22', 'sent', NULL),
(16, NULL, 5, 'Payment received for Sale #26: ₱680.00. Thank you!', '2026-01-28 07:45:48', 'sent', NULL),
(17, NULL, 3, 'Hi! You have an unpaid balance of ₱55.00 for Sale #31. Please settle it by 2026-01-30. Thank you!', '2026-01-28 08:15:42', 'sent', NULL),
(18, NULL, 5, 'Payment received for Sale #22: ₱1,375.00. Thank you!', '2026-01-28 08:17:30', 'sent', NULL),
(19, NULL, 3, 'Payment received for Sale #31: ₱55.00. Thank you!', '2026-01-28 08:18:01', 'sent', NULL),
(20, NULL, 2, 'Hi! You have an unpaid balance of ₱265.00 for Sale #34. Please settle it by 2026-01-30. Thank you!', '2026-01-29 11:09:44', 'sent', NULL),
(21, NULL, 1, 'Hi! You have an unpaid balance of ₱60.00 for Sale #35. Please settle it by 2026-01-30. Thank you!', '2026-01-29 11:14:46', 'sent', NULL),
(22, NULL, 2, 'Hi! You have an unpaid balance of ₱265.00 for Sale #38. Please settle it by 2026-01-30. Thank you!', '2026-01-29 11:27:25', 'sent', NULL),
(23, NULL, 2, 'Payment received for Sale #38: ₱265.00. Thank you!', '2026-01-29 11:28:10', 'sent', NULL),
(24, NULL, 1, 'Payment received for Sale #35: ₱60.00. Thank you!', '2026-01-29 11:36:17', 'sent', NULL),
(25, NULL, 2, 'Hi! You have an unpaid balance of ₱300.00 for Sale #41. Please settle it by 2026-01-30. Thank you!', '2026-01-29 11:46:45', 'sent', NULL),
(26, NULL, 2, 'Hi! You have an unpaid balance of ₱110.00 for Sale #42. Please settle it by 2026-01-30. Thank you!', '2026-01-29 11:47:41', 'sent', NULL),
(27, NULL, 2, 'Payment received for Sale #34: ₱265.00. Thank you!', '2026-01-29 11:48:04', 'sent', NULL),
(28, NULL, 7, 'Hi! You have an unpaid balance of ₱550.00 for Sale #47. Please settle it by 2026-01-30. Thank you!', '2026-01-30 12:21:52', 'sent', NULL),
(29, NULL, 2, 'Payment received for Sale #41: ₱300.00. Thank you!', '2026-01-30 12:25:41', 'sent', NULL),
(30, NULL, 2, 'Payment received for Sale #42: ₱110.00. Thank you!', '2026-01-30 12:29:12', 'sent', NULL),
(31, NULL, 7, 'Payment received for Sale #47: ₱250.00. Thank you!', '2026-01-30 12:31:01', 'sent', NULL),
(32, NULL, 7, 'Payment received for Sale #47: ₱150.00. Thank you!', '2026-01-30 12:31:41', 'sent', NULL),
(33, NULL, 7, 'Payment received for Sale #47: ₱150.00. Thank you!', '2026-01-30 12:32:29', 'sent', NULL),
(34, NULL, 4, 'Hi! You have an unpaid balance of ₱720.00 for Sale #50. Please settle it by 2026-02-02. Thank you!', '2026-01-30 13:28:47', 'sent', NULL),
(35, NULL, 4, 'Payment received for Sale #50: ₱720.00. Thank you!', '2026-01-30 13:29:08', 'sent', NULL),
(36, NULL, 2, 'Hi! You have an unpaid balance of ₱75.00 for Sale #53. Please settle it by 2026-02-02. Thank you!', '2026-01-31 05:39:38', 'sent', NULL),
(37, NULL, 2, 'Payment received for Sale #53: ₱75.00. Thank you!', '2026-01-31 05:43:47', 'sent', NULL),
(38, NULL, 3, 'Hi! You have an unpaid balance of ₱550.00 for Sale #55. Please settle it by 2026-02-15. Thank you!', '2026-02-03 04:22:36', 'sent', NULL),
(39, NULL, 3, 'Payment received for Sale #55: ₱550.00. Thank you!', '2026-02-03 04:24:18', 'sent', NULL),
(40, NULL, 6, 'Hi! You have an unpaid balance of ₱470.00 for Sale #57. Please settle it by 2026-02-15. Thank you!', '2026-02-03 09:09:18', 'sent', NULL),
(41, NULL, 6, 'Payment received for Sale #57: ₱470.00. Thank you!', '2026-02-03 09:09:50', 'sent', NULL),
(42, NULL, 3, 'Hi! You have an unpaid balance of ₱800.00 for Sale #60. Please settle it by 2026-02-15. Thank you!', '2026-02-05 09:07:13', 'sent', NULL),
(43, NULL, 3, 'Payment received for Sale #60: ₱800.00. Thank you!', '2026-02-05 09:07:28', 'sent', NULL),
(44, NULL, 2, 'Hi! You have an unpaid balance of ₱300.00 for Sale #61. Please settle it by 2026-02-15. Thank you!', '2026-02-06 06:01:36', 'sent', NULL),
(45, NULL, 5, 'Hi! You have an unpaid balance of ₱550.00 for Sale #65. Please settle it by 2026-02-15. Thank you!', '2026-02-06 06:15:59', 'sent', NULL),
(46, NULL, 5, 'Payment received for Sale #65: ₱100.00. Thank you!', '2026-02-06 06:18:32', 'sent', NULL),
(47, NULL, 5, 'Payment received for Sale #65: ₱450.00. Thank you!', '2026-02-06 06:19:05', 'sent', NULL),
(48, NULL, 2, 'Payment received for Sale #61: ₱100.00. Thank you!', '2026-02-06 06:35:25', 'sent', NULL),
(49, NULL, 2, 'Payment received for Sale #61: ₱200.00. Thank you!', '2026-02-06 06:35:57', 'sent', NULL),
(50, NULL, 4, 'Hi! You have an unpaid balance of ₱242.00 for Sale #70. Please settle it by 2026-02-25. Thank you!', '2026-02-22 06:26:19', 'sent', NULL),
(51, NULL, 4, 'Payment received for Sale #70: ₱200.00. Thank you!', '2026-02-22 06:27:08', 'sent', NULL),
(52, NULL, 4, 'Payment received for Sale #70: ₱42.00. Thank you!', '2026-02-22 06:30:12', 'sent', NULL),
(53, NULL, 7, 'Hi! You have an unpaid balance of ₱2,550.00 for Sale #76. Please settle it by 2026-02-25. Thank you!', '2026-02-23 04:18:12', 'sent', NULL),
(54, NULL, 7, 'Payment received for Sale #76: ₱2,000.00. Thank you!', '2026-02-23 04:19:14', 'sent', NULL),
(55, NULL, 7, 'Payment received for Sale #76: ₱550.00. Thank you!', '2026-02-23 04:19:24', 'sent', NULL),
(56, NULL, 6, 'Hi! You have an unpaid balance of ₱245.00 for Sale #80. Please settle it by 2026-02-28. Thank you!', '2026-02-25 15:59:13', 'sent', NULL),
(57, NULL, 6, 'Payment received for Sale #80: ₱245.00. Thank you!', '2026-02-25 15:59:25', 'sent', NULL),
(58, NULL, 8, 'Hi! You have an unpaid balance of ₱600.00 for Sale #83. Please settle it by 2026-02-28. Thank you!', '2026-02-27 07:42:39', 'sent', NULL),
(59, NULL, 8, 'Payment received for Sale #83: ₱600.00. Thank you!', '2026-02-27 07:45:07', 'sent', NULL),
(60, NULL, 3, 'Hi! You have an unpaid balance of ₱1,960.00 for Sale #86. Please settle it by 2026-02-28. Thank you!', '2026-02-27 08:03:54', 'sent', NULL),
(61, NULL, 3, 'Payment received for Sale #86: ₱500.00. Thank you!', '2026-02-27 08:04:37', 'sent', NULL),
(62, NULL, 3, 'Payment received for Sale #86: ₱1,460.00. Thank you!', '2026-02-27 08:05:37', 'sent', NULL),
(63, NULL, 8, 'Hi! You have an unpaid balance of ₱4,640.00 for Sale #88. Please settle it by 2026-03-14. Thank you!', '2026-02-27 11:45:16', 'sent', NULL),
(64, NULL, 8, 'Payment received for Sale #88: ₱4,640.00. Thank you!', '2026-02-27 11:48:04', 'sent', NULL),
(65, NULL, 7, 'Hi! You have an unpaid balance of ₱2,350.00 for Sale #90. Please settle it by 2026-03-18. Thank you!', '2026-03-03 10:23:04', 'sent', NULL),
(66, NULL, 7, 'Payment received for Sale #90: ₱2,350.00. Thank you!', '2026-03-04 07:30:06', 'sent', NULL),
(67, NULL, 9, 'Hi! You have an unpaid balance of ₱400.00 for Sale #95. Please settle it by 2026-03-25. Thank you!', '2026-03-22 08:38:53', 'sent', NULL),
(68, NULL, 10, 'Hi! You have an unpaid balance of ₱2,500.00 for Sale #97. Please settle it by 2026-04-08. Thank you!', '2026-03-24 04:44:10', 'sent', NULL),
(69, NULL, 6, 'Hi! You have an unpaid balance of ₱80.00 for Sale #98. Please settle it by 2026-04-08. Thank you!', '2026-03-24 04:44:48', 'sent', NULL),
(70, NULL, 7, 'Hi! You have an unpaid balance of ₱63.25 for Sale #99. Please settle it by 2026-04-09. Thank you!', '2026-03-25 03:20:17', 'sent', NULL),
(71, NULL, 7, 'Hi! You have an unpaid balance of ₱506.00 for Sale #100. Please settle it by 2026-04-24. Thank you!', '2026-03-25 03:22:14', 'sent', NULL),
(72, NULL, 5, 'Hi! You have an unpaid balance of ₱2,300.00 for Sale #101. Please settle it by 2026-04-24. Thank you!', '2026-03-25 03:55:09', 'sent', NULL),
(73, NULL, 3, 'Hi! You have an unpaid balance of ₱2,000.00 for Sale #103. Please settle it by 2026-04-12. Thank you!', '2026-03-28 04:43:56', 'sent', NULL),
(74, NULL, 3, 'Payment received for Sale #103: ₱2,000.00. Thank you!', '2026-03-28 04:44:32', 'sent', NULL),
(75, NULL, 4, 'Hi! You have an unpaid balance of ₱2,100.00 for Sale #104. Please settle it by 2026-04-12. Thank you!', '2026-03-28 04:52:23', 'sent', NULL),
(76, NULL, 4, 'Payment received for Sale #104: ₱2,100.00. Thank you!', '2026-03-28 04:53:07', 'sent', NULL),
(77, NULL, 8, 'Hi! You have an unpaid balance of ₱2,015.00 for Sale #105. Please settle it by 2026-04-12. Thank you!', '2026-03-28 04:55:20', 'sent', NULL),
(78, NULL, 8, 'Payment received for Sale #105: ₱2,015.00. Thank you!', '2026-03-28 04:56:09', 'sent', NULL),
(79, NULL, 8, 'Hi! You have an unpaid balance of ₱450.00 for Sale #106. Please settle it by 2026-04-12. Thank you!', '2026-03-28 04:59:26', 'sent', NULL),
(80, NULL, 8, 'Payment received for Sale #106: ₱450.00. Thank you!', '2026-03-28 05:00:10', 'sent', NULL),
(81, NULL, 1, 'Hi! You have an unpaid balance of ₱2,500.00 for Sale #107. Please settle it by 2026-04-12. Thank you!', '2026-03-28 05:05:14', 'sent', NULL),
(82, NULL, 1, 'Payment received for Sale #107: ₱2,500.00. Thank you!', '2026-03-28 05:08:17', 'sent', NULL),
(83, NULL, 5, 'Payment received for Sale #101: ₱2,300.00. Thank you!', '2026-03-28 05:10:20', 'sent', NULL),
(84, NULL, 7, 'Payment received for Sale #100: ₱506.00. Thank you!', '2026-03-28 05:11:43', 'sent', NULL),
(85, NULL, 7, 'Payment received for Sale #99: ₱63.25. Thank you!', '2026-03-28 05:12:45', 'sent', NULL),
(86, NULL, 8, 'Hi! You have an unpaid balance of ₱46.00 for Sale #109. Please settle it by 2026-05-12. Thank you!', '2026-04-27 01:29:59', 'sent', NULL),
(87, NULL, 8, 'Payment received for Sale #109: ₱46.00. Thank you!', '2026-04-27 01:30:25', 'sent', NULL),
(88, NULL, 7, 'Hi! You have an unpaid balance of ₱500.00 for Sale #112. Please settle it by 2026-05-19. Thank you!', '2026-05-04 03:15:16', 'sent', NULL),
(89, NULL, 4, 'Hi! You have an unpaid balance of ₱3,050.00 for Sale #115. Please settle it by 2026-06-08. Thank you!', '2026-05-24 08:52:40', 'sent', NULL),
(90, NULL, 4, 'Payment received for Sale #115: ₱1,525.00. Thank you!', '2026-05-24 08:53:19', 'sent', NULL),
(91, NULL, 4, 'Payment received for Sale #115: ₱1,525.00. Thank you!', '2026-05-24 08:53:33', 'sent', NULL),
(92, NULL, 5, 'Hi! You have an unpaid balance of ₱3,150.00 for Sale #116. Please settle it by 2026-06-08. Thank you!', '2026-05-24 08:54:15', 'sent', NULL),
(93, NULL, 5, 'Payment received for Sale #116: ₱3,150.00. Thank you!', '2026-05-24 08:54:36', 'sent', NULL),
(94, NULL, 3, 'Hi! You have an unpaid balance of ₱3,050.00 for Sale #118. Please settle it by 2026-06-16. Thank you!', '2026-06-01 13:46:21', 'sent', NULL),
(95, NULL, 3, 'Payment received for Sale #118: ₱3,050.00. Thank you!', '2026-06-01 13:46:47', 'sent', NULL),
(96, NULL, 2, 'Hi! You have an unpaid balance of ₱1,000.00 for Sale #124. Please settle it by 2026-07-31. Thank you!', '2026-07-16 06:15:08', 'sent', NULL),
(97, NULL, 2, 'Payment received for Sale #124: ₱1,000.00. Thank you!', '2026-07-16 06:16:49', 'sent', NULL),
(98, NULL, 10, 'Hi! You have an unpaid balance of ₱4,000.00 for Sale #126. Please settle it by 2026-07-31. Thank you!', '2026-07-16 08:48:51', 'sent', NULL),
(99, NULL, 10, 'Payment received for Sale #126: ₱4,000.00. Thank you!', '2026-07-16 08:52:00', 'sent', NULL),
(100, NULL, 7, 'Payment received for Sale #112: ₱506.72. Thank you!', '2026-08-03 06:06:13', 'sent', NULL),
(101, NULL, 10, 'Payment received for Sale #97: ₱2,543.69. Thank you!', '2026-08-03 06:06:41', 'sent', NULL),
(102, NULL, 1, 'Hi! You have an unpaid balance of ₱27,000.00 for Sale #159. Please settle it by 2026-09-01. Thank you!', '2026-08-17 17:16:08', 'sent', NULL),
(103, NULL, 1, 'Payment received for Sale #159: ₱13,500.00. Thank you!', '2026-08-17 17:16:25', 'sent', NULL),
(104, NULL, 1, 'Payment received for Sale #159: ₱898.00. Thank you!', '2026-08-20 03:28:45', 'sent', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `receipt_reprints`
--

CREATE TABLE `receipt_reprints` (
  `id` int(11) NOT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `reprinted_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `receipt_reprints`
--

INSERT INTO `receipt_reprints` (`id`, `sale_id`, `user_id`, `reprinted_at`) VALUES
(1, 94, 2, '2026-03-23 21:23:13'),
(2, 96, 2, '2026-03-25 10:41:28'),
(3, 107, 2, '2026-04-08 12:27:51'),
(4, 138, 2, '2026-07-27 16:09:40'),
(5, 148, 2, '2026-08-10 14:10:42');

-- --------------------------------------------------------

--
-- Table structure for table `returns`
--

CREATE TABLE `returns` (
  `return_id` int(11) NOT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `qty_returned` decimal(10,2) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `return_date` datetime DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `returns`
--

INSERT INTO `returns` (`return_id`, `sale_id`, `product_id`, `qty_returned`, `reason`, `return_date`, `status`) VALUES
(1, 16, 2, 12.00, 'sera naman yanxxx', '2026-01-26', 'rejected'),
(2, 16, 2, 10.00, 'sira', '2026-01-26', 'approved'),
(3, 20, 2, 25.00, 'damaged', '2026-01-27', 'approved'),
(4, 24, 6, 300.00, 'basa', '2026-01-27', 'rejected'),
(5, 21, 2, 25.00, 'damaged', '2026-01-27', 'approved'),
(6, 60, 11, 10.00, 'daot', '2026-02-05', 'approved'),
(7, 51, 10, 40.00, 'test', '2026-02-06', 'approved'),
(8, 76, 5, 25.00, 'daot test', '2026-02-23', 'approved'),
(9, 83, 4, 10.00, 'wet rice', '2026-02-27', 'approved'),
(10, 119, 6, 1.00, 'rice is damaged and wet', '2026-06-02', 'rejected'),
(11, 142, 28, 1.00, 'DAOT SIYA', '2026-07-31', 'approved'),
(12, 143, 30, 2.00, 'wet rice', '2026-08-02', 'approved'),
(13, 159, 8, 50.00, 'damaged', '2026-08-20', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `rice_grades`
--

CREATE TABLE `rice_grades` (
  `id` int(11) NOT NULL,
  `grade_name` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rice_grades`
--

INSERT INTO `rice_grades` (`id`, `grade_name`, `created_at`) VALUES
(1, 'Premium', '2026-08-12 02:14:36'),
(2, 'Special', '2026-08-12 02:14:36'),
(3, 'Regular', '2026-08-12 02:14:36'),
(4, 'Broken', '2026-08-12 02:14:36'),
(5, 'First Class', '2026-08-12 02:15:31');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sale_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `sale_date` datetime NOT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `voided_by` int(11) DEFAULT NULL,
  `voided_at` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`sale_id`, `user_id`, `customer_id`, `sale_date`, `total_amount`, `status`, `created_at`, `voided_by`, `voided_at`, `void_reason`) VALUES
(1, 2, 1, '0000-00-00 00:00:00', 20000.00, '', '2026-01-24 12:24:23', NULL, NULL, NULL),
(2, 2, 1, '0000-00-00 00:00:00', 20000.00, '', '2026-01-24 12:30:18', NULL, NULL, NULL),
(3, 2, 1, '2026-01-25 00:00:00', 10000000.00, 'pending', '2026-01-25 09:12:56', NULL, NULL, NULL),
(4, 2, 1, '2026-01-25 00:00:00', 18000.00, 'pending', '2026-01-25 09:37:37', NULL, NULL, NULL),
(7, 2, 1, '2026-01-25 00:00:00', 340.00, 'paid', '2026-01-25 11:17:36', NULL, NULL, NULL),
(8, 2, 1, '2026-01-25 00:00:00', 340.00, 'paid', '2026-01-25 11:17:36', NULL, NULL, NULL),
(9, 2, 1, '2026-01-25 19:39:07', 550.00, 'paid', '2026-01-25 11:39:07', NULL, NULL, NULL),
(11, 2, 2, '2026-01-25 20:59:08', 275.00, 'paid', '2026-01-25 12:59:08', NULL, NULL, NULL),
(15, 2, 2, '2026-01-26 17:25:38', 340.00, 'paid', '2026-01-26 09:25:38', NULL, NULL, NULL),
(16, 2, 2, '2026-01-26 17:26:19', 1815.00, 'paid', '2026-01-26 09:26:19', NULL, NULL, NULL),
(17, 2, 1, '2026-01-26 18:42:27', 680.00, 'paid', '2026-01-26 10:42:27', NULL, NULL, NULL),
(18, 2, 4, '2026-01-26 19:01:43', 1700.00, 'paid', '2026-01-26 11:01:43', NULL, NULL, NULL),
(19, 2, 2, '2026-01-26 19:02:37', 550.00, 'paid', '2026-01-26 11:02:37', NULL, NULL, NULL),
(20, 2, 3, '2026-01-27 11:02:10', 1375.00, 'paid', '2026-01-27 03:02:10', NULL, NULL, NULL),
(21, 2, 4, '2026-01-27 14:10:04', 1375.00, 'paid', '2026-01-27 06:10:04', NULL, NULL, NULL),
(22, 2, 5, '2026-01-27 15:24:29', 1375.00, 'paid', '2026-01-27 07:24:29', NULL, NULL, NULL),
(24, 2, 5, '2026-01-27 15:28:03', 40715.00, 'paid', '2026-01-27 07:28:03', NULL, NULL, NULL),
(26, 2, 5, '2026-01-27 15:34:22', 680.00, 'paid', '2026-01-27 07:34:22', NULL, NULL, NULL),
(28, 2, 5, '2026-01-27 21:00:24', 550.00, 'paid', '2026-01-27 13:00:24', NULL, NULL, NULL),
(30, 2, 2, '2026-01-28 15:45:35', 1500.00, 'paid', '2026-01-28 07:45:35', NULL, NULL, NULL),
(31, 2, 3, '2026-01-28 16:15:42', 55.00, 'paid', '2026-01-28 08:15:42', NULL, NULL, NULL),
(32, 2, 6, '2026-01-29 19:01:46', 385.00, 'paid', '2026-01-29 11:01:46', NULL, NULL, NULL),
(33, 2, 5, '2026-01-29 19:03:19', 275.00, 'paid', '2026-01-29 11:03:19', NULL, NULL, NULL),
(34, 2, 2, '2026-01-29 19:09:44', 265.00, 'paid', '2026-01-29 11:09:44', NULL, NULL, NULL),
(35, 2, 1, '2026-01-29 19:14:46', 60.00, 'paid', '2026-01-29 11:14:46', NULL, NULL, NULL),
(36, 2, 6, '2026-01-29 19:15:22', 85.00, 'paid', '2026-01-29 11:15:22', NULL, NULL, NULL),
(37, 2, 1, '2026-01-29 19:26:51', 250.00, 'paid', '2026-01-29 11:26:51', NULL, NULL, NULL),
(38, 2, 2, '2026-01-29 19:27:25', 265.00, 'paid', '2026-01-29 11:27:25', NULL, NULL, NULL),
(39, 2, 6, '2026-01-29 19:36:58', 240.00, 'paid', '2026-01-29 11:36:58', NULL, NULL, NULL),
(40, 2, 5, '2026-01-29 19:46:15', 125.00, 'paid', '2026-01-29 11:46:15', NULL, NULL, NULL),
(41, 2, 2, '2026-01-29 19:46:45', 300.00, 'paid', '2026-01-29 11:46:45', NULL, NULL, NULL),
(42, 2, 2, '2026-01-29 19:47:41', 110.00, 'paid', '2026-01-29 11:47:41', NULL, NULL, NULL),
(43, 2, 7, '2026-01-30 19:09:46', 550.00, 'paid', '2026-01-30 11:09:46', NULL, NULL, NULL),
(44, 2, 5, '2026-01-30 19:21:24', 120.00, 'paid', '2026-01-30 11:21:24', NULL, NULL, NULL),
(45, 2, 6, '2026-01-30 20:17:36', 50.00, 'paid', '2026-01-30 12:17:36', NULL, NULL, NULL),
(46, 2, 3, '2026-01-30 20:21:06', 180.00, 'paid', '2026-01-30 12:21:06', NULL, NULL, NULL),
(47, 2, 7, '2026-01-30 20:21:52', 550.00, 'paid', '2026-01-30 12:21:52', NULL, NULL, NULL),
(50, 2, 4, '2026-01-30 21:28:47', 720.00, 'paid', '2026-01-30 13:28:47', NULL, NULL, NULL),
(51, 2, 7, '2026-01-30 21:29:24', 1200.00, 'paid', '2026-01-30 13:29:24', NULL, NULL, NULL),
(52, 2, 1, '2026-01-31 13:38:59', 530.00, 'paid', '2026-01-31 05:38:59', NULL, NULL, NULL),
(53, 2, 2, '2026-01-31 13:39:38', 75.00, 'paid', '2026-01-31 05:39:38', NULL, NULL, NULL),
(54, 2, 7, '2026-02-03 12:22:06', 250.00, 'paid', '2026-02-03 04:22:06', NULL, NULL, NULL),
(55, 2, 3, '2026-02-03 12:22:36', 550.00, 'paid', '2026-02-03 04:22:36', NULL, NULL, NULL),
(57, 2, 6, '2026-02-03 17:09:18', 470.00, 'paid', '2026-02-03 09:09:18', NULL, NULL, NULL),
(58, 2, 6, '2026-02-05 11:37:54', 300.00, 'paid', '2026-02-05 03:37:54', NULL, NULL, NULL),
(59, 2, 4, '2026-02-05 17:06:29', 530.00, 'paid', '2026-02-05 09:06:29', NULL, NULL, NULL),
(60, 2, 3, '2026-02-05 17:07:13', 800.00, 'paid', '2026-02-05 09:07:13', NULL, NULL, NULL),
(61, 2, 2, '2026-02-06 14:01:36', 300.00, 'paid', '2026-02-06 06:01:36', NULL, NULL, NULL),
(63, 2, 6, '2026-02-06 14:10:56', 500.00, 'paid', '2026-02-06 06:10:56', NULL, NULL, NULL),
(64, 2, 3, '2026-02-06 14:14:01', 600.00, 'paid', '2026-02-06 06:14:01', NULL, NULL, NULL),
(65, 2, 5, '2026-02-06 14:15:59', 550.00, 'paid', '2026-02-06 06:15:59', NULL, NULL, NULL),
(66, 2, 6, '2026-02-06 14:27:53', 600.00, 'paid', '2026-02-06 06:27:53', NULL, NULL, NULL),
(67, 2, 2, '2026-02-08 12:08:53', 540.00, 'paid', '2026-02-08 04:08:53', NULL, NULL, NULL),
(68, 2, 7, '2026-02-22 14:09:53', 89.34, 'paid', '2026-02-22 06:09:53', NULL, NULL, NULL),
(69, 2, 6, '2026-02-22 14:18:13', 500.00, 'paid', '2026-02-22 06:18:13', NULL, NULL, NULL),
(70, 2, 4, '2026-02-22 14:26:19', 242.00, 'paid', '2026-02-22 06:26:19', NULL, NULL, NULL),
(71, 2, 7, '2026-02-22 17:01:30', 320.00, 'paid', '2026-02-22 09:01:30', NULL, NULL, NULL),
(73, 2, 7, '2026-02-22 17:02:31', 3840.00, 'paid', '2026-02-22 09:02:31', NULL, NULL, NULL),
(74, 2, 1, '2026-02-22 17:05:58', 720.00, 'paid', '2026-02-22 09:05:58', NULL, NULL, NULL),
(75, 2, 7, '2026-02-23 12:17:03', 240.00, 'paid', '2026-02-23 04:17:03', NULL, NULL, NULL),
(76, 2, 7, '2026-02-23 12:18:12', 2550.00, 'paid', '2026-02-23 04:18:12', NULL, NULL, NULL),
(77, 2, 2, '2026-02-23 12:20:00', 800.00, 'paid', '2026-02-23 04:20:00', NULL, NULL, NULL),
(78, 2, 6, '2026-02-23 12:20:33', 43.20, 'paid', '2026-02-23 04:20:33', NULL, NULL, NULL),
(79, 2, 6, '2026-02-25 23:08:17', 2550.00, 'paid', '2026-02-25 15:08:17', NULL, NULL, NULL),
(80, 2, 6, '2026-02-25 23:59:13', 245.00, 'paid', '2026-02-25 15:59:13', NULL, NULL, NULL),
(81, 2, 2, '2026-02-27 13:42:59', 1040.00, 'paid', '2026-02-27 05:42:59', NULL, NULL, NULL),
(82, 2, 7, '2026-02-27 15:39:28', 480.00, 'paid', '2026-02-27 07:39:28', NULL, NULL, NULL),
(83, 2, 8, '2026-02-27 15:42:39', 600.00, 'paid', '2026-02-27 07:42:39', NULL, NULL, NULL),
(84, 2, 9, '2026-02-27 16:00:57', 1000.00, 'paid', '2026-02-27 08:00:57', NULL, NULL, NULL),
(85, 2, 9, '2026-02-27 16:01:33', 1000.00, 'paid', '2026-02-27 08:01:33', NULL, NULL, NULL),
(86, 2, 3, '2026-02-27 16:03:54', 1960.00, 'paid', '2026-02-27 08:03:54', NULL, NULL, NULL),
(87, 2, 9, '2026-02-27 19:38:38', 76.80, 'paid', '2026-02-27 11:38:38', NULL, NULL, NULL),
(88, 2, 8, '2026-02-27 19:45:16', 4640.00, 'paid', '2026-02-27 11:45:16', NULL, NULL, NULL),
(89, 2, 5, '2026-03-03 18:22:37', 1000.00, 'paid', '2026-03-03 10:22:37', NULL, NULL, NULL),
(90, 2, 7, '2026-03-03 18:23:04', 2350.00, 'paid', '2026-03-03 10:23:04', NULL, NULL, NULL),
(91, 2, 9, '2026-03-03 18:39:40', 5640.00, 'paid', '2026-03-03 10:39:40', NULL, NULL, NULL),
(92, 2, 8, '2026-03-04 15:28:45', 3000.00, 'paid', '2026-03-04 07:28:45', NULL, NULL, NULL),
(93, 2, 5, '2026-03-04 15:34:56', 12000.00, 'paid', '2026-03-04 07:34:56', NULL, NULL, NULL),
(94, 2, 6, '2026-03-10 20:14:21', 1920.00, 'paid', '2026-03-10 12:14:21', NULL, NULL, NULL),
(95, 2, 9, '2026-03-22 16:38:53', 400.00, 'unpaid', '2026-03-22 08:38:53', NULL, NULL, NULL),
(96, 2, 10, '2026-03-24 12:32:48', 30.00, 'paid', '2026-03-24 04:32:48', NULL, NULL, NULL),
(97, 2, 10, '2026-03-24 12:44:10', 2500.00, 'paid', '2026-03-24 04:44:10', NULL, NULL, NULL),
(98, 2, 6, '2026-03-24 12:44:48', 80.00, 'unpaid', '2026-03-24 04:44:48', NULL, NULL, NULL),
(99, 2, 7, '2026-03-25 11:20:17', 63.25, 'paid', '2026-03-25 03:20:17', NULL, NULL, NULL),
(100, 2, 7, '2026-03-25 11:22:14', 506.00, 'paid', '2026-03-25 03:22:14', NULL, NULL, NULL),
(101, 2, 5, '2026-03-25 11:55:09', 2300.00, 'paid', '2026-03-25 03:55:09', NULL, NULL, NULL),
(102, 2, 9, '2026-03-28 12:43:15', 40.00, 'paid', '2026-03-28 04:43:15', NULL, NULL, NULL),
(103, 2, 3, '2026-03-28 12:43:56', 2000.00, 'paid', '2026-03-28 04:43:56', NULL, NULL, NULL),
(104, 2, 4, '2026-03-28 12:52:23', 2100.00, 'paid', '2026-03-28 04:52:23', NULL, NULL, NULL),
(105, 2, 8, '2026-03-28 12:55:20', 2015.00, 'paid', '2026-03-28 04:55:20', NULL, NULL, NULL),
(106, 2, 8, '2026-03-28 12:59:26', 450.00, 'paid', '2026-03-28 04:59:26', NULL, NULL, NULL),
(107, 2, 1, '2026-03-28 13:05:14', 2500.00, 'paid', '2026-03-28 05:05:14', NULL, NULL, NULL),
(108, 2, 3, '2026-04-08 18:38:41', 32.24, 'paid', '2026-04-08 10:38:41', NULL, NULL, NULL),
(109, 2, 8, '2026-04-27 09:29:59', 460000.00, 'paid', '2026-04-27 01:29:59', NULL, NULL, NULL),
(110, 2, 4, '2026-05-04 10:53:05', 3080.00, 'paid', '2026-05-04 02:53:05', NULL, NULL, NULL),
(111, 2, NULL, '2026-05-04 10:56:20', 90.00, 'paid', '2026-05-04 02:56:20', NULL, NULL, NULL),
(112, 2, 7, '2026-05-04 11:15:16', 500.00, 'paid', '2026-05-04 03:15:16', NULL, NULL, NULL),
(113, 2, NULL, '2026-05-11 12:34:46', 2500.00, 'paid', '2026-05-11 04:34:46', NULL, NULL, NULL),
(114, 2, NULL, '2026-05-24 16:41:24', 3150.00, 'paid', '2026-05-24 08:41:24', NULL, NULL, NULL),
(115, 2, 4, '2026-05-24 16:52:40', 3050.00, 'paid', '2026-05-24 08:52:40', NULL, NULL, NULL),
(116, 2, 5, '2026-05-24 16:54:15', 3150.00, 'paid', '2026-05-24 08:54:15', NULL, NULL, NULL),
(117, 2, NULL, '2026-06-01 21:45:26', 2400.00, 'paid', '2026-06-01 13:45:26', NULL, NULL, NULL),
(118, 2, 3, '2026-06-01 21:46:21', 3050.00, 'paid', '2026-06-01 13:46:21', NULL, NULL, NULL),
(119, 2, NULL, '2026-06-02 11:05:09', 1800.00, 'paid', '2026-06-02 03:05:09', NULL, NULL, NULL),
(120, 2, NULL, '2026-06-09 16:20:16', 2464.00, 'paid', '2026-06-09 08:20:16', NULL, NULL, NULL),
(121, 2, NULL, '2026-06-10 10:22:16', 14000.00, 'paid', '2026-06-10 02:22:16', NULL, NULL, NULL),
(122, 2, NULL, '2026-06-10 10:26:06', 918.75, 'paid', '2026-06-10 02:26:06', NULL, NULL, NULL),
(123, 2, NULL, '2026-07-08 21:19:50', 2300.00, 'paid', '2026-07-08 13:19:50', NULL, NULL, NULL),
(124, 2, 2, '2026-07-16 14:15:08', 1000.00, 'paid', '2026-07-16 06:15:08', NULL, NULL, NULL),
(125, 2, NULL, '2026-07-16 16:45:21', 2900.00, 'paid', '2026-07-16 08:45:21', NULL, NULL, NULL),
(126, 2, 10, '2026-07-16 16:48:51', 4000.00, 'paid', '2026-07-16 08:48:51', NULL, NULL, NULL),
(127, 2, NULL, '2026-07-19 23:11:05', 506.00, 'paid', '2026-07-19 15:11:05', NULL, NULL, NULL),
(128, 2, NULL, '2026-07-19 23:31:20', 2926.00, 'paid', '2026-07-19 15:31:20', NULL, NULL, NULL),
(129, 2, NULL, '2026-07-19 23:37:14', 632.50, 'paid', '2026-07-19 15:37:14', NULL, NULL, NULL),
(130, 2, NULL, '2026-07-21 13:00:37', 316.25, 'paid', '2026-07-21 05:00:37', NULL, NULL, NULL),
(131, 2, NULL, '2026-07-21 13:19:41', 2250.00, 'paid', '2026-07-21 05:19:41', NULL, NULL, NULL),
(132, 2, NULL, '2026-07-21 13:41:01', 2250.00, 'paid', '2026-07-21 05:41:01', NULL, NULL, NULL),
(133, 2, NULL, '2026-07-21 14:35:47', 2655.00, 'paid', '2026-07-21 06:35:47', NULL, NULL, NULL),
(134, 2, NULL, '2026-07-21 14:39:41', 45.00, 'paid', '2026-07-21 06:39:41', NULL, NULL, NULL),
(135, 2, NULL, '2026-07-22 09:27:05', 632.50, 'paid', '2026-07-22 01:27:05', NULL, NULL, NULL),
(136, 2, NULL, '2026-07-23 15:17:59', 2500.00, 'paid', '2026-07-23 07:17:59', NULL, NULL, NULL),
(137, 2, NULL, '2026-07-27 16:04:57', 4655.00, 'paid', '2026-07-27 08:04:57', NULL, NULL, NULL),
(138, 2, NULL, '2026-07-27 16:08:43', 2200.00, 'paid', '2026-07-27 08:08:43', NULL, NULL, NULL),
(139, 2, NULL, '2026-07-28 18:54:36', 2950.00, 'paid', '2026-07-28 10:54:36', NULL, NULL, NULL),
(140, 2, NULL, '2026-07-28 18:55:32', 45.00, 'paid', '2026-07-28 10:55:32', NULL, NULL, NULL),
(141, 2, NULL, '2026-07-29 19:44:11', 4824.00, 'paid', '2026-07-29 11:44:11', NULL, NULL, NULL),
(142, 2, NULL, '2026-07-31 11:28:46', 2040.00, 'paid', '2026-07-31 03:28:46', NULL, NULL, NULL),
(143, 2, NULL, '2026-08-02 21:31:25', 2240.00, 'paid', '2026-08-02 13:31:25', NULL, NULL, NULL),
(144, 10, NULL, '2026-08-03 13:14:39', 2250.00, 'paid', '2026-08-03 05:14:39', NULL, NULL, NULL),
(145, 2, NULL, '2026-08-03 14:06:02', 10800.00, 'paid', '2026-08-03 06:06:02', NULL, NULL, NULL),
(146, 2, NULL, '2026-08-03 14:08:03', 10800.00, 'paid', '2026-08-03 06:08:03', NULL, NULL, NULL),
(147, 2, NULL, '2026-08-03 14:12:09', 4000.00, 'paid', '2026-08-03 06:12:09', NULL, NULL, NULL),
(148, 2, NULL, '2026-08-10 14:08:28', 1834.25, 'paid', '2026-08-10 06:08:28', NULL, NULL, NULL),
(149, 2, NULL, '2026-08-10 14:13:59', 45.00, 'paid', '2026-08-10 06:13:59', NULL, NULL, NULL),
(150, 2, NULL, '2026-08-10 14:37:32', 25000.00, 'paid', '2026-08-10 06:37:32', NULL, NULL, NULL),
(151, 2, NULL, '2026-08-10 14:43:58', 20000.00, 'paid', '2026-08-10 06:43:58', NULL, NULL, NULL),
(152, 2, NULL, '2026-08-17 13:56:43', 45.00, 'paid', '2026-08-17 05:56:43', NULL, NULL, NULL),
(153, 2, NULL, '2026-08-17 14:03:32', 54.00, 'paid', '2026-08-17 06:03:32', NULL, NULL, NULL),
(154, 2, NULL, '2026-08-17 14:05:24', 2700.00, 'paid', '2026-08-17 06:05:24', NULL, NULL, NULL),
(155, 2, NULL, '2026-08-17 14:07:02', 13500.00, 'paid', '2026-08-17 06:07:02', NULL, NULL, NULL),
(156, 2, NULL, '2026-08-17 14:07:23', 2450.00, 'paid', '2026-08-17 06:07:23', NULL, NULL, NULL),
(157, 2, NULL, '2026-08-17 16:45:38', 66.00, 'paid', '2026-08-17 08:45:38', NULL, NULL, NULL),
(158, 2, NULL, '2026-08-17 21:17:30', 45.00, 'paid', '2026-08-17 13:17:30', NULL, NULL, NULL),
(159, 2, 1, '2026-08-18 01:16:08', 27000.00, 'unpaid', '2026-08-17 17:16:08', NULL, NULL, NULL),
(160, 2, NULL, '2022-01-06 09:15:00', 3412.80, 'paid', '2022-01-06 01:15:00', NULL, NULL, NULL),
(161, 2, NULL, '2022-01-15 10:15:00', 4125.60, 'paid', '2022-01-15 02:15:00', NULL, NULL, NULL),
(162, 2, NULL, '2022-01-24 11:15:00', 5084.64, 'paid', '2022-01-24 03:15:00', NULL, NULL, NULL),
(163, 2, NULL, '2022-02-06 09:15:00', 4419.29, 'paid', '2022-02-06 01:15:00', NULL, NULL, NULL),
(164, 2, NULL, '2022-02-15 10:15:00', 5446.82, 'paid', '2022-02-15 02:15:00', NULL, NULL, NULL),
(165, 2, NULL, '2022-02-24 11:15:00', 5839.79, 'paid', '2022-02-24 03:15:00', NULL, NULL, NULL),
(166, 2, NULL, '2022-03-06 09:15:00', 5637.49, 'paid', '2022-03-06 01:15:00', NULL, NULL, NULL),
(167, 2, NULL, '2022-03-15 10:15:00', 6044.93, 'paid', '2022-03-15 02:15:00', NULL, NULL, NULL),
(168, 2, NULL, '2022-03-24 11:15:00', 6403.86, 'paid', '2022-03-24 03:15:00', NULL, NULL, NULL),
(169, 2, NULL, '2022-04-06 09:15:00', 6025.35, 'paid', '2022-04-06 01:15:00', NULL, NULL, NULL),
(170, 2, NULL, '2022-04-15 10:15:00', 6383.33, 'paid', '2022-04-15 02:15:00', NULL, NULL, NULL),
(171, 2, NULL, '2022-04-24 11:15:00', 6469.71, 'paid', '2022-04-24 03:15:00', NULL, NULL, NULL),
(172, 2, NULL, '2022-05-06 09:15:00', 6149.84, 'paid', '2022-05-06 01:15:00', NULL, NULL, NULL),
(173, 2, NULL, '2022-05-15 10:15:00', 6232.66, 'paid', '2022-05-15 02:15:00', NULL, NULL, NULL),
(174, 2, NULL, '2022-05-24 11:15:00', 5289.51, 'paid', '2022-05-24 03:15:00', NULL, NULL, NULL),
(175, 2, NULL, '2022-06-06 09:15:00', 5860.11, 'paid', '2022-06-06 01:15:00', NULL, NULL, NULL),
(176, 2, NULL, '2022-06-15 10:15:00', 4973.53, 'paid', '2022-06-15 02:15:00', NULL, NULL, NULL),
(177, 2, NULL, '2022-06-24 11:15:00', 4251.28, 'paid', '2022-06-24 03:15:00', NULL, NULL, NULL),
(178, 2, NULL, '2022-07-06 09:15:00', 4645.48, 'paid', '2022-07-06 01:15:00', NULL, NULL, NULL),
(179, 2, NULL, '2022-07-15 10:15:00', 3970.99, 'paid', '2022-07-15 02:15:00', NULL, NULL, NULL),
(180, 2, NULL, '2022-07-24 11:15:00', 3477.96, 'paid', '2022-07-24 03:15:00', NULL, NULL, NULL),
(181, 2, NULL, '2022-08-06 09:15:00', 3774.28, 'paid', '2022-08-06 01:15:00', NULL, NULL, NULL),
(182, 2, NULL, '2022-08-15 10:15:00', 3306.19, 'paid', '2022-08-15 02:15:00', NULL, NULL, NULL),
(183, 2, NULL, '2022-08-24 11:15:00', 3709.06, 'paid', '2022-08-24 03:15:00', NULL, NULL, NULL),
(184, 2, NULL, '2022-09-06 09:15:00', 3271.90, 'paid', '2022-09-06 01:15:00', NULL, NULL, NULL),
(185, 2, NULL, '2022-09-15 10:15:00', 3671.08, 'paid', '2022-09-15 02:15:00', NULL, NULL, NULL),
(186, 2, NULL, '2022-09-24 11:15:00', 4001.87, 'paid', '2022-09-24 03:15:00', NULL, NULL, NULL),
(187, 2, NULL, '2022-10-06 09:15:00', 3820.94, 'paid', '2022-10-06 01:15:00', NULL, NULL, NULL),
(188, 2, NULL, '2022-10-15 10:15:00', 4164.81, 'paid', '2022-10-15 02:15:00', NULL, NULL, NULL),
(189, 2, NULL, '2022-10-24 11:15:00', 4330.79, 'paid', '2022-10-24 03:15:00', NULL, NULL, NULL),
(190, 2, NULL, '2022-11-06 09:15:00', 4513.37, 'paid', '2022-11-06 01:15:00', NULL, NULL, NULL),
(191, 2, NULL, '2022-11-15 10:15:00', 4693.63, 'paid', '2022-11-15 02:15:00', NULL, NULL, NULL),
(192, 2, NULL, '2022-11-24 11:15:00', 5786.98, 'paid', '2022-11-24 03:15:00', NULL, NULL, NULL),
(193, 2, NULL, '2022-12-06 09:15:00', 5176.57, 'paid', '2022-12-06 01:15:00', NULL, NULL, NULL),
(194, 2, NULL, '2022-12-15 10:15:00', 6381.77, 'paid', '2022-12-15 02:15:00', NULL, NULL, NULL),
(195, 2, NULL, '2022-12-24 11:15:00', 7274.83, 'paid', '2022-12-24 03:15:00', NULL, NULL, NULL),
(196, 2, NULL, '2023-01-06 09:15:00', 6992.04, 'paid', '2023-01-06 01:15:00', NULL, NULL, NULL),
(197, 2, NULL, '2023-01-15 10:15:00', 7970.75, 'paid', '2023-01-15 02:15:00', NULL, NULL, NULL),
(198, 2, NULL, '2023-01-24 11:15:00', 7214.69, 'paid', '2023-01-24 03:15:00', NULL, NULL, NULL),
(199, 2, NULL, '2023-02-06 09:15:00', 8523.22, 'paid', '2023-02-06 01:15:00', NULL, NULL, NULL),
(200, 2, NULL, '2023-02-15 10:15:00', 7714.64, 'paid', '2023-02-15 02:15:00', NULL, NULL, NULL),
(201, 2, NULL, '2023-02-24 11:15:00', 5748.67, 'paid', '2023-02-24 03:15:00', NULL, NULL, NULL),
(202, 2, NULL, '2023-03-06 09:15:00', 7971.94, 'paid', '2023-03-06 01:15:00', NULL, NULL, NULL),
(203, 2, NULL, '2023-03-15 10:15:00', 5940.73, 'paid', '2023-03-15 02:15:00', NULL, NULL, NULL),
(204, 2, NULL, '2023-03-24 11:15:00', 4401.34, 'paid', '2023-03-24 03:15:00', NULL, NULL, NULL),
(205, 2, NULL, '2023-04-06 09:15:00', 5912.85, 'paid', '2023-04-06 01:15:00', NULL, NULL, NULL),
(206, 2, NULL, '2023-04-15 10:15:00', 4380.51, 'paid', '2023-04-15 02:15:00', NULL, NULL, NULL),
(207, 2, NULL, '2023-04-24 11:15:00', 4756.85, 'paid', '2023-04-24 03:15:00', NULL, NULL, NULL),
(208, 2, NULL, '2023-05-06 09:15:00', 4213.10, 'paid', '2023-05-06 01:15:00', NULL, NULL, NULL),
(209, 2, NULL, '2023-05-15 10:15:00', 4574.77, 'paid', '2023-05-15 02:15:00', NULL, NULL, NULL),
(210, 2, NULL, '2023-05-24 11:15:00', 5862.43, 'paid', '2023-05-24 03:15:00', NULL, NULL, NULL),
(211, 2, NULL, '2023-06-06 09:15:00', 4294.76, 'paid', '2023-06-06 01:15:00', NULL, NULL, NULL),
(212, 2, NULL, '2023-06-15 10:15:00', 5503.63, 'paid', '2023-06-15 02:15:00', NULL, NULL, NULL),
(213, 2, NULL, '2023-06-24 11:15:00', 6414.19, 'paid', '2023-06-24 03:15:00', NULL, NULL, NULL),
(214, 2, NULL, '2023-07-06 09:15:00', 5133.16, 'paid', '2023-07-06 01:15:00', NULL, NULL, NULL),
(215, 2, NULL, '2023-07-15 10:15:00', 5981.95, 'paid', '2023-07-15 02:15:00', NULL, NULL, NULL),
(216, 2, NULL, '2023-07-24 11:15:00', 7162.12, 'paid', '2023-07-24 03:15:00', NULL, NULL, NULL),
(217, 2, NULL, '2023-08-06 09:15:00', 5678.21, 'paid', '2023-08-06 01:15:00', NULL, NULL, NULL),
(218, 2, NULL, '2023-08-15 10:15:00', 6797.98, 'paid', '2023-08-15 02:15:00', NULL, NULL, NULL),
(219, 2, NULL, '2023-08-24 11:15:00', 7093.67, 'paid', '2023-08-24 03:15:00', NULL, NULL, NULL),
(220, 2, NULL, '2023-09-06 09:15:00', 6717.90, 'paid', '2023-09-06 01:15:00', NULL, NULL, NULL),
(221, 2, NULL, '2023-09-15 10:15:00', 7010.47, 'paid', '2023-09-15 02:15:00', NULL, NULL, NULL),
(222, 2, NULL, '2023-09-24 11:15:00', 5854.14, 'paid', '2023-09-24 03:15:00', NULL, NULL, NULL),
(223, 2, NULL, '2023-10-06 09:15:00', 7285.68, 'paid', '2023-10-06 01:15:00', NULL, NULL, NULL),
(224, 2, NULL, '2023-10-15 10:15:00', 6084.04, 'paid', '2023-10-15 02:15:00', NULL, NULL, NULL),
(225, 2, NULL, '2023-10-24 11:15:00', 4559.41, 'paid', '2023-10-24 03:15:00', NULL, NULL, NULL),
(226, 2, NULL, '2023-11-06 09:15:00', 6584.10, 'paid', '2023-11-06 01:15:00', NULL, NULL, NULL),
(227, 2, NULL, '2023-11-15 10:15:00', 4933.97, 'paid', '2023-11-15 02:15:00', NULL, NULL, NULL),
(228, 2, NULL, '2023-11-24 11:15:00', 3997.52, 'paid', '2023-11-24 03:15:00', NULL, NULL, NULL),
(229, 2, NULL, '2023-12-06 09:15:00', 5434.45, 'paid', '2023-12-06 01:15:00', NULL, NULL, NULL),
(230, 2, NULL, '2023-12-15 10:15:00', 4403.38, 'paid', '2023-12-15 02:15:00', NULL, NULL, NULL),
(231, 2, NULL, '2023-12-24 11:15:00', 5322.85, 'paid', '2023-12-24 03:15:00', NULL, NULL, NULL),
(232, 2, NULL, '2024-01-06 09:15:00', 4817.79, 'paid', '2024-01-06 01:15:00', NULL, NULL, NULL),
(233, 2, NULL, '2024-01-15 10:15:00', 5824.07, 'paid', '2024-01-15 02:15:00', NULL, NULL, NULL),
(234, 2, NULL, '2024-01-24 11:15:00', 7178.20, 'paid', '2024-01-24 03:15:00', NULL, NULL, NULL),
(235, 2, NULL, '2024-02-06 09:15:00', 6218.96, 'paid', '2024-02-06 01:15:00', NULL, NULL, NULL),
(236, 2, NULL, '2024-02-15 10:15:00', 7664.62, 'paid', '2024-02-15 02:15:00', NULL, NULL, NULL),
(237, 2, NULL, '2024-02-24 11:15:00', 8218.69, 'paid', '2024-02-24 03:15:00', NULL, NULL, NULL),
(238, 2, NULL, '2024-03-06 09:15:00', 7910.70, 'paid', '2024-03-06 01:15:00', NULL, NULL, NULL),
(239, 2, NULL, '2024-03-15 10:15:00', 8481.80, 'paid', '2024-03-15 02:15:00', NULL, NULL, NULL),
(240, 2, NULL, '2024-03-24 11:15:00', 8985.90, 'paid', '2024-03-24 03:15:00', NULL, NULL, NULL),
(241, 2, NULL, '2024-04-06 09:15:00', 8431.20, 'paid', '2024-04-06 01:15:00', NULL, NULL, NULL),
(242, 2, NULL, '2024-04-15 10:15:00', 8932.24, 'paid', '2024-04-15 02:15:00', NULL, NULL, NULL),
(243, 2, NULL, '2024-04-24 11:15:00', 9052.36, 'paid', '2024-04-24 03:15:00', NULL, NULL, NULL),
(244, 2, NULL, '2024-05-06 09:15:00', 8580.69, 'paid', '2024-05-06 01:15:00', NULL, NULL, NULL),
(245, 2, NULL, '2024-05-15 10:15:00', 8696.18, 'paid', '2024-05-15 02:15:00', NULL, NULL, NULL),
(246, 2, NULL, '2024-05-24 11:15:00', 7380.35, 'paid', '2024-05-24 03:15:00', NULL, NULL, NULL),
(247, 2, NULL, '2024-06-06 09:15:00', 8153.73, 'paid', '2024-06-06 01:15:00', NULL, NULL, NULL),
(248, 2, NULL, '2024-06-15 10:15:00', 6920.10, 'paid', '2024-06-15 02:15:00', NULL, NULL, NULL),
(249, 2, NULL, '2024-06-24 11:15:00', 5915.32, 'paid', '2024-06-24 03:15:00', NULL, NULL, NULL),
(250, 2, NULL, '2024-07-06 09:15:00', 6446.27, 'paid', '2024-07-06 01:15:00', NULL, NULL, NULL),
(251, 2, NULL, '2024-07-15 10:15:00', 5510.38, 'paid', '2024-07-15 02:15:00', NULL, NULL, NULL),
(252, 2, NULL, '2024-07-24 11:15:00', 4826.24, 'paid', '2024-07-24 03:15:00', NULL, NULL, NULL),
(253, 2, NULL, '2024-08-06 09:15:00', 5223.13, 'paid', '2024-08-06 01:15:00', NULL, NULL, NULL),
(254, 2, NULL, '2024-08-15 10:15:00', 4574.82, 'paid', '2024-08-15 02:15:00', NULL, NULL, NULL),
(255, 2, NULL, '2024-08-24 11:15:00', 5133.22, 'paid', '2024-08-24 03:15:00', NULL, NULL, NULL),
(256, 2, NULL, '2024-09-06 09:15:00', 4517.18, 'paid', '2024-09-06 01:15:00', NULL, NULL, NULL),
(257, 2, NULL, '2024-09-15 10:15:00', 5067.87, 'paid', '2024-09-15 02:15:00', NULL, NULL, NULL),
(258, 2, NULL, '2024-09-24 11:15:00', 5524.11, 'paid', '2024-09-24 03:15:00', NULL, NULL, NULL),
(259, 2, NULL, '2024-10-06 09:15:00', 5260.45, 'paid', '2024-10-06 01:15:00', NULL, NULL, NULL),
(260, 2, NULL, '2024-10-15 10:15:00', 5734.18, 'paid', '2024-10-15 02:15:00', NULL, NULL, NULL),
(261, 2, NULL, '2024-10-24 11:15:00', 5962.93, 'paid', '2024-10-24 03:15:00', NULL, NULL, NULL),
(262, 2, NULL, '2024-11-06 09:15:00', 6197.91, 'paid', '2024-11-06 01:15:00', NULL, NULL, NULL),
(263, 2, NULL, '2024-11-15 10:15:00', 6444.99, 'paid', '2024-11-15 02:15:00', NULL, NULL, NULL),
(264, 2, NULL, '2024-11-24 11:15:00', 7946.33, 'paid', '2024-11-24 03:15:00', NULL, NULL, NULL),
(265, 2, NULL, '2024-12-06 09:15:00', 7090.35, 'paid', '2024-12-06 01:15:00', NULL, NULL, NULL),
(266, 2, NULL, '2024-12-15 10:15:00', 8741.53, 'paid', '2024-12-15 02:15:00', NULL, NULL, NULL),
(267, 2, NULL, '2024-12-24 11:15:00', 9965.34, 'paid', '2024-12-24 03:15:00', NULL, NULL, NULL),
(268, 2, NULL, '2025-01-06 09:15:00', 9554.23, 'paid', '2025-01-06 01:15:00', NULL, NULL, NULL),
(269, 2, NULL, '2025-01-15 10:15:00', 10891.56, 'paid', '2025-01-15 02:15:00', NULL, NULL, NULL),
(270, 2, NULL, '2025-01-24 11:15:00', 9858.44, 'paid', '2025-01-24 03:15:00', NULL, NULL, NULL),
(271, 2, NULL, '2025-02-06 09:15:00', 11619.26, 'paid', '2025-02-06 01:15:00', NULL, NULL, NULL),
(272, 2, NULL, '2025-02-15 10:15:00', 10516.70, 'paid', '2025-02-15 02:15:00', NULL, NULL, NULL),
(273, 2, NULL, '2025-02-24 11:15:00', 7836.70, 'paid', '2025-02-24 03:15:00', NULL, NULL, NULL),
(274, 2, NULL, '2025-03-06 09:15:00', 10841.12, 'paid', '2025-03-06 01:15:00', NULL, NULL, NULL),
(275, 2, NULL, '2025-03-15 10:15:00', 8078.17, 'paid', '2025-03-15 02:15:00', NULL, NULL, NULL),
(276, 2, NULL, '2025-03-24 11:15:00', 5984.75, 'paid', '2025-03-24 03:15:00', NULL, NULL, NULL),
(277, 2, NULL, '2025-04-06 09:15:00', 8022.50, 'paid', '2025-04-06 01:15:00', NULL, NULL, NULL),
(278, 2, NULL, '2025-04-15 10:15:00', 5943.61, 'paid', '2025-04-15 02:15:00', NULL, NULL, NULL),
(279, 2, NULL, '2025-04-24 11:15:00', 6453.37, 'paid', '2025-04-24 03:15:00', NULL, NULL, NULL),
(280, 2, NULL, '2025-05-06 09:15:00', 5703.07, 'paid', '2025-05-06 01:15:00', NULL, NULL, NULL),
(281, 2, NULL, '2025-05-15 10:15:00', 6192.54, 'paid', '2025-05-15 02:15:00', NULL, NULL, NULL),
(282, 2, NULL, '2025-05-24 11:15:00', 7936.02, 'paid', '2025-05-24 03:15:00', NULL, NULL, NULL),
(283, 2, NULL, '2025-06-06 09:15:00', 5800.21, 'paid', '2025-06-06 01:15:00', NULL, NULL, NULL),
(284, 2, NULL, '2025-06-15 10:15:00', 7433.07, 'paid', '2025-06-15 02:15:00', NULL, NULL, NULL),
(285, 2, NULL, '2025-06-24 11:15:00', 8662.73, 'paid', '2025-06-24 03:15:00', NULL, NULL, NULL),
(286, 2, NULL, '2025-07-06 09:15:00', 6917.60, 'paid', '2025-07-06 01:15:00', NULL, NULL, NULL),
(287, 2, NULL, '2025-07-15 10:15:00', 8061.73, 'paid', '2025-07-15 02:15:00', NULL, NULL, NULL),
(288, 2, NULL, '2025-07-24 11:15:00', 9651.98, 'paid', '2025-07-24 03:15:00', NULL, NULL, NULL),
(289, 2, NULL, '2025-08-06 09:15:00', 7634.52, 'paid', '2025-08-06 01:15:00', NULL, NULL, NULL),
(290, 2, NULL, '2025-08-15 10:15:00', 9140.32, 'paid', '2025-08-15 02:15:00', NULL, NULL, NULL),
(291, 2, NULL, '2025-08-24 11:15:00', 9538.21, 'paid', '2025-08-24 03:15:00', NULL, NULL, NULL),
(292, 2, NULL, '2025-09-06 09:15:00', 9014.30, 'paid', '2025-09-06 01:15:00', NULL, NULL, NULL),
(293, 2, NULL, '2025-09-15 10:15:00', 9406.61, 'paid', '2025-09-15 02:15:00', NULL, NULL, NULL),
(294, 2, NULL, '2025-09-24 11:15:00', 7854.77, 'paid', '2025-09-24 03:15:00', NULL, NULL, NULL),
(295, 2, NULL, '2025-10-06 09:15:00', 9755.41, 'paid', '2025-10-06 01:15:00', NULL, NULL, NULL),
(296, 2, NULL, '2025-10-15 10:15:00', 8146.30, 'paid', '2025-10-15 02:15:00', NULL, NULL, NULL),
(297, 2, NULL, '2025-10-24 11:15:00', 6105.09, 'paid', '2025-10-24 03:15:00', NULL, NULL, NULL),
(298, 2, NULL, '2025-11-06 09:15:00', 8797.76, 'paid', '2025-11-06 01:15:00', NULL, NULL, NULL),
(299, 2, NULL, '2025-11-15 10:15:00', 6592.99, 'paid', '2025-11-15 02:15:00', NULL, NULL, NULL),
(300, 2, NULL, '2025-11-24 11:15:00', 5341.73, 'paid', '2025-11-24 03:15:00', NULL, NULL, NULL),
(301, 2, NULL, '2025-12-06 09:15:00', 7246.09, 'paid', '2025-12-06 01:15:00', NULL, NULL, NULL),
(302, 2, NULL, '2025-12-15 10:15:00', 5871.09, 'paid', '2025-12-15 02:15:00', NULL, NULL, NULL),
(303, 2, NULL, '2025-12-24 11:15:00', 7097.58, 'paid', '2025-12-24 03:15:00', NULL, NULL, NULL),
(304, 2, NULL, '2026-01-06 09:15:00', 6411.30, 'paid', '2026-01-06 01:15:00', NULL, NULL, NULL),
(305, 2, NULL, '2026-01-15 10:15:00', 7750.00, 'paid', '2026-01-15 02:15:00', NULL, NULL, NULL),
(306, 2, NULL, '2026-01-24 11:15:00', 9551.16, 'paid', '2026-01-24 03:15:00', NULL, NULL, NULL),
(307, 2, NULL, '2026-02-06 09:15:00', 8260.80, 'paid', '2026-02-06 01:15:00', NULL, NULL, NULL),
(308, 2, NULL, '2026-02-15 10:15:00', 10180.54, 'paid', '2026-02-15 02:15:00', NULL, NULL, NULL),
(309, 2, NULL, '2026-02-24 11:15:00', 10915.96, 'paid', '2026-02-24 03:15:00', NULL, NULL, NULL),
(310, 2, NULL, '2026-03-06 09:15:00', 10485.70, 'paid', '2026-03-06 01:15:00', NULL, NULL, NULL),
(311, 2, NULL, '2026-03-15 10:15:00', 11242.78, 'paid', '2026-03-15 02:15:00', NULL, NULL, NULL),
(312, 2, NULL, '2026-03-24 11:15:00', 11910.84, 'paid', '2026-03-24 03:15:00', NULL, NULL, NULL),
(313, 2, NULL, '2026-04-06 09:15:00', 11154.43, 'paid', '2026-04-06 01:15:00', NULL, NULL, NULL),
(314, 2, NULL, '2026-04-15 10:15:00', 11817.86, 'paid', '2026-04-15 02:15:00', NULL, NULL, NULL),
(315, 2, NULL, '2026-04-24 11:15:00', 11977.15, 'paid', '2026-04-24 03:15:00', NULL, NULL, NULL),
(316, 2, NULL, '2026-05-06 09:15:00', 11330.87, 'paid', '2026-05-06 01:15:00', NULL, NULL, NULL),
(317, 2, NULL, '2026-05-15 10:15:00', 11483.37, 'paid', '2026-05-15 02:15:00', NULL, NULL, NULL),
(318, 2, NULL, '2026-05-24 11:15:00', 9745.90, 'paid', '2026-05-24 03:15:00', NULL, NULL, NULL),
(319, 2, NULL, '2026-06-06 09:15:00', 10747.16, 'paid', '2026-06-06 01:15:00', NULL, NULL, NULL),
(320, 2, NULL, '2026-06-15 10:15:00', 9121.26, 'paid', '2026-06-15 02:15:00', NULL, NULL, NULL),
(321, 2, NULL, '2026-06-24 11:15:00', 7796.64, 'paid', '2026-06-24 03:15:00', NULL, NULL, NULL),
(322, 2, NULL, '2026-07-06 09:15:00', 8480.63, 'paid', '2026-07-06 01:15:00', NULL, NULL, NULL),
(323, 2, NULL, '2026-07-15 10:15:00', 7249.39, 'paid', '2026-07-15 02:15:00', NULL, NULL, NULL),
(324, 2, NULL, '2026-07-24 11:15:00', 6349.77, 'paid', '2026-07-24 03:15:00', NULL, NULL, NULL),
(325, 2, NULL, '2026-08-06 09:15:00', 6859.77, 'paid', '2026-08-06 01:15:00', NULL, NULL, NULL),
(326, 2, NULL, '2026-08-15 10:15:00', 6008.41, 'paid', '2026-08-15 02:15:00', NULL, NULL, NULL),
(327, 2, NULL, '2026-08-24 11:15:00', 6741.14, 'paid', '2026-08-24 03:15:00', NULL, NULL, NULL),
(331, 2, NULL, '2026-09-01 23:37:18', 12480.00, 'paid', '2026-09-01 15:37:18', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sales_forecast`
--

CREATE TABLE `sales_forecast` (
  `forecast_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `forecasting_period` enum('daily','weekly','monthly') DEFAULT NULL,
  `forecasting_start_date` date DEFAULT NULL,
  `forecasting_end_date` date DEFAULT NULL,
  `predict_qty_kg` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `generated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales_items`
--

CREATE TABLE `sales_items` (
  `sales_item_id` int(11) NOT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `qty_kg` decimal(10,2) DEFAULT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `line_total` decimal(10,2) DEFAULT NULL,
  `unit_type` enum('kg','sack') DEFAULT 'kg',
  `qty_input` decimal(12,2) DEFAULT 0.00,
  `discount_kg` decimal(12,2) DEFAULT 0.00,
  `regular_kg` decimal(12,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_items`
--

INSERT INTO `sales_items` (`sales_item_id`, `sale_id`, `product_id`, `batch_id`, `qty_kg`, `unit_price`, `line_total`, `unit_type`, `qty_input`, `discount_kg`, `regular_kg`) VALUES
(1, 2, 1, NULL, 1.00, 20000.00, 20000.00, 'kg', 0.00, 0.00, 0.00),
(2, 3, 1, NULL, 500.00, 20000.00, 10000000.00, 'kg', 0.00, 0.00, 0.00),
(3, 4, 2, NULL, 1.00, 18000.00, 18000.00, 'kg', 0.00, 0.00, 0.00),
(6, 8, 1, NULL, 5.00, 68.00, 340.00, 'kg', 0.00, 0.00, 0.00),
(7, 9, 2, NULL, 10.00, 55.00, 550.00, 'kg', 0.00, 0.00, 0.00),
(8, 11, 2, NULL, 5.00, 55.00, 275.00, 'kg', 0.00, 0.00, 0.00),
(14, 15, 1, NULL, 5.00, 68.00, 340.00, 'kg', 0.00, 0.00, 0.00),
(15, 15, 1, NULL, 5.00, 68.00, 340.00, 'kg', 0.00, 0.00, 0.00),
(16, 16, 2, NULL, 33.00, 55.00, 1815.00, 'kg', 0.00, 0.00, 0.00),
(17, 16, 2, NULL, 33.00, 55.00, 1815.00, 'kg', 0.00, 0.00, 0.00),
(18, 17, 1, NULL, 10.00, 68.00, 680.00, 'kg', 0.00, 0.00, 0.00),
(19, 17, 1, NULL, 10.00, 68.00, 680.00, 'kg', 0.00, 0.00, 0.00),
(20, 18, 6, NULL, 20.00, 85.00, 1700.00, 'kg', 0.00, 0.00, 0.00),
(21, 18, 6, NULL, 20.00, 85.00, 1700.00, 'kg', 0.00, 0.00, 0.00),
(22, 19, 2, NULL, 10.00, 55.00, 550.00, 'kg', 0.00, 0.00, 0.00),
(23, 19, 2, NULL, 10.00, 55.00, 550.00, 'kg', 0.00, 0.00, 0.00),
(24, 20, 2, NULL, 25.00, 55.00, 1375.00, 'kg', 0.00, 0.00, 0.00),
(25, 20, 2, NULL, 25.00, 55.00, 1375.00, 'kg', 0.00, 0.00, 0.00),
(26, 21, 2, NULL, 25.00, 55.00, 1375.00, 'kg', 0.00, 0.00, 0.00),
(27, 21, 2, NULL, 25.00, 55.00, 1375.00, 'kg', 0.00, 0.00, 0.00),
(28, 22, 2, NULL, 25.00, 55.00, 1375.00, 'kg', 0.00, 0.00, 0.00),
(29, 22, 2, NULL, 25.00, 55.00, 1375.00, 'kg', 0.00, 0.00, 0.00),
(30, 24, 6, NULL, 479.00, 85.00, 40715.00, 'kg', 0.00, 0.00, 0.00),
(31, 24, 6, NULL, 479.00, 85.00, 40715.00, 'kg', 0.00, 0.00, 0.00),
(32, 26, 1, NULL, 10.00, 68.00, 680.00, 'kg', 0.00, 0.00, 0.00),
(33, 26, 1, NULL, 10.00, 68.00, 680.00, 'kg', 0.00, 0.00, 0.00),
(34, 28, 2, NULL, 10.00, 55.00, 550.00, 'kg', 0.00, 0.00, 0.00),
(35, 30, 10, NULL, 50.00, 30.00, 1500.00, 'kg', 0.00, 0.00, 0.00),
(36, 31, 2, NULL, 1.00, 55.00, 55.00, 'kg', 0.00, 0.00, 0.00),
(37, 32, 2, NULL, 7.00, 55.00, 385.00, 'kg', 0.00, 0.00, 0.00),
(38, 33, 2, NULL, 5.00, 55.00, 275.00, 'kg', 0.00, 0.00, 0.00),
(39, 34, 12, NULL, 5.00, 53.00, 265.00, 'kg', 0.00, 0.00, 0.00),
(40, 35, 10, NULL, 2.00, 30.00, 60.00, 'kg', 0.00, 0.00, 0.00),
(41, 36, 6, NULL, 1.00, 85.00, 85.00, 'kg', 0.00, 0.00, 0.00),
(42, 37, 9, NULL, 10.00, 25.00, 250.00, 'kg', 0.00, 0.00, 0.00),
(43, 38, 12, NULL, 5.00, 53.00, 265.00, 'kg', 0.00, 0.00, 0.00),
(44, 39, 10, NULL, 8.00, 30.00, 240.00, 'kg', 0.00, 0.00, 0.00),
(45, 40, 9, NULL, 5.00, 25.00, 125.00, 'kg', 0.00, 0.00, 0.00),
(46, 41, 10, NULL, 10.00, 30.00, 300.00, 'kg', 0.00, 0.00, 0.00),
(47, 42, 2, NULL, 2.00, 55.00, 110.00, 'kg', 0.00, 0.00, 0.00),
(48, 43, 2, NULL, 10.00, 55.00, 550.00, 'kg', 0.00, 0.00, 0.00),
(49, 44, 10, NULL, 4.00, 30.00, 120.00, 'kg', 0.00, 0.00, 0.00),
(50, 45, 9, NULL, 2.00, 25.00, 50.00, 'kg', 0.00, 0.00, 0.00),
(51, 46, 10, NULL, 6.00, 30.00, 180.00, 'kg', 0.00, 0.00, 0.00),
(52, 47, 2, NULL, 10.00, 55.00, 550.00, 'kg', 0.00, 0.00, 0.00),
(53, 50, 11, NULL, 9.00, 80.00, 720.00, 'kg', 0.00, 0.00, 0.00),
(54, 51, 10, NULL, 40.00, 30.00, 1200.00, 'kg', 0.00, 0.00, 0.00),
(55, 52, 12, NULL, 10.00, 53.00, 530.00, 'kg', 0.00, 0.00, 0.00),
(56, 53, 9, NULL, 3.00, 25.00, 75.00, 'kg', 0.00, 0.00, 0.00),
(57, 54, 9, NULL, 10.00, 25.00, 250.00, 'kg', 0.00, 0.00, 0.00),
(58, 55, 2, NULL, 10.00, 55.00, 550.00, 'kg', 0.00, 0.00, 0.00),
(59, 57, 13, NULL, 10.00, 47.00, 470.00, 'kg', 0.00, 0.00, 0.00),
(60, 58, 10, NULL, 10.00, 30.00, 300.00, 'kg', 0.00, 0.00, 0.00),
(61, 59, 12, NULL, 10.00, 53.00, 530.00, 'kg', 0.00, 0.00, 0.00),
(62, 60, 11, NULL, 10.00, 80.00, 800.00, 'kg', 0.00, 0.00, 0.00),
(63, 61, 10, NULL, 10.00, 30.00, 300.00, 'kg', 0.00, 0.00, 0.00),
(64, 63, 9, NULL, 20.00, 25.00, 500.00, 'kg', 0.00, 0.00, 0.00),
(65, 64, 10, NULL, 20.00, 30.00, 600.00, 'kg', 0.00, 0.00, 0.00),
(66, 65, 2, NULL, 10.00, 55.00, 550.00, 'kg', 0.00, 0.00, 0.00),
(67, 66, 4, NULL, 10.00, 75.00, 750.00, 'kg', 0.00, 0.00, 0.00),
(68, 67, 11, NULL, 10.00, 54.00, 540.00, 'kg', 0.00, 0.00, 0.00),
(69, 68, 15, NULL, 2.00, 44.67, 89.34, 'kg', 0.00, 0.00, 0.00),
(70, 69, 5, NULL, 10.00, 50.00, 500.00, 'kg', 0.00, 0.00, 0.00),
(71, 70, 16, NULL, 10.00, 24.20, 242.00, 'kg', 0.00, 0.00, 0.00),
(72, 71, 1, NULL, 10.00, 40.00, 400.00, 'kg', 0.00, 0.00, 0.00),
(73, 73, 2, NULL, 100.00, 2400.00, 4800.00, 'kg', 0.00, 0.00, 0.00),
(74, 74, 6, NULL, 15.00, 48.00, 720.00, 'kg', 0.00, 0.00, 0.00),
(75, 75, 6, NULL, 5.00, 48.00, 240.00, 'kg', 0.00, 0.00, 0.00),
(76, 76, 5, NULL, 50.00, 2550.00, 2550.00, 'kg', 0.00, 0.00, 0.00),
(77, 77, 10, NULL, 20.00, 500.00, 1000.00, 'kg', 0.00, 0.00, 0.00),
(78, 78, 12, NULL, 1.00, 54.00, 54.00, 'kg', 0.00, 0.00, 0.00),
(79, 79, 5, NULL, 50.00, 2550.00, 2550.00, 'kg', 0.00, 0.00, 0.00),
(80, 80, 2, NULL, 5.00, 49.00, 245.00, 'kg', 0.00, 0.00, 0.00),
(81, 81, 18, NULL, 50.00, 1300.00, 1300.00, 'kg', 0.00, 0.00, 0.00),
(82, 82, 11, NULL, 10.00, 600.00, 600.00, 'kg', 0.00, 0.00, 0.00),
(83, 83, 4, NULL, 10.00, 60.00, 600.00, 'kg', 0.00, 0.00, 0.00),
(84, 84, 8, NULL, 50.00, 1000.00, 1000.00, 'kg', 0.00, 0.00, 0.00),
(85, 85, 8, NULL, 50.00, 1000.00, 1000.00, 'kg', 0.00, 0.00, 0.00),
(86, 86, 13, NULL, 50.00, 2450.00, 2450.00, 'kg', 0.00, 0.00, 0.00),
(87, 87, 6, NULL, 2.00, 48.00, 96.00, 'kg', 0.00, 0.00, 0.00),
(88, 88, 14, NULL, 20.00, 2320.00, 4640.00, 'kg', 0.00, 0.00, 0.00),
(89, 89, 16, NULL, 50.00, 1000.00, 1000.00, 'kg', 0.00, 0.00, 0.00),
(90, 90, 9, NULL, 10.00, 2350.00, 2350.00, 'kg', 0.00, 0.00, 0.00),
(91, 91, 9, NULL, 30.00, 2350.00, 7050.00, 'kg', 0.00, 0.00, 0.00),
(92, 92, 15, NULL, 75.00, 600.00, 3000.00, 'kg', 0.00, 0.00, 0.00),
(93, 93, 2, NULL, 250.00, 2400.00, 12000.00, 'kg', 0.00, 0.00, 0.00),
(94, 94, 15, NULL, 60.00, 600.00, 2400.00, 'kg', 0.00, 0.00, 0.00),
(95, 95, 10, NULL, 10.00, 500.00, 500.00, 'kg', 0.00, 0.00, 0.00),
(96, 96, 25, NULL, 1.00, 30.00, 30.00, 'kg', 1.00, 1.00, 0.00),
(97, 97, 24, NULL, 50.00, 2500.00, 2500.00, 'sack', 1.00, 0.00, 50.00),
(98, 98, 1, NULL, 2.00, 40.00, 80.00, 'kg', 2.00, 0.00, 2.00),
(99, 99, 11, NULL, 1.00, 63.25, 63.25, 'kg', 1.00, 0.00, 1.00),
(100, 100, 11, NULL, 10.00, 600.00, 632.50, 'sack', 1.00, 0.00, 10.00),
(101, 101, 23, NULL, 50.00, 2300.00, 2300.00, 'sack', 1.00, 0.00, 50.00),
(102, 102, 24, NULL, 1.00, 50.00, 50.00, 'kg', 1.00, 0.00, 1.00),
(103, 103, 1, NULL, 50.00, 2300.00, 2000.00, 'sack', 1.00, 0.00, 50.00),
(104, 104, 8, NULL, 50.00, 1000.00, 2100.00, 'sack', 1.00, 0.00, 50.00),
(105, 105, 12, NULL, 50.00, 1000.00, 2015.00, 'sack', 1.00, 0.00, 50.00),
(106, 106, 9, NULL, 10.00, 2350.00, 450.00, 'sack', 1.00, 0.00, 10.00),
(107, 107, 24, NULL, 50.00, 2500.00, 2500.00, 'sack', 1.00, 0.00, 50.00),
(108, 108, 12, NULL, 1.00, 40.30, 40.30, 'kg', 1.00, 0.00, 1.00),
(109, 109, 23, NULL, 1.00, 46.00, 46.00, 'kg', 1.00, 0.00, 1.00),
(110, 110, 22, NULL, 50.00, 2300.00, 3080.00, 'sack', 1.00, 0.00, 50.00),
(111, 111, 9, NULL, 2.00, 45.00, 90.00, 'kg', 2.00, 0.00, 2.00),
(112, 112, 14, NULL, 10.00, 900.00, 500.00, 'sack', 1.00, 0.00, 10.00),
(113, 113, 14, NULL, 50.00, 900.00, 2500.00, 'sack', 5.00, 0.00, 50.00),
(114, 114, 2, 2, 50.00, 3150.00, 3150.00, 'sack', 1.00, 0.00, 50.00),
(115, 115, 1, 1, 50.00, 3050.00, 3050.00, 'sack', 1.00, 0.00, 50.00),
(116, 116, 2, 2, 50.00, 3150.00, 3150.00, 'sack', 1.00, 0.00, 50.00),
(117, 117, 21, 18, 50.00, 3000.00, 3000.00, 'sack', 1.00, 0.00, 50.00),
(118, 118, 1, 1, 50.00, 3050.00, 3050.00, 'sack', 1.00, 0.00, 50.00),
(119, 119, 6, 24, 25.00, 1800.00, 1800.00, 'sack', 1.00, 0.00, 25.00),
(120, 120, 22, 19, 50.00, 2464.00, 2464.00, 'sack', 1.00, 50.00, 0.00),
(121, 121, 5, 27, 250.00, 2800.00, 14000.00, 'sack', 5.00, 0.00, 250.00),
(122, 122, 5, 4, 15.00, 61.25, 918.75, 'kg', 15.00, 0.00, 15.00),
(123, 123, 5, 28, 50.00, 2300.00, 2300.00, 'sack', 1.00, 0.00, 50.00),
(124, 124, 7, 6, 25.00, 1000.00, 1000.00, 'sack', 1.00, 0.00, 25.00),
(125, 125, 13, 12, 50.00, 2500.00, 2500.00, 'sack', 1.00, 0.00, 50.00),
(126, 125, 7, 37, 25.00, 1125.00, 1125.00, 'sack', 1.00, 0.00, 25.00),
(127, 126, 13, 12, 100.00, 2500.00, 5000.00, 'sack', 2.00, 0.00, 100.00),
(128, 127, 11, 10, 10.00, 632.50, 632.50, 'sack', 1.00, 0.00, 10.00),
(129, 128, 22, 19, 50.00, 3080.00, 3080.00, 'sack', 1.00, 0.00, 50.00),
(130, 129, 11, 10, 10.00, 632.50, 632.50, 'sack', 1.00, 0.00, 10.00),
(131, 130, 11, 10, 10.00, 632.50, 632.50, 'sack', 1.00, 0.00, 10.00),
(132, 131, 26, 23, 50.00, 2500.00, 2500.00, 'sack', 1.00, 0.00, 50.00),
(133, 132, 26, 23, 50.00, 2500.00, 2500.00, 'sack', 1.00, 0.00, 50.00),
(134, 133, 9, 8, 10.00, 450.00, 450.00, 'sack', 1.00, 0.00, 10.00),
(135, 133, 14, 13, 50.00, 500.00, 2500.00, 'sack', 5.00, 0.00, 50.00),
(136, 134, 9, 8, 1.00, 45.00, 45.00, 'kg', 1.00, 0.00, 1.00),
(137, 135, 11, 10, 10.00, 632.50, 632.50, 'sack', 1.00, 0.00, 10.00),
(138, 136, 13, 12, 50.00, 2500.00, 2500.00, 'sack', 1.00, 0.00, 50.00),
(139, 137, 22, 19, 100.00, 2450.00, 4900.00, 'sack', 2.00, 100.00, 0.00),
(140, 138, 12, 11, 50.00, 2200.00, 2200.00, 'sack', 1.00, 50.00, 0.00),
(141, 139, 13, 40, 50.00, 2950.00, 2950.00, 'sack', 1.00, 0.00, 50.00),
(142, 140, 9, 8, 1.00, 45.00, 45.00, 'kg', 1.00, 0.00, 1.00),
(143, 141, 13, 40, 50.00, 2950.00, 2950.00, 'sack', 1.00, 0.00, 50.00),
(144, 141, 22, 19, 50.00, 3080.00, 3080.00, 'sack', 1.00, 0.00, 50.00),
(145, 142, 28, 39, 50.00, 2040.00, 2040.00, 'sack', 1.00, 50.00, 0.00),
(146, 143, 30, 61, 50.00, 2800.00, 2800.00, 'sack', 1.00, 0.00, 50.00),
(147, 144, 9, 8, 50.00, 450.00, 2250.00, 'sack', 5.00, 0.00, 50.00),
(148, 145, 29, 60, 250.00, 2700.00, 13500.00, 'sack', 5.00, 0.00, 250.00),
(149, 146, 16, 15, 250.00, 2700.00, 13500.00, 'sack', 5.00, 0.00, 250.00),
(150, 147, 7, 6, 125.00, 1000.00, 5000.00, 'sack', 5.00, 0.00, 125.00),
(151, 148, 11, 10, 29.00, 63.25, 1834.25, 'kg', 29.00, 0.00, 29.00),
(152, 149, 9, 8, 1.00, 45.00, 45.00, 'kg', 1.00, 0.00, 1.00),
(153, 150, 14, 13, 500.00, 500.00, 25000.00, 'sack', 50.00, 0.00, 500.00),
(154, 151, 10, 9, 400.00, 500.00, 20000.00, 'sack', 40.00, 0.00, 400.00),
(155, 152, 9, 8, 1.00, 45.00, 45.00, 'kg', 1.00, 0.00, 1.00),
(156, 153, 16, 15, 1.00, 54.00, 54.00, 'kg', 1.00, 0.00, 1.00),
(157, 154, 16, 15, 50.00, 2700.00, 2700.00, 'sack', 1.00, 0.00, 50.00),
(158, 155, 29, 63, 250.00, 2700.00, 13500.00, 'sack', 5.00, 0.00, 250.00),
(159, 156, 29, 64, 50.00, 2450.00, 2450.00, 'sack', 1.00, 0.00, 50.00),
(160, 157, 27, 25, 1.00, 66.00, 66.00, 'kg', 1.00, 0.00, 1.00),
(161, 158, 9, 8, 1.00, 45.00, 45.00, 'kg', 1.00, 0.00, 1.00),
(162, 159, 8, 7, 450.00, 3000.00, 27000.00, 'sack', 9.00, 0.00, 450.00),
(163, 160, 1, NULL, 19.44, 40.00, 777.60, 'kg', 19.44, 0.00, 19.44),
(164, 160, 2, NULL, 23.76, 40.00, 950.40, 'kg', 23.76, 0.00, 23.76),
(165, 160, 4, NULL, 28.08, 60.00, 1684.80, 'kg', 28.08, 0.00, 28.08),
(166, 161, 2, NULL, 23.76, 40.00, 950.40, 'kg', 23.76, 0.00, 23.76),
(167, 161, 4, NULL, 28.08, 60.00, 1684.80, 'kg', 28.08, 0.00, 28.08),
(168, 161, 5, NULL, 32.40, 46.00, 1490.40, 'kg', 32.40, 0.00, 32.40),
(169, 162, 4, NULL, 28.08, 60.00, 1684.80, 'kg', 28.08, 0.00, 28.08),
(170, 162, 5, NULL, 32.40, 46.00, 1490.40, 'kg', 32.40, 0.00, 32.40),
(171, 162, 6, NULL, 36.72, 52.00, 1909.44, 'kg', 36.72, 0.00, 36.72),
(172, 163, 2, NULL, 25.35, 40.16, 1018.06, 'kg', 25.35, 0.00, 25.35),
(173, 163, 4, NULL, 29.96, 60.24, 1804.79, 'kg', 29.96, 0.00, 29.96),
(174, 163, 5, NULL, 34.57, 46.18, 1596.44, 'kg', 34.57, 0.00, 34.57),
(175, 164, 4, NULL, 29.96, 60.24, 1804.79, 'kg', 29.96, 0.00, 29.96),
(176, 164, 5, NULL, 34.57, 46.18, 1596.44, 'kg', 34.57, 0.00, 34.57),
(177, 164, 6, NULL, 39.18, 52.21, 2045.59, 'kg', 39.18, 0.00, 39.18),
(178, 165, 5, NULL, 34.57, 46.18, 1596.44, 'kg', 34.57, 0.00, 34.57),
(179, 165, 6, NULL, 39.18, 52.21, 2045.59, 'kg', 39.18, 0.00, 39.18),
(180, 165, 7, NULL, 43.78, 50.20, 2197.76, 'kg', 43.78, 0.00, 43.78),
(181, 166, 4, NULL, 30.88, 60.48, 1867.62, 'kg', 30.88, 0.00, 30.88),
(182, 166, 5, NULL, 35.64, 46.37, 1652.63, 'kg', 35.64, 0.00, 35.64),
(183, 166, 6, NULL, 40.39, 52.42, 2117.24, 'kg', 40.39, 0.00, 40.39),
(184, 167, 5, NULL, 35.64, 46.37, 1652.63, 'kg', 35.64, 0.00, 35.64),
(185, 167, 6, NULL, 40.39, 52.42, 2117.24, 'kg', 40.39, 0.00, 40.39),
(186, 167, 7, NULL, 45.14, 50.40, 2275.06, 'kg', 45.14, 0.00, 45.14),
(187, 168, 6, NULL, 40.39, 52.42, 2117.24, 'kg', 40.39, 0.00, 40.39),
(188, 168, 7, NULL, 45.14, 50.40, 2275.06, 'kg', 45.14, 0.00, 45.14),
(189, 168, 1, NULL, 49.89, 40.32, 2011.56, 'kg', 49.89, 0.00, 49.89),
(190, 169, 5, NULL, 35.39, 46.55, 1647.40, 'kg', 35.39, 0.00, 35.39),
(191, 169, 6, NULL, 40.10, 52.62, 2110.06, 'kg', 40.10, 0.00, 40.10),
(192, 169, 7, NULL, 44.82, 50.60, 2267.89, 'kg', 44.82, 0.00, 44.82),
(193, 170, 6, NULL, 40.10, 52.62, 2110.06, 'kg', 40.10, 0.00, 40.10),
(194, 170, 7, NULL, 44.82, 50.60, 2267.89, 'kg', 44.82, 0.00, 44.82),
(195, 170, 1, NULL, 49.54, 40.48, 2005.38, 'kg', 49.54, 0.00, 49.54),
(196, 171, 7, NULL, 44.82, 50.60, 2267.89, 'kg', 44.82, 0.00, 44.82),
(197, 171, 1, NULL, 49.54, 40.48, 2005.38, 'kg', 49.54, 0.00, 49.54),
(198, 171, 2, NULL, 54.26, 40.48, 2196.44, 'kg', 54.26, 0.00, 54.26),
(199, 172, 6, NULL, 38.48, 52.83, 2032.90, 'kg', 38.48, 0.00, 38.48),
(200, 172, 7, NULL, 43.01, 50.80, 2184.91, 'kg', 43.01, 0.00, 43.01),
(201, 172, 1, NULL, 47.54, 40.64, 1932.03, 'kg', 47.54, 0.00, 47.54),
(202, 173, 7, NULL, 43.01, 50.80, 2184.91, 'kg', 43.01, 0.00, 43.01),
(203, 173, 1, NULL, 47.54, 40.64, 1932.03, 'kg', 47.54, 0.00, 47.54),
(204, 173, 2, NULL, 52.06, 40.64, 2115.72, 'kg', 52.06, 0.00, 52.06),
(205, 174, 1, NULL, 47.54, 40.64, 1932.03, 'kg', 47.54, 0.00, 47.54),
(206, 174, 2, NULL, 52.06, 40.64, 2115.72, 'kg', 52.06, 0.00, 52.06),
(207, 174, 4, NULL, 20.37, 60.96, 1241.76, 'kg', 20.37, 0.00, 20.37),
(208, 175, 7, NULL, 40.28, 51.00, 2054.28, 'kg', 40.28, 0.00, 40.28),
(209, 175, 1, NULL, 44.52, 40.80, 1816.42, 'kg', 44.52, 0.00, 44.52),
(210, 175, 2, NULL, 48.76, 40.80, 1989.41, 'kg', 48.76, 0.00, 48.76),
(211, 176, 1, NULL, 44.52, 40.80, 1816.42, 'kg', 44.52, 0.00, 44.52),
(212, 176, 2, NULL, 48.76, 40.80, 1989.41, 'kg', 48.76, 0.00, 48.76),
(213, 176, 4, NULL, 19.08, 61.20, 1167.70, 'kg', 19.08, 0.00, 19.08),
(214, 177, 2, NULL, 48.76, 40.80, 1989.41, 'kg', 48.76, 0.00, 48.76),
(215, 177, 4, NULL, 19.08, 61.20, 1167.70, 'kg', 19.08, 0.00, 19.08),
(216, 177, 5, NULL, 23.32, 46.92, 1094.17, 'kg', 23.32, 0.00, 23.32),
(217, 178, 1, NULL, 41.42, 40.96, 1696.56, 'kg', 41.42, 0.00, 41.42),
(218, 178, 2, NULL, 45.37, 40.96, 1858.36, 'kg', 45.37, 0.00, 45.37),
(219, 178, 4, NULL, 17.75, 61.44, 1090.56, 'kg', 17.75, 0.00, 17.75),
(220, 179, 2, NULL, 45.37, 40.96, 1858.36, 'kg', 45.37, 0.00, 45.37),
(221, 179, 4, NULL, 17.75, 61.44, 1090.56, 'kg', 17.75, 0.00, 17.75),
(222, 179, 5, NULL, 21.70, 47.10, 1022.07, 'kg', 21.70, 0.00, 21.70),
(223, 180, 4, NULL, 17.75, 61.44, 1090.56, 'kg', 17.75, 0.00, 17.75),
(224, 180, 5, NULL, 21.70, 47.10, 1022.07, 'kg', 21.70, 0.00, 21.70),
(225, 180, 6, NULL, 25.64, 53.25, 1365.33, 'kg', 25.64, 0.00, 25.64),
(226, 181, 2, NULL, 42.95, 41.12, 1766.10, 'kg', 42.95, 0.00, 42.95),
(227, 181, 4, NULL, 16.81, 61.68, 1036.84, 'kg', 16.81, 0.00, 16.81),
(228, 181, 5, NULL, 20.54, 47.29, 971.34, 'kg', 20.54, 0.00, 20.54),
(229, 182, 4, NULL, 16.81, 61.68, 1036.84, 'kg', 16.81, 0.00, 16.81),
(230, 182, 5, NULL, 20.54, 47.29, 971.34, 'kg', 20.54, 0.00, 20.54),
(231, 182, 6, NULL, 24.28, 53.46, 1298.01, 'kg', 24.28, 0.00, 24.28),
(232, 183, 5, NULL, 20.54, 47.29, 971.34, 'kg', 20.54, 0.00, 20.54),
(233, 183, 6, NULL, 24.28, 53.46, 1298.01, 'kg', 24.28, 0.00, 24.28),
(234, 183, 7, NULL, 28.01, 51.40, 1439.71, 'kg', 28.01, 0.00, 28.01),
(235, 184, 4, NULL, 16.57, 61.92, 1026.01, 'kg', 16.57, 0.00, 16.57),
(236, 184, 5, NULL, 20.25, 47.47, 961.27, 'kg', 20.25, 0.00, 20.25),
(237, 184, 6, NULL, 23.94, 53.66, 1284.62, 'kg', 23.94, 0.00, 23.94),
(238, 185, 5, NULL, 20.25, 47.47, 961.27, 'kg', 20.25, 0.00, 20.25),
(239, 185, 6, NULL, 23.94, 53.66, 1284.62, 'kg', 23.94, 0.00, 23.94),
(240, 185, 7, NULL, 27.62, 51.60, 1425.19, 'kg', 27.62, 0.00, 27.62),
(241, 186, 6, NULL, 23.94, 53.66, 1284.62, 'kg', 23.94, 0.00, 23.94),
(242, 186, 7, NULL, 27.62, 51.60, 1425.19, 'kg', 27.62, 0.00, 27.62),
(243, 186, 1, NULL, 31.30, 41.28, 1292.06, 'kg', 31.30, 0.00, 31.30),
(244, 187, 5, NULL, 21.00, 47.66, 1000.86, 'kg', 21.00, 0.00, 21.00),
(245, 187, 6, NULL, 24.82, 53.87, 1337.05, 'kg', 24.82, 0.00, 24.82),
(246, 187, 7, NULL, 28.63, 51.80, 1483.03, 'kg', 28.63, 0.00, 28.63),
(247, 188, 6, NULL, 24.82, 53.87, 1337.05, 'kg', 24.82, 0.00, 24.82),
(248, 188, 7, NULL, 28.63, 51.80, 1483.03, 'kg', 28.63, 0.00, 28.63),
(249, 188, 1, NULL, 32.45, 41.44, 1344.73, 'kg', 32.45, 0.00, 32.45),
(250, 189, 7, NULL, 28.63, 51.80, 1483.03, 'kg', 28.63, 0.00, 28.63),
(251, 189, 1, NULL, 32.45, 41.44, 1344.73, 'kg', 32.45, 0.00, 32.45),
(252, 189, 2, NULL, 36.27, 41.44, 1503.03, 'kg', 36.27, 0.00, 36.27),
(253, 190, 6, NULL, 26.79, 54.08, 1448.80, 'kg', 26.79, 0.00, 26.79),
(254, 190, 7, NULL, 30.91, 52.00, 1607.32, 'kg', 30.91, 0.00, 30.91),
(255, 190, 1, NULL, 35.03, 41.60, 1457.25, 'kg', 35.03, 0.00, 35.03),
(256, 191, 7, NULL, 30.91, 52.00, 1607.32, 'kg', 30.91, 0.00, 30.91),
(257, 191, 1, NULL, 35.03, 41.60, 1457.25, 'kg', 35.03, 0.00, 35.03),
(258, 191, 2, NULL, 39.16, 41.60, 1629.06, 'kg', 39.16, 0.00, 39.16),
(259, 192, 1, NULL, 35.03, 41.60, 1457.25, 'kg', 35.03, 0.00, 35.03),
(260, 192, 2, NULL, 39.16, 41.60, 1629.06, 'kg', 39.16, 0.00, 39.16),
(261, 192, 4, NULL, 43.28, 62.40, 2700.67, 'kg', 43.28, 0.00, 43.28),
(262, 193, 7, NULL, 33.96, 52.20, 1772.71, 'kg', 33.96, 0.00, 33.96),
(263, 193, 1, NULL, 38.49, 41.76, 1607.34, 'kg', 38.49, 0.00, 38.49),
(264, 193, 2, NULL, 43.02, 41.76, 1796.52, 'kg', 43.02, 0.00, 43.02),
(265, 194, 1, NULL, 38.49, 41.76, 1607.34, 'kg', 38.49, 0.00, 38.49),
(266, 194, 2, NULL, 43.02, 41.76, 1796.52, 'kg', 43.02, 0.00, 43.02),
(267, 194, 4, NULL, 47.54, 62.64, 2977.91, 'kg', 47.54, 0.00, 47.54),
(268, 195, 2, NULL, 43.02, 41.76, 1796.52, 'kg', 43.02, 0.00, 43.02),
(269, 195, 4, NULL, 47.54, 62.64, 2977.91, 'kg', 47.54, 0.00, 47.54),
(270, 195, 5, NULL, 52.07, 48.02, 2500.40, 'kg', 52.07, 0.00, 52.07),
(271, 196, 1, NULL, 42.01, 41.92, 1761.06, 'kg', 42.01, 0.00, 42.01),
(272, 196, 2, NULL, 46.95, 41.92, 1968.14, 'kg', 46.95, 0.00, 46.95),
(273, 196, 4, NULL, 51.89, 62.88, 3262.84, 'kg', 51.89, 0.00, 51.89),
(274, 197, 2, NULL, 46.95, 41.92, 1968.14, 'kg', 46.95, 0.00, 46.95),
(275, 197, 4, NULL, 51.89, 62.88, 3262.84, 'kg', 51.89, 0.00, 51.89),
(276, 197, 5, NULL, 56.83, 48.21, 2739.77, 'kg', 56.83, 0.00, 56.83),
(277, 198, 4, NULL, 51.89, 62.88, 3262.84, 'kg', 51.89, 0.00, 51.89),
(278, 198, 5, NULL, 56.83, 48.21, 2739.77, 'kg', 56.83, 0.00, 56.83),
(279, 198, 6, NULL, 22.24, 54.50, 1212.08, 'kg', 22.24, 0.00, 22.24),
(280, 199, 2, NULL, 50.01, 42.08, 2104.42, 'kg', 50.01, 0.00, 50.01),
(281, 199, 4, NULL, 55.28, 63.12, 3489.27, 'kg', 55.28, 0.00, 55.28),
(282, 199, 5, NULL, 60.54, 48.39, 2929.53, 'kg', 60.54, 0.00, 60.54),
(283, 200, 4, NULL, 55.28, 63.12, 3489.27, 'kg', 55.28, 0.00, 55.28),
(284, 200, 5, NULL, 60.54, 48.39, 2929.53, 'kg', 60.54, 0.00, 60.54),
(285, 200, 6, NULL, 23.69, 54.70, 1295.84, 'kg', 23.69, 0.00, 23.69),
(286, 201, 5, NULL, 60.54, 48.39, 2929.53, 'kg', 60.54, 0.00, 60.54),
(287, 201, 6, NULL, 23.69, 54.70, 1295.84, 'kg', 23.69, 0.00, 23.69),
(288, 201, 7, NULL, 28.96, 52.60, 1523.30, 'kg', 28.96, 0.00, 28.96),
(289, 202, 4, NULL, 56.90, 63.36, 3605.18, 'kg', 56.90, 0.00, 56.90),
(290, 202, 5, NULL, 62.32, 48.58, 3027.51, 'kg', 62.32, 0.00, 62.32),
(291, 202, 6, NULL, 24.39, 54.91, 1339.25, 'kg', 24.39, 0.00, 24.39),
(292, 203, 5, NULL, 62.32, 48.58, 3027.51, 'kg', 62.32, 0.00, 62.32),
(293, 203, 6, NULL, 24.39, 54.91, 1339.25, 'kg', 24.39, 0.00, 24.39),
(294, 203, 7, NULL, 29.81, 52.80, 1573.97, 'kg', 29.81, 0.00, 29.81),
(295, 204, 6, NULL, 24.39, 54.91, 1339.25, 'kg', 24.39, 0.00, 24.39),
(296, 204, 7, NULL, 29.81, 52.80, 1573.97, 'kg', 29.81, 0.00, 29.81),
(297, 204, 1, NULL, 35.23, 42.24, 1488.12, 'kg', 35.23, 0.00, 35.23),
(298, 205, 5, NULL, 61.80, 48.76, 3013.37, 'kg', 61.80, 0.00, 61.80),
(299, 205, 6, NULL, 24.18, 55.12, 1332.80, 'kg', 24.18, 0.00, 24.18),
(300, 205, 7, NULL, 29.56, 53.00, 1566.68, 'kg', 29.56, 0.00, 29.56),
(301, 206, 6, NULL, 24.18, 55.12, 1332.80, 'kg', 24.18, 0.00, 24.18),
(302, 206, 7, NULL, 29.56, 53.00, 1566.68, 'kg', 29.56, 0.00, 29.56),
(303, 206, 1, NULL, 34.93, 42.40, 1481.03, 'kg', 34.93, 0.00, 34.93),
(304, 207, 7, NULL, 29.56, 53.00, 1566.68, 'kg', 29.56, 0.00, 29.56),
(305, 207, 1, NULL, 34.93, 42.40, 1481.03, 'kg', 34.93, 0.00, 34.93),
(306, 207, 2, NULL, 40.31, 42.40, 1709.14, 'kg', 40.31, 0.00, 40.31),
(307, 208, 6, NULL, 23.17, 55.33, 1282.00, 'kg', 23.17, 0.00, 23.17),
(308, 208, 7, NULL, 28.32, 53.20, 1506.62, 'kg', 28.32, 0.00, 28.32),
(309, 208, 1, NULL, 33.47, 42.56, 1424.48, 'kg', 33.47, 0.00, 33.47),
(310, 209, 7, NULL, 28.32, 53.20, 1506.62, 'kg', 28.32, 0.00, 28.32),
(311, 209, 1, NULL, 33.47, 42.56, 1424.48, 'kg', 33.47, 0.00, 33.47),
(312, 209, 2, NULL, 38.62, 42.56, 1643.67, 'kg', 38.62, 0.00, 38.62),
(313, 210, 1, NULL, 33.47, 42.56, 1424.48, 'kg', 33.47, 0.00, 33.47),
(314, 210, 2, NULL, 38.62, 42.56, 1643.67, 'kg', 38.62, 0.00, 38.62),
(315, 210, 4, NULL, 43.77, 63.84, 2794.28, 'kg', 43.77, 0.00, 43.77),
(316, 211, 7, NULL, 26.49, 53.40, 1414.57, 'kg', 26.49, 0.00, 26.49),
(317, 211, 1, NULL, 31.30, 42.72, 1337.14, 'kg', 31.30, 0.00, 31.30),
(318, 211, 2, NULL, 36.12, 42.72, 1543.05, 'kg', 36.12, 0.00, 36.12),
(319, 212, 1, NULL, 31.30, 42.72, 1337.14, 'kg', 31.30, 0.00, 31.30),
(320, 212, 2, NULL, 36.12, 42.72, 1543.05, 'kg', 36.12, 0.00, 36.12),
(321, 212, 4, NULL, 40.94, 64.08, 2623.44, 'kg', 40.94, 0.00, 40.94),
(322, 213, 2, NULL, 36.12, 42.72, 1543.05, 'kg', 36.12, 0.00, 36.12),
(323, 213, 4, NULL, 40.94, 64.08, 2623.44, 'kg', 40.94, 0.00, 40.94),
(324, 213, 5, NULL, 45.75, 49.13, 2247.70, 'kg', 45.75, 0.00, 45.75),
(325, 214, 1, NULL, 29.09, 42.88, 1247.38, 'kg', 29.09, 0.00, 29.09),
(326, 214, 2, NULL, 33.56, 42.88, 1439.05, 'kg', 33.56, 0.00, 33.56),
(327, 214, 4, NULL, 38.04, 64.32, 2446.73, 'kg', 38.04, 0.00, 38.04),
(328, 215, 2, NULL, 33.56, 42.88, 1439.05, 'kg', 33.56, 0.00, 33.56),
(329, 215, 4, NULL, 38.04, 64.32, 2446.73, 'kg', 38.04, 0.00, 38.04),
(330, 215, 5, NULL, 42.51, 49.31, 2096.17, 'kg', 42.51, 0.00, 42.51),
(331, 216, 4, NULL, 38.04, 64.32, 2446.73, 'kg', 38.04, 0.00, 38.04),
(332, 216, 5, NULL, 42.51, 49.31, 2096.17, 'kg', 42.51, 0.00, 42.51),
(333, 216, 6, NULL, 46.99, 55.74, 2619.22, 'kg', 46.99, 0.00, 46.99),
(334, 217, 2, NULL, 31.74, 43.04, 1366.09, 'kg', 31.74, 0.00, 31.74),
(335, 217, 4, NULL, 35.97, 64.56, 2322.22, 'kg', 35.97, 0.00, 35.97),
(336, 217, 5, NULL, 40.20, 49.50, 1989.90, 'kg', 40.20, 0.00, 40.20),
(337, 218, 4, NULL, 35.97, 64.56, 2322.22, 'kg', 35.97, 0.00, 35.97),
(338, 218, 5, NULL, 40.20, 49.50, 1989.90, 'kg', 40.20, 0.00, 40.20),
(339, 218, 6, NULL, 44.43, 55.95, 2485.86, 'kg', 44.43, 0.00, 44.43),
(340, 219, 5, NULL, 40.20, 49.50, 1989.90, 'kg', 40.20, 0.00, 40.20),
(341, 219, 6, NULL, 44.43, 55.95, 2485.86, 'kg', 44.43, 0.00, 44.43),
(342, 219, 7, NULL, 48.66, 53.80, 2617.91, 'kg', 48.66, 0.00, 48.66),
(343, 220, 4, NULL, 35.41, 64.80, 2294.57, 'kg', 35.41, 0.00, 35.41),
(344, 220, 5, NULL, 39.58, 49.68, 1966.33, 'kg', 39.58, 0.00, 39.58),
(345, 220, 6, NULL, 43.75, 56.16, 2457.00, 'kg', 43.75, 0.00, 43.75),
(346, 221, 5, NULL, 39.58, 49.68, 1966.33, 'kg', 39.58, 0.00, 39.58),
(347, 221, 6, NULL, 43.75, 56.16, 2457.00, 'kg', 43.75, 0.00, 43.75),
(348, 221, 7, NULL, 47.91, 54.00, 2587.14, 'kg', 47.91, 0.00, 47.91),
(349, 222, 6, NULL, 43.75, 56.16, 2457.00, 'kg', 43.75, 0.00, 43.75),
(350, 222, 7, NULL, 47.91, 54.00, 2587.14, 'kg', 47.91, 0.00, 47.91),
(351, 222, 1, NULL, 18.75, 43.20, 810.00, 'kg', 18.75, 0.00, 18.75),
(352, 223, 5, NULL, 40.98, 49.86, 2043.26, 'kg', 40.98, 0.00, 40.98),
(353, 223, 6, NULL, 45.30, 56.37, 2553.56, 'kg', 45.30, 0.00, 45.30),
(354, 223, 7, NULL, 49.61, 54.20, 2688.86, 'kg', 49.61, 0.00, 49.61),
(355, 224, 6, NULL, 45.30, 56.37, 2553.56, 'kg', 45.30, 0.00, 45.30),
(356, 224, 7, NULL, 49.61, 54.20, 2688.86, 'kg', 49.61, 0.00, 49.61),
(357, 224, 1, NULL, 19.41, 43.36, 841.62, 'kg', 19.41, 0.00, 19.41),
(358, 225, 7, NULL, 49.61, 54.20, 2688.86, 'kg', 49.61, 0.00, 49.61),
(359, 225, 1, NULL, 19.41, 43.36, 841.62, 'kg', 19.41, 0.00, 19.41),
(360, 225, 2, NULL, 23.73, 43.36, 1028.93, 'kg', 23.73, 0.00, 23.73),
(361, 226, 6, NULL, 48.84, 56.58, 2763.37, 'kg', 48.84, 0.00, 48.84),
(362, 226, 7, NULL, 53.49, 54.40, 2909.86, 'kg', 53.49, 0.00, 53.49),
(363, 226, 1, NULL, 20.93, 43.52, 910.87, 'kg', 20.93, 0.00, 20.93),
(364, 227, 7, NULL, 53.49, 54.40, 2909.86, 'kg', 53.49, 0.00, 53.49),
(365, 227, 1, NULL, 20.93, 43.52, 910.87, 'kg', 20.93, 0.00, 20.93),
(366, 227, 2, NULL, 25.58, 43.52, 1113.24, 'kg', 25.58, 0.00, 25.58),
(367, 228, 1, NULL, 20.93, 43.52, 910.87, 'kg', 20.93, 0.00, 20.93),
(368, 228, 2, NULL, 25.58, 43.52, 1113.24, 'kg', 25.58, 0.00, 25.58),
(369, 228, 4, NULL, 30.23, 65.28, 1973.41, 'kg', 30.23, 0.00, 30.23),
(370, 229, 7, NULL, 58.70, 54.60, 3205.02, 'kg', 58.70, 0.00, 58.70),
(371, 229, 1, NULL, 22.97, 43.68, 1003.33, 'kg', 22.97, 0.00, 22.97),
(372, 229, 2, NULL, 28.07, 43.68, 1226.10, 'kg', 28.07, 0.00, 28.07),
(373, 230, 1, NULL, 22.97, 43.68, 1003.33, 'kg', 22.97, 0.00, 22.97),
(374, 230, 2, NULL, 28.07, 43.68, 1226.10, 'kg', 28.07, 0.00, 28.07),
(375, 230, 4, NULL, 33.18, 65.52, 2173.95, 'kg', 33.18, 0.00, 33.18),
(376, 231, 2, NULL, 28.07, 43.68, 1226.10, 'kg', 28.07, 0.00, 28.07),
(377, 231, 4, NULL, 33.18, 65.52, 2173.95, 'kg', 33.18, 0.00, 33.18),
(378, 231, 5, NULL, 38.28, 50.23, 1922.80, 'kg', 38.28, 0.00, 38.28),
(379, 232, 1, NULL, 25.04, 43.84, 1097.75, 'kg', 25.04, 0.00, 25.04),
(380, 232, 2, NULL, 30.60, 43.84, 1341.50, 'kg', 30.60, 0.00, 30.60),
(381, 232, 4, NULL, 36.17, 65.76, 2378.54, 'kg', 36.17, 0.00, 36.17),
(382, 233, 2, NULL, 30.60, 43.84, 1341.50, 'kg', 30.60, 0.00, 30.60),
(383, 233, 4, NULL, 36.17, 65.76, 2378.54, 'kg', 36.17, 0.00, 36.17),
(384, 233, 5, NULL, 41.73, 50.42, 2104.03, 'kg', 41.73, 0.00, 41.73),
(385, 234, 4, NULL, 36.17, 65.76, 2378.54, 'kg', 36.17, 0.00, 36.17),
(386, 234, 5, NULL, 41.73, 50.42, 2104.03, 'kg', 41.73, 0.00, 41.73),
(387, 234, 6, NULL, 47.30, 56.99, 2695.63, 'kg', 47.30, 0.00, 47.30),
(388, 235, 2, NULL, 32.56, 44.00, 1432.64, 'kg', 32.56, 0.00, 32.56),
(389, 235, 4, NULL, 38.48, 66.00, 2539.68, 'kg', 38.48, 0.00, 38.48),
(390, 235, 5, NULL, 44.40, 50.60, 2246.64, 'kg', 44.40, 0.00, 44.40),
(391, 236, 4, NULL, 38.48, 66.00, 2539.68, 'kg', 38.48, 0.00, 38.48),
(392, 236, 5, NULL, 44.40, 50.60, 2246.64, 'kg', 44.40, 0.00, 44.40),
(393, 236, 6, NULL, 50.32, 57.20, 2878.30, 'kg', 50.32, 0.00, 50.32),
(394, 237, 5, NULL, 44.40, 50.60, 2246.64, 'kg', 44.40, 0.00, 44.40),
(395, 237, 6, NULL, 50.32, 57.20, 2878.30, 'kg', 50.32, 0.00, 50.32),
(396, 237, 7, NULL, 56.25, 55.00, 3093.75, 'kg', 56.25, 0.00, 56.25),
(397, 238, 4, NULL, 39.57, 66.24, 2621.12, 'kg', 39.57, 0.00, 39.57),
(398, 238, 5, NULL, 45.66, 50.78, 2318.61, 'kg', 45.66, 0.00, 45.66),
(399, 238, 6, NULL, 51.75, 57.41, 2970.97, 'kg', 51.75, 0.00, 51.75),
(400, 239, 5, NULL, 45.66, 50.78, 2318.61, 'kg', 45.66, 0.00, 45.66),
(401, 239, 6, NULL, 51.75, 57.41, 2970.97, 'kg', 51.75, 0.00, 51.75),
(402, 239, 7, NULL, 57.83, 55.20, 3192.22, 'kg', 57.83, 0.00, 57.83),
(403, 240, 6, NULL, 51.75, 57.41, 2970.97, 'kg', 51.75, 0.00, 51.75),
(404, 240, 7, NULL, 57.83, 55.20, 3192.22, 'kg', 57.83, 0.00, 57.83),
(405, 240, 1, NULL, 63.92, 44.16, 2822.71, 'kg', 63.92, 0.00, 63.92),
(406, 241, 5, NULL, 45.22, 50.97, 2304.86, 'kg', 45.22, 0.00, 45.22),
(407, 241, 6, NULL, 51.25, 57.62, 2953.03, 'kg', 51.25, 0.00, 51.25),
(408, 241, 7, NULL, 57.28, 55.40, 3173.31, 'kg', 57.28, 0.00, 57.28),
(409, 242, 6, NULL, 51.25, 57.62, 2953.03, 'kg', 51.25, 0.00, 51.25),
(410, 242, 7, NULL, 57.28, 55.40, 3173.31, 'kg', 57.28, 0.00, 57.28),
(411, 242, 1, NULL, 63.31, 44.32, 2805.90, 'kg', 63.31, 0.00, 63.31),
(412, 243, 7, NULL, 57.28, 55.40, 3173.31, 'kg', 57.28, 0.00, 57.28),
(413, 243, 1, NULL, 63.31, 44.32, 2805.90, 'kg', 63.31, 0.00, 63.31),
(414, 243, 2, NULL, 69.34, 44.32, 3073.15, 'kg', 69.34, 0.00, 69.34),
(415, 244, 6, NULL, 49.06, 57.82, 2836.65, 'kg', 49.06, 0.00, 49.06),
(416, 244, 7, NULL, 54.83, 55.60, 3048.55, 'kg', 54.83, 0.00, 54.83),
(417, 244, 1, NULL, 60.60, 44.48, 2695.49, 'kg', 60.60, 0.00, 60.60),
(418, 245, 7, NULL, 54.83, 55.60, 3048.55, 'kg', 54.83, 0.00, 54.83),
(419, 245, 1, NULL, 60.60, 44.48, 2695.49, 'kg', 60.60, 0.00, 60.60),
(420, 245, 2, NULL, 66.37, 44.48, 2952.14, 'kg', 66.37, 0.00, 66.37),
(421, 246, 1, NULL, 60.60, 44.48, 2695.49, 'kg', 60.60, 0.00, 60.60),
(422, 246, 2, NULL, 66.37, 44.48, 2952.14, 'kg', 66.37, 0.00, 66.37),
(423, 246, 4, NULL, 25.97, 66.72, 1732.72, 'kg', 25.97, 0.00, 25.97),
(424, 247, 7, NULL, 51.22, 55.80, 2858.08, 'kg', 51.22, 0.00, 51.22),
(425, 247, 1, NULL, 56.62, 44.64, 2527.52, 'kg', 56.62, 0.00, 56.62),
(426, 247, 2, NULL, 62.01, 44.64, 2768.13, 'kg', 62.01, 0.00, 62.01),
(427, 248, 1, NULL, 56.62, 44.64, 2527.52, 'kg', 56.62, 0.00, 56.62),
(428, 248, 2, NULL, 62.01, 44.64, 2768.13, 'kg', 62.01, 0.00, 62.01),
(429, 248, 4, NULL, 24.26, 66.96, 1624.45, 'kg', 24.26, 0.00, 24.26),
(430, 249, 2, NULL, 62.01, 44.64, 2768.13, 'kg', 62.01, 0.00, 62.01),
(431, 249, 4, NULL, 24.26, 66.96, 1624.45, 'kg', 24.26, 0.00, 24.26),
(432, 249, 5, NULL, 29.66, 51.34, 1522.74, 'kg', 29.66, 0.00, 29.66),
(433, 250, 1, NULL, 52.55, 44.80, 2354.24, 'kg', 52.55, 0.00, 52.55),
(434, 250, 2, NULL, 57.56, 44.80, 2578.69, 'kg', 57.56, 0.00, 57.56),
(435, 250, 4, NULL, 22.52, 67.20, 1513.34, 'kg', 22.52, 0.00, 22.52),
(436, 251, 2, NULL, 57.56, 44.80, 2578.69, 'kg', 57.56, 0.00, 57.56),
(437, 251, 4, NULL, 22.52, 67.20, 1513.34, 'kg', 22.52, 0.00, 22.52),
(438, 251, 5, NULL, 27.53, 51.52, 1418.35, 'kg', 27.53, 0.00, 27.53),
(439, 252, 4, NULL, 22.52, 67.20, 1513.34, 'kg', 22.52, 0.00, 22.52),
(440, 252, 5, NULL, 27.53, 51.52, 1418.35, 'kg', 27.53, 0.00, 27.53),
(441, 252, 6, NULL, 32.53, 58.24, 1894.55, 'kg', 32.53, 0.00, 32.53),
(442, 253, 2, NULL, 54.37, 44.96, 2444.48, 'kg', 54.37, 0.00, 54.37),
(443, 253, 4, NULL, 21.27, 67.44, 1434.45, 'kg', 21.27, 0.00, 21.27),
(444, 253, 5, NULL, 26.00, 51.70, 1344.20, 'kg', 26.00, 0.00, 26.00),
(445, 254, 4, NULL, 21.27, 67.44, 1434.45, 'kg', 21.27, 0.00, 21.27),
(446, 254, 5, NULL, 26.00, 51.70, 1344.20, 'kg', 26.00, 0.00, 26.00),
(447, 254, 6, NULL, 30.73, 58.45, 1796.17, 'kg', 30.73, 0.00, 30.73),
(448, 255, 5, NULL, 26.00, 51.70, 1344.20, 'kg', 26.00, 0.00, 26.00),
(449, 255, 6, NULL, 30.73, 58.45, 1796.17, 'kg', 30.73, 0.00, 30.73),
(450, 255, 7, NULL, 35.46, 56.20, 1992.85, 'kg', 35.46, 0.00, 35.46),
(451, 256, 4, NULL, 20.93, 67.68, 1416.54, 'kg', 20.93, 0.00, 20.93),
(452, 256, 5, NULL, 25.58, 51.89, 1327.35, 'kg', 25.58, 0.00, 25.58),
(453, 256, 6, NULL, 30.23, 58.66, 1773.29, 'kg', 30.23, 0.00, 30.23),
(454, 257, 5, NULL, 25.58, 51.89, 1327.35, 'kg', 25.58, 0.00, 25.58),
(455, 257, 6, NULL, 30.23, 58.66, 1773.29, 'kg', 30.23, 0.00, 30.23),
(456, 257, 7, NULL, 34.88, 56.40, 1967.23, 'kg', 34.88, 0.00, 34.88),
(457, 258, 6, NULL, 30.23, 58.66, 1773.29, 'kg', 30.23, 0.00, 30.23),
(458, 258, 7, NULL, 34.88, 56.40, 1967.23, 'kg', 34.88, 0.00, 34.88),
(459, 258, 1, NULL, 39.53, 45.12, 1783.59, 'kg', 39.53, 0.00, 39.53),
(460, 259, 5, NULL, 26.46, 52.07, 1377.77, 'kg', 26.46, 0.00, 26.46),
(461, 259, 6, NULL, 31.27, 58.86, 1840.55, 'kg', 31.27, 0.00, 31.27),
(462, 259, 7, NULL, 36.08, 56.60, 2042.13, 'kg', 36.08, 0.00, 36.08),
(463, 260, 6, NULL, 31.27, 58.86, 1840.55, 'kg', 31.27, 0.00, 31.27),
(464, 260, 7, NULL, 36.08, 56.60, 2042.13, 'kg', 36.08, 0.00, 36.08),
(465, 260, 1, NULL, 40.89, 45.28, 1851.50, 'kg', 40.89, 0.00, 40.89),
(466, 261, 7, NULL, 36.08, 56.60, 2042.13, 'kg', 36.08, 0.00, 36.08),
(467, 261, 1, NULL, 40.89, 45.28, 1851.50, 'kg', 40.89, 0.00, 40.89),
(468, 261, 2, NULL, 45.70, 45.28, 2069.30, 'kg', 45.70, 0.00, 45.70),
(469, 262, 6, NULL, 33.68, 59.07, 1989.48, 'kg', 33.68, 0.00, 33.68),
(470, 262, 7, NULL, 38.86, 56.80, 2207.25, 'kg', 38.86, 0.00, 38.86),
(471, 262, 1, NULL, 44.04, 45.44, 2001.18, 'kg', 44.04, 0.00, 44.04),
(472, 263, 7, NULL, 38.86, 56.80, 2207.25, 'kg', 38.86, 0.00, 38.86),
(473, 263, 1, NULL, 44.04, 45.44, 2001.18, 'kg', 44.04, 0.00, 44.04),
(474, 263, 2, NULL, 49.22, 45.44, 2236.56, 'kg', 49.22, 0.00, 49.22),
(475, 264, 1, NULL, 44.04, 45.44, 2001.18, 'kg', 44.04, 0.00, 44.04),
(476, 264, 2, NULL, 49.22, 45.44, 2236.56, 'kg', 49.22, 0.00, 49.22),
(477, 264, 4, NULL, 54.41, 68.16, 3708.59, 'kg', 54.41, 0.00, 54.41),
(478, 265, 7, NULL, 42.60, 57.00, 2428.20, 'kg', 42.60, 0.00, 42.60),
(479, 265, 1, NULL, 48.28, 45.60, 2201.57, 'kg', 48.28, 0.00, 48.28),
(480, 265, 2, NULL, 53.96, 45.60, 2460.58, 'kg', 53.96, 0.00, 53.96),
(481, 266, 1, NULL, 48.28, 45.60, 2201.57, 'kg', 48.28, 0.00, 48.28),
(482, 266, 2, NULL, 53.96, 45.60, 2460.58, 'kg', 53.96, 0.00, 53.96),
(483, 266, 4, NULL, 59.64, 68.40, 4079.38, 'kg', 59.64, 0.00, 59.64),
(484, 267, 2, NULL, 53.96, 45.60, 2460.58, 'kg', 53.96, 0.00, 53.96),
(485, 267, 4, NULL, 59.64, 68.40, 4079.38, 'kg', 59.64, 0.00, 59.64),
(486, 267, 5, NULL, 65.32, 52.44, 3425.38, 'kg', 65.32, 0.00, 65.32),
(487, 268, 1, NULL, 52.58, 45.76, 2406.06, 'kg', 52.58, 0.00, 52.58),
(488, 268, 2, NULL, 58.77, 45.76, 2689.32, 'kg', 58.77, 0.00, 58.77),
(489, 268, 4, NULL, 64.96, 68.64, 4458.85, 'kg', 64.96, 0.00, 64.96),
(490, 269, 2, NULL, 58.77, 45.76, 2689.32, 'kg', 58.77, 0.00, 58.77),
(491, 269, 4, NULL, 64.96, 68.64, 4458.85, 'kg', 64.96, 0.00, 64.96),
(492, 269, 5, NULL, 71.14, 52.62, 3743.39, 'kg', 71.14, 0.00, 71.14),
(493, 270, 4, NULL, 64.96, 68.64, 4458.85, 'kg', 64.96, 0.00, 64.96),
(494, 270, 5, NULL, 71.14, 52.62, 3743.39, 'kg', 71.14, 0.00, 71.14),
(495, 270, 6, NULL, 27.84, 59.49, 1656.20, 'kg', 27.84, 0.00, 27.84),
(496, 271, 2, NULL, 62.48, 45.92, 2869.08, 'kg', 62.48, 0.00, 62.48),
(497, 271, 4, NULL, 69.05, 68.88, 4756.16, 'kg', 69.05, 0.00, 69.05),
(498, 271, 5, NULL, 75.63, 52.81, 3994.02, 'kg', 75.63, 0.00, 75.63),
(499, 272, 4, NULL, 69.05, 68.88, 4756.16, 'kg', 69.05, 0.00, 69.05),
(500, 272, 5, NULL, 75.63, 52.81, 3994.02, 'kg', 75.63, 0.00, 75.63),
(501, 272, 6, NULL, 29.59, 59.70, 1766.52, 'kg', 29.59, 0.00, 29.59),
(502, 273, 5, NULL, 75.63, 52.81, 3994.02, 'kg', 75.63, 0.00, 75.63),
(503, 273, 6, NULL, 29.59, 59.70, 1766.52, 'kg', 29.59, 0.00, 29.59),
(504, 273, 7, NULL, 36.17, 57.40, 2076.16, 'kg', 36.17, 0.00, 36.17),
(505, 274, 4, NULL, 70.94, 69.12, 4903.37, 'kg', 70.94, 0.00, 70.94),
(506, 274, 5, NULL, 77.69, 52.99, 4116.79, 'kg', 77.69, 0.00, 77.69),
(507, 274, 6, NULL, 30.40, 59.90, 1820.96, 'kg', 30.40, 0.00, 30.40),
(508, 275, 5, NULL, 77.69, 52.99, 4116.79, 'kg', 77.69, 0.00, 77.69),
(509, 275, 6, NULL, 30.40, 59.90, 1820.96, 'kg', 30.40, 0.00, 30.40),
(510, 275, 7, NULL, 37.16, 57.60, 2140.42, 'kg', 37.16, 0.00, 37.16),
(511, 276, 6, NULL, 30.40, 59.90, 1820.96, 'kg', 30.40, 0.00, 30.40),
(512, 276, 7, NULL, 37.16, 57.60, 2140.42, 'kg', 37.16, 0.00, 37.16),
(513, 276, 1, NULL, 43.91, 46.08, 2023.37, 'kg', 43.91, 0.00, 43.91),
(514, 277, 5, NULL, 76.88, 53.18, 4088.48, 'kg', 76.88, 0.00, 76.88),
(515, 277, 6, NULL, 30.09, 60.11, 1808.71, 'kg', 30.09, 0.00, 30.09),
(516, 277, 7, NULL, 36.77, 57.80, 2125.31, 'kg', 36.77, 0.00, 36.77),
(517, 278, 6, NULL, 30.09, 60.11, 1808.71, 'kg', 30.09, 0.00, 30.09),
(518, 278, 7, NULL, 36.77, 57.80, 2125.31, 'kg', 36.77, 0.00, 36.77),
(519, 278, 1, NULL, 43.46, 46.24, 2009.59, 'kg', 43.46, 0.00, 43.46),
(520, 279, 7, NULL, 36.77, 57.80, 2125.31, 'kg', 36.77, 0.00, 36.77),
(521, 279, 1, NULL, 43.46, 46.24, 2009.59, 'kg', 43.46, 0.00, 43.46),
(522, 279, 2, NULL, 50.14, 46.24, 2318.47, 'kg', 50.14, 0.00, 50.14),
(523, 280, 6, NULL, 28.77, 60.32, 1735.41, 'kg', 28.77, 0.00, 28.77),
(524, 280, 7, NULL, 35.16, 58.00, 2039.28, 'kg', 35.16, 0.00, 35.16),
(525, 280, 1, NULL, 41.56, 46.40, 1928.38, 'kg', 41.56, 0.00, 41.56),
(526, 281, 7, NULL, 35.16, 58.00, 2039.28, 'kg', 35.16, 0.00, 35.16),
(527, 281, 1, NULL, 41.56, 46.40, 1928.38, 'kg', 41.56, 0.00, 41.56),
(528, 281, 2, NULL, 47.95, 46.40, 2224.88, 'kg', 47.95, 0.00, 47.95),
(529, 282, 1, NULL, 41.56, 46.40, 1928.38, 'kg', 41.56, 0.00, 41.56),
(530, 282, 2, NULL, 47.95, 46.40, 2224.88, 'kg', 47.95, 0.00, 47.95),
(531, 282, 4, NULL, 54.35, 69.60, 3782.76, 'kg', 54.35, 0.00, 54.35),
(532, 283, 7, NULL, 32.82, 58.20, 1910.12, 'kg', 32.82, 0.00, 32.82),
(533, 283, 1, NULL, 38.79, 46.56, 1806.06, 'kg', 38.79, 0.00, 38.79),
(534, 283, 2, NULL, 44.76, 46.56, 2084.03, 'kg', 44.76, 0.00, 44.76),
(535, 284, 1, NULL, 38.79, 46.56, 1806.06, 'kg', 38.79, 0.00, 38.79),
(536, 284, 2, NULL, 44.76, 46.56, 2084.03, 'kg', 44.76, 0.00, 44.76),
(537, 284, 4, NULL, 50.73, 69.84, 3542.98, 'kg', 50.73, 0.00, 50.73),
(538, 285, 2, NULL, 44.76, 46.56, 2084.03, 'kg', 44.76, 0.00, 44.76),
(539, 285, 4, NULL, 50.73, 69.84, 3542.98, 'kg', 50.73, 0.00, 50.73),
(540, 285, 5, NULL, 56.70, 53.54, 3035.72, 'kg', 56.70, 0.00, 56.70),
(541, 286, 1, NULL, 35.98, 46.72, 1680.99, 'kg', 35.98, 0.00, 35.98),
(542, 286, 2, NULL, 41.51, 46.72, 1939.35, 'kg', 41.51, 0.00, 41.51),
(543, 286, 4, NULL, 47.05, 70.08, 3297.26, 'kg', 47.05, 0.00, 47.05),
(544, 287, 2, NULL, 41.51, 46.72, 1939.35, 'kg', 41.51, 0.00, 41.51),
(545, 287, 4, NULL, 47.05, 70.08, 3297.26, 'kg', 47.05, 0.00, 47.05),
(546, 287, 5, NULL, 52.58, 53.73, 2825.12, 'kg', 52.58, 0.00, 52.58),
(547, 288, 4, NULL, 47.05, 70.08, 3297.26, 'kg', 47.05, 0.00, 47.05),
(548, 288, 5, NULL, 52.58, 53.73, 2825.12, 'kg', 52.58, 0.00, 52.58),
(549, 288, 6, NULL, 58.11, 60.74, 3529.60, 'kg', 58.11, 0.00, 58.11),
(550, 289, 2, NULL, 39.18, 46.88, 1836.76, 'kg', 39.18, 0.00, 39.18),
(551, 289, 4, NULL, 44.40, 70.32, 3122.21, 'kg', 44.40, 0.00, 44.40),
(552, 289, 5, NULL, 49.63, 53.91, 2675.55, 'kg', 49.63, 0.00, 49.63),
(553, 290, 4, NULL, 44.40, 70.32, 3122.21, 'kg', 44.40, 0.00, 44.40),
(554, 290, 5, NULL, 49.63, 53.91, 2675.55, 'kg', 49.63, 0.00, 49.63),
(555, 290, 6, NULL, 54.85, 60.94, 3342.56, 'kg', 54.85, 0.00, 54.85),
(556, 291, 5, NULL, 49.63, 53.91, 2675.55, 'kg', 49.63, 0.00, 49.63),
(557, 291, 6, NULL, 54.85, 60.94, 3342.56, 'kg', 54.85, 0.00, 54.85),
(558, 291, 7, NULL, 60.07, 58.60, 3520.10, 'kg', 60.07, 0.00, 60.07),
(559, 292, 4, NULL, 43.64, 70.56, 3079.24, 'kg', 43.64, 0.00, 43.64),
(560, 292, 5, NULL, 48.77, 54.10, 2638.46, 'kg', 48.77, 0.00, 48.77),
(561, 292, 6, NULL, 53.91, 61.15, 3296.60, 'kg', 53.91, 0.00, 53.91),
(562, 293, 5, NULL, 48.77, 54.10, 2638.46, 'kg', 48.77, 0.00, 48.77),
(563, 293, 6, NULL, 53.91, 61.15, 3296.60, 'kg', 53.91, 0.00, 53.91),
(564, 293, 7, NULL, 59.04, 58.80, 3471.55, 'kg', 59.04, 0.00, 59.04),
(565, 294, 6, NULL, 53.91, 61.15, 3296.60, 'kg', 53.91, 0.00, 53.91),
(566, 294, 7, NULL, 59.04, 58.80, 3471.55, 'kg', 59.04, 0.00, 59.04),
(567, 294, 1, NULL, 23.10, 47.04, 1086.62, 'kg', 23.10, 0.00, 23.10),
(568, 295, 5, NULL, 50.41, 54.28, 2736.25, 'kg', 50.41, 0.00, 50.41),
(569, 295, 6, NULL, 55.72, 61.36, 3418.98, 'kg', 55.72, 0.00, 55.72),
(570, 295, 7, NULL, 61.02, 59.00, 3600.18, 'kg', 61.02, 0.00, 61.02),
(571, 296, 6, NULL, 55.72, 61.36, 3418.98, 'kg', 55.72, 0.00, 55.72),
(572, 296, 7, NULL, 61.02, 59.00, 3600.18, 'kg', 61.02, 0.00, 61.02),
(573, 296, 1, NULL, 23.88, 47.20, 1127.14, 'kg', 23.88, 0.00, 23.88),
(574, 297, 7, NULL, 61.02, 59.00, 3600.18, 'kg', 61.02, 0.00, 61.02),
(575, 297, 1, NULL, 23.88, 47.20, 1127.14, 'kg', 23.88, 0.00, 23.88),
(576, 297, 2, NULL, 29.19, 47.20, 1377.77, 'kg', 29.19, 0.00, 29.19),
(577, 298, 6, NULL, 59.97, 61.57, 3692.35, 'kg', 59.97, 0.00, 59.97),
(578, 298, 7, NULL, 65.68, 59.20, 3888.26, 'kg', 65.68, 0.00, 65.68),
(579, 298, 1, NULL, 25.70, 47.36, 1217.15, 'kg', 25.70, 0.00, 25.70),
(580, 299, 7, NULL, 65.68, 59.20, 3888.26, 'kg', 65.68, 0.00, 65.68),
(581, 299, 1, NULL, 25.70, 47.36, 1217.15, 'kg', 25.70, 0.00, 25.70),
(582, 299, 2, NULL, 31.41, 47.36, 1487.58, 'kg', 31.41, 0.00, 31.41),
(583, 300, 1, NULL, 25.70, 47.36, 1217.15, 'kg', 25.70, 0.00, 25.70),
(584, 300, 2, NULL, 31.41, 47.36, 1487.58, 'kg', 31.41, 0.00, 31.41),
(585, 300, 4, NULL, 37.12, 71.04, 2637.00, 'kg', 37.12, 0.00, 37.12),
(586, 301, 7, NULL, 71.94, 59.40, 4273.24, 'kg', 71.94, 0.00, 71.94),
(587, 301, 1, NULL, 28.15, 47.52, 1337.69, 'kg', 28.15, 0.00, 28.15),
(588, 301, 2, NULL, 34.41, 47.52, 1635.16, 'kg', 34.41, 0.00, 34.41),
(589, 302, 1, NULL, 28.15, 47.52, 1337.69, 'kg', 28.15, 0.00, 28.15),
(590, 302, 2, NULL, 34.41, 47.52, 1635.16, 'kg', 34.41, 0.00, 34.41),
(591, 302, 4, NULL, 40.66, 71.28, 2898.24, 'kg', 40.66, 0.00, 40.66),
(592, 303, 2, NULL, 34.41, 47.52, 1635.16, 'kg', 34.41, 0.00, 34.41),
(593, 303, 4, NULL, 40.66, 71.28, 2898.24, 'kg', 40.66, 0.00, 40.66),
(594, 303, 5, NULL, 46.92, 54.65, 2564.18, 'kg', 46.92, 0.00, 46.92),
(595, 304, 1, NULL, 30.64, 47.68, 1460.92, 'kg', 30.64, 0.00, 30.64),
(596, 304, 2, NULL, 37.45, 47.68, 1785.62, 'kg', 37.45, 0.00, 37.45),
(597, 304, 4, NULL, 44.25, 71.52, 3164.76, 'kg', 44.25, 0.00, 44.25),
(598, 305, 2, NULL, 37.45, 47.68, 1785.62, 'kg', 37.45, 0.00, 37.45),
(599, 305, 4, NULL, 44.25, 71.52, 3164.76, 'kg', 44.25, 0.00, 44.25),
(600, 305, 5, NULL, 51.06, 54.83, 2799.62, 'kg', 51.06, 0.00, 51.06),
(601, 306, 4, NULL, 44.25, 71.52, 3164.76, 'kg', 44.25, 0.00, 44.25),
(602, 306, 5, NULL, 51.06, 54.83, 2799.62, 'kg', 51.06, 0.00, 51.06),
(603, 306, 6, NULL, 57.87, 61.98, 3586.78, 'kg', 57.87, 0.00, 57.87),
(604, 307, 2, NULL, 39.78, 47.84, 1903.08, 'kg', 39.78, 0.00, 39.78),
(605, 307, 4, NULL, 47.01, 71.76, 3373.44, 'kg', 47.01, 0.00, 47.01),
(606, 307, 5, NULL, 54.24, 55.02, 2984.28, 'kg', 54.24, 0.00, 54.24),
(607, 308, 4, NULL, 47.01, 71.76, 3373.44, 'kg', 47.01, 0.00, 47.01),
(608, 308, 5, NULL, 54.24, 55.02, 2984.28, 'kg', 54.24, 0.00, 54.24),
(609, 308, 6, NULL, 61.47, 62.19, 3822.82, 'kg', 61.47, 0.00, 61.47),
(610, 309, 5, NULL, 54.24, 55.02, 2984.28, 'kg', 54.24, 0.00, 54.24),
(611, 309, 6, NULL, 61.47, 62.19, 3822.82, 'kg', 61.47, 0.00, 61.47),
(612, 309, 7, NULL, 68.71, 59.80, 4108.86, 'kg', 68.71, 0.00, 68.71),
(613, 310, 4, NULL, 48.26, 72.00, 3474.72, 'kg', 48.26, 0.00, 48.26),
(614, 310, 5, NULL, 55.68, 55.20, 3073.54, 'kg', 55.68, 0.00, 55.68),
(615, 310, 6, NULL, 63.10, 62.40, 3937.44, 'kg', 63.10, 0.00, 63.10),
(616, 311, 5, NULL, 55.68, 55.20, 3073.54, 'kg', 55.68, 0.00, 55.68),
(617, 311, 6, NULL, 63.10, 62.40, 3937.44, 'kg', 63.10, 0.00, 63.10),
(618, 311, 7, NULL, 70.53, 60.00, 4231.80, 'kg', 70.53, 0.00, 70.53),
(619, 312, 6, NULL, 63.10, 62.40, 3937.44, 'kg', 63.10, 0.00, 63.10),
(620, 312, 7, NULL, 70.53, 60.00, 4231.80, 'kg', 70.53, 0.00, 70.53),
(621, 312, 1, NULL, 77.95, 48.00, 3741.60, 'kg', 77.95, 0.00, 77.95),
(622, 313, 5, NULL, 55.06, 55.38, 3049.22, 'kg', 55.06, 0.00, 55.06),
(623, 313, 6, NULL, 62.40, 62.61, 3906.86, 'kg', 62.40, 0.00, 62.40),
(624, 313, 7, NULL, 69.74, 60.20, 4198.35, 'kg', 69.74, 0.00, 69.74),
(625, 314, 6, NULL, 62.40, 62.61, 3906.86, 'kg', 62.40, 0.00, 62.40),
(626, 314, 7, NULL, 69.74, 60.20, 4198.35, 'kg', 69.74, 0.00, 69.74),
(627, 314, 1, NULL, 77.09, 48.16, 3712.65, 'kg', 77.09, 0.00, 77.09),
(628, 315, 7, NULL, 69.74, 60.20, 4198.35, 'kg', 69.74, 0.00, 69.74),
(629, 315, 1, NULL, 77.09, 48.16, 3712.65, 'kg', 77.09, 0.00, 77.09),
(630, 315, 2, NULL, 84.43, 48.16, 4066.15, 'kg', 84.43, 0.00, 84.43),
(631, 316, 6, NULL, 59.63, 62.82, 3745.96, 'kg', 59.63, 0.00, 59.63),
(632, 316, 7, NULL, 66.65, 60.40, 4025.66, 'kg', 66.65, 0.00, 66.65),
(633, 316, 1, NULL, 73.66, 48.32, 3559.25, 'kg', 73.66, 0.00, 73.66),
(634, 317, 7, NULL, 66.65, 60.40, 4025.66, 'kg', 66.65, 0.00, 66.65),
(635, 317, 1, NULL, 73.66, 48.32, 3559.25, 'kg', 73.66, 0.00, 73.66),
(636, 317, 2, NULL, 80.68, 48.32, 3898.46, 'kg', 80.68, 0.00, 80.68),
(637, 318, 1, NULL, 73.66, 48.32, 3559.25, 'kg', 73.66, 0.00, 73.66),
(638, 318, 2, NULL, 80.68, 48.32, 3898.46, 'kg', 80.68, 0.00, 80.68),
(639, 318, 4, NULL, 31.57, 72.48, 2288.19, 'kg', 31.57, 0.00, 31.57),
(640, 319, 7, NULL, 62.17, 60.60, 3767.50, 'kg', 62.17, 0.00, 62.17),
(641, 319, 1, NULL, 68.71, 48.48, 3331.06, 'kg', 68.71, 0.00, 68.71),
(642, 319, 2, NULL, 75.26, 48.48, 3648.60, 'kg', 75.26, 0.00, 75.26),
(643, 320, 1, NULL, 68.71, 48.48, 3331.06, 'kg', 68.71, 0.00, 68.71),
(644, 320, 2, NULL, 75.26, 48.48, 3648.60, 'kg', 75.26, 0.00, 75.26),
(645, 320, 4, NULL, 29.45, 72.72, 2141.60, 'kg', 29.45, 0.00, 29.45),
(646, 321, 2, NULL, 75.26, 48.48, 3648.60, 'kg', 75.26, 0.00, 75.26),
(647, 321, 4, NULL, 29.45, 72.72, 2141.60, 'kg', 29.45, 0.00, 29.45),
(648, 321, 5, NULL, 35.99, 55.75, 2006.44, 'kg', 35.99, 0.00, 35.99),
(649, 322, 1, NULL, 63.68, 48.64, 3097.40, 'kg', 63.68, 0.00, 63.68),
(650, 322, 2, NULL, 69.74, 48.64, 3392.15, 'kg', 69.74, 0.00, 69.74),
(651, 322, 4, NULL, 27.29, 72.96, 1991.08, 'kg', 27.29, 0.00, 27.29),
(652, 323, 2, NULL, 69.74, 48.64, 3392.15, 'kg', 69.74, 0.00, 69.74),
(653, 323, 4, NULL, 27.29, 72.96, 1991.08, 'kg', 27.29, 0.00, 27.29),
(654, 323, 5, NULL, 33.36, 55.94, 1866.16, 'kg', 33.36, 0.00, 33.36),
(655, 324, 4, NULL, 27.29, 72.96, 1991.08, 'kg', 27.29, 0.00, 27.29),
(656, 324, 5, NULL, 33.36, 55.94, 1866.16, 'kg', 33.36, 0.00, 33.36),
(657, 324, 6, NULL, 39.42, 63.23, 2492.53, 'kg', 39.42, 0.00, 39.42),
(658, 325, 2, NULL, 65.78, 48.80, 3210.06, 'kg', 65.78, 0.00, 65.78),
(659, 325, 4, NULL, 25.74, 73.20, 1884.17, 'kg', 25.74, 0.00, 25.74),
(660, 325, 5, NULL, 31.46, 56.12, 1765.54, 'kg', 31.46, 0.00, 31.46),
(661, 326, 4, NULL, 25.74, 73.20, 1884.17, 'kg', 25.74, 0.00, 25.74),
(662, 326, 5, NULL, 31.46, 56.12, 1765.54, 'kg', 31.46, 0.00, 31.46),
(663, 326, 6, NULL, 37.18, 63.44, 2358.70, 'kg', 37.18, 0.00, 37.18),
(664, 327, 5, NULL, 31.46, 56.12, 1765.54, 'kg', 31.46, 0.00, 31.46),
(665, 327, 6, NULL, 37.18, 63.44, 2358.70, 'kg', 37.18, 0.00, 37.18),
(666, 327, 7, NULL, 42.90, 61.00, 2616.90, 'kg', 42.90, 0.00, 42.90),
(676, 331, 29, 69, 300.00, 2600.00, 15600.00, 'sack', 6.00, 0.00, 300.00);

-- --------------------------------------------------------

--
-- Table structure for table `stock_batches`
--

CREATE TABLE `stock_batches` (
  `batch_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `batch_code` varchar(50) DEFAULT NULL,
  `source_reference_id` int(11) DEFAULT NULL,
  `source_reference_type` varchar(30) DEFAULT NULL,
  `arrived_at` date DEFAULT NULL,
  `unit_weight_kg` decimal(10,2) NOT NULL DEFAULT 0.00,
  `initial_qty_kg` decimal(12,2) NOT NULL DEFAULT 0.00,
  `remaining_qty_kg` decimal(12,2) NOT NULL DEFAULT 0.00,
  `regular_qty_kg` decimal(12,2) NOT NULL DEFAULT 0.00,
  `discounted_qty_kg` decimal(12,2) NOT NULL DEFAULT 0.00,
  `cost_per_kg` decimal(12,2) NOT NULL DEFAULT 0.00,
  `regular_price_per_kg` decimal(12,2) NOT NULL DEFAULT 0.00,
  `discounted_price_per_kg` decimal(12,2) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock_batches`
--

INSERT INTO `stock_batches` (`batch_id`, `product_id`, `batch_code`, `source_reference_id`, `source_reference_type`, `arrived_at`, `unit_weight_kg`, `initial_qty_kg`, `remaining_qty_kg`, `regular_qty_kg`, `discounted_qty_kg`, `cost_per_kg`, `regular_price_per_kg`, `discounted_price_per_kg`, `note`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 1, 'LEGACY-1', NULL, 'legacy', '2026-04-26', 50.00, 1048.00, 948.00, 948.00, 0.00, 55.20, 61.00, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-06-01 21:46:21'),
(2, 2, 'LEGACY-2', NULL, 'legacy', '2026-04-26', 50.00, 745.00, 645.00, 645.00, 0.00, 56.00, 63.00, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-05-24 16:54:15'),
(3, 4, 'LEGACY-4', NULL, 'legacy', '2026-04-26', 50.00, 60.00, 60.00, 60.00, 0.00, 60.00, 66.00, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-05-11 12:47:25'),
(4, 5, 'LEGACY-5', NULL, 'legacy', '2026-04-26', 50.00, 15.00, 0.00, 0.00, 0.00, 55.60, 61.25, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-06-10 10:26:06'),
(5, 6, 'LEGACY-6', NULL, 'legacy', '2026-04-26', 25.00, 23.00, 23.00, 23.00, 0.00, 58.00, 63.80, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-05-11 12:47:25'),
(6, 7, 'LEGACY-7', NULL, 'legacy', '2026-03-25', 25.00, 251.00, 101.00, 101.00, 0.00, 40.00, 40.00, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-08-03 14:12:09'),
(7, 8, 'LEGACY-8', NULL, 'legacy', '2026-03-17', 50.00, 480.00, 30.00, 30.00, 0.00, 46.00, 60.00, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-08-18 01:16:08'),
(8, 9, 'LEGACY-9', NULL, 'legacy', '2026-02-17', 10.00, 508.00, 443.00, 443.00, 0.00, 60.00, 45.00, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-08-17 21:17:30'),
(9, 10, 'LEGACY-10', NULL, 'legacy', '2026-03-25', 10.00, 460.00, 60.00, 60.00, 0.00, 70.00, 50.00, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-08-10 14:43:58'),
(10, 11, 'LEGACY-11', NULL, 'legacy', '2026-01-15', 10.00, 569.00, 500.00, 460.00, 40.00, 60.00, 63.25, 50.60, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-08-10 14:08:28'),
(11, 12, 'LEGACY-12', NULL, 'legacy', '2026-05-04', 50.00, 1018.00, 968.00, 968.00, 0.00, 46.00, 56.00, 44.00, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-07-27 16:08:43'),
(12, 13, 'LEGACY-13', NULL, 'legacy', '2026-02-13', 50.00, 240.00, 40.00, 40.00, 0.00, 49.00, 50.00, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-07-23 15:17:59'),
(13, 14, 'LEGACY-14', NULL, 'legacy', '2026-03-20', 10.00, 620.00, 70.00, 70.00, 0.00, 90.00, 50.00, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-08-10 14:37:32'),
(14, 15, 'LEGACY-15', NULL, 'legacy', '2026-05-04', 15.00, 163.00, 163.00, 163.00, 0.00, 53.33, 60.33, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-05-11 12:47:25'),
(15, 16, 'LEGACY-16', NULL, 'legacy', '2026-03-09', 50.00, 940.00, 639.00, 639.00, 0.00, 50.00, 54.00, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-08-17 14:05:24'),
(16, 17, 'LEGACY-17', NULL, 'legacy', '2026-03-25', 50.00, 600.00, 600.00, 600.00, 0.00, 46.00, 46.00, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-05-11 12:47:25'),
(17, 18, 'LEGACY-18', NULL, 'legacy', '2026-01-13', 50.00, 900.00, 900.00, 900.00, 0.00, 26.00, 56.00, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-05-11 12:47:25'),
(18, 21, 'LEGACY-21', NULL, 'legacy', '2026-04-26', 50.00, 800.00, 750.00, 750.00, 0.00, 54.20, 60.00, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-06-01 21:45:26'),
(19, 22, 'LEGACY-22', NULL, 'legacy', '2026-03-11', 50.00, 700.00, 100.00, 100.00, 0.00, 46.00, 61.60, 49.00, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-08-20 11:20:17'),
(20, 23, 'LEGACY-23', NULL, 'legacy', '2026-03-24', 50.00, 399.00, 399.00, 399.00, 0.00, 46.00, 46.00, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-05-11 12:47:25'),
(21, 24, 'LEGACY-24', NULL, 'legacy', '2026-03-23', 50.00, 899.00, 899.00, 899.00, 0.00, 50.00, 50.00, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-05-11 12:47:25'),
(22, 25, 'LEGACY-25', NULL, 'legacy', '2026-03-24', 50.00, 499.00, 499.00, 350.00, 149.00, 50.00, 50.00, 30.00, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-05-11 12:47:25'),
(23, 26, 'LEGACY-26', NULL, 'legacy', '2026-04-26', 50.00, 1400.00, 1300.00, 1300.00, 0.00, 50.00, 50.00, NULL, 'Legacy stock balance before batch tracking', NULL, '2026-05-11 12:47:25', '2026-07-21 13:41:01'),
(24, 6, 'B000024', 39, 'purchase', '2026-06-02', 25.00, 750.00, 700.00, 675.00, 25.00, 52.00, 72.00, 57.00, 'Stock received (Receiving) | sacks=30 | sack_size=25kg | supplier/sack=₱1,300.00 | transport=₱0.00 | cost/kg=₱52.00 | markup/kg=₱20.00 | sell/kg=₱72.00 | sell/sack=₱1,800.00', 1, '2026-06-02 10:58:59', '2026-07-27 15:50:04'),
(25, 27, 'B000025', 50, 'purchase', '2026-06-02', 50.00, 150.00, 149.00, 149.00, 0.00, 46.00, 66.00, NULL, 'Stock received (Receiving) | sacks=3 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱20.00 | sell/kg=₱66.00 | sell/sack=₱3,300.00', 1, '2026-06-02 14:35:36', '2026-08-17 16:45:38'),
(26, 15, 'B000026', 52, 'purchase', '2026-06-02', 15.00, 45.00, 45.00, 45.00, 0.00, 53.33, 66.33, NULL, 'Stock received (Receiving) | sacks=3 | sack_size=15kg | supplier/sack=₱800.00 | transport=₱0.00 | cost/kg=₱53.33 | markup/kg=₱13.00 | sell/kg=₱66.33 | sell/sack=₱995.00', 1, '2026-06-02 14:42:35', '2026-06-02 14:42:35'),
(27, 5, 'B000027', 54, 'purchase', '2026-06-10', 50.00, 250.00, 0.00, 0.00, 0.00, 46.00, 56.00, NULL, 'Stock received (Receiving) | sacks=5 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱10.00 | sell/kg=₱56.00 | sell/sack=₱2,800.00', 1, '2026-06-10 10:16:42', '2026-06-10 10:22:16'),
(28, 5, 'B000028', 58, 'purchase', '2026-07-08', 50.00, 100.00, 50.00, 50.00, 0.00, 46.00, 46.00, NULL, 'Stock received (Receiving) | sacks=2 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00', 1, '2026-07-08 21:17:43', '2026-07-08 21:19:50'),
(29, 4, 'B000029', 59, 'purchase', '2026-07-08', 50.00, 150.00, 150.00, 150.00, 0.00, 60.00, 60.00, NULL, 'Stock received (Receiving) | sacks=3 | sack_size=50kg | supplier/sack=₱3,000.00 | transport=₱0.00 | cost/kg=₱60.00 | markup/kg=₱0.00 | sell/kg=₱60.00 | sell/sack=₱3,000.00', 1, '2026-07-08 21:34:52', '2026-07-08 21:34:52'),
(30, 4, 'B000030', 59, 'purchase', '2026-07-08', 50.00, 150.00, 150.00, 150.00, 0.00, 60.00, 60.00, NULL, 'Stock received (Receiving) | sacks=3 | sack_size=50kg | supplier/sack=₱3,000.00 | transport=₱0.00 | cost/kg=₱60.00 | markup/kg=₱0.00 | sell/kg=₱60.00 | sell/sack=₱3,000.00', 1, '2026-07-08 21:35:15', '2026-07-08 21:35:15'),
(31, 4, 'B000031', 59, 'purchase', '2026-07-08', 50.00, 150.00, 150.00, 150.00, 0.00, 60.00, 60.00, NULL, 'Stock received (Receiving) | sacks=3 | sack_size=50kg | supplier/sack=₱3,000.00 | transport=₱0.00 | cost/kg=₱60.00 | markup/kg=₱0.00 | sell/kg=₱60.00 | sell/sack=₱3,000.00', 1, '2026-07-08 21:41:43', '2026-07-08 21:41:43'),
(32, 5, 'B000032', 60, 'purchase', '2026-07-16', 50.00, 250.00, 250.00, 250.00, 0.00, 50.00, 55.00, NULL, 'Stock received (Receiving) | sacks=5 | sack_size=50kg | supplier/sack=₱2,500.00 | transport=₱0.00 | cost/kg=₱50.00 | markup/kg=₱5.00 | sell/kg=₱55.00 | sell/sack=₱2,750.00', 1, '2026-07-16 14:09:39', '2026-07-16 14:09:39'),
(33, 27, 'B000033', 61, 'purchase', '2026-07-16', 50.00, 50.00, 50.00, 50.00, 0.00, 46.00, 55.99, NULL, 'Stock received (Receiving) | sacks=1 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱9.99 | sell/kg=₱55.99 | sell/sack=₱2,799.50', 1, '2026-07-16 14:26:21', '2026-07-16 14:26:21'),
(34, 27, 'B000034', 62, 'purchase', '2026-07-16', 50.00, 100.00, 100.00, 100.00, 0.00, 46.00, 50.99, NULL, 'Stock received (Receiving) | sacks=2 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱4.99 | sell/kg=₱50.99 | sell/sack=₱2,549.50', 1, '2026-07-16 14:31:59', '2026-07-16 14:31:59'),
(35, 15, 'B000035', 63, 'purchase', '2026-07-16', 15.00, 15.00, 15.00, 15.00, 0.00, 53.33, 53.33, NULL, 'Stock received (Receiving) | sacks=1 | sack_size=15kg | supplier/sack=₱800.00 | transport=₱0.00 | cost/kg=₱53.33 | markup/kg=₱0.00 | sell/kg=₱53.33 | sell/sack=₱800.00', 1, '2026-07-16 15:39:25', '2026-07-16 15:39:25'),
(36, 15, 'B000036', 64, 'purchase', '2026-07-16', 15.00, 165.00, 165.00, 150.00, 15.00, 53.33, 58.33, 46.66, 'Stock received (Receiving) | sacks=11 | sack_size=15kg | supplier/sack=₱800.00 | transport=₱0.00 | cost/kg=₱53.33 | markup/kg=₱5.00 | sell/kg=₱58.33 | sell/sack=₱875.00', 1, '2026-07-16 16:10:36', '2026-07-29 18:39:40'),
(37, 7, 'B000037', 65, 'purchase', '2026-07-16', 25.00, 250.00, 225.00, 225.00, 0.00, 40.00, 45.00, NULL, 'Stock received (Receiving) | sacks=10 | sack_size=25kg | supplier/sack=₱1,000.00 | transport=₱0.00 | cost/kg=₱40.00 | markup/kg=₱5.00 | sell/kg=₱45.00 | sell/sack=₱1,125.00', 1, '2026-07-16 16:13:26', '2026-07-16 16:45:21'),
(38, 13, 'B000038', 66, 'purchase', '2026-07-19', 50.00, 50.00, 50.00, 50.00, 0.00, 49.00, 49.00, NULL, 'Stock in recorded | sacks=1 | sack_size=50kg | supplier/sack=₱2,450.00 | transport=₱0.00 | cost/kg=₱49.00 | markup/kg=₱0.00 | sell/kg=₱49.00 | sell/sack=₱2,450.00', 1, '2026-07-19 21:37:09', '2026-07-19 21:37:09'),
(39, 28, 'B000039', 67, 'purchase', '2026-07-22', 50.00, 150.00, 50.00, 50.00, 0.00, 46.00, 51.00, 40.80, 'Stock in recorded | sacks=3 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱5.00 | sell/kg=₱51.00 | sell/sack=₱2,550.00', 1, '2026-07-22 09:19:18', '2026-08-11 15:52:53'),
(40, 13, 'B000040', 68, 'purchase', '2026-07-27', 50.00, 1000.00, 900.00, 900.00, 0.00, 49.00, 59.00, NULL, 'Stock in recorded | sacks=20 | sack_size=50kg | supplier/sack=₱2,450.00 | transport=₱0.00 | cost/kg=₱49.00 | markup/kg=₱10.00 | sell/kg=₱59.00 | sell/sack=₱2,950.00', 1, '2026-07-27 15:22:07', '2026-07-29 19:44:11'),
(41, 6, 'B000041', 74, 'purchase', '2026-07-29', 25.00, 50.00, 50.00, 50.00, 0.00, 52.00, 52.00, NULL, 'Stock in recorded | sacks=2 | sack_size=25kg | supplier/sack=₱1,300.00 | transport=₱0.00 | cost/kg=₱52.00 | markup/kg=₱0.00 | sell/kg=₱52.00 | sell/sack=₱1,300.00', 1, '2026-07-29 19:39:06', '2026-07-29 19:39:06'),
(42, 28, 'B000042', 73, 'purchase', '2026-07-29', 50.00, 100.00, 100.00, 100.00, 0.00, 46.00, 46.00, NULL, 'Stock in recorded | sacks=2 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00', 1, '2026-07-29 19:39:15', '2026-07-29 19:39:15'),
(43, 28, 'B000043', 72, 'purchase', '2026-07-29', 50.00, 250.00, 250.00, 250.00, 0.00, 46.00, 46.00, NULL, 'Stock in recorded | sacks=5 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00', 1, '2026-07-29 19:39:20', '2026-07-29 19:39:20'),
(44, 27, 'B000044', 71, 'purchase', '2026-07-29', 50.00, 100.00, 100.00, 100.00, 0.00, 46.00, 46.00, NULL, 'Stock in recorded | sacks=2 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00', 1, '2026-07-29 19:39:24', '2026-07-29 19:39:24'),
(45, 28, 'B000045', 70, 'purchase', '2026-07-29', 50.00, 100.00, 100.00, 100.00, 0.00, 46.00, 46.00, NULL, 'Stock in recorded | sacks=2 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00', 1, '2026-07-29 19:39:28', '2026-07-29 19:39:28'),
(46, 28, 'B000046', 69, 'purchase', '2026-07-29', 50.00, 1500.00, 1500.00, 1500.00, 0.00, 46.00, 46.00, NULL, 'Stock in recorded | sacks=30 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00', 1, '2026-07-29 19:39:46', '2026-07-29 19:39:46'),
(47, 27, 'B000047', 62, 'purchase', '2026-07-29', 50.00, 100.00, 100.00, 100.00, 0.00, 46.00, 46.00, NULL, 'Stock in recorded | sacks=2 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00', 1, '2026-07-29 19:39:51', '2026-07-29 19:39:51'),
(48, 27, 'B000048', 61, 'purchase', '2026-07-29', 50.00, 50.00, 50.00, 50.00, 0.00, 46.00, 46.00, NULL, 'Stock in recorded | sacks=1 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00', 1, '2026-07-29 19:39:55', '2026-07-29 19:39:55'),
(49, 5, 'B000049', 60, 'purchase', '2026-07-29', 50.00, 250.00, 250.00, 250.00, 0.00, 50.00, 50.00, NULL, 'Stock in recorded | sacks=5 | sack_size=50kg | supplier/sack=₱2,500.00 | transport=₱0.00 | cost/kg=₱50.00 | markup/kg=₱0.00 | sell/kg=₱50.00 | sell/sack=₱2,500.00', 1, '2026-07-29 19:39:59', '2026-07-29 19:39:59'),
(50, 4, 'B000050', 59, 'purchase', '2026-07-29', 50.00, 150.00, 150.00, 150.00, 0.00, 60.00, 60.00, NULL, 'Stock in recorded | sacks=3 | sack_size=50kg | supplier/sack=₱3,000.00 | transport=₱0.00 | cost/kg=₱60.00 | markup/kg=₱0.00 | sell/kg=₱60.00 | sell/sack=₱3,000.00', 1, '2026-07-29 19:40:03', '2026-07-29 19:40:03'),
(51, 2, 'B000051', 57, 'purchase', '2026-07-29', 50.00, 50.00, 50.00, 50.00, 0.00, 46.00, 46.00, NULL, 'Stock in recorded | sacks=1 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00', 1, '2026-07-29 19:40:17', '2026-07-29 19:40:17'),
(52, 2, 'B000052', 56, 'purchase', '2026-07-29', 50.00, 250.00, 250.00, 250.00, 0.00, 40.00, 40.00, NULL, 'Stock in recorded | sacks=5 | sack_size=50kg | supplier/sack=₱2,000.00 | transport=₱0.00 | cost/kg=₱40.00 | markup/kg=₱0.00 | sell/kg=₱40.00 | sell/sack=₱2,000.00', 1, '2026-07-29 19:40:22', '2026-07-29 19:40:22'),
(53, 5, 'B000053', 55, 'purchase', '2026-07-29', 50.00, 250.00, 250.00, 250.00, 0.00, 46.00, 46.00, NULL, 'Stock in recorded | sacks=5 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00', 1, '2026-07-29 19:40:33', '2026-07-29 19:40:33'),
(54, 1, 'B000054', 53, 'purchase', '2026-07-29', 50.00, 250.00, 250.00, 250.00, 0.00, 40.00, 40.00, NULL, 'Stock in recorded | sacks=5 | sack_size=50kg | supplier/sack=₱2,000.00 | transport=₱0.00 | cost/kg=₱40.00 | markup/kg=₱0.00 | sell/kg=₱40.00 | sell/sack=₱2,000.00', 1, '2026-07-29 19:40:45', '2026-07-29 19:40:45'),
(55, 17, 'B000055', 42, 'purchase', '2026-07-29', 50.00, 100.00, 100.00, 100.00, 0.00, 46.00, 46.00, NULL, 'Stock in recorded | sacks=2 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00', 1, '2026-07-29 19:40:59', '2026-07-29 19:40:59'),
(56, 7, 'B000056', 75, 'purchase', '2026-07-31', 25.00, 50.00, 50.00, 50.00, 0.00, 40.00, 50.00, NULL, 'Stock in recorded | sacks=2 | sack_size=25kg | supplier/sack=₱1,000.00 | transport=₱0.00 | cost/kg=₱40.00 | markup/kg=₱10.00 | sell/kg=₱50.00 | sell/sack=₱1,250.00', 1, '2026-07-31 10:17:36', '2026-07-31 10:17:36'),
(57, 28, 'B000057', 75, 'purchase', '2026-07-31', 50.00, 50.00, 50.00, 50.00, 0.00, 46.00, 50.00, NULL, 'Stock in recorded | sacks=1 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱4.00 | sell/kg=₱50.00 | sell/sack=₱2,500.00', 1, '2026-07-31 10:18:33', '2026-07-31 10:18:33'),
(58, 14, 'B000058', 76, 'purchase', '2026-07-31', 10.00, 20.00, 20.00, 20.00, 0.00, 50.00, 55.00, NULL, 'delivered by supplier | sacks=2 | sack_size=10kg | supplier/sack=₱500.00 | transport=₱0.00 | cost/kg=₱50.00 | markup/kg=₱5.00 | sell/kg=₱55.00 | sell/sack=₱550.00', 1, '2026-07-31 10:24:55', '2026-07-31 10:24:55'),
(59, 27, 'B000059', 48, 'purchase', '2026-08-02', 50.00, 250.00, 250.00, 250.00, 0.00, 46.00, 46.00, NULL, 'Stock in recorded | sacks=5 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱0.00 | sell/kg=₱46.00 | sell/sack=₱2,300.00', 1, '2026-08-02 14:47:18', '2026-08-02 14:47:18'),
(60, 29, 'B000060', 77, 'purchase', '2026-08-02', 50.00, 250.00, 0.00, 0.00, 0.00, 44.00, 54.00, NULL, 'Stock in recorded | sacks=5 | sack_size=50kg | supplier/sack=₱2,200.00 | transport=₱0.00 | cost/kg=₱44.00 | markup/kg=₱10.00 | sell/kg=₱54.00 | sell/sack=₱2,700.00', 1, '2026-08-02 14:51:58', '2026-08-03 14:06:02'),
(61, 30, 'B000061', 78, 'purchase', '2026-08-02', 50.00, 500.00, 450.00, 450.00, 0.00, 46.00, 56.00, NULL, 'Stock in recorded | sacks=10 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱10.00 | sell/kg=₱56.00 | sell/sack=₱2,800.00', 1, '2026-08-02 21:26:36', '2026-08-02 21:31:25'),
(62, 8, 'B000062', 79, 'purchase', '2026-08-02', 50.00, 50.00, 50.00, 50.00, 0.00, 46.00, 56.00, NULL, 'Stock in recorded | sacks=1 | sack_size=50kg | supplier/sack=₱2,300.00 | transport=₱0.00 | cost/kg=₱46.00 | markup/kg=₱10.00 | sell/kg=₱56.00 | sell/sack=₱2,800.00', 1, '2026-08-02 21:27:46', '2026-08-02 21:27:46'),
(63, 29, 'B000063', 80, 'purchase', '2026-08-03', 50.00, 250.00, 0.00, 0.00, 0.00, 44.00, 54.00, NULL, 'Stock in recorded | sacks=5 | sack_size=50kg | supplier/sack=₱2,200.00 | transport=₱0.00 | cost/kg=₱44.00 | markup/kg=₱10.00 | sell/kg=₱54.00 | sell/sack=₱2,700.00', 1, '2026-08-03 14:04:05', '2026-08-17 14:07:02'),
(64, 29, 'B000064', 81, 'purchase', '2026-08-10', 50.00, 50.00, 0.00, 0.00, 0.00, 44.00, 49.00, NULL, 'Stock in recorded | sacks=1 | sack_size=50kg | supplier/sack=₱2,200.00 | transport=₱0.00 | cost/kg=₱44.00 | markup/kg=₱5.00 | sell/kg=₱49.00 | sell/sack=₱2,450.00', 1, '2026-08-10 14:04:21', '2026-08-17 14:07:23'),
(65, 14, 'B000065', 82, 'purchase', '2026-08-12', 10.00, 50.00, 50.00, 50.00, 0.00, 50.00, 55.00, NULL, 'Stock in recorded | sacks=5 | sack_size=10kg | supplier/sack=₱500.00 | transport=₱0.00 | cost/kg=₱50.00 | markup/kg=₱5.00 | sell/kg=₱55.00 | sell/sack=₱550.00', 1, '2026-08-12 10:48:17', '2026-08-12 10:48:17'),
(66, 14, 'B000066', 83, 'purchase', '2026-08-17', 10.00, 50.00, 50.00, 50.00, 0.00, 50.00, 57.00, NULL, 'Stock in recorded | sacks=5 | sack_size=10kg | supplier/sack=₱500.00 | transport=₱0.00 | cost/kg=₱50.00 | markup/kg=₱7.00 | sell/kg=₱57.00 | sell/sack=₱570.00', 1, '2026-08-18 00:46:20', '2026-08-18 00:46:20'),
(67, 14, 'B000067', 84, 'purchase', '2026-08-17', 10.00, 50.00, 50.00, 50.00, 0.00, 50.00, 55.00, NULL, 'Stock in recorded | sacks=5 | sack_size=10kg | supplier/sack=₱500.00 | transport=₱0.00 | cost/kg=₱50.00 | markup/kg=₱5.00 | sell/kg=₱55.00 | sell/sack=₱550.00', 1, '2026-08-18 01:21:36', '2026-08-18 01:21:36'),
(68, 10, 'B000068', 85, 'purchase', '2026-08-18', 10.00, 50.00, 50.00, 50.00, 0.00, 70.00, 70.00, NULL, 'Stock in recorded | sacks=5 | sack_size=10kg | supplier/sack=₱700.00 | transport=₱0.00 | cost/kg=₱70.00 | markup/kg=₱0.00 | sell/kg=₱70.00 | sell/sack=₱700.00 | payment=credit', 1, '2026-08-18 15:23:48', '2026-08-18 15:23:48'),
(69, 29, 'B000069', 88, 'purchase', '2026-09-01', 50.00, 500.00, 200.00, 200.00, 0.00, 42.00, 52.00, NULL, 'Stock in recorded | sacks=10 | sack_size=50kg | supplier/sack=₱2,100.00 | transport=₱0.00 | cost/kg=₱42.00 | markup/kg=₱10.00 | sell/kg=₱52.00 | sell/sack=₱2,600.00 | payment=cash', 1, '2026-09-01 23:32:35', '2026-09-01 23:37:18');

-- --------------------------------------------------------

--
-- Table structure for table `stock_condition`
--

CREATE TABLE `stock_condition` (
  `stock_condition_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL DEFAULT 0,
  `batch_id` int(11) DEFAULT NULL,
  `rice_name` varchar(150) NOT NULL,
  `variety` varchar(150) NOT NULL,
  `condition_type` enum('Sellable','Discounted','Unsellable','Damaged') NOT NULL DEFAULT 'Sellable',
  `reason` varchar(255) DEFAULT NULL,
  `quantity` decimal(12,2) NOT NULL DEFAULT 0.00,
  `discount_price_per_kg` decimal(12,2) DEFAULT NULL,
  `adjusted_by` int(11) DEFAULT NULL,
  `date_arrived` datetime NOT NULL DEFAULT current_timestamp(),
  `original_price_per_kg` decimal(10,2) DEFAULT NULL,
  `recorded_by` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock_condition`
--

INSERT INTO `stock_condition` (`stock_condition_id`, `product_id`, `batch_id`, `rice_name`, `variety`, `condition_type`, `reason`, `quantity`, `discount_price_per_kg`, `adjusted_by`, `date_arrived`, `original_price_per_kg`, `recorded_by`) VALUES
(1, 6, NULL, 'Angelica Rice', 'Premium', 'Damaged', 'test', 25.00, NULL, NULL, '2026-03-18 21:30:00', NULL, NULL),
(2, 21, NULL, 'Dinorado', 'Regular', 'Unsellable', 'Quality downgrade - testtt', 150.00, NULL, 1, '2026-03-22 18:02:54', NULL, NULL),
(3, 22, NULL, 'Coco Pandan', 'Premium', 'Damaged', 'Wet stock - test', 250.00, NULL, 1, '2026-03-22 18:03:37', NULL, NULL),
(4, 11, NULL, 'Japonika', 'Premium', 'Discounted', 'Discounted @ ₱50.60/kg - test', 40.00, 50.00, 1, '2026-03-22 18:42:27', NULL, NULL),
(5, 25, NULL, 'Dona Maria', 'Premium', 'Discounted', 'Discounted @ ₱30.00/kg - test', 150.00, 30.00, 1, '2026-03-24 12:10:04', NULL, NULL),
(6, 8, NULL, 'NFA Rice', 'Premium', 'Damaged', 'Pest contamination - test', 100.00, NULL, 1, '2026-03-24 12:28:31', NULL, NULL),
(7, 14, NULL, 'Black Rice', 'Premium', 'Unsellable', 'Torn sack - sada', 10.00, NULL, 1, '2026-04-07 10:58:43', NULL, NULL),
(8, 23, NULL, 'Jasponica', 'Regular', 'Damaged', 'Pest contamination - pest', 50.00, NULL, 1, '2026-04-08 19:05:07', NULL, NULL),
(9, 26, NULL, 'Agriko', 'Regular', 'Damaged', 'Torn sack - done', 150.00, NULL, 1, '2026-04-26 21:06:09', NULL, NULL),
(10, 22, 19, 'Coco Pandan', 'Premium', 'Discounted', 'Discounted @ ₱49.28/kg - DISCOUNTED', 100.00, 49.28, 1, '2026-06-09 16:15:27', NULL, NULL),
(11, 6, 24, 'Angelica Rice', 'Premium', 'Damaged', 'Quality downgrade - QUALITY IS NOT GOOD', 25.00, NULL, 1, '2026-07-27 15:42:13', NULL, NULL),
(12, 6, 24, 'Angelica Rice', 'Premium', 'Discounted', 'Discounted @ ₱57.00/kg - DISCOUNTED', 25.00, 57.00, 1, '2026-07-27 15:50:04', NULL, NULL),
(13, 22, 19, 'Coco Pandan', 'Premium', 'Discounted', 'Discounted @ ₱49.00/kg - DISCOUNTED', 50.00, 49.00, 1, '2026-07-27 15:53:31', NULL, NULL),
(14, 12, 11, 'Jasmine Rice (Local)', 'Regular', 'Discounted', 'Discounted @ ₱44.00/kg - DISCOUNTED', 50.00, 44.00, 1, '2026-07-27 16:06:25', NULL, NULL),
(15, 15, 36, 'Sakura', 'Premium', 'Discounted', 'Discounted @ ₱46.66/kg - DISCOUNTED BECASUE OF QUALITY', 15.00, 46.66, 1, '2026-07-29 18:39:40', NULL, NULL),
(16, 28, 39, 'Maharlika', 'Premium', 'Discounted', 'Discounted @ ₱40.80/kg - discounted for quality downgrade', 50.00, 40.80, 1, '2026-07-31 11:25:07', NULL, NULL),
(17, 28, 39, 'Maharlika', 'Premium', 'Damaged', 'Torn sack', 50.00, NULL, 1, '2026-08-11 15:52:53', NULL, NULL),
(18, 22, 19, 'Coco Pandan', 'Premium', 'Damaged', 'Manual recount correction - DFDF', 350.00, NULL, 1, '2026-08-20 11:20:17', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `stock_condition_logs`
--

CREATE TABLE `stock_condition_logs` (
  `scl_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `condition_type` enum('damaged','cheap_sell') NOT NULL,
  `qty_kg` decimal(12,2) NOT NULL DEFAULT 0.00,
  `cheap_price_per_kg` decimal(12,2) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `status` enum('open','resolved') NOT NULL DEFAULT 'open',
  `reported_by` int(11) DEFAULT NULL,
  `reported_at` datetime NOT NULL DEFAULT current_timestamp(),
  `resolved_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stock_settings`
--

CREATE TABLE `stock_settings` (
  `id` tinyint(4) NOT NULL,
  `low_threshold_kg` decimal(10,2) NOT NULL DEFAULT 10.00,
  `over_threshold_kg` decimal(10,2) NOT NULL DEFAULT 1000.00,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `dynamic_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `dynamic_cover_days` int(11) NOT NULL DEFAULT 7,
  `dynamic_overstock_days` int(11) NOT NULL DEFAULT 30,
  `dynamic_last_run` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock_settings`
--

INSERT INTO `stock_settings` (`id`, `low_threshold_kg`, `over_threshold_kg`, `updated_at`, `updated_by`, `dynamic_enabled`, `dynamic_cover_days`, `dynamic_overstock_days`, `dynamic_last_run`) VALUES
(1, 300.00, 2500.00, '2026-07-22 09:20:39', NULL, 1, 7, 30, '2026-04-26');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `supplier_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `default_payment_terms` varchar(50) DEFAULT NULL,
  `default_lead_time_days` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`supplier_id`, `name`, `contact_person`, `phone`, `address`, `default_payment_terms`, `default_lead_time_days`, `notes`, `created_at`, `status`) VALUES
(1, 'ABC Ride Trading', NULL, '09129823923', 'Cogon', NULL, NULL, NULL, '2026-01-28 05:49:02', 'active'),
(2, 'Agri Oro', NULL, '0923457982', 'cdo', NULL, NULL, NULL, '2026-01-28 08:57:03', 'active'),
(3, 'Grace Rice Trading', NULL, '09563287432', 'Cogon', NULL, NULL, NULL, '2026-01-29 02:21:50', 'active'),
(4, 'Rice Granaries', NULL, '09533844623', 'Cogon', NULL, NULL, NULL, '2026-04-26 13:07:37', 'active'),
(5, 'GoodForce Trading, Inc.', NULL, '09762873615', 'Puntod, Cagayan de Oro City', NULL, NULL, NULL, '2026-07-22 01:06:24', 'active'),
(6, 'BK Basic Rice Trading, Inc.', NULL, '09234791299', 'Gusa, Cagayan de Oro City', NULL, NULL, NULL, '2026-07-22 01:07:30', 'active'),
(7, 'Suy Sing CDO', NULL, '0967839234', 'Highway, Cagayan de Oro City', NULL, NULL, NULL, '2026-08-17 16:54:37', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_payments`
--

CREATE TABLE `supplier_payments` (
  `sp_id` int(11) NOT NULL,
  `ap_id` int(11) NOT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `method` enum('cash','gcash','bank') DEFAULT 'cash',
  `reference_no` varchar(100) DEFAULT NULL,
  `paid_at` datetime NOT NULL DEFAULT current_timestamp(),
  `paid_by` int(11) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier_payments`
--

INSERT INTO `supplier_payments` (`sp_id`, `ap_id`, `purchase_id`, `supplier_id`, `amount`, `method`, `reference_no`, `paid_at`, `paid_by`, `note`, `created_at`) VALUES
(1, 1, 2, 1, 4000.00, 'cash', '', '2026-01-28 15:15:06', 5, 'paid', '2026-01-28 07:15:06'),
(2, 2, 3, 1, 10000.00, 'cash', '', '2026-01-28 15:55:56', 5, '', '2026-01-28 07:55:56'),
(3, 4, 6, 1, 11200.00, 'cash', '', '2026-01-28 16:55:36', 5, '', '2026-01-28 08:55:36'),
(4, 5, 9, 3, 3360.00, 'cash', '', '2026-01-29 10:24:14', 5, 'done paid', '2026-01-29 02:24:14'),
(5, 6, 10, 3, 300.00, 'cash', '', '2026-01-29 19:53:29', 5, '', '2026-01-29 11:53:29'),
(6, 6, 10, 3, 4000.00, 'cash', '', '2026-01-29 19:53:37', 5, '', '2026-01-29 11:53:37'),
(7, 7, 16, 3, 400.00, 'cash', '', '2026-02-05 17:12:49', 5, 'paid na yan baks', '2026-02-05 09:12:49'),
(8, 13, 22, 3, 10000.00, 'cash', '', '2026-02-23 12:27:11', 5, 'test', '2026-02-23 04:27:11'),
(9, 13, 22, 3, 150.00, 'cash', '', '2026-02-23 12:27:26', 5, 'test', '2026-02-23 04:27:26'),
(10, 8, 17, 2, 440.00, 'cash', '', '2026-02-27 13:47:47', 5, '', '2026-02-27 05:47:47'),
(11, 16, 25, 1, 3000.00, 'cash', '', '2026-02-27 15:51:33', 5, '', '2026-02-27 07:51:33'),
(12, 21, 30, 2, 2000.00, 'cash', '', '2026-03-24 12:41:09', 5, 'PARTIAL', '2026-03-24 04:41:09'),
(13, 21, 30, 2, 21000.00, 'cash', '', '2026-03-24 12:41:37', 5, 'FULL', '2026-03-24 04:41:37'),
(14, 23, 32, 1, 23000.00, 'cash', '', '2026-03-25 11:42:23', 5, '', '2026-03-25 03:42:23'),
(15, 24, 33, 2, 5000.00, 'cash', '', '2026-03-25 11:46:25', 5, '', '2026-03-25 03:46:25'),
(16, 22, 31, 1, 10000.00, 'cash', '', '2026-03-28 13:19:04', 5, '', '2026-03-28 05:19:04'),
(17, 20, 29, 1, 25000.00, 'cash', '', '2026-03-28 13:24:05', 5, '', '2026-03-28 05:24:05'),
(18, 19, 28, 1, 50000.00, 'cash', '', '2026-03-28 13:26:01', 5, '', '2026-03-28 05:26:01'),
(19, 18, 27, 3, 46276.40, 'cash', '', '2026-04-17 20:06:35', 5, '', '2026-04-17 12:06:35'),
(20, 28, 39, 3, 39000.00, 'cash', '', '2026-06-02 11:14:40', 5, 'paid', '2026-06-02 03:14:40'),
(21, 32, 85, 4, 3500.00, 'cash', '', '2026-08-18 15:37:47', 5, 'paid', '2026-08-18 07:37:47'),
(22, 31, 54, 4, 11669.84, 'cash', '', '2026-08-20 11:33:17', 5, '', '2026-08-20 03:33:17'),
(23, 30, 52, 3, 2000.01, 'cash', '', '2026-08-20 11:33:44', 5, '', '2026-08-20 03:33:44'),
(24, 30, 52, 3, 100.00, 'cash', '', '2026-08-20 11:37:15', 5, '', '2026-08-20 03:37:15');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expires_at` datetime DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `role` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `reset_token`, `reset_token_expires_at`, `first_name`, `last_name`, `phone`, `email`, `role`, `created_at`, `status`) VALUES
(1, 'admin', '$2y$10$VppWtCcA0hAvVzNFEdlaQetJo1i0tpvfQWbReMMZbwf5GzXCVcXIa', NULL, NULL, 'System', 'Administrator', '09123456789', 'kriezylv@gmail.com', 'admin', '2026-01-23 11:33:23', 'active'),
(2, 'cashier', '$2y$10$/vjzCy.EfjxkbAGb1nMAQefwgm8VprGACjTwyL5CvUafCnMEgFgIC', NULL, NULL, 'Cashier', 'System', '09345766834', 'averyash68@gmail.com', 'cashier', '2026-01-24 05:14:29', 'active'),
(5, 'owner', '$2y$10$MAXQlW5g5XlS89s848bLWOTsaO41CRZpDXyFQ2W/wu2Se38YiA.OW', 'bb3e790456ac1c0e7f537db9610b734324d777abd8d57965c326cd593f69e061', '2026-08-20 05:38:33', 'Kriz', 'Villlalobos', '09127837823', 'kriezylvillalobos@gmail.com', 'owner', '2026-01-25 07:26:32', 'active'),
(10, 'justinia', '$2y$10$S1T2QDDTAR4pUhdn5Kt5iuyeW1Ic.Ry./PCwU1xZ20AeEaq81cWEC', NULL, NULL, 'Justinia', 'Garoza', '09703375597', 'justiniagaroza@gmail.com', 'cashier', '2026-08-03 05:12:46', 'active'),
(11, 'jayson', '$2y$10$53j2Jm871hi5rnYWXM747.06S6fcH6wcBpGShH0Q27//i.NEYP8oK', NULL, NULL, 'Jayson', 'Belmes', '09345766834', 'jrbelmes.coc@phinmaed.com', 'cashier', '2026-08-20 01:37:52', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `user_email_otp_challenges`
--

CREATE TABLE `user_email_otp_challenges` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `otp_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `max_attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 5,
  `used_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_email_otp_challenges`
--

INSERT INTO `user_email_otp_challenges` (`id`, `user_id`, `otp_hash`, `expires_at`, `attempts`, `max_attempts`, `used_at`, `created_at`) VALUES
(1, 2, '$2y$10$PYAxzQXsWzpkHhXmp/jDbeeYkgGVveyxuqcvJ9YMb1fHwd.VQH6hW', '2026-03-03 15:41:00', 0, 5, '2026-03-03 15:38:10', '2026-03-03 07:36:00'),
(2, 2, '$2y$10$vaah.PRd/JCOwSBTHdGFbuw6OBxXja.SlUtlXDSpZpx8JegYN8uBy', '2026-03-03 16:07:52', 0, 5, '2026-03-03 16:03:20', '2026-03-03 08:02:52'),
(3, 2, '$2y$10$neEqH1VkMtCq2oVPaTOSkeazFwVUcbll3rAcP9SuJhwJLr2AEhbfu', '2026-03-03 16:08:35', 0, 5, '2026-03-03 16:03:51', '2026-03-03 08:03:35'),
(4, 2, '$2y$10$LR3J4Dml1JjjHzur9udJ2uKsStG8X31vyUTKinazNBAZguUyx.e7.', '2026-03-03 16:19:55', 0, 5, '2026-03-03 16:15:28', '2026-03-03 08:14:55'),
(5, 2, '$2y$10$wfHG.EA/edObHkDxEFVbw.kfifpmYYCZzYNI8V2Thr6Fiv4tpQ2Em', '2026-03-03 16:20:28', 0, 5, '2026-03-03 16:15:46', '2026-03-03 08:15:28'),
(6, 2, '$2y$10$iJpQj19Ou12CMsGrRCIhyOOPMDFw5gVOo/EnVvdDatZmy509moS6a', '2026-03-03 18:15:39', 0, 5, '2026-03-03 18:10:57', '2026-03-03 10:10:39'),
(7, 2, '$2y$10$mH/qy0PessM8w2Q0Y0lDWujaBzImFX9bsJ7PgnQytWDWi..tweyPe', '2026-03-03 18:18:41', 0, 5, '2026-03-03 18:14:04', '2026-03-03 10:13:41'),
(8, 2, '$2y$10$6emKm5J/sHO9oR4XO.M6ouANpQli3VbcJEzI63cFpwISbORq56iti', '2026-03-03 18:19:20', 0, 5, '2026-03-03 18:15:40', '2026-03-03 10:14:20'),
(9, 2, '$2y$10$d5kQrjLMJjPfaS12lAgvhuGZWauWVJzhZoZTmyJrbYLhhrQnDSEby', '2026-03-03 18:20:40', 0, 5, '2026-03-03 18:15:57', '2026-03-03 10:15:40'),
(10, 1, '$2y$10$Iekl3cCj0TOzXe14MiOONeBBwiVgdsBxMQ5JXBHywtGW7KzvEr38u', '2026-03-03 18:56:12', 0, 5, '2026-03-03 18:52:41', '2026-03-03 10:51:12'),
(11, 1, '$2y$10$Wy/k6YC/Omstxx33J6fGJOsWbUDz4v949XEO/JPJSTPZ7Lmyg6P5e', '2026-03-04 13:38:24', 0, 5, '2026-03-04 13:33:43', '2026-03-04 05:33:24'),
(12, 2, '$2y$10$BoQCh6K00icuTpzMlDm8fuHgtFz4SHzlQaC9C8THeXga4sRu89YMa', '2026-03-04 15:33:03', 0, 5, '2026-03-04 15:28:23', '2026-03-04 07:28:03'),
(13, 2, '$2y$10$qjRi22ErfC/BGxwCtSrrz.NG3.b/wD5PZtcokO3aHBDiGviMx8UHC', '2026-03-04 15:34:31', 0, 5, '2026-03-04 15:29:45', '2026-03-04 07:29:31'),
(14, 2, '$2y$10$oCZdhX1GjT4L1ENHIuQ9murz1wxe3cl9dSxyUinSaadRRV6KjCt4m', '2026-03-04 15:39:17', 0, 5, '2026-03-04 15:34:37', '2026-03-04 07:34:17'),
(15, 5, '$2y$10$/CZ/PsKrlG/fkTsnKnI36OMsLCZz2T1ejFl/mKx3SW.h8oPi0djfW', '2026-03-04 15:43:15', 0, 5, '2026-03-04 15:38:33', '2026-03-04 07:38:15'),
(16, 1, '$2y$10$2shO5vU/cDJBaN3HwacLK.bQIPgunpDCoXDLF08ZjgrILjZV6NTja', '2026-03-06 15:12:49', 0, 5, '2026-03-06 15:08:37', '2026-03-06 07:07:49'),
(17, 1, '$2y$10$h/38znTkRpU4g6GYD3iBWeV7RXn.IQIFB669ck038AAXCPUxeDaKy', '2026-03-09 12:50:44', 0, 5, '2026-03-09 12:46:06', '2026-03-09 04:45:44'),
(18, 2, '$2y$10$VDQO39xbHkrPZaE1hde2aebS4U.lKTsYY1jr32LinGlFbNO3EwEWq', '2026-03-10 19:41:15', 0, 5, '2026-03-10 19:37:10', '2026-03-10 11:36:15'),
(19, 1, '$2y$10$b3IIayciwZQ6GdWpwncF0.lp3po/ErmMuJoGQn38bTnfyJ.XWGT1e', '2026-03-14 13:46:47', 0, 5, '2026-03-14 13:49:29', '2026-03-14 05:41:47'),
(20, 1, '$2y$10$D/dfpbjGhGvoyqVIj8cmJevrMW5PBVRguXx8pISZ/s60zdDwnhH4S', '2026-03-14 13:54:29', 0, 5, '2026-03-14 13:55:00', '2026-03-14 05:49:29'),
(21, 2, '$2y$10$f7pCjMOdwnyZwp5WBwx1aeQmSg9dJdP7vo63gH12BhtgdpfxNJnBO', '2026-03-17 08:04:27', 0, 5, '2026-03-17 07:59:54', '2026-03-16 23:59:27'),
(22, 2, '$2y$10$ew7PnlizvObEEjUaDDAAn.aMIgAOU9ls9uHXh0lGAMtkaWPmhLRKq', '2026-03-17 08:40:52', 0, 5, '2026-03-17 08:36:20', '2026-03-17 00:35:52'),
(23, 2, '$2y$10$m4TOfUX0eSzkLyqTWkngGu0/ByE14CYo51Iubvtx4jNTai9mOwWfm', '2026-03-18 21:54:10', 0, 5, '2026-03-18 21:49:41', '2026-03-18 13:49:10'),
(24, 1, '$2y$10$JvRH6MMNrPqyLJ53X5eqp.QS7YLTHO/9eppeO/weYwWjIF38rhCAe', '2026-03-18 22:05:30', 0, 5, '2026-03-18 22:01:24', '2026-03-18 14:00:30'),
(25, 1, '$2y$10$FRzPlebkoTlyZKk56cadFuMP3X87WONfNNQpgjA6UlXOhC2TAvkl6', '2026-03-19 13:19:36', 0, 5, '2026-03-19 13:14:54', '2026-03-19 05:14:36'),
(26, 5, '$2y$10$Amw/GjQt7Vm.maFIr2nMMesNt2Z2uIx/H6OfEw2Tmeu4Rvk1qAswG', '2026-03-20 20:50:26', 0, 5, '2026-03-20 20:55:52', '2026-03-20 12:45:26'),
(27, 1, '$2y$10$XAVD3QpnHviCsmh3KxIeauHTcRtNHpCLphXsBiphAYiU0NyDpDNk.', '2026-03-20 21:02:06', 0, 5, '2026-03-20 20:57:40', '2026-03-20 12:57:06'),
(28, 2, '$2y$10$b6nngtkAcm1v2FINoFdg2eHzSeYuGfdukoBRWexnu/easbnKbu8eS', '2026-03-20 21:03:33', 0, 5, '2026-03-20 20:58:48', '2026-03-20 12:58:33'),
(29, 1, '$2y$10$opdSPBuigfkvLIIDBYeBmuNtKCeexR4cJ.KaxWWbbVKkpBiJj/gqa', '2026-03-20 21:38:38', 2, 5, '2026-03-20 21:34:47', '2026-03-20 13:33:38'),
(30, 1, '$2y$10$0dQJ5r5ogYj3TuyQI.NjAuFv23bJqrHuZmzoc1l3vSngB0Swr5lS.', '2026-03-20 21:39:47', 0, 5, '2026-03-20 21:35:05', '2026-03-20 13:34:47'),
(31, 2, '$2y$10$qtnHOdRBfsvE9MoS67wkguMNDzeGK2rxJP5KBLv/h4uDzk.IAcRdG', '2026-03-20 22:05:57', 0, 5, '2026-03-20 22:01:27', '2026-03-20 14:00:57'),
(32, 5, '$2y$10$tuscSSc/K3Ig6Yn6F0w/Xe0mTIuu7dkQb0rjqj5v8RiVsLD4DlzK6', '2026-03-20 22:43:58', 0, 5, '2026-03-20 22:39:16', '2026-03-20 14:38:58'),
(33, 5, '$2y$10$eJZlQOenPSU0r4GPxulKXORVgRjZHBSHv577d0S52fsUt.k7WnNL2', '2026-03-20 22:45:47', 0, 5, '2026-03-20 22:41:16', '2026-03-20 14:40:47'),
(34, 5, '$2y$10$WmAzXunNabwln8aGMP2Jb.4Csudd/U91uIvKkxwk4qqhCUSlSKGeq', '2026-03-20 22:46:43', 0, 5, '2026-03-20 22:42:00', '2026-03-20 14:41:43'),
(35, 1, '$2y$10$/jZFfjfJOAGu7Mqtp4rvoumuMJTJLtxIYaHJ1id2SEDXe04CqA/zW', '2026-03-20 22:49:21', 0, 5, '2026-03-20 22:44:44', '2026-03-20 14:44:21'),
(36, 2, '$2y$10$VygBv6TvTzO3vf4CRloaquGpkk9kCLdbYWo4U3mq/MDx9IB7jf6jS', '2026-03-22 19:35:05', 0, 5, '2026-03-22 19:30:34', '2026-03-22 11:30:05'),
(37, 2, '$2y$10$vmgTnG2M9snsqvco8Eg2BurUh/isMY0oN52GCBfGSMPdt8W5SV6dy', '2026-03-22 19:35:34', 0, 5, '2026-03-22 19:31:28', '2026-03-22 11:30:34'),
(38, 2, '$2y$10$R4sZVpfRMW8bahsgA2qEze8/HRduliuP6NHYfi3jjBs8dXykNlZ3y', '2026-03-22 19:36:28', 0, 5, '2026-03-22 20:30:59', '2026-03-22 11:31:28'),
(39, 2, '$2y$10$85NPeAz0S/9FAj9XIhbHlup4HuJ6m7d8LPHPpvjp3ajjhBoQxsGXW', '2026-03-22 20:35:59', 0, 5, '2026-03-22 20:33:39', '2026-03-22 12:30:59'),
(40, 2, '$2y$10$5ZCGYj.lSUg35x2DRvrvUuiycBsK7lGD3ZPWzIqC0xnP4MUmJh.WO', '2026-03-22 20:38:39', 0, 5, '2026-03-22 20:59:02', '2026-03-22 12:33:39'),
(41, 2, '$2y$10$syg6kJvfY8rtj5Knyo/WXegjKBAYtGj2ZZpmGAvEZQcSVj4xzcfSe', '2026-03-22 21:04:02', 0, 5, '2026-03-22 21:01:04', '2026-03-22 12:59:02'),
(42, 2, '$2y$10$/XcnFUmf8qK58VtC1bphhuaUg0E.0Axz58vqI3X27xSFpwAu1Os2K', '2026-03-22 21:06:04', 0, 5, '2026-03-22 21:02:31', '2026-03-22 13:01:04'),
(43, 2, '$2y$10$ug3tS7GMezTvXEJ3O.hYP.GKOWZHJRgS2VMsM4MArkjgakRPpcjQq', '2026-03-22 21:07:31', 0, 5, '2026-03-23 10:15:50', '2026-03-22 13:02:31'),
(44, 2, '$2y$10$fdc.fCNg4ZVWqScByCkQC.tFU.nENpA0CdN4BaAucLUkEzgDVKFVO', '2026-03-23 10:20:50', 0, 5, '2026-03-23 10:30:36', '2026-03-23 02:15:50'),
(45, 2, '$2y$10$HiGUcW3i3AuOE35krW2X9OsYAZxgctS0f7/e0pg60zAod/eDyjis.', '2026-03-23 10:35:36', 0, 5, '2026-03-23 10:31:44', '2026-03-23 02:30:36'),
(46, 2, '$2y$10$VTavMmt6rL0U/uanfzFiyun0AJwY9kUROEh/52h6YRkYjmURMq02S', '2026-03-23 10:36:44', 0, 5, '2026-03-23 10:32:09', '2026-03-23 02:31:44'),
(47, 1, '$2y$10$amCsvtwkEo5HhgevXpcBR.x2Rc1ZsM1uIOTeXdDokhfwo1qqjiULe', '2026-03-23 10:45:09', 0, 5, '2026-03-23 10:40:25', '2026-03-23 02:40:09'),
(48, 5, '$2y$10$rrQSVv9dFyqzWocAoMpmg.dmooNmrNnP.sgywBtUiFC2pLj8CEyma', '2026-03-23 11:52:35', 0, 5, '2026-03-23 11:48:10', '2026-03-23 03:47:35'),
(49, 1, '$2y$10$p.qB0WBfjLXhcxxMh27UyOtfcB8sJYF8MYTW5XzT6F5r68YZsyJBe', '2026-03-23 12:03:52', 0, 5, '2026-03-23 11:59:08', '2026-03-23 03:58:52'),
(50, 5, '$2y$10$pxwpDHbBgMKRVSp.Xq36N.3OrSW/w4v0ZzgHmc7o1Y5ipVE54XdzO', '2026-03-23 12:08:30', 0, 5, '2026-03-23 12:03:45', '2026-03-23 04:03:30'),
(51, 1, '$2y$10$c7oS6bdFmbNtWoEpGLRCT.4/qQ.rPLvHYdzISvBwNMiSiBNrG5VdS', '2026-03-23 12:23:56', 0, 5, '2026-03-23 12:19:12', '2026-03-23 04:18:56'),
(52, 5, '$2y$10$twAQc3.Rt9CL3Hk.95WO1.NynHDm2lTvaobBAWTh0eQbEtIWRSpVK', '2026-03-23 12:52:22', 0, 5, '2026-03-23 12:47:36', '2026-03-23 04:47:22'),
(53, 1, '$2y$10$YsO.uWLIjRicWRm9dH7cl.AGHMCs3qj0jxdW6pkPrp/fLHzAz7jYS', '2026-03-23 13:36:57', 0, 5, '2026-03-23 13:32:13', '2026-03-23 05:31:57'),
(54, 2, '$2y$10$BxCouXCuBU86beRLjZ8YK.9G8ATNEVinvL0apgtO8uHGUVqOdeIEy', '2026-03-23 20:49:00', 0, 5, '2026-03-23 20:44:19', '2026-03-23 12:44:00'),
(55, 1, '$2y$10$Y12CCSOR2S7HFLEwP59/GeXKDvQDJuH8jXPhhWAC6jvlSK49mF2wW', '2026-03-24 11:13:07', 0, 5, '2026-03-24 11:09:41', '2026-03-24 03:08:07'),
(56, 2, '$2y$10$T/wQRUkQdsKFgN/Uqeb75eCUzReYrbgx9LllFLN9vVOqZNwYd3aC.', '2026-03-24 12:35:51', 0, 5, '2026-03-24 12:31:21', '2026-03-24 04:30:51'),
(57, 5, '$2y$10$DjIu/UZeHH1NBD.GkvYOU.yaUtNjFAeOQfwpejuvAHvy/71pBuWpC', '2026-03-24 12:39:16', 0, 5, '2026-03-24 12:35:40', '2026-03-24 04:34:16'),
(58, 1, '$2y$10$F0tJOURWQZr/wEv4Ouop4O7f83w5j77Mcmg6OH9DqBA1FX9SIeGke', '2026-03-24 12:41:48', 0, 5, '2026-03-24 12:37:57', '2026-03-24 04:36:48'),
(59, 5, '$2y$10$2l/mjXbEIRbtVdAEPB3leeJ5Atkb6k5.Etvdtilh.PA5YSde09tt2', '2026-03-24 12:45:11', 0, 5, '2026-03-24 12:40:28', '2026-03-24 04:40:11'),
(60, 2, '$2y$10$W99M9SGi1uMaZKU6hfO5ceT4So/R4TahnFnrL5BYzZJnuSPkeOT6e', '2026-03-24 12:48:00', 0, 5, '2026-03-24 12:43:23', '2026-03-24 04:43:00'),
(61, 1, '$2y$10$5zrDwiXUQEei7dX5WzETfuMWJODo77YU1CWDqC76RpOIQ4OlE4v.q', '2026-03-24 17:07:53', 0, 5, '2026-03-24 17:03:20', '2026-03-24 09:02:53'),
(62, 2, '$2y$10$OakAxy5h2mRxASXlZnvDE.mEvLZU01sWMPuL7665QRjCd7vCvmud2', '2026-03-25 10:31:48', 0, 5, '2026-03-25 10:28:39', '2026-03-25 02:26:48'),
(63, 2, '$2y$10$B6j13q.KPbW8g0n2Jq2OI.HQHfDA.eqOxqVjfi7rO.n/uIBSmer0a', '2026-03-25 10:33:39', 0, 5, '2026-03-25 10:39:35', '2026-03-25 02:28:39'),
(64, 2, '$2y$10$c4H1fxGxnRT3X.sOhO9Phuz.zxkVfxWQZUC.FKhFshPhRTGUwwcUS', '2026-03-25 10:44:35', 0, 5, '2026-03-25 10:39:58', '2026-03-25 02:39:35'),
(65, 1, '$2y$10$pil7qZ0R7lOnHemROKP4g.qv7CPGtsTU1QEJieApNAQg.DhmKA8UW', '2026-03-25 11:32:40', 0, 5, '2026-03-25 11:29:25', '2026-03-25 03:27:40'),
(66, 5, '$2y$10$0VDWRvj9A2hlC9AcY4trbO2g2p1C7kwbrC7.r5gOSywuNGCMgZDTu', '2026-03-25 11:44:52', 0, 5, '2026-03-25 11:40:37', '2026-03-25 03:39:52'),
(67, 1, '$2y$10$cy0Y.TZgTaulgjZ2WZksR..mOwOvn0O585W024SnBRoezxaSn34AG', '2026-03-25 11:48:27', 0, 5, '2026-03-25 11:43:42', '2026-03-25 03:43:27'),
(68, 2, '$2y$10$ritXw5hiPWkzk2DBJ2E6W.lrp36eVwcz/7NEt3iKpLVbxRM01LXj6', '2026-03-25 11:55:08', 0, 5, '2026-03-25 11:50:30', '2026-03-25 03:50:08'),
(69, 1, '$2y$10$kVVGq7HNXLQfZhf.rsa5yeWrSW9/Kxs.6gQ4EFklZZU9jDHTU0nmq', '2026-03-25 22:45:51', 0, 5, '2026-03-25 22:41:05', '2026-03-25 14:40:51'),
(70, 1, '$2y$10$k6YdS3MR/idGNp74RPrS9OOoq3UvIYdbXJUafle7xu69C8pQ3pBkG', '2026-03-26 11:48:06', 0, 5, '2026-03-26 11:43:31', '2026-03-26 03:43:06'),
(71, 1, '$2y$10$a1juSxq.xCvBOetqPKQT3.N1C3smtpWY82BreRkW6zb/k9uLZrdCq', '2026-03-28 11:45:56', 0, 5, '2026-03-28 11:42:51', '2026-03-28 03:40:56'),
(72, 1, '$2y$10$4dkK9vrg6O6xjxSVQ27dwOwCP0jbxMSzjD0hYCcTAzOwH8VRt4yfG', '2026-03-28 11:47:52', 0, 5, '2026-03-28 11:44:51', '2026-03-28 03:42:52'),
(73, 1, '$2y$10$lytW8XcawUqAlAMM/xg3c.VQzkfYpFqGA59apcXlhaUIE6WTT.3NW', '2026-03-28 11:49:51', 0, 5, '2026-03-28 11:46:35', '2026-03-28 03:44:51'),
(74, 1, '$2y$10$QM7uy48mylMjwBbbODiKWe1neEclVGZeaK.myfw9nciBICvkRdTK2', '2026-03-28 11:51:35', 0, 5, '2026-03-28 11:48:11', '2026-03-28 03:46:35'),
(75, 1, '$2y$10$X3gpFnwTdlGNTLXXPSQdNu7Qu/9eNUynu/GpuapVy0Fsv5UGf.9me', '2026-03-28 11:53:11', 0, 5, '2026-03-28 11:49:54', '2026-03-28 03:48:11'),
(76, 2, '$2y$10$/rkcYOD5cIHUsMoNwsK1SOb/wCWz/Li5k.BSf2Cx/gSi3wIw.jIwe', '2026-03-28 12:46:14', 0, 5, '2026-03-28 12:41:47', '2026-03-28 04:41:14'),
(77, 5, '$2y$10$qdmOcIb4OkjQKglHe2qHxOcQ03JHFY3k0LHNqI.if7sFr1fxnPkhO', '2026-03-28 13:21:58', 0, 5, '2026-03-28 13:17:16', '2026-03-28 05:16:58'),
(78, 1, '$2y$10$dqJ91l.ObaSCvd2vVJZHWOF.KTavZx7I6T3lsFmDPgeGjlK5Phb62', '2026-04-01 15:08:39', 0, 5, '2026-04-01 15:04:19', '2026-04-01 07:03:39'),
(79, 1, '$2y$10$XoRbM2/EPYqxaYSlClqop.Otrq4wav.D8Q4LDF2nn8QrkBW7Y6Tt2', '2026-04-07 08:57:04', 0, 5, '2026-04-07 08:52:24', '2026-04-07 00:52:04'),
(80, 2, '$2y$10$c3qSJPVXR1IlgFqoYgxaU.oW7DM7cx3Wmu2DtGTsXL4ZY9Z/bnRBy', '2026-04-07 12:03:55', 0, 5, '2026-04-07 11:59:23', '2026-04-07 03:58:55'),
(81, 5, '$2y$10$tbwWi1OfM0ZsXc.wz0kPr.oectFmZNwhjHBRc7rCI/0o.LQaZOGgy', '2026-04-07 12:24:45', 0, 5, '2026-04-07 12:20:43', '2026-04-07 04:19:45'),
(82, 1, '$2y$10$xcG6/8Y6g7wWWta8MmLXa.i4w0d/wai1N//AmRhYwz2H4vrDc846m', '2026-04-08 12:13:17', 0, 5, '2026-04-08 12:08:31', '2026-04-08 04:08:17'),
(83, 2, '$2y$10$jmo6H9aFKabYhvZqJnNirOb9MHhTwxG1tHwnG1fgu3fhzrDW0dE/6', '2026-04-08 12:30:53', 0, 5, '2026-04-08 12:26:07', '2026-04-08 04:25:53'),
(84, 5, '$2y$10$Es88GTGoju8pOklUiLBxXuGfMlkFNDhle/zou9p8o99KyXofqC2vK', '2026-04-08 12:33:56', 0, 5, '2026-04-08 12:29:12', '2026-04-08 04:28:56'),
(85, 1, '$2y$10$JUQKqohX5EJCWSfoLuSzROi0HDXuQgoYHKD0wHYFuBfbK7fGY1mB.', '2026-04-08 18:29:38', 0, 5, '2026-04-08 18:24:55', '2026-04-08 10:24:38'),
(86, 2, '$2y$10$zjMq4Bh35pc2gr2qTQrZ1O7D/iXuR3lVGBECBi5lNsZmzj6c02obe', '2026-04-08 18:31:32', 0, 5, '2026-04-08 18:26:46', '2026-04-08 10:26:32'),
(87, 1, '$2y$10$pXHw1pj8/uzHcQsJuTEUJuQK3ZyLPnG/Olbvjhz5gCAJODucBY4gm', '2026-04-08 18:51:44', 0, 5, '2026-04-08 18:47:04', '2026-04-08 10:46:44'),
(88, 2, '$2y$10$2pUMVq6Powz.qrKbcR90tuUV3GYb71uXiF34xp9tYDHOc6gjmasAy', '2026-04-08 19:15:52', 0, 5, '2026-04-08 19:11:10', '2026-04-08 11:10:52'),
(89, 5, '$2y$10$g0akfNlTt7TaB4niGvXX3enbES6kFSGqMSu63g1kytNYRMMSBtAYC', '2026-04-08 19:35:33', 0, 5, '2026-04-08 19:30:49', '2026-04-08 11:30:33'),
(90, 1, '$2y$10$ziTcxpVVV2DGDDC6uRSSSe9wHZG4GYU8qzCXkVsoB5cEX9H33gSN.', '2026-04-08 19:53:15', 0, 5, '2026-04-08 19:48:30', '2026-04-08 11:48:15'),
(91, 2, '$2y$10$JzSR33td2twoXSu.yyh4CO2aCXJtx11oKHpAg6Fa59c.DMBhzpNny', '2026-04-08 20:15:19', 0, 5, '2026-04-08 20:10:32', '2026-04-08 12:10:19'),
(92, 5, '$2y$10$doRVpo1SGaiHk2AUdDKy4eNORTzYzdKOygJGBEdHdHFKg1PGA.n3u', '2026-04-08 20:20:40', 0, 5, '2026-04-08 20:15:57', '2026-04-08 12:15:40'),
(93, 1, '$2y$10$ieLpnW9yyKmWMtCYfvFTjeKuOQhS9GrXJrbM3PHmgwL2j2yCkTyFi', '2026-04-08 20:54:45', 0, 5, '2026-04-08 20:50:01', '2026-04-08 12:49:45'),
(94, 1, '$2y$10$aVtn4kEMmVM8Py.Ya9TxkubHSx1ywZJIYvkwtUd./crLfB1KDJQi2', '2026-04-08 20:57:49', 0, 5, '2026-04-08 20:53:04', '2026-04-08 12:52:49'),
(95, 2, '$2y$10$f4rssST.yv/Vts/ZbZwGg.Y8M1hX.2KrOC6kye4EMbFFV4gT/ICLO', '2026-04-08 20:58:51', 0, 5, '2026-04-08 20:54:05', '2026-04-08 12:53:51'),
(96, 5, '$2y$10$rwNxZtkWyc3dD6ptt8t2K.xOwvVEDrtfC9EcKneZBjzgjNK4.hzHy', '2026-04-08 21:02:09', 0, 5, '2026-04-08 20:57:21', '2026-04-08 12:57:09'),
(97, 1, '$2y$10$a5fn7sVAcukvsDgUQcx.UuJOhKtgAkKlpSw8EtJVsqJcxiDzioSqy', '2026-04-21 18:38:48', 0, 5, '2026-04-21 18:34:18', '2026-04-21 10:33:48'),
(98, 1, '$2y$10$8d3sn59TxLT0EEa3Z1lXReTbz5TO0JlFJIqd0AbV99J8.21cOOsxC', '2026-04-21 18:39:18', 0, 5, '2026-04-21 18:34:42', '2026-04-21 10:34:18'),
(99, 1, '$2y$10$JT3q4dlw6kNImyDUF7aAYO3kvPGiQjhLFMAvsKCgpUuwDuA5S7Ze2', '2026-04-21 18:43:38', 0, 5, '2026-04-21 18:38:55', '2026-04-21 10:38:38'),
(100, 1, '$2y$10$q7/50j2WFhVuPPU2GUR89eIgIpLAmR8NpKx/Ta/SREXdhBYYKstS.', '2026-04-21 18:53:13', 0, 5, '2026-04-21 18:48:27', '2026-04-21 10:48:13'),
(101, 1, '$2y$10$S.SYjmIb4MTG8CeRKe4OZOOoGOqMgUiwQh3S.An2UcLKjk7o4/hge', '2026-04-21 19:22:08', 0, 5, '2026-04-21 19:17:58', '2026-04-21 11:17:08'),
(102, 2, '$2y$10$/4iWRKBQ70WuQz5UEW9Kne5410RXXuKmc6euVztEJAP4hetieFI9a', '2026-04-21 19:24:22', 0, 5, '2026-04-21 19:19:38', '2026-04-21 11:19:22'),
(103, 5, '$2y$10$v1dz5H/v6uNII3QnTJQu2OW1L4q2mJOARSONphR4DI1DZgvzA5aTu', '2026-04-21 19:25:48', 0, 5, '2026-04-21 19:21:02', '2026-04-21 11:20:48'),
(104, 1, '$2y$10$IAUJxcIkqY1JXvXDIdakxuZyvmPrjmB3ELlzlAAYZvuJ8if1liUHK', '2026-04-21 19:29:01', 0, 5, '2026-04-21 19:24:16', '2026-04-21 11:24:01'),
(105, 1, '$2y$10$C72pxDlpxQdSyWVXbk15Q.zIwNE.53dDIZst/zvta/ftG7JCaMerq', '2026-04-21 19:39:59', 0, 5, '2026-04-21 19:35:13', '2026-04-21 11:34:59'),
(106, 2, '$2y$10$o/uWPugr4mONTjsB1afyWOLSYSsr9WJPPEfyds/zrQdY2d4irkJyO', '2026-04-26 21:21:47', 0, 5, '2026-04-26 21:17:28', '2026-04-26 13:16:47'),
(107, 5, '$2y$10$fHS.AtRosr9Bv5d71JsTnuzLSau42h2oYJEbiKkdsfGm3QB5U6EK2', '2026-04-26 21:23:21', 0, 5, '2026-04-26 21:18:36', '2026-04-26 13:18:21'),
(108, 5, '$2y$10$UWPQKcgHbwxptf15mbS9H.izz67o4UwWnZrzeO7V/eEaDvTvj81Ni', '2026-04-26 21:24:09', 0, 5, '2026-04-26 21:19:34', '2026-04-26 13:19:09'),
(109, 5, '$2y$10$SHhy7V95LibH4rhr9S18b.mnRLuT4oWfk9gRHKTg1dr7eetiZ4cZK', '2026-04-26 21:24:34', 0, 5, '2026-04-26 21:19:45', '2026-04-26 13:19:34'),
(110, 2, '$2y$10$0XpN0HP1W0Yiw4.28xEhe..0ZboZL6aLxu8Ixv7ULQ7iEVxJyeNKe', '2026-04-26 21:25:27', 0, 5, '2026-04-26 21:20:40', '2026-04-26 13:20:27'),
(111, 1, '$2y$10$viHzMmV8ohvChg0wy6G10.TfzSzCuUJoHdoRUeK0vj0udR9roKq6q', '2026-04-27 09:28:41', 0, 5, '2026-04-27 09:25:30', '2026-04-27 01:23:41'),
(112, 1, '$2y$10$laAE2QepFiHf6awTSnpIge.N7FR8ZweTR26ULzRyYplTKgkR4mBJm', '2026-04-27 09:30:30', 0, 5, '2026-04-27 09:26:01', '2026-04-27 01:25:30'),
(113, 2, '$2y$10$M4b7sPL97x0oJUy98bOPMeQsppbyBCdJKlHnyQv5BRW3kq5Ww6vw2', '2026-04-27 09:32:34', 0, 5, '2026-04-27 09:27:49', '2026-04-27 01:27:34'),
(114, 1, '$2y$10$CAlixdN7zYqSbfuWsge7euh.JcEETDGCYgcmtfx.2L.g0vIhGSq2K', '2026-04-27 18:46:51', 0, 5, '2026-04-27 18:42:07', '2026-04-27 10:41:51'),
(115, 1, '$2y$10$J2tMVfrT8DisXGJWMs0LBODp0KwF.0mzlFcNFEk/YejPZKCypYoLG', '2026-05-04 10:30:01', 0, 5, '2026-05-04 10:25:59', '2026-05-04 02:25:01'),
(116, 5, '$2y$10$kdZBGT8NgS8Uh0tiFw4qcOY1Z28j.gCNwGJ9Ohv/ZC6wXAkiY2z4C', '2026-05-04 11:05:24', 0, 5, '2026-05-04 11:01:24', '2026-05-04 03:00:24'),
(117, 2, '$2y$10$lkNEVTZ0rsmJOcT5HC45.OarrWGITpmaK2fWgNFOYRQaqxmPJl5uq', '2026-05-04 11:18:58', 0, 5, '2026-05-04 11:14:28', '2026-05-04 03:13:58'),
(118, 1, '$2y$10$5eyuslcUoek4/9n9S1KFoOuhazJrQae7k9VraKT0OFHY10/AUmDPq', '2026-05-11 12:30:41', 0, 5, '2026-05-11 12:25:56', '2026-05-11 04:25:41'),
(119, 5, '$2y$10$hA7WFXBbI7eKwZXpUo4pY.CawDHMF9M8ZW3S3RM16IhVWCAFS5.XS', '2026-05-11 12:33:54', 0, 5, '2026-05-11 12:29:10', '2026-05-11 04:28:54'),
(120, 2, '$2y$10$Tt0AIf4mf8j1BsAJcxIajOOk.k72ZreSZzb4MZ/bcd.0agKrJr8YG', '2026-05-11 12:36:48', 0, 5, '2026-05-11 12:33:43', '2026-05-11 04:31:48'),
(121, 2, '$2y$10$DkZxCXQ/lpxvIHUoQj113.ge.g5/nY4aVmeGlSuOTQob5nq8eZVca', '2026-05-24 16:37:29', 0, 5, '2026-05-24 16:32:45', '2026-05-24 08:32:29'),
(122, 5, '$2y$10$.gFu0PxxS7C.7Daqd6S.hu1ygZyMzrqr3F0X110lFT9hV/58X7aQ6', '2026-05-24 17:06:20', 0, 5, '2026-05-24 17:01:56', '2026-05-24 09:01:20'),
(123, 1, '$2y$10$xX7e1sCqzyMCYz8mgbW0cu/UJG0CjjnR6rcZKjQJ3/PcLRd5bVHMS', '2026-06-01 20:33:13', 0, 5, '2026-06-01 20:28:26', '2026-06-01 12:28:13'),
(124, 2, '$2y$10$0G5AQHJE27aVWrMvXq16E.gHZsAoYmvk737epYHYBFFnL3Fuf742m', '2026-06-01 20:38:07', 0, 5, '2026-06-01 20:33:20', '2026-06-01 12:33:07'),
(125, 5, '$2y$10$bt5QnIX3.yMRt9B/JG27b.yUAXZZIjq90rDvzcMIaSMKrEy8N1M9O', '2026-06-01 20:39:52', 0, 5, '2026-06-01 20:35:06', '2026-06-01 12:34:52'),
(126, 1, '$2y$10$dXUWAZYaRvbmtsC4CnULSuKr.V977/WBSMIDRtIrhGdMqXrBkC0qC', '2026-06-01 20:41:58', 0, 5, '2026-06-01 20:37:31', '2026-06-01 12:36:58'),
(127, 2, '$2y$10$Jf3ClQF3pRaZGtUZscORseZhK9f4YTePFk2fJmUy13vZRmI/XWx2y', '2026-06-01 21:07:40', 0, 5, '2026-06-01 21:02:57', '2026-06-01 13:02:40'),
(128, 1, '$2y$10$SGDPPtCCXK/zWXufZ..84ewRJ5Qs.Trv0PAVy2yTIWTjNT5DJSOry', '2026-06-02 10:56:29', 0, 5, '2026-06-02 10:51:44', '2026-06-02 02:51:29'),
(129, 2, '$2y$10$Y4x0pi0bMCxS6dmuifl5pup6rD8josP3gc92dM/oRCmL7pn/GLCNq', '2026-06-02 11:06:03', 0, 5, '2026-06-02 11:01:34', '2026-06-02 03:01:03'),
(130, 5, '$2y$10$CbP9ajtUbkvxt9nQWAL2berKIt2h6TB0w.YRHmCXpbmJvcdg/bVX.', '2026-06-02 11:11:44', 0, 5, '2026-06-02 11:07:01', '2026-06-02 03:06:44'),
(131, 1, '$2y$10$hlGmv9Z1YHJes3jtJU/3MOiMz2AC2INYG8kXO1waxgI8iSsDj2aNe', '2026-06-02 11:24:57', 0, 5, '2026-06-02 11:20:42', '2026-06-02 03:19:57'),
(132, 1, '$2y$10$f9Z5m0AuPBGFGUAtkd6u5OCZcO7rwE4Nw4bsq8NVcIXbbttgR0Md2', '2026-06-09 15:56:20', 0, 5, '2026-06-09 15:51:38', '2026-06-09 07:51:20'),
(133, 1, '$2y$10$yhgD2T/vxhf8KCQK17ZGse9Qoa7eGJezqYEM.cWxu5DLLTETRgL06', '2026-06-09 16:10:31', 0, 5, '2026-06-09 16:05:44', '2026-06-09 08:05:31'),
(134, 2, '$2y$10$1T/dDTHwHzMD0.JTox/RSe.w9Rfew26O9B0h60yEEIS4v4RTAiynC', '2026-06-09 16:17:38', 0, 5, '2026-06-09 16:13:16', '2026-06-09 08:12:38'),
(135, 1, '$2y$10$0OkMRRfRy18enfEw4Ewvnuk7d2/5dwgIWURTFa9W15TCFZX8bYani', '2026-06-10 09:47:39', 0, 5, '2026-06-10 09:42:55', '2026-06-10 01:42:39'),
(136, 2, '$2y$10$NYCmkShaCfSzt6VHzTHq5.Zja5j06DZ2U/iUkGjvL5.I5.9C7MXQm', '2026-06-10 09:48:28', 0, 5, '2026-06-10 09:43:41', '2026-06-10 01:43:28'),
(137, 5, '$2y$10$y0cGSATrmf4RNkMNifLY2emIc/W5Tz0HmUqU/UE2z7yypyTsTqXLS', '2026-06-10 10:04:26', 0, 5, '2026-06-10 09:59:56', '2026-06-10 01:59:26'),
(138, 1, '$2y$10$slv/QzycHx/b5oetDN9tRurYnbXLwtO9ad4YBmQkvCsiwAIMamfIK', '2026-06-10 10:09:02', 0, 5, '2026-06-10 10:04:15', '2026-06-10 02:04:02'),
(139, 2, '$2y$10$J/STxlviMFPRiJG1cxd8iuwdPMztOIa2gsboqMXtVC1l5BVtTzOn2', '2026-06-10 10:23:08', 0, 5, '2026-06-10 10:18:24', '2026-06-10 02:18:08'),
(140, 1, '$2y$10$VqwqIr54dA6C3h1W6pCX8ej15aJND04JPln0PZAot5f.8sK7tJLyy', '2026-06-10 17:24:45', 4, 5, '2026-06-10 17:21:31', '2026-06-10 09:19:45'),
(141, 1, '$2y$10$MfkdY8VwRfuHiwitOOrN4eV7InWBlvcJ5zZ.orfCRB10xAnXaYSGW', '2026-06-11 08:25:13', 0, 5, '2026-06-11 08:21:59', '2026-06-11 00:20:13'),
(142, 2, '$2y$10$FXj52/eQYWZI2OlnHksBzeBTOzPQft.Bjdox1eKeN88rsqZ8m7yBW', '2026-06-11 08:41:31', 0, 5, '2026-06-11 08:36:53', '2026-06-11 00:36:31'),
(143, 5, '$2y$10$X0w5Ac1BWIgCHLdCETt5YeXX9UxYz6helj6jF7iaBE0q7AQTKTg2m', '2026-06-11 08:47:48', 0, 5, '2026-06-11 08:43:21', '2026-06-11 00:42:48'),
(144, 1, '$2y$10$SeoStjjsnKdgNBadma0RC.X4cpFleTljPN7Pw0SgUEBUcQ5yV6YF6', '2026-06-11 08:49:39', 0, 5, '2026-06-11 08:45:51', '2026-06-11 00:44:39'),
(146, 1, '$2y$10$LT3ZEZb0N2xUE1xvsu/M3uN8lVj8wK77//w9/Rs5t00YbJH236476', '2026-06-11 09:34:44', 0, 5, '2026-06-11 09:30:14', '2026-06-11 01:29:44'),
(147, 5, '$2y$10$ImyVJoaa0Wq2kr9EliopsuKS7PEsuXclvX5nVLLGWdVj4wTfzHbJi', '2026-06-11 12:12:43', 0, 5, '2026-06-11 12:07:57', '2026-06-11 04:07:43'),
(148, 1, '$2y$10$efyeAnL6Hw6jMebOl9W43.tK5y8LwcTnq9qMQQs5Gq802Tl6A8YqK', '2026-06-11 12:13:39', 0, 5, '2026-06-11 12:09:14', '2026-06-11 04:08:39'),
(149, 1, '$2y$10$IH5XMhBNvDQvbJ2ZHKdmueCQJb/H0xV3YHL21zxu/av.X3fbG0w4W', '2026-06-12 10:26:22', 0, 5, '2026-06-12 10:25:12', '2026-06-12 02:21:22'),
(150, 1, '$2y$10$T2SuQuslNKf/hKN1lb3Ng.I5p9IVhYp7XY8wYBhMQJWkGvCww5AAW', '2026-06-12 10:30:12', 0, 5, '2026-06-12 10:25:28', '2026-06-12 02:25:12'),
(151, 5, '$2y$10$59.mheCV4C1z7ig61swKW.chPWwrgSislI.4bJs3Q9QOuwXQYuHZG', '2026-06-12 11:17:28', 0, 5, '2026-06-12 11:12:41', '2026-06-12 03:12:28'),
(152, 1, '$2y$10$5clK.d7zG1vDcliA7vocQeJVt3nIExNyc12tfgKjJJDk0s8/3IP3K', '2026-07-07 11:12:03', 0, 5, '2026-07-07 11:07:22', '2026-07-07 03:07:03'),
(153, 1, '$2y$10$VxN6BI10Fe5V.rStPWFId.Hsse/SqwSIiQFBoUqIZhh.n8U9HscDG', '2026-07-08 20:19:42', 0, 5, '2026-07-08 20:14:58', '2026-07-08 12:14:42'),
(154, 2, '$2y$10$enfq2EjRzXLdXXPkd8slEugqNtv8LvS..MPCkSCIofqy1gM83Lf9S', '2026-07-08 20:36:40', 0, 5, '2026-07-08 20:31:53', '2026-07-08 12:31:40'),
(155, 5, '$2y$10$9z54Yf8DxU4UPItHPNuDZOVqWxVOs1Q50o7/HPu1dVxnA6Wlw9A1G', '2026-07-08 21:19:51', 0, 5, '2026-07-08 21:15:08', '2026-07-08 13:14:51'),
(156, 2, '$2y$10$q5a8el790GOL6KsZTZPAtOFlMjJaKlhkiqznq9gcFEhq8xz7jxJUG', '2026-07-08 21:24:05', 0, 5, '2026-07-08 21:19:20', '2026-07-08 13:19:05'),
(157, 5, '$2y$10$wVFJq41cYLz0Wx6qp3Qm/uiD8P/9FN2AoK6rvT5DPGY7RQLJg0EOO', '2026-07-08 21:39:01', 0, 5, '2026-07-08 21:34:14', '2026-07-08 13:34:01'),
(158, 1, '$2y$10$tTjT1ioJsmWAF0H/5oSVZeMk9d43JyVZCf9hjgzXnNIn3.cfoi76q', '2026-07-16 13:52:11', 0, 5, '2026-07-16 13:48:16', '2026-07-16 05:47:11'),
(159, 1, '$2y$10$.iPrx3R8HpTVTLH/z7hnAO2.42CJYN.28lnva103McD2376g1AXki', '2026-07-16 13:53:16', 0, 5, '2026-07-16 13:50:15', '2026-07-16 05:48:16'),
(160, 1, '$2y$10$c31QCz5u1uaVYTV45ZMmTeENAo9fuPClLHTq.Kb3NhTVuIrnt/kY2', '2026-07-16 13:55:15', 0, 5, '2026-07-16 13:58:32', '2026-07-16 05:50:15'),
(161, 1, '$2y$10$8UuGGjzZ.r9XHus8nUV2xO6Qvwn8Lwp5Dofz/KM8cDDaCEFTqTkQa', '2026-07-16 14:03:32', 0, 5, '2026-07-16 13:59:43', '2026-07-16 05:58:32'),
(162, 1, '$2y$10$qz3rNkgwejxfy5YxJzxuG.GmvOe5jnsVXnk.tdAF5llIGt8eYXP9m', '2026-07-16 14:04:43', 2, 5, '2026-07-16 14:03:02', '2026-07-16 05:59:43'),
(163, 1, '$2y$10$aS0BTQN.heTXQeVb2AAHFeoe8FMsLnyDWJvaj3Ei6E0.v9OE71aoq', '2026-07-16 14:08:02', 0, 5, '2026-07-16 14:03:47', '2026-07-16 06:03:02'),
(164, 5, '$2y$10$UxQuzMsuf6s3rCj/u7GZ/ebzRNWoPUF4OJjwjQuUjo3Bpd8VhyoxO', '2026-07-16 14:12:19', 0, 5, '2026-07-16 14:07:40', '2026-07-16 06:07:19'),
(165, 2, '$2y$10$CjxszceQS0s6Ub2Bq3Ii.u.QkENT9uKvs0M1b7Xh8HXZRve82iGGi', '2026-07-16 14:17:17', 0, 5, '2026-07-16 14:13:11', '2026-07-16 06:12:17'),
(166, 2, '$2y$10$WO0BFr4Yx5pypoTKRLgVJOMx4am/cCVdV2qrZTQh.EDdo4AKx/GDa', '2026-07-16 14:52:03', 0, 5, '2026-07-16 14:47:23', '2026-07-16 06:47:03'),
(167, 2, '$2y$10$BR0sR7YLOq28POy/B3VqF./uzrLdl3lvLBzAwn4ZJpX0gFV8pIVnO', '2026-07-16 15:21:54', 0, 5, '2026-07-16 15:17:31', '2026-07-16 07:16:54'),
(168, 2, '$2y$10$02aRD8yjlJPyMNSr1u/3quQ421gA3L0sHP7Egt8PtpgisTbB2pWPa', '2026-07-16 15:48:33', 0, 5, '2026-07-16 15:44:29', '2026-07-16 07:43:33'),
(169, 2, '$2y$10$vi41ntpg9Sqa6qUXS/byy.i6ebfUajhx5YAXq/2cPsm48qFNmTSvu', '2026-07-16 16:23:17', 0, 5, '2026-07-16 16:21:46', '2026-07-16 08:18:17'),
(170, 2, '$2y$10$uneD5zUf7G9rJflIh80squviRPr0go/6BMSbaBk2/GQHkDwjUrc0a', '2026-07-16 16:26:46', 0, 5, '2026-07-16 16:35:19', '2026-07-16 08:21:46'),
(171, 2, '$2y$10$jQbTFUI.ui4Qc4xbCLCybungBODdQx7TCJ/BqLkErJ7/gFLq8h16C', '2026-07-16 16:40:19', 0, 5, '2026-07-16 16:37:13', '2026-07-16 08:35:19'),
(172, 2, '$2y$10$Xuvm1SPQPZcXJHqyQSsqXOU2p/HdaXvnTm30petAskKHpxEo186q.', '2026-07-16 16:42:13', 0, 5, '2026-07-16 16:38:18', '2026-07-16 08:37:13'),
(173, 1, '$2y$10$SYpON//OKFnHpdl58qv1lelqsPf3Dkqd3oQXd5ss6wentKRmAbb5y', '2026-07-19 20:52:40', 0, 5, '2026-07-19 20:47:54', '2026-07-19 12:47:40'),
(174, 5, '$2y$10$K4IMjpLGXoK1.sMKFEzckOZDprmwQASFP0kRPTBFmOR9AcGhWNlhS', '2026-07-19 21:11:10', 0, 5, '2026-07-19 21:06:26', '2026-07-19 13:06:10'),
(175, 2, '$2y$10$/lwqWRM7t2NMmCQnmJiMPu4XrinB6yZb3QRgPODXPLKeDDiUlAziK', '2026-07-19 21:19:37', 0, 5, '2026-07-19 21:14:53', '2026-07-19 13:14:37'),
(176, 2, '$2y$10$MU2h4dJOLhwFbfJt7MVy6eOpDj4FDLkGRa1IjTilbTHTufX6Bnlju', '2026-07-19 22:36:18', 0, 5, '2026-07-19 22:31:41', '2026-07-19 14:31:18'),
(177, 2, '$2y$10$JxonoI/7Bn247i7NuuBlrOyyBwLzz9q.PXb400ZpIIjErXUC5Eq16', '2026-07-19 23:45:39', 0, 5, '2026-07-19 23:40:52', '2026-07-19 15:40:39'),
(178, 2, '$2y$10$j2MnTPUFYIIurUYTrBqms.P9v50rjH7cHGP04W.vynrPAHQ.0q3tW', '2026-07-21 12:38:29', 0, 5, '2026-07-21 12:34:07', '2026-07-21 04:33:29'),
(179, 1, '$2y$10$37bGtoxs4yVkXZ2GKhqE.O.L.GsA2wMB1xteZ2VdN9RDc5kU5W2jy', '2026-07-21 12:49:04', 0, 5, '2026-07-21 12:44:16', '2026-07-21 04:44:04'),
(180, 5, '$2y$10$wmGETAIQGgIXsTdYksJQ/.4RHtDtWC88VOil4Bu4ErT2aRmSMFdsS', '2026-07-21 15:04:35', 0, 5, '2026-07-21 14:59:48', '2026-07-21 06:59:35'),
(181, 1, '$2y$10$nAwfigLE5jJFJ.SCJ5NQ0.Tyx/.vqPJ6gMMEcxgV2JI/KibnYRp6K', '2026-07-22 09:03:53', 0, 5, '2026-07-22 08:59:10', '2026-07-22 00:58:53'),
(182, 5, '$2y$10$Z47NwibCFzhrTAiV7EVEfelQHxoANZVR6aIBf7KG.cglWveB85FTG', '2026-07-22 09:09:45', 0, 5, '2026-07-22 09:04:58', '2026-07-22 01:04:45'),
(183, 2, '$2y$10$BiQjVqVBjiM7bVuw.RiwyOmSQLqAF0ILTmzRv8jqETYE.Oq1iezz.', '2026-07-22 09:28:08', 0, 5, '2026-07-22 09:23:21', '2026-07-22 01:23:08'),
(184, 5, '$2y$10$rQodOJdjhrLExKhZRKrhXu14wUMuO1vkrdFl2JjXA5aqeeHLiiOIW', '2026-07-22 09:35:57', 0, 5, '2026-07-22 09:31:14', '2026-07-22 01:30:57'),
(185, 1, '$2y$10$mmjG/EU3Xf2AK0rhkok4qOjMaz/K7n.TrmpMoGVUutjC3GJFAF2A2', '2026-07-23 15:12:17', 0, 5, '2026-07-23 15:07:39', '2026-07-23 07:07:17'),
(186, 2, '$2y$10$pNll16f6ZYAydVX6XU4BzO.0m6rVcoVoDchIH093ww2mhTkkpOUmC', '2026-07-23 15:13:43', 0, 5, '2026-07-23 15:08:59', '2026-07-23 07:08:43'),
(187, 5, '$2y$10$ZuQ5/CPF5xSoHJyoa.LdSOm5/EkDluu0aTlP1TcZpOYAKhfcFbkoW', '2026-07-23 15:17:18', 0, 5, '2026-07-23 15:13:19', '2026-07-23 07:12:18'),
(188, 2, '$2y$10$Fnd4bofajtWyxlWh.GYLcOTaCV29/S91XyVkdX3LC1jGiY24xbQrG', '2026-07-23 16:45:56', 0, 5, '2026-07-23 16:41:16', '2026-07-23 08:40:56'),
(189, 1, '$2y$10$PByejuBKyJ1zIVozP/TBresTD9KmG3b5WOKCLN79e4RLQGKCF.PJe', '2026-07-23 20:30:48', 0, 5, '2026-07-23 20:26:01', '2026-07-23 12:25:48'),
(190, 5, '$2y$10$s4D0NrJ0xg5iFWB9OwRZheD7YPoqq/gJkl6LrS.LUwio8b3k59rgG', '2026-07-23 21:25:28', 0, 5, '2026-07-23 21:20:57', '2026-07-23 13:20:28'),
(191, 2, '$2y$10$TQRD.OMo.My4l5P9OmWh5OjvSwmKSGhm3CVEOYJZq1nYO3gI.rftm', '2026-07-23 21:41:12', 0, 5, '2026-07-23 21:36:29', '2026-07-23 13:36:12'),
(192, 1, '$2y$10$rXVEVfcaXwOL3jauXnzKB.cwq5OGL7GPQAM4Us3S/MQFIA1YQo70e', '2026-07-23 21:52:33', 0, 5, '2026-07-23 21:47:52', '2026-07-23 13:47:33'),
(193, 5, '$2y$10$dYHSSIXHLxQfMal2DB.uUuMB.SfapFqUZagc5UhD9OO.eFEPeaoqK', '2026-07-23 21:53:31', 0, 5, '2026-07-23 21:48:45', '2026-07-23 13:48:31'),
(194, 1, '$2y$10$SxKXih2OBQECqyEv.SZEA.oklp1POLwddAinkP1uw9VVfOvlM2YkC', '2026-07-27 14:52:48', 0, 5, '2026-07-27 14:48:07', '2026-07-27 06:47:48'),
(195, 5, '$2y$10$M3Fn6ZWkFKB0cblEfd.8vOnu2pPz1OL8bnKoyCu89pS53qHkytS3O', '2026-07-27 14:53:38', 0, 5, '2026-07-27 14:48:52', '2026-07-27 06:48:38'),
(196, 2, '$2y$10$QdamP5./R1BelU7ZHyHI1uYFkudIFs7B1r0fEM66jswneiWt3xifS', '2026-07-27 14:54:18', 0, 5, '2026-07-27 14:49:35', '2026-07-27 06:49:18'),
(197, 2, '$2y$10$4kYQDLtoM1ZKkhoi9UotmeUexUmbtCAmCfinG3GP198LoJM5vhBXm', '2026-07-27 15:50:46', 0, 5, '2026-07-27 15:46:14', '2026-07-27 07:45:46'),
(198, 2, '$2y$10$QzFdCmGxYeO3jJ4fNhIeoObYFkKaZ1/wqpUWSsiwy0J2MFErzzkVC', '2026-07-28 18:40:53', 0, 5, '2026-07-28 18:36:10', '2026-07-28 10:35:53'),
(199, 2, '$2y$10$6/hrvWL0X8X/2yXqDGYdAO3kTk667w4R1abF6ffzTYTeKsWgxeAha', '2026-07-28 18:57:50', 0, 5, '2026-07-28 18:53:02', '2026-07-28 10:52:50'),
(200, 1, '$2y$10$XdHjeWF9VZYJ7n0ngGD.s.RaNH65cpduGYyTAFCHm50gMXGDYtBxS', '2026-07-28 18:58:41', 0, 5, '2026-07-28 18:53:54', '2026-07-28 10:53:41'),
(201, 1, '$2y$10$5WASgQTs4wDsrXKP/U/h1ect2ZyDkBINpTiHRpXJ3vOB.sfsJ2WwK', '2026-07-29 08:51:08', 0, 5, '2026-07-29 08:46:50', '2026-07-29 00:46:08'),
(202, 5, '$2y$10$lolX896stBW4PsRGizqaf.A6H3letOKE1MpeKilUFLmc21vhMNy6K', '2026-07-29 08:53:02', 0, 5, '2026-07-29 08:48:16', '2026-07-29 00:48:02'),
(203, 1, '$2y$10$uB.dQWz1DgnASvQPzP.qUuvJg/r9/ab6SxnUJiL13XEbaYS4OXgRS', '2026-07-29 16:42:45', 0, 5, '2026-07-29 16:38:03', '2026-07-29 08:37:45'),
(204, 1, '$2y$10$2DRdpYBjCUofzysmUt6sSuqfyxecBnjjxpkfxcivR1RRQAbe.Edve', '2026-07-29 16:51:15', 0, 5, '2026-07-29 16:46:27', '2026-07-29 08:46:15'),
(205, 5, '$2y$10$ZSbKbNjLzAYYmCX1QUoSPeLdNSrTWJ5R0h8ig0KxijTsl21.DqpyG', '2026-07-29 17:02:25', 0, 5, '2026-07-29 16:57:36', '2026-07-29 08:57:25'),
(206, 2, '$2y$10$98owbI4zu0b/x3/S8N94Ceg7xu/MXglQqzNVSY9rWpfdRv1MnIAk6', '2026-07-29 18:21:08', 0, 5, '2026-07-29 18:16:21', '2026-07-29 10:16:08'),
(207, 1, '$2y$10$3gSBeyVMbaCEr5/w2MopB.sIOHmE3rEuLn9X48H7QkkMnEsVuhGP2', '2026-07-29 18:41:38', 0, 5, '2026-07-29 18:36:52', '2026-07-29 10:36:38'),
(208, 1, '$2y$10$zrFBW59NIfzKtvjoxcWyEu.XNm7KAEU7uSWWSeQ9DQvhT1p/h5Pbe', '2026-07-29 19:06:18', 0, 5, '2026-07-29 19:01:32', '2026-07-29 11:01:18'),
(209, 5, '$2y$10$2frzo/NSKAQJSEEpDqoMdeLS/r.tqKJdXUvxDKYVs.5v//lPEyc1C', '2026-07-29 19:31:53', 0, 5, '2026-07-29 19:27:07', '2026-07-29 11:26:53'),
(210, 2, '$2y$10$.r2dJmP4EeMqPSrVCVeVLuNgVhUwEtuklPoKN694ZYcmi/SucUfw6', '2026-07-29 19:47:54', 0, 5, '2026-07-29 19:43:09', '2026-07-29 11:42:54'),
(211, 1, '$2y$10$i7OSqVy3YAveEhMesk4KzeWHpwCStQ4q0b3l8N3yn3UFGOo9MR5bS', '2026-07-31 09:58:27', 0, 5, '2026-07-31 09:53:46', '2026-07-31 01:53:27'),
(212, 5, '$2y$10$sRxhU4uEHdewIazUByXBr.LU1SRn.zrbqE.YnHzg13hOpjHbX5uSW', '2026-07-31 10:11:05', 0, 5, '2026-07-31 10:06:21', '2026-07-31 02:06:05'),
(213, 2, '$2y$10$Fgg3oWSx0xiLh67csDcfQuR5X/qnj1C3ECcWi3C9ZFQsxh4bxMhv6', '2026-07-31 10:30:46', 0, 5, '2026-07-31 10:26:23', '2026-07-31 02:25:46'),
(214, 2, '$2y$10$HZqg3t/HLrLMqGURTgRAyeHkJzjXVsZwuH96aUwznUWjZ1hGkUE9e', '2026-07-31 11:19:49', 0, 5, '2026-07-31 11:15:03', '2026-07-31 03:14:49'),
(215, 5, '$2y$10$7G/bJvJkWQ4g2Q3j8ul6U.i6/a36kJK4xlizlJo7qPoj96pJOGSSO', '2026-07-31 11:39:23', 0, 5, '2026-07-31 11:34:36', '2026-07-31 03:34:23'),
(216, 1, '$2y$10$OGSuz6EqvORZlJh3DCTnq.mhMIO7JFk1iH53VeXY.jLg/aJYo7WQG', '2026-08-02 14:43:50', 0, 5, '2026-08-02 14:39:03', '2026-08-02 06:38:50'),
(217, 5, '$2y$10$W8XL2fO3wHaqmoJ.SoFCE.kBnCP0PMiKZ.TbJJOcUcvFFdNvLy5d2', '2026-08-02 14:53:53', 0, 5, '2026-08-02 14:49:04', '2026-08-02 06:48:53'),
(218, 2, '$2y$10$6mN7snNtSuK2IOag/VSByu6lfata10FgvHK9QQPUkWbz2aDNj6zMu', '2026-08-02 15:57:12', 0, 5, '2026-08-02 15:52:24', '2026-08-02 07:52:12'),
(219, 1, '$2y$10$l.On0WkDIxk9Ck0NRY4ZuealDy41nZRcm7himipOI4x8mFkyienlm', '2026-08-02 21:01:07', 0, 5, '2026-08-02 20:56:21', '2026-08-02 12:56:07'),
(220, 5, '$2y$10$8qAbLeDvqdYG2RvKb3oQ0OrsFgIRhHD7FuuO2azlYLQY12/gCwo0e', '2026-08-02 21:30:02', 0, 5, '2026-08-02 21:25:15', '2026-08-02 13:25:02'),
(221, 2, '$2y$10$9HFb3ztYiACqO1pvL0Tuz.k1MPsOnjiVApcAc.D0iWs0oM2GhrgjK', '2026-08-02 21:34:49', 0, 5, '2026-08-02 21:30:01', '2026-08-02 13:29:49'),
(222, 1, '$2y$10$iHg7h7VEAHKgxEa8OOCCbeR1P4Qm/57D9Jdw0E9y8ZRZg8TiXfRDq', '2026-08-02 21:37:57', 0, 5, '2026-08-02 21:33:09', '2026-08-02 13:32:57'),
(223, 1, '$2y$10$sx1t0HnI4rVNGb0j98dJKePlVTgv6YFOFBpn6r/kpUsmYPtnDI8N2', '2026-08-03 12:55:43', 0, 5, '2026-08-03 12:50:57', '2026-08-03 04:50:43'),
(224, 5, '$2y$10$r2Rr3Y0QhpsQ3sii1cMik.ImimKPNvruBTkEKh.OoiXKJiT6bAPhy', '2026-08-03 13:11:30', 0, 5, '2026-08-03 13:06:51', '2026-08-03 05:06:30'),
(225, 1, '$2y$10$aiUthcRpNSRojP/VwZaDp.VlvdpJxtXrIL3oe7G14N8uZ4PmaWT3q', '2026-08-03 13:14:15', 0, 5, '2026-08-03 13:09:27', '2026-08-03 05:09:15'),
(226, 10, '$2y$10$undn4gXjQ26TvamJRF7vDuG/jibMDahO.la7H5CuWomFNMzFfZZhq', '2026-08-03 13:19:00', 0, 5, '2026-08-03 13:14:17', '2026-08-03 05:14:00'),
(227, 1, '$2y$10$7PxvpH.WIA768FVVKH7O8eSIsj20MLIRpfiaA0mQtQMF.MIX6bRRq', '2026-08-03 13:27:50', 0, 5, '2026-08-03 13:23:04', '2026-08-03 05:22:50'),
(228, 2, '$2y$10$0sVxyv7mlTh2Kmr1aySGBOyMkesS5PqdKUQ.5znZJJ0x9pKqeHfEO', '2026-08-03 13:39:14', 0, 5, '2026-08-03 13:34:28', '2026-08-03 05:34:14'),
(229, 5, '$2y$10$RwDKZdXPw.ldCpXDmFBqPOQsedcb7quZQ0rY0w7AjyhKmCFmQZRPK', '2026-08-03 13:41:59', 0, 5, '2026-08-03 13:37:11', '2026-08-03 05:36:59'),
(230, 2, '$2y$10$b998r3UzLZ2RvPsvGlX7KOMQy9XSqCypiwb8//GRgTrhO7YIttR5C', '2026-08-03 14:10:08', 0, 5, '2026-08-03 14:05:20', '2026-08-03 06:05:08'),
(231, 1, '$2y$10$MIWGgcXac4utPHf9pG9f8uhaXVfhVrRS1ae6MYunwFwrbA5UZK6e2', '2026-08-03 14:18:07', 0, 5, '2026-08-03 14:13:19', '2026-08-03 06:13:07'),
(232, 2, '$2y$10$aV.IMRdWDp6hX0i4A7BpIekSotYPQVuwcJCG2HacevdoEyaHwGRqm', '2026-08-03 14:40:38', 0, 5, '2026-08-03 14:35:52', '2026-08-03 06:35:38'),
(233, 1, '$2y$10$swO/1BbgURD1GyfL9ZPrb.SgkRKf.yJQ/sISXvXA4xnSNS41YSbty', '2026-08-03 14:41:27', 0, 5, '2026-08-03 14:36:39', '2026-08-03 06:36:27'),
(234, 1, '$2y$10$v7yNvIS5BdNWRkHxtu06aex05fLmq94MijSIEPC1tZHDRHn6g6G2m', '2026-08-05 10:33:59', 0, 5, '2026-08-05 10:29:15', '2026-08-05 02:28:59'),
(235, 5, '$2y$10$I03ulBvDaBc5gsT/lPB6cOm/.cPJPovAKQE8Mq1vrDTWeW97CTaEu', '2026-08-05 10:35:18', 0, 5, '2026-08-05 10:30:37', '2026-08-05 02:30:18'),
(236, 2, '$2y$10$7UGo0yhgLmz5Dsh5/EgDhulhq7SrOGKQJlDlypt/1XJ.y31/5MYuW', '2026-08-05 10:36:29', 0, 5, '2026-08-05 10:31:42', '2026-08-05 02:31:29'),
(237, 1, '$2y$10$SHHtsoNxjM5Als2eSAhJX.F2lUPLfbraaiUDfnIwBBVHdB7x/bPQ.', '2026-08-06 09:31:03', 0, 5, '2026-08-06 09:26:20', '2026-08-06 01:26:03'),
(238, 2, '$2y$10$mNvp96orf5tK0x1CQqKHdeCtVuDeZJpBIdeDNZdL.zuuq1ilRyUHC', '2026-08-06 09:32:17', 0, 5, '2026-08-06 09:27:38', '2026-08-06 01:27:17'),
(239, 1, '$2y$10$zj/J6rmip0our4wMVoi4S.mt8CUug4bfK7ohYA4u0iuTN1RyjyWe2', '2026-08-10 13:22:31', 0, 5, '2026-08-10 13:17:54', '2026-08-10 05:17:31'),
(240, 5, '$2y$10$eWWyMO5Zh4FeIJBx.mwNauAqyvrW0xjmAKfa5qb9br4vxZUJKCRBu', '2026-08-10 13:23:28', 0, 5, '2026-08-10 13:18:44', '2026-08-10 05:18:28'),
(241, 2, '$2y$10$HqxiigdQQ2DdErf7IRxO8ucei6jLm8kXZXgkhwYgQ9kHIKonli5p.', '2026-08-10 13:24:45', 0, 5, '2026-08-10 13:19:59', '2026-08-10 05:19:45'),
(242, 2, '$2y$10$DIZv6IHP8RMVg21Fr96ny.JbIWL..tRsYL16mKt1MGRX1zZIH2bAS', '2026-08-10 14:04:02', 0, 5, '2026-08-10 13:59:23', '2026-08-10 05:59:02'),
(243, 2, '$2y$10$vNOwlCNHG6IuX.vIUpSoYevyAYnTkhCNVTgENM6aR8jGcIceEvD5e', '2026-08-10 14:04:23', 0, 5, '2026-08-10 14:00:12', '2026-08-10 05:59:23'),
(244, 2, '$2y$10$X56zCpUnErUKkKn2P0fmBeXmhkiLKjkQsqSlMNA8MGN5rjvgmG8Nq', '2026-08-10 14:05:12', 0, 5, '2026-08-10 14:00:28', '2026-08-10 06:00:12'),
(245, 2, '$2y$10$FWFY7fMgfeD3XmbYSLNT6uAHEGV/ff9hp0HVd4ZYQX7e4hj617Aym', '2026-08-10 14:41:21', 0, 5, '2026-08-10 14:36:43', '2026-08-10 06:36:21'),
(246, 1, '$2y$10$cZcQsIpQvtOjToGkOVlMwOy3u4grGqSPJkEoILa5scOfzfjuIQxfK', '2026-08-11 11:38:05', 0, 5, '2026-08-11 11:33:20', '2026-08-11 03:33:05'),
(247, 1, '$2y$10$ukFK7FEv9lNCAJoKhuvN.OzPLLDJJWS2W3gCrDWYqttHg7p0qgW62', '2026-08-11 11:38:27', 0, 5, '2026-08-11 11:33:40', '2026-08-11 03:33:27'),
(248, 2, '$2y$10$Wq21oaniGFCo20BbYj2Qk.Mn/dEoC6Lu7sHqgOLUfJrtlHFkmWq1y', '2026-08-11 13:53:28', 0, 5, '2026-08-11 13:49:04', '2026-08-11 05:48:28'),
(249, 1, '$2y$10$Jx7fwYUrWf4W9WO9dKJhFeFggeYSDblSuqr5r6tWw7k.YmQBRsvuK', '2026-08-11 14:09:30', 0, 5, '2026-08-11 14:07:03', '2026-08-11 06:04:30'),
(250, 1, '$2y$10$5x98Jq5WvFGQYFmQ4a8ce.sPPbiUWCRudpunTyHVPoHRxhBNG/Ave', '2026-08-11 15:32:53', 1, 5, '2026-08-11 15:28:28', '2026-08-11 07:27:53'),
(251, 1, '$2y$10$.NTP.yBdtfXoIqrY4tWsLemYmc96g.1Ca2iKeNHmEzMAc5a1i1k9a', '2026-08-12 09:55:22', 0, 5, '2026-08-12 09:50:38', '2026-08-12 01:50:22'),
(252, 5, '$2y$10$Vo4OeOGZPvx5NQEwke5JnOprt2g3ddQewd6s3wQKY5fohzEvExMl.', '2026-08-12 10:47:15', 0, 5, '2026-08-12 10:42:28', '2026-08-12 02:42:15'),
(253, 2, '$2y$10$Mtbtjr/aTMGlb4wF/RsAeu/UP0O9I4ipltDNjTTczZwN0.qB6GDJ6', '2026-08-12 11:23:12', 0, 5, '2026-08-12 11:18:25', '2026-08-12 03:18:12'),
(254, 1, '$2y$10$76SitKLFWHqIMymbFK7BPeBdB96lkueMUmUDJoUVxOx/Joh77jOzy', '2026-08-12 11:53:46', 1, 5, '2026-08-12 11:49:10', '2026-08-12 03:48:46'),
(255, 1, '$2y$10$KystZi5uDVmCza0zJSoiMewchBBfbXha3NHdLyxvlosXSS6XzM65K', '2026-08-15 15:36:05', 0, 5, '2026-08-15 15:31:19', '2026-08-15 07:31:05'),
(256, 5, '$2y$10$HQmQ9A7Fl09Td/8AcKD6A.rgquJCEoG9fZnuTDIxRxbklWWVVyx46', '2026-08-15 15:48:36', 0, 5, '2026-08-15 15:43:48', '2026-08-15 07:43:36'),
(257, 1, '$2y$10$APllPJZPeescJKZkcDHOLePL.0Kcg4y/x.E/kb0cj6tt6mfDcC8Ya', '2026-08-17 13:49:54', 0, 5, '2026-08-17 13:45:12', '2026-08-17 05:44:54'),
(258, 5, '$2y$10$zUQu5lNTEupbWnxEWM//6ulaBssl3bH2y2eYOJn5.uVyqk6X81V52', '2026-08-17 13:50:45', 1, 5, '2026-08-17 13:46:23', '2026-08-17 05:45:45'),
(259, 2, '$2y$10$AlMdBeMFRWmgTw.heGkvwO0o6JJHQQkG4TTGbN3Wp5oJ83Om2l3qa', '2026-08-17 13:52:05', 0, 5, '2026-08-17 13:47:29', '2026-08-17 05:47:05'),
(260, 2, '$2y$10$B.QkPM7kupWF0hR6dgKa1O4raubFm3lD3lrEn5BYcOKcnkGC.68TW', '2026-08-17 15:46:51', 0, 5, '2026-08-17 15:42:08', '2026-08-17 07:41:51'),
(261, 1, '$2y$10$iMFCrOncBvVbCeyuAAnmFOQaUXG16pGG6LxL4NwjGjP/w2A4LXp3.', '2026-08-17 20:58:56', 0, 5, '2026-08-17 20:55:54', '2026-08-17 12:53:56'),
(262, 2, '$2y$10$/PICZusN5aLaCzNNB879GOgVywZTUVbmp1JdNUZ4XfgDDtPogdyfu', '2026-08-17 21:03:52', 0, 5, '2026-08-17 20:59:17', '2026-08-17 12:58:52'),
(263, 5, '$2y$10$mckWrE/iy8t2iHHaDe92iOxEVjDSCQe1vzSeI57rqCxmC9eXivKB6', '2026-08-17 21:26:47', 0, 5, '2026-08-17 21:22:08', '2026-08-17 13:21:47'),
(264, 2, '$2y$10$et4eHcrZeRD5vdV3URjZC.AGMvCImfVySBJOQScn2jvTqe5uDMjIe', '2026-08-17 21:37:58', 0, 5, '2026-08-17 21:33:12', '2026-08-17 13:32:58'),
(265, 5, '$2y$10$85XzvbVq9Jwx71A/qkgIYua8aYa1ZZZCmhKI6WdTJRRNyeHBHLzLy', '2026-08-17 21:54:02', 0, 5, '2026-08-17 21:49:15', '2026-08-17 13:49:02'),
(266, 5, '$2y$10$uNe.p6PGiNNx765lcjzone8L5AWjx/9ogTgeY/O3iOcpLWVL7ZA1K', '2026-08-17 22:03:32', 0, 5, '2026-08-17 21:58:45', '2026-08-17 13:58:32'),
(267, 2, '$2y$10$L87Jxt/tKO699KYrkd45RuLb8VmUsxOBe/69U1fbkuW0ocsoa/52y', '2026-08-18 00:49:05', 0, 5, '2026-08-18 00:44:20', '2026-08-17 16:44:05'),
(268, 5, '$2y$10$5eePnpQ7bP7lvPP8qe7X2eeVzh4YieFdtMs4JNHShx56MTrSIZn.e', '2026-08-18 14:28:26', 0, 5, '2026-08-18 14:23:59', '2026-08-18 06:23:26'),
(269, 2, '$2y$10$5kzwVjBejnJrnmWsKhx2qOyB.p32JGxrTGnFOtdtlgKdm7DQlJdb6', '2026-08-18 14:32:01', 0, 5, '2026-08-18 14:31:10', '2026-08-18 06:27:01'),
(270, 1, '$2y$10$/BqqbtvowZN8LR9euABsAexz2Az5KsYOShlk.GmUoLoT3FtUxcR/K', '2026-08-18 14:34:43', 0, 5, '2026-08-18 14:29:56', '2026-08-18 06:29:43'),
(271, 2, '$2y$10$S.ffPxqv1mlXdJamZY4r5u4RaiLvF3DbpzcCmCoU2r5Zq8JPq2gSO', '2026-08-18 14:36:10', 0, 5, '2026-08-18 14:31:23', '2026-08-18 06:31:10'),
(272, 5, '$2y$10$AbvzxNRcIXcpb76LKPxhVOb4nGr2T/LN9ZOuzJzmMang1kdt5/SEq', '2026-08-18 15:23:21', 0, 5, '2026-08-18 15:18:40', '2026-08-18 07:18:21'),
(273, 1, '$2y$10$QRsqCPZ4aBRJsAhLlA8op.E9vVHU3VdxAr4sABH/W879JA8G4Khhq', '2026-08-20 09:13:01', 0, 5, '2026-08-20 09:08:49', '2026-08-20 01:08:01'),
(274, 1, '$2y$10$B69rCIns63VvqUFck2.PY.bFTXLzuoCoht5LlqYvM1aZ4jcakKmo.', '2026-08-20 09:13:49', 0, 5, '2026-08-20 09:09:46', '2026-08-20 01:08:49'),
(275, 1, '$2y$10$mjj4iE3AKr5s0D9ZE2yRb.d6MRptGKl8Z5Y98dIGM18sIh7tyBxte', '2026-08-20 09:14:46', 0, 5, '2026-08-20 09:10:03', '2026-08-20 01:09:46'),
(276, 5, '$2y$10$fSx1lGDtxnUDxJncMhxJq.S8pixDXUiN1wZRHEUL3WdjuDdqPpxJC', '2026-08-20 09:15:38', 0, 5, '2026-08-20 09:11:16', '2026-08-20 01:10:38'),
(277, 2, '$2y$10$k7AjCTY4y5nusq/XhoVg5.koT02SpnmpQyJ.ufYnpntbbtQH0dTLm', '2026-08-20 09:17:05', 0, 5, '2026-08-20 09:12:38', '2026-08-20 01:12:05'),
(278, 11, '$2y$10$62TwQ39XNkKwHWROEyGrbOrNL0TFBO/NzIJQsK5gVy55D3y2AUiiK', '2026-08-20 09:45:36', 0, 5, '2026-08-20 09:40:58', '2026-08-20 01:40:36'),
(279, 11, '$2y$10$8Ra6.1H1EqV8Y3QURU2cF.s9eAHzViO06CewDnMjpGY.M1NgJFY9i', '2026-08-20 09:47:53', 1, 5, '2026-08-20 09:43:42', '2026-08-20 01:42:53'),
(280, 2, '$2y$10$60YNdekL8L2SBInHXOzKAOO9umbKBMAmRbsx8QU1h4yVYGMbQVK.O', '2026-08-20 09:53:33', 0, 5, '2026-08-20 09:48:48', '2026-08-20 01:48:33'),
(281, 1, '$2y$10$GpcNSUYtanTFYWeEoDn/H.JCUvNvvZkSnoe0YfZ8XHmN7iIWEVtVG', '2026-08-20 11:08:11', 0, 5, '2026-08-20 11:07:09', '2026-08-20 03:03:11'),
(282, 1, '$2y$10$dEOf7T4FRlHrbQBZm40nK.81A.sSlp4zXE8jxgeJtxCrkalWpruVG', '2026-08-20 11:12:09', 0, 5, '2026-08-20 11:07:39', '2026-08-20 03:07:09'),
(283, 1, '$2y$10$A5oKEJGzSfgpIweLJSVV.OTF.p0I/fLb36CuLIMUM.58qXPIwsQdu', '2026-08-20 11:14:50', 1, 5, '2026-08-20 11:10:23', '2026-08-20 03:09:50'),
(284, 5, '$2y$10$5yoY48yXgeZuCgTgKATiAeBvow6ZXxnNtiDYYZ7DIMdccQxhNzyqq', '2026-08-20 11:29:11', 0, 5, '2026-08-20 11:24:28', '2026-08-20 03:24:11'),
(285, 2, '$2y$10$Mvr8g4xz5LE5DUWdHcOK1Ol13qL2wFWrj91wnr2QV2wZChKv58wDe', '2026-08-20 11:54:19', 1, 5, '2026-08-20 11:50:09', '2026-08-20 03:49:19'),
(286, 2, '$2y$10$vYRn.rKYdZ2IXSRUIxtBPOebAZBS2lqZflrT6i0GtSpUOYPRV87sa', '2026-08-20 11:56:42', 0, 5, '2026-08-20 21:45:54', '2026-08-20 03:51:42'),
(287, 1, '$2y$10$6dvwUxpmkaCwlYfL82UIUePTelz6sutKBEmvdcK8O8o3l970GiBJy', '2026-08-20 20:25:14', 0, 5, '2026-08-20 20:20:33', '2026-08-20 12:20:14'),
(288, 2, '$2y$10$ZFriSEGvEKEOGMA11r08WO82CoVyhgTyf8un4do0szgKWW7TqmiOO', '2026-08-20 21:50:54', 0, 5, '2026-08-20 21:46:14', '2026-08-20 13:45:54'),
(289, 5, '$2y$10$GCjW0nBY/fqJVdK8czhkUu.r2OsC7hfRxNimmqcQpG2UAYl5PZ1BK', '2026-08-20 22:08:01', 0, 5, '2026-08-20 22:03:18', '2026-08-20 14:03:01'),
(290, 2, '$2y$10$9VoKfcVCg5L5mrFWNldOw.yiuB4He936yTtLdt2kjbcVs8AON/YQm', '2026-08-20 23:53:55', 0, 5, '2026-08-20 23:49:10', '2026-08-20 15:48:55'),
(291, 1, '$2y$10$qcFgQZPZS6sZIqo37USSY.OyldWb7zZc3MumZTC5nfqDi1NaIn7kS', '2026-08-31 12:19:47', 0, 5, '2026-08-31 12:15:05', '2026-08-31 04:14:47'),
(292, 2, '$2y$10$9p1UUd0AXK1dj8QODmJ9weO9XuEDkVbloPrFB5BQSaOo13UunT2Ei', '2026-08-31 12:21:03', 0, 5, '2026-08-31 12:16:17', '2026-08-31 04:16:03'),
(293, 5, '$2y$10$uVlYgIDgW3qmYesFOGh8dOvHd90Pjr3AgplDchUxaitMZt1wX4iB6', '2026-08-31 12:22:35', 0, 5, '2026-08-31 12:17:53', '2026-08-31 04:17:35'),
(294, 2, '$2y$10$RLWGfHyk02VJVHu.3n4N2eD7rlrf0Vsdy9XAuxGijpffvVizGP7bi', '2026-09-01 22:26:10', 0, 5, '2026-09-01 22:21:27', '2026-09-01 14:21:10'),
(295, 1, '$2y$10$54xW1Uq8BouJ4.LtrxPNwO7iF.mNZ8OkQl9LobJ2gdFHhl1AC5xzy', '2026-09-01 22:31:29', 0, 5, '2026-09-01 22:26:45', '2026-09-01 14:26:29'),
(296, 5, '$2y$10$bYwJ0EKYKWTpGYlWM8jNv.IibAkwK4Yz0HzXnlJtyg/FaUYDMAXyK', '2026-09-01 22:50:03', 0, 5, '2026-09-01 22:45:25', '2026-09-01 14:45:03'),
(297, 1, '$2y$10$qDobXWJYrSoXmqXJXd2Yo.l.5re9fkMpwjfom0lacsIG4jVN0sm.2', '2026-09-01 22:51:54', 0, 5, '2026-09-01 22:47:08', '2026-09-01 14:46:54'),
(298, 2, '$2y$10$ja3NIeCY0AXEPlxzkgAb5.zXz9DngEI12LCtjb5fu.IjbXNosoW4G', '2026-09-01 23:39:01', 0, 5, '2026-09-01 23:35:02', '2026-09-01 15:34:01');

-- --------------------------------------------------------

--
-- Table structure for table `user_notif_state`
--

CREATE TABLE `user_notif_state` (
  `user_id` int(11) NOT NULL,
  `last_seen_push_notif_id` int(11) NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_notif_state`
--

INSERT INTO `user_notif_state` (`user_id`, `last_seen_push_notif_id`, `updated_at`) VALUES
(1, 103, '2026-08-20 09:58:40'),
(2, 104, '2026-08-20 11:50:35'),
(5, 0, '2026-04-26 21:18:38'),
(10, 0, '2026-08-03 13:14:20'),
(11, 0, '2026-08-20 09:41:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_trusted_devices`
--

CREATE TABLE `user_trusted_devices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_trusted_devices`
--

INSERT INTO `user_trusted_devices` (`id`, `user_id`, `token_hash`, `user_agent`, `ip_address`, `expires_at`, `last_used_at`, `created_at`) VALUES
(1, 2, '5d195d9c2bea3ea779f61302fdd2605d4c009551b9f20ba0e79052675c00244f', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G955U Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36', '::1', '2026-04-02 16:15:46', '2026-03-03 16:21:43', '2026-03-03 08:15:46'),
(2, 2, '059f16d59b39f215f9d58a4e71d218652aa799c852c274ac83385a9777df3fa4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1', '2026-04-02 18:15:57', '2026-03-04 13:32:32', '2026-03-03 10:15:57'),
(3, 1, '29fa2b39d2af44553940cdf75167efb0c07ea6a4cf6b3a771136c88b15234ff4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1', '2026-04-03 13:33:43', '2026-03-04 15:35:12', '2026-03-04 05:33:43'),
(5, 1, '62b13161bf0066ccc78ae9b1609a154022fa099ebedb1d43b2487b2331e1a7be', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '::1', '2026-04-13 13:55:00', '2026-03-18 21:02:03', '2026-03-14 05:55:00'),
(6, 1, 'dc33ed8326e781caf6a9a929b72e8c9e263ee4c0f844ae20b13cc9109455c8de', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-17 21:02:03', '2026-03-18 21:02:03', '2026-03-18 13:02:03'),
(7, 2, '9713d028ef213b150b78223c02913a13598a77e95c386b24e61d000de8bd042f', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-17 21:49:41', '2026-03-18 21:49:41', '2026-03-18 13:49:41'),
(8, 1, '5f20c9bed7adbf213cd8ff2e588cdf8bf9a85b3fa098ad5bdb2bb0ab497e709c', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-17 22:01:24', '2026-03-19 11:41:18', '2026-03-18 14:01:24'),
(9, 1, 'f89197ef4349d16e9d2366a3e267b5003364c1512e093a1184282970e8e59c1d', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-18 11:41:18', '2026-03-20 19:27:25', '2026-03-19 03:41:18'),
(10, 1, 'f4e0a3f7e7aa40aed05b3d23300655d81b513b70ead40ae6d41ea92236124598', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '127.0.0.1', '2026-04-18 13:14:54', '2026-03-19 13:14:54', '2026-03-19 05:14:54'),
(11, 1, 'b22b7c49ff78b577294aa14d3ab7c81cd0f82b34eab8fe2696f0d8a468fe5e9e', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-19 19:27:25', '2026-03-20 19:49:06', '2026-03-20 11:27:25'),
(13, 1, 'd4d821b805d5c0003afc8d00e9b7fef659a53bfea3f15466a9014f0a725e64e9', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-19 20:57:40', '2026-03-20 20:57:40', '2026-03-20 12:57:40'),
(14, 2, 'e61c2f53082b0414be62a94d277fa46f08c88079a77a0c4663eea79078bb6977', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-19 20:58:48', '2026-03-20 20:58:48', '2026-03-20 12:58:48'),
(15, 1, '3b6dcb554bd1ff275668f81101e1caf2eb8bfb64db5182142d70b71cd41af07e', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-19 21:35:05', '2026-03-20 21:35:05', '2026-03-20 13:35:05'),
(16, 2, '351f1af2eaee2000617451cb9c7bd4b1d17437fe203273efaa8f45d2ad73172e', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-19 22:01:27', '2026-03-20 22:01:27', '2026-03-20 14:01:27'),
(19, 1, 'c2da6276d410857750e821c120a4ef23021f1ef25d6ff7af2aa9ebd83544799e', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-19 22:44:44', '2026-03-22 17:03:03', '2026-03-20 14:44:44'),
(20, 1, '03e3b76860623774af93240b43ccee92262c0a295bdcae9d0fd3a22839166360', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-21 17:03:03', '2026-03-22 17:21:41', '2026-03-22 09:03:03'),
(21, 1, '088a6984640f8928cbeea5283eb986d43a5e18ba274919c08b581ec13add1405', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-21 17:21:41', '2026-03-22 19:33:51', '2026-03-22 09:21:41'),
(22, 1, '1ad4207f010e762056f6111104d51d988ae40306db4dc64b34e5509a46e6f37e', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-21 19:33:51', '2026-03-22 19:33:51', '2026-03-22 11:33:51'),
(23, 2, '90a0594f29f6596fadb2ef6d12cbd7de0c0a2bff3c93f2d09b641e3bab03c502', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-22 10:32:09', '2026-03-23 10:32:09', '2026-03-23 02:32:09'),
(24, 1, '63950962b03d08573982704b2cc18a32dcd62a9d38638342efe9198b4aed719f', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-22 10:40:25', '2026-03-23 10:40:25', '2026-03-23 02:40:25'),
(26, 1, '6935557fb36d81a283f60bfd1f7870cf20669652101591f1e4b83883a2aaea88', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-22 11:59:08', '2026-03-23 11:59:08', '2026-03-23 03:59:08'),
(28, 1, '144e659c58b9e8580ed343a161a4e3a074db163a8f43bedafddd98a26a89f1cd', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-22 12:19:12', '2026-03-23 12:19:12', '2026-03-23 04:19:12'),
(31, 1, '8e35e8aa6cd512e9a1eeed33cad754bbbd6129e5e461137d5d2eb415a17fc8f4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-22 13:32:13', '2026-03-23 19:47:32', '2026-03-23 05:32:13'),
(32, 1, '7f7bf0d18a342b95eee8466c8fd60655fd0b4d4ed5807e14812f97e5dd6feca9', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-22 19:47:32', '2026-03-23 19:47:32', '2026-03-23 11:47:32'),
(33, 2, '5787d445610735ca8d01b543fec251fb47d6e3c76600547c2fcb83e2aeb1e161', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-22 20:44:19', '2026-03-23 20:44:19', '2026-03-23 12:44:19'),
(34, 1, '54f7711b8374fea4a758252b86877ed8100904a90ddd49da4909c1045d28bb3a', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-23 11:09:41', '2026-03-24 11:09:41', '2026-03-24 03:09:41'),
(35, 2, 'e2a1a3fbce9117133d4fc506113c7469c0273d8f2492106ec8f420a1e3fc0a81', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-23 12:31:21', '2026-03-24 12:31:21', '2026-03-24 04:31:21'),
(37, 1, '35ace115835fed9fd891d037a4bd907dee4e8c593563353286d1ea9cecd20011', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-23 12:37:57', '2026-03-24 12:37:57', '2026-03-24 04:37:57'),
(39, 2, '7e9e1644b264408eba1f5db36c340cde9b5f5b4094d3c7aef31445fa83b359ca', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-23 12:43:23', '2026-03-24 12:43:23', '2026-03-24 04:43:23'),
(40, 1, '67d9154cd6f4cc1697e4bc705ec015d6e1c03faa4d3a07bb940f42a86dabd338', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-23 17:03:20', '2026-03-25 09:38:52', '2026-03-24 09:03:20'),
(41, 1, '0f6b8942abf22ae953c753c9506a71c7e378f88560bbfb1ca3153cf67547b4e8', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-24 09:38:52', '2026-03-25 09:38:52', '2026-03-25 01:38:52'),
(42, 2, '36e80c48fad353a17464f8d5b27510ccac819019746de87b187cefa932741b5a', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-24 10:39:58', '2026-03-25 10:39:58', '2026-03-25 02:39:58'),
(43, 1, '49a23b86fe35cb3c3869b1fccfeb1e2970a9b6b2bfe0b7bc5f9df79d46fef954', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-24 11:29:25', '2026-03-25 11:29:25', '2026-03-25 03:29:25'),
(45, 1, '9c8f04488a78bea311df675e0d2d4e1bd140acb301546457ca6e3cbfffcc6f4a', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-27 11:49:54', '2026-03-28 11:49:54', '2026-03-28 03:49:54'),
(46, 2, 'a5e253e0e8039b59c6e3678440651195c32bb225a91882c6ec033dde6d88289a', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-04-27 12:41:47', '2026-03-28 12:41:47', '2026-03-28 04:41:47'),
(48, 1, '07f762a7292dabe9a3bede3babc52ad3572cdef71d11ed52d61599e7d5660646', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-05-07 08:52:24', '2026-04-07 08:52:24', '2026-04-07 00:52:24'),
(49, 2, 'be8709e6ed79c6da61e31114fcf348c840885fc3b50308170057102784749c3e', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-05-07 11:59:23', '2026-04-07 11:59:23', '2026-04-07 03:59:23'),
(51, 1, '1c4e60846440d28e09f36355a2c865ba22afbca12795c4e71ec40a7d1c9361ae', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-05-08 12:08:31', '2026-04-08 12:08:31', '2026-04-08 04:08:31'),
(52, 2, '96a4a10a086801e05ea821f7592003277ebd1fba5a2e798fcd711ab49fc5d041', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-05-08 12:26:07', '2026-04-08 12:26:07', '2026-04-08 04:26:07'),
(55, 1, '50c65a29beebd6aad32411a46124a1cefd1cb5fe2503d0fc10eebe8cf0e6f2d9', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-05-08 18:24:55', '2026-04-08 18:24:55', '2026-04-08 10:24:55'),
(56, 2, 'cae9871265954185d031da38c062a3dfabf77ec1c6b3fa843c72c66bf291f71b', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-05-08 18:26:46', '2026-04-08 18:26:46', '2026-04-08 10:26:46'),
(57, 1, '63f12c978be546cf628e85e3cdb041c744053b90e8ba194cbda40dce47835eac', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-05-08 18:47:04', '2026-04-08 18:47:04', '2026-04-08 10:47:04'),
(59, 1, '0c663eb195944e4dce9a44b31eb37328b8a058e50e374ee08eb6ea8fa7717888', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-05-08 19:48:30', '2026-04-08 19:49:30', '2026-04-08 11:48:30'),
(60, 2, '195ca4d4c6a0548a83ba11a10b3178288ce555005a8e48e1aecdf223ae09b4f3', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-05-08 20:10:32', '2026-04-08 20:15:21', '2026-04-08 12:10:32'),
(62, 1, 'cbae2c25fe004fbb4205e786af5a5cbd0ea62edd24a6e6273d221b39fa9879a8', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-05-08 20:53:04', '2026-04-08 20:53:04', '2026-04-08 12:53:04'),
(63, 2, '4eb2258bdb1d5f33fdbae7bac2724f45cd4359ae98a80c67462bbb61e28c3c8c', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '::1', '2026-05-08 20:54:05', '2026-04-08 20:54:05', '2026-04-08 12:54:05'),
(65, 1, '22946f304e09e4c9b91eda2e1465bde46f0bb573714e795760cb0b7dd3299482', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '::1', '2026-05-21 19:17:58', '2026-04-21 19:17:58', '2026-04-21 11:17:58'),
(66, 2, '96f78a4907d695909d9482889cdefcc952bcc2d59a71b2d27539ffbecb68d088', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '::1', '2026-05-21 19:19:38', '2026-04-21 19:19:38', '2026-04-21 11:19:38'),
(68, 1, 'c1a90196da7695b8d44fb14a19e93b339d8ee02b7c2a237a7f32babab731c065', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '::1', '2026-05-21 19:35:13', '2026-04-26 19:20:17', '2026-04-21 11:35:13'),
(70, 2, 'b08ba0c76e3a885151e631b9c9479cc03649bdff53abb3b3a9cbed471ea1b3c7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1', '2026-05-26 21:20:40', '2026-04-26 21:20:57', '2026-04-26 13:20:40'),
(71, 1, '68c38e2ed55d457ee87a1bbaea583df40cd368eadf9cd39bf940d85bedde4686', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1', '2026-05-27 09:26:01', '2026-04-27 09:26:01', '2026-04-27 01:26:01'),
(72, 2, '64a95c67b0143ce28d370167f75d28beaff2e5aa622c42049fc321b808bdf8eb', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1', '2026-05-27 09:27:49', '2026-05-04 10:49:30', '2026-04-27 01:27:49'),
(73, 2, '9f07234b4c9155819c1258c255f9a931bdee64a7a2f5b66e9d764da9cbde2338', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1', '2026-06-03 10:49:30', '2026-05-04 10:49:30', '2026-05-04 02:49:30'),
(75, 2, 'd22666a4f067bdcf2de517d75486b7befb404a4bf762d5352008670dd433eb15', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1', '2026-06-03 11:14:28', '2026-05-04 11:14:28', '2026-05-04 03:14:28'),
(76, 1, '13c1b2b4abf7a7ab7ce699cc183b6562d530cd9f97e4452c63593d0ce0567f65', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1', '2026-06-10 12:25:56', '2026-05-24 16:03:37', '2026-05-11 04:25:56'),
(78, 2, '9c89a7534bb2e0cda2c3781011a69f3d14782675399dfbcac7aa6af98e33844f', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0', '::1', '2026-06-10 12:33:43', '2026-05-11 12:33:43', '2026-05-11 04:33:43'),
(79, 1, '05e31209d4ff279c150f15c10e0dcdbf4db48c2d14d1c3c9e1b8d1f4e0b3ed64', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1', '2026-06-23 16:03:37', '2026-05-24 16:03:37', '2026-05-24 08:03:37'),
(80, 2, 'b5d0598f1aa543c02f392f009e48ca291fc4d4da2e8c38724e5766aef1ead852', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1', '2026-06-23 16:32:45', '2026-05-24 16:32:45', '2026-05-24 08:32:45'),
(82, 1, '9493d8755ac1af266d34f2b198185a1ce467d6724de1657a45f63fa5b84fc77d', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 AVG/147.0.0.0', '::1', '2026-07-01 20:28:26', '2026-06-01 20:28:26', '2026-06-01 12:28:26'),
(83, 2, 'c1a58bc217fa3bbfc1adab3318d168387a0944d48c3cbda832f0f6d33723608f', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 AVG/147.0.0.0', '::1', '2026-07-01 20:33:20', '2026-06-01 20:33:20', '2026-06-01 12:33:20'),
(85, 1, 'd41cbedeb585bb53c6e6b8ffd9dc24c902a7435db67c5185ec1ff28e5350ff38', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 AVG/147.0.0.0', '::1', '2026-07-01 20:37:31', '2026-06-01 20:37:31', '2026-06-01 12:37:31'),
(86, 2, '5dff9fc8c7f5a96bf483379f667b7d4195bd146485333407453b5dbc7d9e2987', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1', '2026-07-01 21:02:57', '2026-06-01 21:02:57', '2026-06-01 13:02:57'),
(87, 1, '9f6d8617cf40ef69135d1954c1b0f18f9b688e8c7702a3d27d61740a26a880d0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1', '2026-07-02 10:51:44', '2026-06-02 10:51:44', '2026-06-02 02:51:44'),
(88, 2, '262a2391e2db813908c193ec304a408372d9a54d1dd26e94d27d682e6ccec761', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1', '2026-07-02 11:01:34', '2026-06-02 11:01:34', '2026-06-02 03:01:34'),
(90, 1, '1da47ba447e2f77f19f822b7f3d760eab514ddedaf79b90b6a3c4899619cba69', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1', '2026-07-09 15:51:38', '2026-06-09 15:51:38', '2026-06-09 07:51:38'),
(91, 1, 'fec384023c033062b60c4a9fc40d925f9824358383dfef50f221daf5623c2a1f', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '::1', '2026-07-09 16:05:44', '2026-06-09 16:05:44', '2026-06-09 08:05:44'),
(92, 2, '38cf0ac47222c8eec102e05d02e2866ee85bea2f65e8d58ad07e1ecd5939a428', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '::1', '2026-07-09 16:13:16', '2026-06-09 16:13:16', '2026-06-09 08:13:16'),
(93, 1, '55f6bdfd6460736270c065d06b51aca5dbf76333cd6a37c70c74f6cb01e59f0b', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1', '2026-07-10 09:42:55', '2026-06-10 09:53:25', '2026-06-10 01:42:55'),
(94, 2, 'ad29d44549bb18faab1f129f0dc551b7397b453ca07ca8be6e6a958a0d663333', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '::1', '2026-07-10 09:43:41', '2026-06-10 09:43:41', '2026-06-10 01:43:41'),
(95, 1, '12063bb5f01b006b30490f0e25c3354e5f57c649960dab610afa32ac3a5f353b', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1', '2026-07-10 09:53:25', '2026-06-10 09:57:04', '2026-06-10 01:53:25'),
(96, 1, 'b9e38cefe0caf603b5a7934ab90907538e16bcd41b32c7c519dc20803b93e0e8', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1', '2026-07-10 09:57:04', '2026-06-10 09:57:04', '2026-06-10 01:57:04'),
(98, 1, '3aed663324012017072a00aed45c4b03ebe5f1a69f355c5cdd3637019f184764', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '::1', '2026-07-10 10:04:15', '2026-06-10 10:04:15', '2026-06-10 02:04:15'),
(99, 2, '616b323e5e832c9801d5f3fa7e13ee046a3416da2fa6a89e1bd8837e7ae4dc88', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '::1', '2026-07-10 10:18:24', '2026-06-10 10:18:24', '2026-06-10 02:18:24'),
(100, 1, '5c40c2016b500eb47c076c883069a8990484c2e875c59f5e34fb234eeede28ae', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '::1', '2026-07-10 17:21:31', '2026-06-10 17:21:31', '2026-06-10 09:21:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_payable`
--
ALTER TABLE `account_payable`
  ADD PRIMARY KEY (`ap_id`),
  ADD KEY `purchase_id` (`purchase_id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `account_payable_approved_by_fk` (`approved_by`);

--
-- Indexes for table `account_receivable`
--
ALTER TABLE `account_receivable`
  ADD PRIMARY KEY (`ar_id`),
  ADD KEY `sales_id` (`sales_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`activity_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `adjust_logs`
--
ALTER TABLE `adjust_logs`
  ADD PRIMARY KEY (`adjust_log_id`),
  ADD KEY `idx_product_created` (`product_id`,`created_at`),
  ADD KEY `idx_type_created` (`adjust_type`,`created_at`),
  ADD KEY `fk_adjust_logs_user` (`adjusted_by`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `demo_seed_runs`
--
ALTER TABLE `demo_seed_runs`
  ADD PRIMARY KEY (`seed_key`);

--
-- Indexes for table `discounts`
--
ALTER TABLE `discounts`
  ADD PRIMARY KEY (`discount_id`),
  ADD KEY `sale_id` (`sale_id`);

--
-- Indexes for table `finance_charge_logs`
--
ALTER TABLE `finance_charge_logs`
  ADD PRIMARY KEY (`charge_id`),
  ADD UNIQUE KEY `uq_charge_once` (`account_type`,`account_id`,`charge_date`);

--
-- Indexes for table `finance_settings`
--
ALTER TABLE `finance_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory_transactions`
--
ALTER TABLE `inventory_transactions`
  ADD PRIMARY KEY (`inventTrans_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `login_logs`
--
ALTER TABLE `login_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `sale_id` (`sale_id`);

--
-- Indexes for table `payment_request`
--
ALTER TABLE `payment_request`
  ADD PRIMARY KEY (`pay_req_id`),
  ADD KEY `sale_id` (`sale_id`);

--
-- Indexes for table `penalties`
--
ALTER TABLE `penalties`
  ADD PRIMARY KEY (`penalty_id`),
  ADD UNIQUE KEY `unique_reference` (`reference_id`,`reference_type`),
  ADD KEY `reference_id` (`reference_id`);

--
-- Indexes for table `penalty_waivers`
--
ALTER TABLE `penalty_waivers`
  ADD PRIMARY KEY (`waiver_id`),
  ADD KEY `reference_id` (`reference_id`),
  ADD KEY `waived_by` (`waived_by`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_discount_stock`
--
ALTER TABLE `product_discount_stock`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`purchases_id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `purchase_items`
--
ALTER TABLE `purchase_items`
  ADD PRIMARY KEY (`purchase_item_id`),
  ADD KEY `purchases_id` (`purchases_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `push_notif_logs`
--
ALTER TABLE `push_notif_logs`
  ADD PRIMARY KEY (`push_notif_id`),
  ADD KEY `payment_id` (`payment_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `receipt_reprints`
--
ALTER TABLE `receipt_reprints`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_receipt_reprints_sale_id` (`sale_id`),
  ADD KEY `idx_receipt_reprints_user_id` (`user_id`);

--
-- Indexes for table `returns`
--
ALTER TABLE `returns`
  ADD PRIMARY KEY (`return_id`),
  ADD KEY `sale_id` (`sale_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `rice_grades`
--
ALTER TABLE `rice_grades`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `grade_name` (`grade_name`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sale_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `sales_forecast`
--
ALTER TABLE `sales_forecast`
  ADD PRIMARY KEY (`forecast_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `generated_by` (`generated_by`);

--
-- Indexes for table `sales_items`
--
ALTER TABLE `sales_items`
  ADD PRIMARY KEY (`sales_item_id`),
  ADD KEY `sale_id` (`sale_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `stock_batches`
--
ALTER TABLE `stock_batches`
  ADD PRIMARY KEY (`batch_id`),
  ADD KEY `idx_batch_product_arrived` (`product_id`,`arrived_at`),
  ADD KEY `idx_batch_remaining` (`product_id`,`remaining_qty_kg`),
  ADD KEY `idx_batch_discounted` (`product_id`,`discounted_qty_kg`);

--
-- Indexes for table `stock_condition`
--
ALTER TABLE `stock_condition`
  ADD PRIMARY KEY (`stock_condition_id`),
  ADD KEY `idx_rice_variety` (`rice_name`,`variety`),
  ADD KEY `idx_condition_date` (`condition_type`,`date_arrived`),
  ADD KEY `idx_stock_condition_product_id` (`product_id`),
  ADD KEY `idx_stock_condition_adjusted_by` (`adjusted_by`);

--
-- Indexes for table `stock_condition_logs`
--
ALTER TABLE `stock_condition_logs`
  ADD PRIMARY KEY (`scl_id`),
  ADD KEY `idx_product_status` (`product_id`,`status`),
  ADD KEY `idx_type_status` (`condition_type`,`status`),
  ADD KEY `idx_scl_product_id` (`product_id`),
  ADD KEY `idx_scl_reported_by` (`reported_by`);

--
-- Indexes for table `stock_settings`
--
ALTER TABLE `stock_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_stock_settings_updated_by` (`updated_by`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `supplier_payments`
--
ALTER TABLE `supplier_payments`
  ADD PRIMARY KEY (`sp_id`),
  ADD KEY `sp_ap_fk` (`ap_id`),
  ADD KEY `sp_supplier_fk` (`supplier_id`),
  ADD KEY `sp_paid_by_fk` (`paid_by`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `uq_users_email` (`email`);

--
-- Indexes for table `user_email_otp_challenges`
--
ALTER TABLE `user_email_otp_challenges`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_expires` (`user_id`,`expires_at`);

--
-- Indexes for table `user_notif_state`
--
ALTER TABLE `user_notif_state`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_trusted_devices`
--
ALTER TABLE `user_trusted_devices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_token_hash` (`token_hash`),
  ADD KEY `idx_user_expires` (`user_id`,`expires_at`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_payable`
--
ALTER TABLE `account_payable`
  MODIFY `ap_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `account_receivable`
--
ALTER TABLE `account_receivable`
  MODIFY `ar_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=710;

--
-- AUTO_INCREMENT for table `adjust_logs`
--
ALTER TABLE `adjust_logs`
  MODIFY `adjust_log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `discounts`
--
ALTER TABLE `discounts`
  MODIFY `discount_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `finance_charge_logs`
--
ALTER TABLE `finance_charge_logs`
  MODIFY `charge_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=589;

--
-- AUTO_INCREMENT for table `inventory_transactions`
--
ALTER TABLE `inventory_transactions`
  MODIFY `inventTrans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=291;

--
-- AUTO_INCREMENT for table `login_logs`
--
ALTER TABLE `login_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=627;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- AUTO_INCREMENT for table `payment_request`
--
ALTER TABLE `payment_request`
  MODIFY `pay_req_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `penalties`
--
ALTER TABLE `penalties`
  MODIFY `penalty_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `penalty_waivers`
--
ALTER TABLE `penalty_waivers`
  MODIFY `waiver_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `purchases_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `purchase_items`
--
ALTER TABLE `purchase_items`
  MODIFY `purchase_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `push_notif_logs`
--
ALTER TABLE `push_notif_logs`
  MODIFY `push_notif_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `receipt_reprints`
--
ALTER TABLE `receipt_reprints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `returns`
--
ALTER TABLE `returns`
  MODIFY `return_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `rice_grades`
--
ALTER TABLE `rice_grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sale_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=332;

--
-- AUTO_INCREMENT for table `sales_forecast`
--
ALTER TABLE `sales_forecast`
  MODIFY `forecast_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales_items`
--
ALTER TABLE `sales_items`
  MODIFY `sales_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=677;

--
-- AUTO_INCREMENT for table `stock_batches`
--
ALTER TABLE `stock_batches`
  MODIFY `batch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `stock_condition`
--
ALTER TABLE `stock_condition`
  MODIFY `stock_condition_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `stock_condition_logs`
--
ALTER TABLE `stock_condition_logs`
  MODIFY `scl_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `supplier_payments`
--
ALTER TABLE `supplier_payments`
  MODIFY `sp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user_email_otp_challenges`
--
ALTER TABLE `user_email_otp_challenges`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=299;

--
-- AUTO_INCREMENT for table `user_trusted_devices`
--
ALTER TABLE `user_trusted_devices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `account_payable`
--
ALTER TABLE `account_payable`
  ADD CONSTRAINT `account_payable_approved_by_fk` FOREIGN KEY (`approved_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `account_payable_ibfk_1` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`purchases_id`),
  ADD CONSTRAINT `account_payable_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`);

--
-- Constraints for table `account_receivable`
--
ALTER TABLE `account_receivable`
  ADD CONSTRAINT `account_receivable_ibfk_1` FOREIGN KEY (`sales_id`) REFERENCES `sales` (`sale_id`),
  ADD CONSTRAINT `account_receivable_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`);

--
-- Constraints for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `adjust_logs`
--
ALTER TABLE `adjust_logs`
  ADD CONSTRAINT `fk_adjust_logs_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `fk_adjust_logs_user` FOREIGN KEY (`adjusted_by`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `discounts`
--
ALTER TABLE `discounts`
  ADD CONSTRAINT `discounts_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`);

--
-- Constraints for table `inventory_transactions`
--
ALTER TABLE `inventory_transactions`
  ADD CONSTRAINT `inventory_transactions_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `login_logs`
--
ALTER TABLE `login_logs`
  ADD CONSTRAINT `login_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`);

--
-- Constraints for table `payment_request`
--
ALTER TABLE `payment_request`
  ADD CONSTRAINT `payment_request_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`);

--
-- Constraints for table `product_discount_stock`
--
ALTER TABLE `product_discount_stock`
  ADD CONSTRAINT `fk_product_discount_stock_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `purchases`
--
ALTER TABLE `purchases`
  ADD CONSTRAINT `purchases_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`),
  ADD CONSTRAINT `purchases_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `purchase_items`
--
ALTER TABLE `purchase_items`
  ADD CONSTRAINT `purchase_items_ibfk_1` FOREIGN KEY (`purchases_id`) REFERENCES `purchases` (`purchases_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `purchase_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;

--
-- Constraints for table `push_notif_logs`
--
ALTER TABLE `push_notif_logs`
  ADD CONSTRAINT `push_notif_logs_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`payment_id`),
  ADD CONSTRAINT `push_notif_logs_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`);

--
-- Constraints for table `receipt_reprints`
--
ALTER TABLE `receipt_reprints`
  ADD CONSTRAINT `fk_receipt_reprints_sale` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_receipt_reprints_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `returns`
--
ALTER TABLE `returns`
  ADD CONSTRAINT `returns_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`),
  ADD CONSTRAINT `returns_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`);

--
-- Constraints for table `sales_forecast`
--
ALTER TABLE `sales_forecast`
  ADD CONSTRAINT `sales_forecast_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `sales_forecast_ibfk_2` FOREIGN KEY (`generated_by`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `sales_items`
--
ALTER TABLE `sales_items`
  ADD CONSTRAINT `sales_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`),
  ADD CONSTRAINT `sales_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `stock_condition`
--
ALTER TABLE `stock_condition`
  ADD CONSTRAINT `fk_stock_condition_adjusted_by` FOREIGN KEY (`adjusted_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_stock_condition_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `stock_condition_logs`
--
ALTER TABLE `stock_condition_logs`
  ADD CONSTRAINT `fk_scl_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_scl_user` FOREIGN KEY (`reported_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_stock_condition_logs_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_stock_condition_logs_reported_by` FOREIGN KEY (`reported_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `stock_settings`
--
ALTER TABLE `stock_settings`
  ADD CONSTRAINT `fk_stock_settings_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `supplier_payments`
--
ALTER TABLE `supplier_payments`
  ADD CONSTRAINT `sp_ap_fk` FOREIGN KEY (`ap_id`) REFERENCES `account_payable` (`ap_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sp_paid_by_fk` FOREIGN KEY (`paid_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `sp_supplier_fk` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`);

--
-- Constraints for table `user_email_otp_challenges`
--
ALTER TABLE `user_email_otp_challenges`
  ADD CONSTRAINT `fk_otp_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `user_trusted_devices`
--
ALTER TABLE `user_trusted_devices`
  ADD CONSTRAINT `fk_trusted_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
