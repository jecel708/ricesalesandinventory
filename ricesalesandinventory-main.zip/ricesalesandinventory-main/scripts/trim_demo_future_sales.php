<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "This cleanup script must be run from the command line.\n");
    exit(1);
}

require_once __DIR__ . '/../config/db.php';

$cutoff = '2026-09-01 23:59:59';
$conn->begin_transaction();

try {
    $ids = [];
    $stmt = $conn->prepare("
        SELECT sale_id
        FROM sales
        WHERE sale_id >= 160
          AND sale_date > ?
          AND sale_date < '2026-10-01 00:00:00'
          AND LOWER(status) = 'paid'
    ");
    $stmt->bind_param('s', $cutoff);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $ids[] = (int)$row['sale_id'];
    }
    $stmt->close();

    if ($ids) {
        $idList = implode(',', $ids);
        $conn->query("DELETE FROM sales_items WHERE sale_id IN ({$idList})");
        $conn->query("DELETE FROM sales WHERE sale_id IN ({$idList})");
    }

    $conn->commit();
    fwrite(STDOUT, 'Removed ' . count($ids) . " future demo sale(s).\n");
} catch (Throwable $e) {
    $conn->rollback();
    fwrite(STDERR, "Cleanup failed: {$e->getMessage()}\n");
    exit(1);
}
