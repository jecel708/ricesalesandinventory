<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "This seed script must be run from the command line.\n");
    exit(1);
}

require_once __DIR__ . '/../config/db.php';

$seedKey = 'demo_sales_2022_2026_v1';
$conn->begin_transaction();

try {
    $conn->query("
        CREATE TABLE IF NOT EXISTS demo_seed_runs (
            seed_key VARCHAR(100) NOT NULL PRIMARY KEY,
            inserted_sales INT NOT NULL DEFAULT 0,
            inserted_items INT NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $check = $conn->prepare('SELECT seed_key FROM demo_seed_runs WHERE seed_key = ? LIMIT 1');
    $check->bind_param('s', $seedKey);
    $check->execute();
    if ($check->get_result()->num_rows > 0) {
        $check->close();
        $conn->rollback();
        fwrite(STDOUT, "Demo sales are already seeded ({$seedKey}). No changes made.\n");
        exit(0);
    }
    $check->close();

    $products = [];
    $productResult = $conn->query("
        SELECT product_id, price_per_kg
        FROM products
        WHERE archived = 0
        ORDER BY product_id
        LIMIT 6
    ");
    while ($productResult && ($product = $productResult->fetch_assoc())) {
        $products[] = [
            'id' => (int)$product['product_id'],
            'price' => max(1.0, (float)$product['price_per_kg']),
        ];
    }

    if (!$products) {
        throw new RuntimeException('No active products were found. Add products before seeding demo sales.');
    }

    $userResult = $conn->query("
        SELECT user_id
        FROM users
        WHERE LOWER(role) IN ('admin', 'owner', 'cashier')
        ORDER BY CASE WHEN LOWER(role) = 'cashier' THEN 0 ELSE 1 END, user_id
        LIMIT 1
    ");
    $user = $userResult ? $userResult->fetch_assoc() : null;
    if (!$user) {
        throw new RuntimeException('No eligible user was found for the demo sales.');
    }
    $userId = (int)$user['user_id'];

    $saleStmt = $conn->prepare("
        INSERT INTO sales (user_id, customer_id, sale_date, total_amount, status, created_at)
        VALUES (?, NULL, ?, ?, 'paid', ?)
    ");
    $itemStmt = $conn->prepare("
        INSERT INTO sales_items
            (sale_id, product_id, batch_id, qty_kg, unit_price, line_total,
             unit_type, qty_input, discount_kg, regular_kg)
        VALUES (?, ?, NULL, ?, ?, ?, 'kg', ?, 0, ?)
    ");

    $insertedSales = 0;
    $insertedItems = 0;
    $start = new DateTimeImmutable('2022-01-01');
    // Keep demo history within the current date; future sales should not appear in reports.
    $end = new DateTimeImmutable('today');
    if ($end > new DateTimeImmutable('2026-09-01')) {
        $end = new DateTimeImmutable('2026-09-01');
    }
    $month = $start;
    $monthIndex = 0;

    while ($month <= $end) {
        $year = (int)$month->format('Y');
        $monthNumber = (int)$month->format('n');
        $daysInMonth = (int)$month->format('t');
        $season = 1.0 + (0.16 * sin(($monthNumber / 12) * 2 * M_PI));
        $growth = 1.0 + ($monthIndex * 0.012);

        for ($saleNumber = 0; $saleNumber < 3; $saleNumber++) {
            $saleDate = $month->setDate($year, $monthNumber, min(6 + ($saleNumber * 9), $daysInMonth))
                ->setTime(9 + $saleNumber, 15, 0)
                ->format('Y-m-d H:i:s');
            $total = 0.0;
            $saleItems = [];

            $productCount = min(count($products), 3);
            for ($offset = 0; $offset < $productCount; $offset++) {
                $product = $products[($monthIndex + $saleNumber + $offset) % count($products)];
                $qty = round((18 + (($monthIndex + $saleNumber + $offset) % 8) * 4) * $season * $growth, 2);
                $unitPrice = round($product['price'] * (1 + ($monthIndex * 0.004)), 2);
                $lineTotal = round($qty * $unitPrice, 2);
                $total += $lineTotal;
                $saleItems[] = [$product['id'], $qty, $unitPrice, $lineTotal];
            }

            $total = round($total, 2);
            $saleStmt->bind_param('isds', $userId, $saleDate, $total, $saleDate);
            $saleStmt->execute();
            $saleId = $saleStmt->insert_id;
            $insertedSales++;

            foreach ($saleItems as [$productId, $qty, $unitPrice, $lineTotal]) {
                $itemStmt->bind_param('iiddddd', $saleId, $productId, $qty, $unitPrice, $lineTotal, $qty, $qty);
                $itemStmt->execute();
                $insertedItems++;
            }
        }

        $month = $month->modify('+1 month');
        $monthIndex++;
    }

    $runStmt = $conn->prepare('INSERT INTO demo_seed_runs (seed_key, inserted_sales, inserted_items) VALUES (?, ?, ?)');
    $runStmt->bind_param('sii', $seedKey, $insertedSales, $insertedItems);
    $runStmt->execute();
    $runStmt->close();
    $saleStmt->close();
    $itemStmt->close();
    $conn->commit();

    fwrite(STDOUT, "Inserted {$insertedSales} demo sales and {$insertedItems} sales items from 2022-01 through 2026-09.\n");
} catch (Throwable $e) {
    $conn->rollback();
    fwrite(STDERR, "Seed failed: {$e->getMessage()}\n");
    exit(1);
}
