<?php
declare(strict_types=1);

header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');

$secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
session_set_cookie_params([
  'lifetime' => 0,
  'path' => '/',
  'secure' => $secure,
  'httponly' => true,
  'samesite' => 'Lax',
]);

session_start();
require_once 'config/db.php';
require_once 'includes/mfa.php';


function h(string $v): string {
  return htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
}

function otp_fail(string $msg): void {
  $_SESSION['otp_error'] = $msg;
  header('Location: verify_otp.php');
  exit;
}

function otp_redirect_target(string $role): string {
  $role = strtolower(trim($role));
  if ($role === 'admin') {
    return 'admin/dashboard.php';
  }
  if ($role === 'cashier') {
    return 'cashier/dashboard.php';
  }
  if ($role === 'owner') {
    return 'owner/dashboard.php';
  }

  return 'logout.php';
}

$showVerifiedState = isset($_SESSION['otp_verified_redirect']) && is_string($_SESSION['otp_verified_redirect']);

if (!$showVerifiedState && (!($_SESSION['mfa_pending'] ?? false) || !isset($_SESSION['preauth_user_id']))) {
  header('Location: login.php');
  exit;
}

if (empty($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$username = (string)($_SESSION['preauth_username'] ?? $_SESSION['username'] ?? 'User');

if ($showVerifiedState) {
  $userId = (int)($_SESSION['user_id'] ?? 0);
  $role = (string)($_SESSION['role'] ?? '');
  $rememberDevice = false;
} else {
  $userId = (int)$_SESSION['preauth_user_id'];
  $role = (string)($_SESSION['preauth_role'] ?? '');
  $rememberDevice = (bool)($_SESSION['preauth_remember_device'] ?? false);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $csrfPost = (string)($_POST['csrf_token'] ?? '');
  $csrfSess = (string)($_SESSION['csrf_token'] ?? '');
  if ($csrfPost === '' || $csrfSess === '' || !hash_equals($csrfSess, $csrfPost)) {
    otp_fail('Invalid request. Please refresh and try again.');
  }

  if (isset($_POST['resend_otp'])) {
    $lastSent = (int)($_SESSION['mfa_last_sent_at'] ?? 0);
    $elapsed = time() - $lastSent;
    if ($elapsed < 60) {
      $remain = 60 - $elapsed;
      otp_fail("Please wait {$remain} seconds before requesting a new OTP.");
    }

    $stmt = $conn->prepare('SELECT email FROM users WHERE user_id=? LIMIT 1');
    if (!$stmt) {
      otp_fail('Server error while preparing OTP resend.');
    }
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $email = trim((string)($row['email'] ?? ''));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
      otp_fail('No valid email found for this account.');
    }

    if (!mfa_send_otp_for_user($conn, $userId, $email)) {
      otp_fail('Unable to resend OTP right now.');
    }

    $_SESSION['mfa_last_sent_at'] = time();
    $_SESSION['otp_success'] = 'A new OTP has been sent to your email.';
    header('Location: verify_otp.php');
    exit;
  }

  $otp = trim((string)($_POST['otp'] ?? ''));
  if (!preg_match('/^[0-9]{6}$/', $otp)) {
    otp_fail('Enter a valid 6-digit OTP code.');
  }

  $stmt = $conn->prepare('SELECT id, otp_hash, expires_at, attempts, max_attempts, used_at FROM user_email_otp_challenges WHERE user_id=? ORDER BY id DESC LIMIT 1');
  if (!$stmt) {
    otp_fail('Server error while validating OTP.');
  }

  $stmt->bind_param('i', $userId);
  $stmt->execute();
  $challenge = $stmt->get_result()->fetch_assoc();
  $stmt->close();

  if (!$challenge) {
    otp_fail('No OTP challenge found. Please login again.');
  }

  if (!empty($challenge['used_at'])) {
    otp_fail('This OTP has already been used. Please request a new one.');
  }

  if (strtotime((string)$challenge['expires_at']) < time()) {
    otp_fail('OTP expired. Please request a new one.');
  }

  $attempts = (int)($challenge['attempts'] ?? 0);
  $maxAttempts = (int)($challenge['max_attempts'] ?? 5);
  if ($attempts >= $maxAttempts) {
    otp_fail('Too many attempts. Please request a new OTP.');
  }

  $isValid = password_verify($otp, (string)$challenge['otp_hash']);

  if (!$isValid) {
    $update = $conn->prepare('UPDATE user_email_otp_challenges SET attempts = attempts + 1 WHERE id=?');
    if ($update) {
      $cid = (int)$challenge['id'];
      $update->bind_param('i', $cid);
      $update->execute();
      $update->close();
    }

    $remaining = max(0, $maxAttempts - ($attempts + 1));
    otp_fail("Incorrect OTP. {$remaining} attempt(s) left.");
  }

  $mark = $conn->prepare('UPDATE user_email_otp_challenges SET used_at=NOW() WHERE id=?');
  if ($mark) {
    $cid = (int)$challenge['id'];
    $mark->bind_param('i', $cid);
    $mark->execute();
    $mark->close();
  }

  $userStmt = $conn->prepare('SELECT user_id, username, role, status FROM users WHERE user_id=? LIMIT 1');
  if (!$userStmt) {
    otp_fail('Server error while finalizing login.');
  }
  $userStmt->bind_param('i', $userId);
  $userStmt->execute();
  $user = $userStmt->get_result()->fetch_assoc();
  $userStmt->close();

  if (!$user || strtolower((string)($user['status'] ?? 'inactive')) !== 'active') {
    otp_fail('Account is not active. Please contact admin.');
  }

  session_regenerate_id(true);

  $_SESSION['user_id'] = (int)$user['user_id'];
  $_SESSION['username'] = (string)$user['username'];
  $_SESSION['role'] = (string)$user['role'];
  $_SESSION['mfa_verified'] = true;

  unset(
    $_SESSION['mfa_pending'],
    $_SESSION['preauth_user_id'],
    $_SESSION['preauth_role'],
    $_SESSION['preauth_username'],
    $_SESSION['preauth_remember_device'],
    $_SESSION['mfa_last_sent_at']
  );

  $device = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown Device';
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown IP';
  $logStmt = $conn->prepare('INSERT INTO login_logs (user_id, login_time, device_info, ip_address) VALUES (?, NOW(), ?, ?)');
  if ($logStmt) {
    $uid = (int)$user['user_id'];
    $logStmt->bind_param('iss', $uid, $device, $ip);
    $logStmt->execute();
    $logStmt->close();
  }

  $_SESSION['otp_verified_name'] = (string)$user['username'];
  $_SESSION['otp_verified_redirect'] = otp_redirect_target((string)$user['role']);
  header('Location: verify_otp.php?verified=1');
  exit;
}

$error = (string)($_SESSION['otp_error'] ?? '');
$success = (string)($_SESSION['otp_success'] ?? '');
unset($_SESSION['otp_error'], $_SESSION['otp_success']);

$lastSentAt = (int)($_SESSION['mfa_last_sent_at'] ?? 0);
$resendRemain = max(0, 60 - (time() - $lastSentAt));

$verifiedRedirect = (string)($_SESSION['otp_verified_redirect'] ?? '');
$verifiedName = (string)($_SESSION['otp_verified_name'] ?? $username);
$showVerifiedState = $verifiedRedirect !== '' && isset($_GET['verified']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Verify OTP | Rice Control System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="css/verify-otp.css?v=1" rel="stylesheet">
</head>
<body>
<div
  class="container otp-shell d-flex align-items-center py-4 py-lg-5"
  data-otp-shell="1"
  data-verified="<?= $showVerifiedState ? '1' : '0' ?>"
  data-redirect="<?= h($verifiedRedirect) ?>"
  data-resend-remain="<?= (int)$resendRemain ?>"
>
  <div class="row justify-content-center w-100">
    <div class="col-md-7 col-lg-5">
      <div class="otp-panel">
        <div class="otp-body">
          <?php if ($showVerifiedState): ?>
          <div class="otp-success-wrap">
            <div class="otp-success-circle">
              <div class="otp-success-check"></div>
            </div>
            <div class="otp-success-title">Verification Successful</div>
            <p class="otp-success-text">Welcome, <strong><?= h($verifiedName) ?></strong>. Redirecting you to your dashboard...</p>
            <div class="otp-progress"><div class="otp-progress-bar"></div></div>
          </div>
          <?php else: ?>
          <img src="assets/logo.jpg" alt="Rice Control logo" class="otp-logo">
          <div class="otp-title">Verify Your Identity</div>
          <p class="otp-subtitle">We've sent a verification code to <strong><?= h($username) ?></strong>.</p>

          <?php if ($success): ?>
            <div class="alert alert-success"><?= h($success) ?></div>
          <?php endif; ?>

          <?php if ($error): ?>
            <div class="alert alert-danger"><?= h($error) ?></div>
          <?php endif; ?>

          <form method="POST" action="verify_otp.php" class="mb-3">
            <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">
            <div class="mb-3">
              <input type="text" name="otp" id="otpInput" maxlength="6" pattern="[0-9]{6}" inputmode="numeric" autocomplete="one-time-code" class="form-control otp-input" placeholder="Enter the 6-digit code" required>
              <div class="otp-meta">
                <span><i class="fa-regular fa-clock me-1"></i>Valid for 5 minutes</span>
              </div>
            </div>
            <button type="submit" class="btn btn-primary otp-primary w-100">Continue</button>
          </form>

        <div class="text-center mt-3 otp-footer">
  <form method="POST" action="verify_otp.php">
    <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">

    <button
      type="submit"
      name="resend_otp"
      value="1"
      class="btn btn-outline-primary"
      <?= $resendRemain > 0 ? 'disabled' : '' ?>
    >
      <i class="fa-solid fa-rotate-right me-1"></i>
      <span id="resendBtnText">Resend Code</span>
      <span id="resendBtnCountdown" class="ms-1 <?= $resendRemain > 0 ? '' : 'd-none' ?>">(<?= (int)$resendRemain ?>s)</span>
    </button>
  </form>
  <div id="resendCountdownText" class="small text-muted mt-2">
    <?= $resendRemain > 0 ? 'You can resend in ' . (int)$resendRemain . ' second(s).' : 'You can resend a new OTP now.' ?>
  </div>
</div>
          <div class="text-center mt-3">
            <a href="logout.php" class="otp-footer-link">Cancel Login</a>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="js/verify-otp.js?v=1"></script>
</body>
</html>
