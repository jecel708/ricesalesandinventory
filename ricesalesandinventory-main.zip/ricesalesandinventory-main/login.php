<?php
declare(strict_types=1);

header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Permissions-Policy: geolocation=(), camera=(), microphone=()');

header(
  "Content-Security-Policy: ".
  "default-src 'self'; ".
  "img-src 'self' data:; ".
  "style-src 'self' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com 'unsafe-inline'; ".
  "script-src 'self' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com;"
);

ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');

$secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

session_set_cookie_params([
  'lifetime' => 0,
  'path' => '/',
  'secure' => $secure,
  'httponly' => true,
  'samesite' => 'Lax',
]);

session_start();

function h(string $v): string {
  return htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
}

function issueCaptcha(): void {
  $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  $captcha = '';
  $maxIndex = strlen($alphabet) - 1;

  for ($index = 0; $index < 6; $index++) {
    $captcha .= $alphabet[random_int(0, $maxIndex)];
  }

  $_SESSION['captcha_code'] = $captcha;
  $_SESSION['captcha_generated_at'] = time();
}

if (empty($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (
  empty($_SESSION['captcha_code']) ||
  !isset($_SESSION['captcha_generated_at']) ||
  (time() - (int)$_SESSION['captcha_generated_at']) > 300
) {
  issueCaptcha();
}

$error = $_SESSION['flash_error'] ?? '';
$success = $_SESSION['flash_success'] ?? '';
unset($_SESSION['flash_error'], $_SESSION['flash_success']);

if (isset($_SESSION['user_id']) && (($_SESSION['mfa_verified'] ?? false) === true)) {
  $role = strtolower((string)($_SESSION['role'] ?? ''));
  if ($role === 'admin') { header('Location: admin/dashboard.php'); exit; }
  if ($role === 'cashier') { header('Location: cashier/dashboard.php'); exit; }
  if ($role === 'owner') { header('Location: owner/dashboard.php'); exit; }
  header('Location: logout.php');
  exit;
}

if (($_SESSION['mfa_pending'] ?? false) === true) {
  header('Location: verify_otp.php');
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login | DE ORO HIYS </title>

<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#0f172a">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

<link href="css/login.css?v=5" rel="stylesheet">
</head>

<body>
<div class="container-fluid">
<div class="row min-vh-100">

  <div class="col-md-6 d-flex align-items-center login-column">
    <div class="w-100 px-3 px-md-5 panel-wrap">
      <div class="login-panel">

        <div class="brand-row mb-3">
          <img src="assets/logo.jpg" alt="Logo" class="brand-logo">
          <div class="brand-text">
            <strong>DE ORO HIYS</strong>
            <span>GENERAL MERCHANDISE</span>
          </div>
        </div>

        <h2 class="fw-bold mb-1">Welcome back!</h2>
        <p class="text-muted mb-5">Login to Rice Inventory System</p>

        <?php if ($success): ?>
          <div class="alert alert-success"><?= h((string)$success) ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
          <div class="alert alert-danger"><?= h((string)$error) ?></div>
        <?php endif; ?>

        <form method="POST" action="auth.php" class="needs-validation" novalidate id="loginForm">

          <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">

          <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" class="form-control" name="username" id="username" required autocomplete="username">
            <div class="invalid-feedback">Username required</div>
          </div>

          <div class="mb-3">
            <label class="form-label">Password</label>
            <div class="input-group">
              <input type="password" class="form-control" name="password" id="password" required autocomplete="current-password">
              <button type="button" class="input-group-text bg-white" id="togglePwdBtn">
                <i class="fa fa-eye" id="eyeIcon"></i>
              </button>
              <div class="invalid-feedback">Password required</div>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label">Security Check</label>
            <div class="captcha-box">
              <img
                src="captcha.php"
                alt="Captcha code"
                class="captcha-image"
                id="captchaImage"
                width="220"
                height="64"
              >
              <button type="button" class="btn btn-outline-secondary captcha-refresh" id="refreshCaptchaBtn">
                <i class="fa-solid fa-rotate-right"></i>
                Refresh
              </button>
            </div>
            <input
              type="text"
              class="form-control mt-3"
              name="captcha"
              id="captcha"
              inputmode="text"
              maxlength="6"
              autocomplete="off"
              required
              placeholder="Enter the 6-character code"
            >
            <div class="form-text">Captcha expires after 5 minutes.</div>
            <div class="invalid-feedback">Please enter the captcha code.</div>
          </div>

          <button type="submit" class="btn btn-dark w-100" id="loginBtn">Login</button>
        </form>

        <div class="text-end mt-2">
          <a href="forgot_password.php" class="small text-decoration-none">Forgot Password?</a>
        </div>

        <p class="security-note text-center mt-3 mb-0">
           Email OTP is required for every login.
        </p>

      </div>
    </div>
  </div>

  <div class="col-md-6 hero-image d-none d-md-block"></div>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/login.js?v=2"></script>
</body>
</html>
